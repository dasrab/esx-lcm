#!/bin/bash
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
set -eu
# ---------------------
# Run Python Unit tests
# ---------------------
ISM_RECIPES_LIB="./ism-recipes/lib"
ISM_RECIPES_PKG="./ism-recipes/lib/tests/brownfield_tests/"

decorate() {
    echo "---------------------------------------------------------"
    echo $@
    echo "---------------------------------------------------------"
}

decorate "Running unit test for ${ISM_RECIPES_LIB}"
#TODO need to fix no handlers error
nosetests --with-coverage --cover-erase --cover-package=${ISM_RECIPES_PKG} -v -w ${ISM_RECIPES_LIB}
