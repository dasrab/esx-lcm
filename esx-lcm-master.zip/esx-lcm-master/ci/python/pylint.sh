#!/bin/bash
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

set -eux
source /repo/ci/components

echo -e "\nPYTOOLS.SH/PYLINT: checking pylint\n"
IFS=","
for i in $PYTHON_COMPONENTS
do
    rm -f pylint-bad-files
    errors=`pylint --rcfile=/repo/ci/python/pylintrc /repo/$i | tee pylint-bad-files | grep -v '^$\|^-----|^Your code' pylint-bad-files | wc -l`
    if [[ $errors != "0" ]];
    then
        echo ""
        echo "PYLINT: FAILED: the following files are not formatted correctly:"
        echo ""
        cat pylint-bad-files
        exit 1
    fi
done
