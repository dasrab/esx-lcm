#!/bin/bash
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#
# Confidential computer software. Valid license from HPE required for
# possession, use or copying. Consistent with FAR 12.211 and 12.212,
# Commercial Computer Software, Computer Software Documentation, and
# Technical Data for Commercial Items are licensed to the U.S. Government
# under vendor's standard commercial license.
#

# Lint helm charts
docker run --rm -v $PWD:$PWD -w $PWD staging-docker.artifactory.zing.ncsre.hpcloud.net/arta/helm:0.0.0-dc598747306a85f2b47b4dba2f3528b4e138942d helm lint $(ls -d helm/*/)

# Build all images and charts specified in products.yml - they are later uploaded as artifacts on successful merge
gather.sh --debug --build-only artifacts.yaml
