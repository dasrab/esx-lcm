#!/bin/bash
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
set -eux
source /repo/ci/components
cp -R /repo /go/src/repo

set +x; echo -e "\nGOTOOLS.SH/GO FMT: checking go fmt\n"; set -x
IFS=","
for i in $GO_FMT_DIRS
do
    rm -Rf /go/src/repo/$i/vendor
    rm -f gofmt-bad-files
    errors=`gofmt -d /go/src/repo/$i | tee gofmt-bad-files |wc -l`
    if [[ $errors != "0" ]];
    then
        set +x
        echo ""
        echo "GO FMT: FAILED: the following files are not formatted correctly:"
        echo ""
        cat gofmt-bad-files
        exit 1
    fi
done
set +x; echo -e "GOTOOLS.SH/GO FMT: PASSED\n"; set -x

set +x; echo -e "\nGOTOOLS.SH/GO VET: checking go vet\n"; set -x
IFS=","
for i in $GO_VET_DIRS
do
    rm -Rf /go/src/repo/$i/vendor
    rm -f govet-bad-files
    errors=`go tool vet /go/src/repo/${i}/ 2>&1 | tee govet-bad-files | wc -l`
    if [[ $errors != "0" ]];
    then
        set +x
        echo ""
        echo "GO VET: FAILED: the following files failed go vet:"
        echo ""
        cat govet-bad-files
        exit 1
    fi
done
set +x; echo -e "GOTOOLS.SH/GO VET: PASSED\n"; set -x

