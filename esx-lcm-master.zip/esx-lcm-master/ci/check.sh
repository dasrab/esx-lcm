#!/bin/bash
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#
# Confidential computer software. Valid license from HP required for
# possession, use or copying. Consistent with FAR 12.211 and 12.212,
# Commercial Computer Software, Computer Software Documentation, and
# Technical Data for Commercial Items are licensed to the U.S. Government
# under vendor's standard commercial license.
#
set -eu

set +x; echo -e "\nCHECK.SH: PREPARATION\n"; set -x

source ci/components
MYSQL_IMAGE="hub.docker.hpecorp.net/ncs-vmware/mysql-esxlcm:latest"
MYSQL_CONTAINER_NAME=mysql-esx-lcm
GO_PACKAGE_PATH="/go/src/github.hpe.com/ncs-vmware/esx-lcm"

function atexit {
          set +x; echo -e "\nEND OF CHECK.SH\n"; set -x
          docker rm -f ${MYSQL_CONTAINER_NAME}

}
trap atexit EXIT
REPO_DIR="${REPO_DIR:-$(git rev-parse --show-toplevel 2>/dev/null)}"
docker build --build-arg http_proxy --build-arg https_proxy -t gitlint ${REPO_DIR}/ci/gitlint

set +x; echo -e "\nGITLINT: checking git commit message\n"; set -x
docker run -t --rm -v ${REPO_DIR}/:/repo gitlint --config ci/gitlint/config
set +x; echo -e "GITLINT: PASSED\n"; set -x

set +x; echo -e "\nGOLANG/GOTOOLS.SH: checking go fmt;go vet\n"; set -x
docker run --entrypoint /repo/ci/golang/gotools.sh -t --rm -v ${REPO_DIR}/:/repo golang:1.8.3
set +x; echo -e "GOLANG/GOTOOLS.SH: PASSED\n"; set -x

## Need to start database container which needed for go test
docker run --name ${MYSQL_CONTAINER_NAME} -d -p 3306:3306 $MYSQL_IMAGE
sleep 5
DB_IP_ADDR=$(docker inspect --format '{{ .NetworkSettings.IPAddress }}' $(docker ps --filter name=${MYSQL_CONTAINER_NAME} -q))

## Update ism/ism.properties with latest MYSQL Container IP Address.
sed "s/Host = 127.0.0.1/Host = ${DB_IP_ADDR}/g" -i ${REPO_DIR}/ism/ism.properties

## Disable security manager for unit tests
sed "s/Enabled = true/Enabled = false/g" -i ${REPO_DIR}/ism/ism.properties

## To run go test we need a esx-lcm containers with all dependencies installed.
set +x; echo -e "\nBuild container for esx-lcm go test\n"; set -x
CI_ESX_LCM_NAME="ci-esx-lcm-unit_test"
docker build -f ${REPO_DIR}/ci/golang/Dockerfile --build-arg http_proxy --build-arg https_proxy -t ${CI_ESX_LCM_NAME} .
docker run -e http_proxy -e https_proxy -w ${GO_PACKAGE_PATH}/ism -t --rm -v ${REPO_DIR}:${GO_PACKAGE_PATH} ${CI_ESX_LCM_NAME} sh -c 'glide install'
set +x; echo -e "\nBuild container for esx-lcm go test: Completed\n"; set -x

set +x; echo -e "\nchecking go test\n"; set -x
docker run -t --rm -v ${REPO_DIR}:${GO_PACKAGE_PATH} ${CI_ESX_LCM_NAME} sh -c 'sh /go/src/github.hpe.com/ncs-vmware/esx-lcm/ism/unit_test.sh'
set +x; echo -e "\ngo test: PASSED\n"; set -x


## To run python unit test we containers with all dependencies installed.
set +x; echo -e "\nBuild container for esx-lcm python unit test\n"; set -x
docker build -f ${REPO_DIR}/ci/python/Dockerfile --build-arg http_proxy --build-arg https_proxy -t ci-py27 .
set +x; echo -e "\nBuild container for esx-lcm python unit test: Completed\n"; set -x

set +x; echo -e "\nRunning Pylint\n"; set -x
docker run -t --rm -v ${REPO_DIR}/:/repo ci-py27 sh -c "/bin/pylint.sh"
set +x; echo -e "\nPylint: PASSED\n"; set -x

set +x; echo -e "\nRunning Python Unit tests\n"; set -x
docker run -t --rm -v ${REPO_DIR}/:/repo ci-py27 bash -c "ci/python/pyunit_tests.sh"
set +x; echo -e "\nPython Unit tests: PASSED\n"; set -x

docker run --rm -v $PWD:$PWD -w $PWD staging-docker.artifactory.zing.ncsre.hpcloud.net/arta/helm:0.0.0-dc598747306a85f2b47b4dba2f3528b4e138942d helm lint $(ls -d helm/*/)
