# esx-lcm
---
Life cycle manager of NCS VMware Cloud Platform. 

#### Components of esx-lcm services

##### ism
Infrastructure System Manager written in GO

##### ism-recipes
Custom version ansible playbooks and python modules. 

##### ism-lib
Custom libraries for ism-recipes to connect Oneview, vCenter etc.

##### helm
Charts and config file used for kubernetes deployment

# Development Setup
See: [Dev Document](dev/README.md)

## ESX LCM Docker image Build

`docker build -f Dockerfile -t esx-lcm:devtest .`

If issue in the proxy use below 
`docker build -f Dockerfile -t esx-lcm:devtest --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy --build-arg no_proxy=$no_proxy .`

-------------------------------------------------------------

