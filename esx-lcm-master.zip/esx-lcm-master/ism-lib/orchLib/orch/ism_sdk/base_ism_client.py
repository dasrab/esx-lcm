# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import sys
import time

from activity import Ism_Error
from base_http_client import BaseHTTPClient
from ..log import getLogger


class BaseISMClient(BaseHTTPClient):

    def __init__(self, private_request):
        self.private_request = private_request
        self.LOG = getLogger(__name__)
        self.LOG.debug('private_request = ' + str(self.private_request))
        if private_request is None:
            self.LOG.error('Private request object missing for ISM SDK.')
            raise Ism_Error("HCOE_ISM_SDK_MISSING_PRIVATE_REQUEST",
                            "Private request object missing for ISM SDK.")
        if not private_request.hostname:
            self.LOG.error('Hostname not provided to ISM SDK.')
            raise Ism_Error("HCOE_ISM_SDK_MISSING_HOSTNAME",
                            "Hostname not provided to ISM SDK.")
        BaseHTTPClient.__init__(self)

    def create(self, uri, payload):
        return self._post(self.private_request.hostname +
                          uri, payload, headers=self.private_request.headers)

    def update(self, uri, payload):
        return self._put(self.private_request.hostname +
                         uri, payload, headers=self.private_request.headers)

    def patch(self, uri, payload=''):
        return self._patch(self.private_request.hostname +
                           uri, payload, headers=self.private_request.headers)

    def get(self, uri, query_expression=''):
        query_string = ''

        if query_expression and query_expression != '':
            query_string = '?query=' + query_expression

        return self._get(
            self.private_request.hostname + uri + query_string,
            headers=self.private_request.headers)['members']

    def get_by_id(self, uri, uuid):
        return self._get(
            self.private_request.hostname + uri + uuid,
            headers=self.private_request.headers)

    def get_by_resource_uri(self, uri):
        return self._get(
            self.private_request.hostname + uri,
            headers=self.private_request.headers)

    def delete(self, uri):
        return self._delete(
            self.private_request.hostname + uri,
            headers=self.private_request.headers)

    def wait4task(self, task, tout=60, verbose=False):
        count = 0
        if task is None:
            return None
        while self.is_task_running(task):
            if verbose:
                sys.stdout.write('Task still running after %d seconds   \r'
                                 % count)
                sys.stdout.flush()
            time.sleep(1)
            count += 1
            if count > tout:
                refreshed_task = self.get_by_resource_uri(task['uri'])
                raise Exception(
                    'Waited {} seconds for task {} to complete, aborting!'.format(
                        str(tout), str(refreshed_task)))
        return None

    def is_task_running(self, task):
        resource = self.get_by_resource_uri(task['uri'])
        return str(resource['state']).lower() != 'completed'

    @staticmethod
    def make_associated_resource(resource_type=None, resource_uri=None):
        return {"resourceType": resource_type, "resourceUri": resource_uri}
