# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
import httplib as http

RETRY_MAX_TIMES = 9
RETRY_BACKOFF_FACTOR_SECS = 0.5
RETRY_STATUS_FORCELIST = [
    http.INTERNAL_SERVER_ERROR,
    http.BAD_GATEWAY,
    http.SERVICE_UNAVAILABLE,
    http.GATEWAY_TIMEOUT]

TASK_URI = '/rest/tasks'
