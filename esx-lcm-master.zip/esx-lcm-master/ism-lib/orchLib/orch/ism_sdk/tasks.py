# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.ism_sdk.base_ism_client import BaseISMClient
from orch.ism_sdk.constants import TASK_URI


class Tasks(BaseISMClient):

    def get_task(self, uuid):
        return BaseISMClient.get_by_id(self, TASK_URI + '/', uuid)

    def complete_task(self, uuid):
        return self.update_task(uuid, 100, 'Completed')

    def update_task(self, uuid, progress, state=None):
        task = self.get_task(uuid)
        if state is not None:
            task['state'] = state
        task['percentComplete'] = int(progress)
        return self.update(task['uri'], task)
