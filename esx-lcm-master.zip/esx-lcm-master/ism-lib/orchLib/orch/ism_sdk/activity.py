# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP


class Ism_Error(Exception):
    def __init__(
            self,
            error_code,
            error_msg="",
            details="",
            nested_errors=[],
            recommended_actions=[],
            data=None,
            can_force=False):
        super(Ism_Error, self).__init__(error_code)
        self.error_code = error_code
        self.error_msg = error_msg
        self.details = details
        self.error_source = "Orchestration"
        self.nested_errors = self.handle_nested_errors(nested_errors)
        self.recommended_actions = recommended_actions
        self.data = data
        self.can_force = can_force

    def handle_nested_errors(self, input_errors):
        nested_errors = []
        for input_error in input_errors:
            if isinstance(input_error, Ism_Error):
                nested_errors += [input_error]
            # TODO: We should be able to handle OneViewExceptions
            else:
                nested_errors += [
                    Ism_Error(
                        error_code="HCOE_ISM_EXECUTION_ERROR",
                        details=str(input_error))]
        return nested_errors

    def to_dict(self):
        nested_dict = []
        for err in self.nested_errors:
            nested_dict.append(err.to_dict())

        return {
            "message": self.error_code + '_MSG',
            "details": self.details,
            "recommendedActions": self.recommended_actions,
            "nestedErrors": nested_dict,
            "errorSource": self.error_source,
            "errorCode": self.error_code,
            "data": self.data,
            "canForce": self.can_force
        }

    def to_error(self):
        err = self.to_dict()
        err['message'] = self.error_msg
        return err

    @staticmethod
    def is_ism_error(input_dict):
        return input_dict.viewkeys() == set(["message",
                                             "details",
                                             "recommendedActions",
                                             "nestedErrors",
                                             "errorSource",
                                             "errorCode",
                                             "data",
                                             "canForce"])


class IsmErrorHandler(object):
    """
        ISM Error Decorator and Context
    """

    def get_associated_details(self, main_exception):
        # If it's an exception, it has a 'message' field
        e = main_exception.message

        # OV Exception has sub-fields 'message' and 'errorCode'
        if 'message' in e and 'errorCode' in e:
            details = e['message']
        else:
            details = str(main_exception)
        return details

    def __init__(self, code, data=None):
        self.code = code
        if data:
            self.data = data if isinstance(data, list) else [data]
        else:
            self.data = None

    def __call__(self, f):
        def wrapped_f(*args, **kwargs):
            try:
                return f(*args, **kwargs)
            except Ism_Error as ism_e:
                raise Ism_Error(error_code=self.code,
                                data=self.data, nested_errors=[ism_e])
            except Exception as e:
                details = self.get_associated_details(e)
                raise Ism_Error(error_code=self.code,
                                details=details, data=self.data)
        return wrapped_f

    def __enter__(self):
        pass

    def __exit__(self, *args):
        if args[0]:
            if isinstance(args[1], Ism_Error):
                raise Ism_Error(error_code=self.code,
                                data=self.data, nested_errors=[args[1]])
            elif isinstance(args[1], Exception):
                details = self.get_associated_details(args[1])
                raise Ism_Error(error_code=self.code,
                                details=details, data=self.data)
