# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import json
import constants
import requests

from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class BaseHTTPClient:

    def __init__(self, cert=None, key=None):
        adapter = HTTPAdapter()
        adapter.max_retries = Retry(
            total=constants.RETRY_MAX_TIMES,
            backoff_factor=constants.RETRY_BACKOFF_FACTOR_SECS,
            status_forcelist=constants.RETRY_STATUS_FORCELIST,
        )
        self.session = requests.Session()
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
        self.cert = (cert, key) if cert and key else None

    def _get(self, full_http_request, headers=None):
        return self.__do_request(self.session.get,
                                 url=full_http_request,
                                 headers=headers,
                                 cert=self.cert,
                                 verify=False)

    def _delete(self, full_http_request, headers=None):
        return self.__do_request(self.session.delete,
                                 url=full_http_request,
                                 headers=headers,
                                 cert=self.cert,
                                 verify=False)

    def _post(self, full_http_request, payload, headers=None):
        data = self.__dump(full_http_request, payload)
        return self.__do_request(self.session.post,
                                 url=full_http_request,
                                 headers=headers,
                                 data=data,
                                 cert=self.cert,
                                 verify=False)

    def _put(self, full_http_request, payload, headers=None):
        data = self.__dump(full_http_request, payload)
        return self.__do_request(self.session.put,
                                 url=full_http_request,
                                 headers=headers,
                                 data=data,
                                 cert=self.cert,
                                 verify=False)

    def _patch(self, full_http_request, payload, headers=None):
        data = self.__dump(full_http_request, payload)
        return self.__do_request(self.session.patch,
                                 url=full_http_request,
                                 headers=headers,
                                 data=data,
                                 cert=self.cert,
                                 verify=False)

    def __do_request(self, req, url, **kwargs):
        r = req(url, **kwargs)
        r.raise_for_status()
        return self.__json(r)

    @staticmethod
    def __json(request):
        try:
            resource = request.json()
        except Exception as e:
            raise Exception(
                "Could not decode response of '{}' from {} ({})".format(
                    request.content, request.url, e))
        return resource

    @staticmethod
    def __dump(full_http_request, payload):
        try:
            data = json.dumps(payload)
        except Exception as e:
            raise Exception("Could not decode payload '{}' at {} ({})".format(
                payload, full_http_request, e))
        return data
