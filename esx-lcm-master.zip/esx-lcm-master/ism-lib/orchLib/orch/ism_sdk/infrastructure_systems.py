# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

from base_ism_client import BaseISMClient

# Constants
INFRASTRUCTURE_SYSTEM_URI = '/rest/infrastructure-systems'

# timeouts in hours
DEPLOY_TIMEOUT = 8 * 60 * 60
RECONFIGURE_TIMEOUT = 2 * 60 * 60


class InfrastructureSystems(BaseISMClient):

    def create_infrastructure_system(
            self,
            name,
            blocking=True,
            extraPayloadArgs=None):

        payload = {
            'name': name,
        }

        if extraPayloadArgs:
            for keys in extraPayloadArgs:
                payload[keys] = extraPayloadArgs[keys]

        self.LOG.info("Payload for create resource %s" % str(payload))

        _task = self.create(uri=INFRASTRUCTURE_SYSTEM_URI, payload=payload)

        if blocking:
            _task = self.wait4task(_task)

        return _task

    def get_all_infrastructure_systems(self, query_expression=''):
        return self.get(INFRASTRUCTURE_SYSTEM_URI, query_expression)

    def delete_infrastructure_system(self, uri):
        return self.delete(uri)

    def update_infrastructure_system(self, uri, payload):
        return self.patch(uri, payload)
