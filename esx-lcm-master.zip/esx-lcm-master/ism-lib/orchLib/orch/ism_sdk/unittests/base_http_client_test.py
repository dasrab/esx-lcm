#!/usr/bin/env python
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
from __future__ import absolute_import
from ..base_http_client import BaseHTTPClient

import httplib
import unittest
import mock
import requests
import requests.adapters
import requests_mock


class BaseHTTPClientTest(unittest.TestCase):

    class MockHTTPResponse(httplib.HTTPResponse):

        def __init__(self, status):
            httplib.HTTPResponse.__init__(self, sock=mock.MagicMock())
            self.fp = None
            self.msg = mock.MagicMock()
            self.status = status

    client = BaseHTTPClient()

    def test_get_json(self):
        with requests_mock.mock() as m:
            m.get('https://test.com', json='data')
            v = self.client._get('https://test.com')
            self.assertEqual(v, 'data')

    def test_get_error_404(self):
        with requests_mock.mock() as m:
            m.get('https://test.com', status_code=httplib.NOT_FOUND)
            with self.assertRaises(requests.HTTPError):
                self.client._get('https://test.com')

    def test_get_error_501(self):
        with requests_mock.mock() as m:
            m.get('https://test.com', status_code=httplib.NOT_IMPLEMENTED)
            with self.assertRaises(requests.HTTPError):
                self.client._get('https://test.com')

    def test_post(self):
        with requests_mock.mock() as m:
            m.post('https://test.com', json='data')
            v = self.client._post('https://test.com', payload={})
            self.assertEqual(v, 'data')

    def test_put(self):
        with requests_mock.mock() as m:
            m.put('https://test.com', json='data')
            v = self.client._put('https://test.com', payload={})
            self.assertEqual(v, 'data')

    def test_delete(self):
        with requests_mock.mock() as m:
            m.delete('https://test.com', json='data')
            self.client._delete('https://test.com')

    # requests_mock does not support testing the retry operation, because it overrides the Adapter, which contains the
    # Retry information. Instead, we will have to mock the lower-level _make_request function, so we can verify that a
    # retry is happening (requests.adapters.RetryError) without requiring to
    # connect to the internet.

    @mock.patch('time.sleep')
    @mock.patch(
        'requests.packages.urllib3.connectionpool.HTTPConnectionPool._make_request')
    def test_get_http_retries(self, make_request, sleep):
        sleep.side_effect = None
        self.assert_retry_error(
            'http://test.com', make_request, httplib.INTERNAL_SERVER_ERROR)
        self.assert_retry_error(
            'http://test.com', make_request, httplib.GATEWAY_TIMEOUT)
        self.assert_retry_error(
            'http://test.com', make_request, httplib.BAD_GATEWAY)
        self.assert_retry_error(
            'http://test.com', make_request, httplib.SERVICE_UNAVAILABLE)

    @mock.patch('time.sleep')
    @mock.patch(
        'requests.packages.urllib3.connectionpool.HTTPConnectionPool._make_request')
    @mock.patch(
        'requests.packages.urllib3.connectionpool.HTTPSConnectionPool._prepare_proxy')
    def test_get_https_retries(self, proxy, make_request, sleep):
        sleep.side_effect = None
        proxy.side_effect = None
        self.assert_retry_error(
            'https://test.com', make_request, httplib.INTERNAL_SERVER_ERROR)
        self.assert_retry_error(
            'https://test.com', make_request, httplib.GATEWAY_TIMEOUT)
        self.assert_retry_error(
            'https://test.com', make_request, httplib.BAD_GATEWAY)
        self.assert_retry_error(
            'https://test.com', make_request, httplib.SERVICE_UNAVAILABLE)

    def assert_retry_error(self, url, request, status):
        call_count_before = request.call_count
        with self.assertRaises(requests.adapters.RetryError):
            request.return_value = self.MockHTTPResponse(status)
            self.client._get(url)
            self.assertEqual(10, request.call_count - call_count_before)

    # The test below requires internet connection!
    @unittest.skip(
        'test_get_internet_retries skipped: this takes a while! Use it to manually validate client retry.')
    def test_get_internet_retries(self):
        with self.assertRaises(requests.adapters.RetryError):
            self.client._get('http://httpstat.us/500')
