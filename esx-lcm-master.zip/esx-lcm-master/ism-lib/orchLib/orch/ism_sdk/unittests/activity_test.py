# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from __future__ import absolute_import
from ..activity import Ism_Error, IsmErrorHandler

import unittest


class TestIsmErrorHandler(unittest.TestCase):

    def _test_raise_exception(self, f):

        with self.assertRaises(Ism_Error) as ismError:
            f()

        ism_err = ismError.exception
        self.assertEqual('HCOE_ERROR', ism_err.error_code)
        self.assertEqual('details', ism_err.data[0])
        self.assertEqual('ab', ism_err.details)
        self.assertEqual(len(ism_err.nested_errors), 0)

    def _test_raise_ism_error(self, f):

        with self.assertRaises(Ism_Error) as ismError:
            f()

        ism_err = ismError.exception
        self.assertEqual('HCOE_ERROR', ism_err.error_code)
        self.assertEqual('details', ism_err.data[0])
        self.assertEqual(len(ism_err.nested_errors), 1)
        self.assertEqual(ism_err.nested_errors[0].error_code, 'HCOE_ISM_TEST')
        self.assertEqual(ism_err.nested_errors[0].details, 'ab')

    def test_context(self):

        def raise_exception_from_context():
            with IsmErrorHandler('HCOE_ERROR', 'details'):
                raise Exception('ab')

        self._test_raise_exception(raise_exception_from_context)

        def raise_ism_error_from_context():
            with IsmErrorHandler('HCOE_ERROR', 'details'):
                raise Ism_Error(error_code='HCOE_ISM_TEST', details="ab")

        self._test_raise_ism_error(raise_ism_error_from_context)

    def test_decorator(self):

        @IsmErrorHandler('HCOE_ERROR', 'details')
        def raise_exception_from_decorator():
            raise Exception('ab')

        self._test_raise_exception(raise_exception_from_decorator)

        @IsmErrorHandler('HCOE_ERROR', 'details')
        def raise_ism_error_from_decorator():
            raise Ism_Error(error_code='HCOE_ISM_TEST', details="ab")

        self._test_raise_ism_error(raise_ism_error_from_decorator)


if __name__ == '__main__':
    unittest.main()
