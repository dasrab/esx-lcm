#!/usr/bin/env python
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.ism_sdk.activity import Ism_Error


def _new_validation_error(nested_err):
    return Ism_Error(
        error_code='HCOE_ISM_PARAMETER_VALIDATION_ERROR',
        nested_errors=[nested_err])


def validate_not_empty(keys):
    def f_wrapper(f):
        def valid_wrapper(*args, **kwargs):
            params = args[1]
            _keys = keys if isinstance(keys, list) else [keys]
            for key in _keys:
                if key not in params:
                    raise _new_validation_error(
                        Ism_Error('HCOE_ISM_MISSING_PARAMETER', details=key))
                v = params.get(key, None)
                if v is None:
                    raise _new_validation_error(
                        Ism_Error('HCOE_ISM_EMPTY_PARAMETER', details=key))
                if (isinstance(v, str) or isinstance(v, dict)
                        or isinstance(v, list)) and (len(v) == 0):
                    raise _new_validation_error(
                        Ism_Error('HCOE_ISM_EMPTY_PARAMETER', details=key))
            return f(*args, **kwargs)
        return valid_wrapper
    return f_wrapper


def validate_contains(key, values):
    def f_wrapper(f):
        def valid_wrapper(*args, **kwargs):
            params = args[1]
            _values = values if isinstance(values, list) else [values]
            for v in _values:
                if v not in params[key]:
                    raise _new_validation_error(
                        Ism_Error(
                            'HCOE_ISM_MISSING_PARAMETER', details='%s does not contain %s' %
                            (key, v)))
            return f(*args, **kwargs)
        return valid_wrapper
    return f_wrapper


def validate_len(key, size):
    def f_wrapper(f):
        def valid_wrapper(*args, **kwargs):
            params = args[1]
            val = params[key]
            if not isinstance(val, list):
                raise _new_validation_error(
                    Ism_Error(
                        'HCOE_ISM_INVALID_TYPE_ERROR',
                        details='%s is not a list' %
                        key))
            if len(val) != size:
                raise _new_validation_error(
                    Ism_Error(
                        'HCOE_ISM_INVALID_LENGTH_ERROR',
                        details='%s actual length is %d, but expected is %d' %
                        (key,
                         len(val),
                         size)))
            return f(*args, **kwargs)
        return valid_wrapper
    return f_wrapper


def custom_validation(key, valid_f):
    def f_wrapper(f):
        def valid_wrapper(*args, **kwargs):
            param = args[1][key]
            err = valid_f(param)
            if err:
                raise _new_validation_error(err)
            return f(*args, **kwargs)
        return valid_wrapper
    return f_wrapper
