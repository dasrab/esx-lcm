#!/usr/bin/env python
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import requests

CONNECTION_URI = '/rest/zones/{}/connections'
UUID_QUERY = '?query=uuid=={}'


class ZoneController:

    def __init__(self, private_request):
        self.private_request = private_request

    def get(self, zone_id, zone_ctrl_id):
        zone_ctrl_uri = '/'.join(
            [CONNECTION_URI.format(zone_id), zone_ctrl_id])
        full_http_request = ''.join(
            [self.private_request.hostname, zone_ctrl_uri]
        )
        r = requests.get(
            full_http_request,
            headers=self.private_request.headers)
        zone_ctrl = r.json()

        if not zone_ctrl:
            raise Exception("ZoneController settings not found for id='{}'"
                            .format(zone_ctrl_id))

        return zone_ctrl

    def get_by_uuid(self, zone_id, zone_ctrl_uuid):
        zonr_ctrl_uri = ''.join(
            [CONNECTION_URI.format(zone_id),
             UUID_QUERY.format(zone_ctrl_uuid)])
        full_http_request = ''.join(
            [self.private_request.hostname, zonr_ctrl_uri]
        )
        r = requests.get(
            full_http_request,
            headers=self.private_request.headers)
        zone_ctrls = r.json()['members']
        if zone_ctrls:
            return zone_ctrls[0]
