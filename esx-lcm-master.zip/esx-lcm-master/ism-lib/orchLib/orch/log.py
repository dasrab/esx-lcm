# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import logging
import logging.config
import sys

g_level = None
g_playbook = None

DATE_FMT = '%Y-%m-%dT%H:%M:%S'
LOGGER_FMT = '{"@timestamp": "%(asctime)s" ,"context": "%(filename)s:%(lineno)d" ,"level": "%(levelname)s","msg": "%(message)s"}'
LOGGER_FMT_PLAYBOOK = '{"@timestamp": "%(asctime)s" ,"context": "[%(playbook)s] %(filename)s:%(lineno)d" ,"level": "%(levelname)s","msg": "%(message)s"}'
#LOGGER_FMT = '%(levelname)s: %(asctime)s [%(threadName)s] %(filename)s:%(lineno)d: %(message)s'
#LOGGER_FMT_PLAYBOOK = '%(levelname)s: %(asctime)s [%(threadName)s] [%(playbook)s] %(filename)s:%(lineno)d: %(message)s'

PLAYBOOK_HANDLER = logging.StreamHandler(sys.stdout)
PLAYBOOK_HANDLER.setFormatter(logging.Formatter(LOGGER_FMT_PLAYBOOK, DATE_FMT))


class CustomAdapter(logging.LoggerAdapter):

    def __init__(self, logger, extra):
        super(CustomAdapter, self).__init__(logger, extra)

    def warn(self, msg, *args, **kwargs):
        super(CustomAdapter, self).warning(msg, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        super(CustomAdapter, self).critical(msg, *args, **kwargs)

    def setLevel(self, level):
        self.logger.setLevel(level)

    def addHandler(self, hdlr):
        self.logger.addHandler(hdlr)


def setup(
        conf_file=None,
        log_file=None,
        log_level=logging.WARN,
        log_format=LOGGER_FMT,
        disable=False):

    if conf_file:
        logging.config.fileConfig(conf_file)
    else:
        logging.basicConfig(filename=log_file, level=log_level,
                            format=log_format, datefmt=DATE_FMT)

    if disable:
        logging.disable(logging.CRITICAL)


def setLevel(level):
    global g_level
    g_level = level.upper()


def setPlaybook(playbook):
    global g_playbook
    g_playbook = playbook


def getLogger(name):
    """Returns a logger instance

    Args:
        name: Name of the calling module

    """
    logger = logging.getLogger(name)
    logger.propagate = 0

    if g_level:
        logger.setLevel(g_level.upper())

    if g_playbook:
        if PLAYBOOK_HANDLER not in logger.handlers:
            logger.addHandler(PLAYBOOK_HANDLER)
        return CustomAdapter(logger, {"playbook": g_playbook})
    else:
        return logger
