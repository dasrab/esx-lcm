#!/usr/bin/env python
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import log

HOST = 'https://localhost:8083'


class PrivateRequest:

    def __init__(self, hostname=HOST):
        self.LOG = log.getLogger(__name__)
        self.hostname = hostname
        self.headers = None

    def __str__(self):
        if self.is_valid():
            # Omit headers from logs
            return "hostname: {}\nheaders: *************".format(self.hostname)
        else:
            return "hostname: {}\nheaders: {}".format(self.hostname, self.headers)

    def is_valid(self):
        return self.headers is not None and self.headers != ""
