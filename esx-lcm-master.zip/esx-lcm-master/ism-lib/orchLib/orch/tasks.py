#!/usr/bin/env python
# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP

import logging
import json
import time
import requests

from orch.ism_sdk.constants import TASK_URI


class Task:

    def __init__(self, parent, name, private_request):
        logging.getLogger('requests').setLevel(logging.CRITICAL)
        logging.getLogger("urllib3").setLevel(logging.CRITICAL)
        self.name = name
        self.parent = parent
        self.private_request = private_request
        payload = {'name': name, 'parentId': parent}
        r = requests.post(
            self.private_request.hostname +
            TASK_URI,
            headers=self.private_request.headers,
            data=json.dumps(payload))
        self.id = r.json()['uuid']

    def update(
            self,
            progress,
            state,
            status,
            progress_status=None,
            error=None):
        payload = self.get()
        if progress_status is not None:
            if payload['progressUpdates'] is not None:
                payload['progressUpdates'].append(progress_status)
            else:
                payload['progressUpdates'] = [progress_status]
        payload['percentComplete'] = progress
        payload['state'] = state
        payload['status'] = status
        if error is not None:
            payload['error'] = error.to_dict()

        r = requests.put(
            self.private_request.hostname + TASK_URI + '/' + str(
                self.id),
            headers=self.private_request.headers,
            data=json.dumps(payload))
        return r.json()

    def update_resource_uri(self, resource_uri):
        payload = self.get()
        payload['associatedResourceInstanceUri'] = resource_uri

        r = requests.put(
            self.private_request.hostname + TASK_URI + '/' + str(
                self.id),
            headers=self.private_request.headers,
            data=json.dumps(payload))
        return r.json()

    def complete(self, status, error=None):
        return self.update(100, 'Completed', status, error=error)

    def get(self, value=None):
        r = requests.get(
            self.private_request.hostname + TASK_URI + '/' + str(
                self.id), headers=self.private_request.headers)
        if value:
            return r.json()[value]
        return r.json()


class Parent_Task:

    def __init__(self, private_request, task_uri):
        logging.getLogger('requests').setLevel(logging.CRITICAL)
        logging.getLogger("urllib3").setLevel(logging.CRITICAL)
        self.private_request = private_request
        self.task_uri = task_uri

    def get_task(self):
        r = requests.get(
            self.private_request.hostname +
            self.task_uri,
            headers=self.private_request.headers)
        return r.json()

    def update_task(self, progress, progress_status=None):
        payload = self.get_task()
        payload['percentComplete'] = progress
        if progress_status is not None:
            if payload['progressUpdates'] is not None:
                payload['progressUpdates'].append(progress_status)
            else:
                payload['progressUpdates'] = [progress_status]

        r = requests.put(
            self.private_request.hostname + self.task_uri,
            headers=self.private_request.headers,
            data=json.dumps(payload))
        return r.json()


class Task_Waiter:

    def __init__(self, private_request):
        logging.getLogger('requests').setLevel(logging.CRITICAL)
        logging.getLogger("urllib3").setLevel(logging.CRITICAL)
        self.private_request = private_request

    def get_task(self, task_uri):
        r = requests.get(
            self.private_request.hostname +
            task_uri,
            headers=self.private_request.headers)
        return r.json()

    def wait_task(self, task_uri, timeout=30):
        for i in range(timeout):
            task = self.get_task(task_uri)
            if str(task['state']).lower() == 'completed':
                return task
            time.sleep(1)
        raise "Task "
