#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import json
import requests

ZONE_ENVIRONMENT_URI = '/rest/zone-environment'
URL_QUERY = '?query=associatedZoneURI=='
ZONE_URI = '/rest/zones'


class ZoneEnvironment:

    def __init__(self, private_request):
        self.private_request = private_request

    def update_sptblueprintUris(self, zone_uuid, sptblueprinturis):
        zone_uri = ZONE_URI + "/%s" % zone_uuid
        zone_environment = self.get(zone_uri)
        zone_environment_uri = zone_environment['uri']
        payload = [{"op": "replace",
                    "path": "/sptBlueprintURIs",
                    "value": sptblueprinturis}]
        try:
            requests.patch(
                self.private_request.hostname +
                zone_environment_uri,
                headers=self.private_request.headers,
                data=json.dumps(payload))
        except requests.HTTPError as e:
            raise e

    def get(self, zone_uri):
        full_http_request = self.private_request.hostname + \
            ZONE_ENVIRONMENT_URI + URL_QUERY + str(zone_uri)
        r = requests.get(
            full_http_request,
            headers=self.private_request.headers)
        members = r.json()['members']

        if not members:
            raise Exception("Settings not found for " + zone_uri)

        return members[0]

    def delete(self, zone_uri):
        zone_env = self.get(zone_uri)
        full_http_request = self.private_request.hostname + \
            ZONE_ENVIRONMENT_URI + "/" + str(zone_env['uuid'])
        requests.delete(
            full_http_request,
            headers=self.private_request.headers)
        return None
