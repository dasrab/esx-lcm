#!/usr/bin/env python
# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP

import copy
import datetime
import json
import log
import re
import traceback

from orch.tasks import Parent_Task
from orch.tasks import Task
from orch.tasks import Task_Waiter
from orch.zone_environment import ZoneEnvironment
from orch.ism_sdk.activity import Ism_Error, IsmErrorHandler
from orch.private_request import PrivateRequest


class ModuleBase:

    def __init__(self):
        self.infrastructure_system_uri = None
        self.parent_id = None
        self.LOG = log.getLogger(__name__)
        self.task = None
        self.parent_task_uri = None
        self.private_request = PrivateRequest()

    def base_pre_execute(self, params):
        self.LOG.debug('Pre-execute running')
        self.infrastructure_system_uri = params.get('infra_system_uri')
        self.zone_uuid = params.get('uuid')
        self.parent_id = params.get('parent_id')
        self.parent_task_uri = params.get('parent_task_uri')
        self.private_request = PrivateRequest(params.get('ism_hostname'))
        # TODO: Log configuration can be added here as well

    def base_post_execute(self, params):
        #self.LOG.debug('Post-execute running')
        pass

    def base_execute(self, params):
        try:
            log_params = copy.deepcopy(params)
            self.clear_secret_parameters(log_params)
            log_params_json = json.dumps(
                log_params,
                sort_keys=True,
                indent=4)
            log_params_json = self.clear_embedded_secret_parameters(
                log_params_json)
            self.LOG.debug(
                'Executing task with params: ' +
                log_params_json)
            self.base_pre_execute(params)
            execution_return = self.execute(params)
            self.base_post_execute(params)
            return execution_return
        except Exception as e:
            # self.LOG.debug(
            #    'Module Execution Failed! : ' +
            #    traceback.format_exc())
            return self.exit_fail(e)

    def clear_embedded_secret_parameters(self, param_json):
        regex_replacement_str_map = {
            "sessionkey=(\w){32}": "sessionkey=*****"
        }
        for regex, rep_str in regex_replacement_str_map.iteritems():
            param_json = re.sub(regex, rep_str, param_json)
        return param_json

    def clear_secret_parameters(self, params):
        if isinstance(params, dict):
            for key, value in params.iteritems():
                if 'pass' in key.lower():
                    params[key] = '*****'
                if 'auth' in key.lower():
                    params[key] = '*****'
                if 'token' in key.lower():
                    params[key] = '*****'
                if 'pwd' in key.lower():
                    params[key] = '*****'
                if 'sessionkey' in key.lower():
                    params[key] = '*****'
                self.clear_secret_parameters(params[key])
        if isinstance(params, list):
            for v in params:
                self.clear_secret_parameters(v)

    def execute(self, params):
        self.LOG.debug(params)
        raise ImportError(
            "Error! Execute method should be overridden in the python modules")

    '''
    Progress update
    '''

    # Verifies if current module is attached to ISM framework
    def is_reporting_progress(self):
        if self.private_request.hostname is None:
            return False
        if not self.parent_id:
            return False
        return True

    # Verifies if current module is already reporting step progress
    def is_task_progress(self):
        if self.is_reporting_progress():
            return hasattr(self, 'task') and (self.task is not None)
        return False

    def add_task(self, parent, step_msg):
        self.task = self.create_task(parent, step_msg)
        if self.task is not None:
            return self.task.id
        return None

    def create_task(self, parent, name):
        with IsmErrorHandler('HCOE_ISM_CREATE_TASK_ERROR', name):
            if self.is_reporting_progress():
                return Task(
                    parent,
                    name,
                    self.private_request)
            return None

    def update_task(self, progress, progress_msg, status='OK', error=None):
        if self.is_task_progress():
            if isinstance(error, basestring):
                self.LOG.warn(
                    "Report progress in compatibility mode. Please update implementation")
                error = Ism_Error(
                    "HCOE_ISM_GENERIC_MODULE_ERROR",
                    details=error)

            if progress == 100:
                return self.task.complete(status, error)

            progress_update = self.get_progress_update_dict(progress_msg)
            return self.task.update(progress, 'Running', status,
                                    progress_update, error)
        return None

    def update_resource_uri(self, resource_uri):
        if resource_uri is not None:
            return self.task.update_resource_uri(resource_uri)

    def update_parent_task(self, progress, progress_msg):
        if self.is_reporting_progress():
            p_task = Parent_Task(self.private_request,
                                 self.parent_task_uri)
            progress_update = self.get_progress_update_dict(progress_msg)
            return p_task.update_task(progress, progress_update)

    def close_task(self, status, error=None):
        if self.is_task_progress():
            with IsmErrorHandler('HCOE_ISM_COMPLETE_TASK_ERROR', self.task.name):
                return self.task.complete(status, error)
        return None

    def get_progress_update_dict(self, msg):
        return {"statusUpdate": msg,
                "timeStamp": datetime.datetime.utcnow().isoformat() + 'Z'}

    def exit_success(self, return_body):
        self.close_task('OK')
        return self.exit(return_body, 'SUCCESS')

    def exit_fail(self, return_body, failure_message=None):
        self.LOG.debug('%s execution failed: %s' %
                       (self.__class__.__name__, traceback.format_exc()))

        # If it isn't an ISM_Error, create the nested_errors to be added.
        nested_error = return_body
        if not isinstance(nested_error, Ism_Error):
            if failure_message:
                self.LOG.warn(
                    "Report progress in compatibility mode. Please update implementation")
                nested_details = failure_message
            else:
                self.LOG.error(
                    "Found unknown error type. Reporting generic error")
                nested_details = str(return_body)
            nested_error = Ism_Error(
                error_code="HCOE_ISM_GENERIC_MODULE_ERROR",
                details=nested_details)

        error = Ism_Error(error_code="HCOE_ISM_MODULE_FAILED", data=[
            str(self.__class__.__name__)], nested_errors=[nested_error])
        self.close_task('Critical', error)
        return self.exit(error.to_dict(), 'FAIL')

    def exit(self, body_dict, status):
        status_dict = {'module_status'	: status}
        response = {'headers'	: status_dict,
                    'body'		: body_dict}
        return response

    def update_zone_environment(self, zone_uuid, sptBlueprintUris):
        # TODO: Need to fix this
        self.zone_uuid = zone_uuid
        if self.zone_uuid is not None and self.zone_uuid != "":
            zone_environment = ZoneEnvironment(self.private_request)
            zone_environment.update_sptblueprintUris(
                self.zone_uuid, sptBlueprintUris)
        return None

    def get_zone_environment(self, zone_uri):
        if zone_uri is not None and zone_uri != "":
            zone_environment = ZoneEnvironment(self.private_request)
            return zone_environment.get(zone_uri)
        return None

    def delete_zone_environment(self, zone_uri):
        if zone_uri is not None and zone_uri != "":
            zone_environment = ZoneEnvironment(self.private_request)
            return zone_environment.delete(zone_uri)
        return None


def with_task(name):
    """
        Task Decorator
    """

    def wrap(f):
        def wrapped_f(*args, **kwargs):
            module_base = args[0]

            if not module_base.is_reporting_progress():
                return f(*args, **kwargs)

            module_base.task = None

            try:
                module_base.task = Task(
                    module_base.parent_id,
                    name,
                    module_base.private_request)

                ret = f(*args, **kwargs)

                module_base.task.complete('OK')

                return ret

            except Ism_Error as ism_err:
                if module_base.task is not None:
                    module_base.task.complete('Critical', ism_err)
                raise ism_err
        return wrapped_f
    return wrap
