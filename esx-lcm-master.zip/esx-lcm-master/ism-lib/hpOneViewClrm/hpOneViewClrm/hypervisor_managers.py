# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

"""
hypervisor_managers.py
~~~~~~~~~~~~

This module implements HypervisorManager HP OneView REST API
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from hpOneView.resources import task_monitor
from hpOneView.connection import *
from hpOneView.exceptions import *

from hpOneViewClrm import constants
from hpOneViewClrm.hpOneView_addons import *

standard_library.install_aliases()

__title__ = 'hypervisor_managers'
__version__ = '0.0.1'
__copyright__ = '(C) Copyright (2012-2016) Hewlett Packard Enterprise ' \
                ' Development LP'
__license__ = 'MIT'
__status__ = 'Development'

###
# (C) Copyright (2012-2015) Hewlett Packard Enterprise Development LP
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
###


class hypervisor_managers(object):

    def __init__(self, con):
        self._con = con
        self._task_monitor = task_monitor.TaskMonitor(con)

    def create_hypervisor_manager(
            self,
            name=None,
            username=None,
            password=None,
            hypervisorType=None,
            blocking=True,
            verbose=False):
        """
        Create a HypervisorManager dictionary for use with the V300 API
        Args:
            name:
                FQDN or the IP address of the Hypervisor Manager
            username:
                User name that can be used to authenticate with this hypervisor manager
            password:
                Password that can be used to authenticate with this hypervisor manager.
            hypervisorType:
                Type of Hypervisor (Vmware/HyperV/KVM)
        Returns: dict
        """

        # FIXME: temporary - begin
        if hypervisorType == 'vSphere':
            hypervisorType = 'Vmware'
        # FIXME: temporary - end
        # FIXME: temporary - begin
        if hypervisorType == 'SCVMM':
            hypervisorType = 'HyperV'
        # FIXME: temporary - end

        hypervisor_manager = make_hypervisor_manager(
            name,
            username,
            password,
            hypervisorType)

        task, body = self._con.post(
            uri['hypervisor-managers'], hypervisor_manager)
        tout = constants.MIN_11
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)

    def get_hypervisor_managers(self):
        body = self._con.get(uri['hypervisor-managers'])
        return get_members(body)

    def get_hypervisor_manager(self, hostname):
        hyp_mgr_list = self.get_hypervisor_managers()
        hyp_mgr = [
            _hyp_mgr for _hyp_mgr in hyp_mgr_list if _hyp_mgr['name'] == hostname]
        return hyp_mgr[0] if hyp_mgr else hyp_mgr

    def get_hypervisor_manager_by_uri(self, hypervisor_manager_uri):
        body = self._con.get(hypervisor_manager_uri)
        return body

    def update_hypervisor_manager(
            self,
            hypervisor,
            blocking=True,
            verbose=False):

        task, body = self._con.put(hypervisor['uri'], hypervisor)
        tout = constants.MIN_11
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)

    def delete_hypervisor_manager(
            self,
            uri=None,
            blocking=True):

        task, body = self._con.delete(uri + '?force=True')
        tout = constants.MIN_11
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)
