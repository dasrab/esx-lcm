# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

"""
cluster_profile.py
~~~~~~~~~~~~

This module implements HypervisorClusterProfile HP OneView REST API
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

import traceback
from hpOneView.resources import task_monitor
from hpOneView.connection import *
from hpOneView.exceptions import *

from hpOneViewClrm import constants
from hpOneViewClrm.hpOneView_addons import *

standard_library.install_aliases()

__title__ = 'cluster_profile'
__version__ = '0.0.1'
__copyright__ = '(C) Copyright (2012-2017) Hewlett Packard Enterprise ' \
                ' Development LP'
__license__ = 'MIT'
__status__ = 'Development'

###
# (C) Copyright (2012-2017) Hewlett Packard Enterprise Development LP
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
###


class cluster_profile(object):

    def __init__(self, con):
        self._con = con
        self._task_monitor = task_monitor.TaskMonitor(con)

    def create_cluster_profile(self,
                               name,
                               hypervisor_type,
                               server_profile_template_uri,
                               deployment_plan_uri,
                               server_password,
                               server_hardware_uri,
                               hypervisor_manager_uri,
                               network_uri,
                               datacenter_path,
                               vSwitchType,
                               haEnabled=False,
                               multiNicVMotion=False,
                               blocking=True
                               ):
        """
        Create a HypervisorClusterProfile dictionary for use with the V300 API
        Args:
            name:
                Unique name of the Cluster Profile
            hypervisor_type:
                Type of the hypervisor in the cluster
            server_profile_template_uri:
                URI of the server profile template.
            server_hardware_uri:
                URI of server hardware that is to be provisioned as a hypervisor host
            hypervisor_manager_uri:
                URI of the hypervisor manager in which the cluster will be created.
            network_uri:
                URI of the network.
            datacenter_path:
                 dataCenter path in the hypervisor manager where the cluster will be created.
            blocking:
                boolean indicating if operation should wait for task completion
        Returns: dict
        """

        # FIXME: temporary - begin
        if hypervisor_type == 'vSphere':
            hypervisor_type = 'Vmware'
        # FIXME: temporary - end


        cluster_profile_payload = make_cluster_profile(
            name,
            hypervisor_type,
            server_profile_template_uri,
            deployment_plan_uri,
            server_password,
            server_hardware_uri,
            hypervisor_manager_uri,
            datacenter_path,
            network_uri,
            vSwitchType,
            haEnabled,
            multiNicVMotion)

        task, body = self._con.post(
            uri['hypervisor-cluster-profiles'], cluster_profile_payload)
        # Setting timeout to 95 mins because OV-CLRM timeout is set to 90
        # minutes
        tout = constants.MIN_150
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)
        return task

    def expand_cluster_profile(self,
                               cluster_profile_uri,
                               server_hardware_uri,
                               blocking=True,
                               verbose=False):
        """
        Expand a Hypervisor Cluster Profile
        Args:

            cluster_profile_uri:
                URI of Cluster Profile
            server_hardware_uri:
                URI of server hardware that is to be provisioned as a hypervisor host
            blocking:
                boolean indicating if operation should wait for task completion
            verbose:
                boolean indicating if task progress should be printed
        Returns: dict
        """
        cluster_list = self._con.get(cluster_profile_uri)
        for uri in server_hardware_uri:
            cluster_list['addHostRequests'].append(uri)

        task, body = self._con.put(cluster_profile_uri, cluster_list)
        tout = constants.HOUR_3

        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)
        return task

    def get_cluster_profiles(self):
        body = self._con.get(uri['hypervisor-cluster-profiles'])
        return get_members(body)

    def get_cluster_profile_by_uri(self, cluster_profile_uri):
        body = self._con.get(cluster_profile_uri)
        return body

    def contract_cluster_profile(self,
                                 cluster_profile_uri,
                                 host_profile_uris_to_del,
                                 blocking=True,
                                 verbose=False):
        """
        Contract a Hypervisor Cluster Profile
        Args:
            cluster_profile_uri:
                URI of cluster profile
            host_profile_uris_to_del:
                URI of server profile that is to be deleted from cluster
            blocking:
                boolean indicating if operation should wait for task completion
            verbose:
                boolean indicating if task progress should be printed
        Returns: dict
        """
        removed = False
        cluster_response = self._con.get(cluster_profile_uri)
        host_profile_uris = cluster_response['hypervisorHostProfileUris']
        for host_profile in host_profile_uris_to_del:
            try:
                host_profile_uris.remove(host_profile)
            except Exception as e:
                self.LOG.debug(traceback.format_exc())
                return None
            else:
                removed = True
        if removed:
            task, body = self._con.put(cluster_profile_uri, cluster_response)
            tout = constants.INFINITE
            if blocking:
                return self._task_monitor.wait_for_task(task, timeout=tout)
            return task
        return None

    def get_cluster_by_uri(self, cluster_uri):
        body = self._con.get(cluster_uri)
        return body

    def delete_cluster_profile(
            self,
            cluster_profile_uri,
            blocking=True,
            verbose=False):
        """
        Delete all host profiles in Hypervisor Cluster Profile
        Args:
            cluster_profile_uri:
                URI of cluster profile
            blocking:
                boolean indicating if operation should wait for task completion
            verbose:
                boolean indicating if task progress should be printed
        Returns: dict
        """

        task, body = self._con.delete(cluster_profile_uri)
        if blocking:
            return self._task_monitor.get_completed_task(
                task, timeout=constants.MIN_11)
        return task

    def update_cluster_profile(
            self,
            cluster_profile_payload,
            blocking=False,
            verbose=False):
        """
        Update the cluster profile with the given payload. If timeout is
        specified then this will wait for the task to move into terminal state.
        otherwise it will return the task created for updating cluster profile.

        Args:
            cluster_profile_payload:
                payload with cluster profile changes
            blocking:
                boolean to indicate if should wait for task
            verbose:
                boolean to indicate if should print task wait operation
        Returns: the task resource
        """
        task, body = self._con.put(
            cluster_profile_payload['uri'], cluster_profile_payload)
        tout = constants.HOUR_1
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=tout)
        return task

    def remediate(self, cluster_profile_uri):
        obj = self.get_cluster_profile_by_uri(
            cluster_profile_uri=cluster_profile_uri)
        obj['compliance']['state'] = "Remediate"
        task = self.update_cluster_profile(cluster_profile_payload=obj)
        # return self.get_cluster_profile_by_uri(obj['uri'])
        return task

    def generate_vswitch_layout(self, spt_uri, cluster_profile):
        payload = dict()
        payload['serverProfileTemplateUri'] = spt_uri
        payload['hypervisorManagerUri'] = cluster_profile[
            'hypervisorManagerUri']
        payload['hypervisorClusterSettings'] = cluster_profile[
            'hypervisorClusterSettings']
        payload['virtualSwitchConfigPolicy'] = cluster_profile[
            'hypervisorHostProfileTemplate']['virtualSwitchConfigPolicy']

        _, body = self._con.post(uri['hypervisor-vswitch-layout'], payload)
        return body
