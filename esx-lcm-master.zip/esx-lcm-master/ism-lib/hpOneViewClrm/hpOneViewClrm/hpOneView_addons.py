# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

# This files contains the changes that are required for ESX-LCM which are not available at
# github.com/HewlettPackard/python-hpOneView (tag: v3.1.0)

uri = {
    #------------------------------------
    # Settings
    #------------------------------------
    'globalSettings': '/rest/global-settings',
    'vol-tmplate-policy': '/rest/global-settings/StorageVolumeTemplateRequired',
    'eulaStatus': '/rest/appliance/eula/status',
    'eulaSave': '/rest/appliance/eula/save',
    'serviceAccess': '/rest/appliance/settings/enableServiceAccess',
    'service': '/rest/appliance/settings/serviceaccess',
    'applianceNetworkInterfaces': '/rest/appliance/network-interfaces',
    'healthStatus': '/rest/appliance/health-status',
    'version': '/rest/version',
    'supportDump': '/rest/appliance/support-dumps',
    'backups': '/rest/backups',
    'archive': '/rest/backups/archive',
    'dev-read-community-str': '/rest/appliance/device-read-community-string',
    'licenses': '/rest/licenses',
    'nodestatus': '/rest/appliance/nodeinfo/status',
    'nodeversion': '/rest/appliance/nodeinfo/version',
    'shutdown': '/rest/appliance/shutdown',
    'trap': '/rest/appliance/trap-destinations',
    'restores': '/rest/restores',
    'domains': '/rest/domains',
    'schema': '/rest/domains/schema',
    'progress': '/rest/appliance/progress',
    'appliance-firmware': '/rest/appliance/firmware/image',
    'fw-pending': '/rest/appliance/firmware/pending',
    'time-locale': '/rest/appliance/configuration/time-locale',
    'ntp': '/rest/appliance/configuration/timeconfig/ntp',

    #------------------------------------
    # Security
    #------------------------------------
    'activeSessions': '/rest/active-user-sessions',
    'loginSessions': '/rest/login-sessions',
    'users': '/rest/users',
    'userRole': '/rest/users/role',
    'changePassword': '/rest/users/changePassword',
    'roles': '/rest/roles',
    'category-actions': '/rest/authz/category-actions',
    'role-category-actions': '/rest/authz/role-category-actions',
    'validator': '/rest/authz/validator',
    #------------------------------------
    # Facilities
    #------------------------------------
    'datacenters': '/rest/datacenters',
    'powerDevices': '/rest/power-devices',
    'powerDevicesDiscover': '/rest/power-devices/discover',
    'racks': '/rest/racks',
    #------------------------------------
    # Systems
    #------------------------------------
    'servers': '/rest/server-hardware',
    'server-hardware-types': '/rest/server-hardware-types',
    'enclosures': '/rest/enclosures',
    'enclosureGroups': '/rest/enclosure-groups',
    'enclosurePreview': '/rest/enclosure-preview',
    'fwUpload': '/rest/firmware-bundles',
    'fwDrivers': '/rest/firmware-drivers',
    #------------------------------------
    # Connectivity
    #------------------------------------
    'conn': '/rest/connections',
    'ct': '/rest/connection-templates',
    'enet': '/rest/ethernet-networks',
    'fcnet': '/rest/fc-networks',
    'nset': '/rest/network-sets',
    'li': '/rest/logical-interconnects',
    'lig': '/rest/logical-interconnect-groups',
    'ic': '/rest/interconnects',
    'ictype': '/rest/interconnect-types',
    'uplink-sets': '/rest/uplink-sets',
    'ld': '/rest/logical-downlinks',
    'idpool': '/rest/id-pools',
    'ipv4-ranges': '/rest/id-pools/ipv4/ranges',
    'ipv4-subnets': '/rest/id-pools/ipv4/subnets',
    'vmac-pool': '/rest/id-pools/vmac',
    'vwwn-pool': '/rest/id-pools/vwwn',
    'vsn-pool': '/rest/id-pools/vsn',
    #------------------------------------
    #  Server Profiles
    #------------------------------------
    'profiles': '/rest/server-profiles',
    'profile-templates': '/rest/server-profile-templates',
    'profile-networks': '/rest/server-profiles/available-networks',
    'profile-networks-schema': '/rest/server-profiles/available-networks/schema',
    'profile-available-servers': '/rest/server-profiles/available-servers',
    'profile-available-servers-schema': '/rest/server-profiles/available-servers/schema',
    'profile-available-storage-system': '/rest/server-profiles/available-storage-system',
    'profile-available-storage-systems': '/rest/server-profiles/available-storage-systems',
    'profile-available-targets': '/rest/server-profiles/available-targets',
    'profile-messages-schema': '/rest/server-profiles/messages/schema',
    'profile-ports': '/rest/server-profiles/profile-ports',
    'profile-ports-schema': '/rest/server-profiles/profile-ports/schema',
    'profile-schema': '/rest/server-profiles/schema',
    #------------------------------------
    #  Health
    #------------------------------------
    'alerts': '/rest/alerts',
    'events': '/rest/events',
    'audit-logs': '/rest/audit-logs',
    'audit-logs-download': '/rest/audit-logs/download',
    #------------------------------------
    #  Certificates
    #------------------------------------
    'certificates': '/rest/certificates',
    'ca': '/rest/certificates/ca',
    'crl': '/rest/certificates/ca/crl',
    'rabbitmq-kp': '/rest/certificates/client/rabbitmq/keypair',
    'rabbitmq': '/rest/certificates/client/rabbitmq',
    'cert-https': '/rest/certificates/https',
    #------------------------------------
    #  Searching and Indexing
    #------------------------------------
    'resource': '/rest/index/resources',
    'association': '/rest/index/associations',
    'tree': '/rest/index/trees',
    'search-suggestion': '/rest/index/search-suggestions',
    # 'GetAllNetworks': ('/index/rest/index/resources'
    #                   '?sort=name:asc&category=fc-networks'
    #                   '&category=networks&start=0&count=-1'),
    # 'GetEthNetworks': ('/index/rest/index/resources'
    #                   '?sort=name:asc&category=networks&start=0&count=-1'),
    # 'GetFcNetworks': ('/index/rest/index/resources'
    #                  '?sort=name:asc&category=fc-networks&start=0&count=-1'),
    #------------------------------------
    #  Logging and Tracking
    #------------------------------------
    'task': '/rest/tasks',
    #------------------------------------
    # Storage
    #------------------------------------
    'storage-pools': '/rest/storage-pools',
    'storage-systems': '/rest/storage-systems',
    'storage-volumes': '/rest/storage-volumes',
    'vol-templates': '/rest/storage-volume-templates',
    'vol-attachments': '/rest/storage-volume-attachments',
    'connectable-vol': '/rest/storage-volume-templates/connectable-volume-templates',
    'attachable-volumes': '/rest/storage-volumes/attachable-volumes',
    'sdi-system-profiles': '/rest/sdi-system-profiles',
    'sdi-systems': '/rest/sdi-systems',
    #------------------------------------
    # FC-SANS
    #------------------------------------
    'device-managers': '/rest/fc-sans/device-managers',
    'managed-sans': '/rest/fc-sans/managed-sans',
    'providers': '/rest/fc-sans/providers',
    #------------------------------------
    # Hypervisors
    #------------------------------------
    'hypervisor-managers': '/rest/hypervisor-managers',
    'hypervisor-cluster-profiles': '/rest/hypervisor-cluster-profiles',
    'hypervisor-clusters': '/rest/hypervisor-clusters',
    'hypervisor-host-profiles': '/rest/hypervisor-host-profiles',
    'hypervisor-hosts': '/rest/hypervisor-hosts',
    'hypervisor-vswitch-layout': '/rest/hypervisor-cluster-profiles/virtualswitch-layout',
    #------------------------------------
    # Uncategorized
    #------------------------------------
    'unmanaged-devices': '/rest/unmanaged-devices',
}


def make_sdi_system_profile(name,
                            system_version,
                            hypervisor_cluster_profile_uri,
                            is_cpu_memory_auto_managed,
                            cpu_count,
                            memory_allocation,
                            locale,
                            users,
                            ntp_servers,
                            software_specific_attributes,
                            system_nodes
                            ):

    return {
        'SystemType': 'StoreVirtualVsaCluster',
        'SystemVersion': system_version,
        'Name': name,
        'hostingHypervisorClusterProfileUri': hypervisor_cluster_profile_uri,
        'isCpuAndMemoryAutoManaged': is_cpu_memory_auto_managed,
        'CpuCount': cpu_count,
        'MemoryAllocation': memory_allocation,
        'Locale': locale,
        'users': users,
        'ntpServers': ntp_servers,
        'SoftwareSpecificAttributes': software_specific_attributes,
        'SystemNodes': system_nodes
    }


def make_hypervisor_manager(name, username, password, hypervisorType):
    if ':' in name and name.count(":") == 1:
        port = name.split(':')[1]
        name = name.split(':')[0]
        return {
            'type': 'HypervisorManager',
            'name': name,
            'port': int(port),
            'username': username,
            'password': password,
            'hypervisorType': hypervisorType
        }
    else:
        return {
            'type': 'HypervisorManager',
            'name': name,
            'username': username,
            'password': password,
            'hypervisorType': hypervisorType
        }


def make_cluster_profile(name,
                         hypervisorType,
                         serverProfileTemplateUri,
                         deployment_plan_uri,
                         server_password,
                         serverHardwareUri,
                         hypervisorManagerUri,
                         dataCenterPath,
                         networkUri,
                         vSwitchType,
                         haEnabled,
                         multiNicVMotion
                         ):

    serverHardwareArray = []
    for serverHardwareUriElement in serverHardwareUri:
        serverHardwareArray.append(
            {'serverHardwareUri': serverHardwareUriElement})

    return {
        'type': 'HypervisorClusterProfile',
        'name': name,
        'hypervisorType': hypervisorType,
        'hypervisorHostProfileTemplate': {
            'serverProfileTemplateUri': serverProfileTemplateUri,
            "deploymentPlan": {
                "deploymentPlanUri": deployment_plan_uri,
                "serverPassword": server_password},
            'hostConfigPolicy': {
                'useHostPrefixAsHostname': True}},
        'addHostRequests': serverHardwareArray,
        'hypervisorManagerUri': hypervisorManagerUri,
        'path': dataCenterPath,
        'hypervisorClusterSettings': {
            'type': hypervisorType,
            'virtualSwitchType': vSwitchType,
            'distributedSwitchVersion': '6.5.0',
            'distributedSwitchUsage': 'AllNetworks',
            'haEnabled': haEnabled,
            'multiNicVMotion': multiNicVMotion}}


def get_members(mlist):
    return mlist['members'] if mlist and mlist['members'] else []
