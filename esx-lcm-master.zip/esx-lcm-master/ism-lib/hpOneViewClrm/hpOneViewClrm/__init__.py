# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from __future__ import unicode_literals
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
from future import standard_library

standard_library.install_aliases()

__title__ = 'hpOneViewClrm'

import sys

PYTHON_VERSION = sys.version_info[:3]
PY2 = (PYTHON_VERSION[0] == 2)
if PY2:
    if PYTHON_VERSION < (2, 7, 9):
        raise Exception('Must use Python 2.7.9 or later')
elif PYTHON_VERSION < (3, 4):
    raise Exception('Must use Python 3.4 or later')

from hpOneViewClrm.hpOneView_addons import *
from hpOneViewClrm.hypervisor_profiles import *
from hpOneViewClrm.cluster_profile import *
from hpOneViewClrm.hypervisor_managers import *
