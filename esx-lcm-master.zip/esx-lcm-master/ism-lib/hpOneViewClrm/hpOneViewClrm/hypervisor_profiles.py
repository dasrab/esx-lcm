# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

"""
hypervisor_profiles.py
~~~~~~~~~~~~

This module implements Hypervisor Host Profiles HP OneView REST API
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from hpOneView.resources import task_monitor
from hpOneView.connection import *
from hpOneView.exceptions import *

from hpOneViewClrm import constants
from hpOneViewClrm.hpOneView_addons import *

standard_library.install_aliases()

__title__ = 'hypervisor_profiles'
__version__ = '0.0.1'
__copyright__ = '(C) Copyright (2012-2016) Hewlett Packard Enterprise ' \
                ' Development LP'
__license__ = 'MIT'
__status__ = 'Development'

# ##
# (C) Copyright (2012-2015) Hewlett Packard Enterprise Development LP
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ##

HypervisorProfilesTerminalStates = ['Active', 'Error', 'Removed', 'CloneError']


class hypervisor_profiles(object):

    def __init__(self, con):
        self._con = con
        self._task_monitor = task_monitor.TaskMonitor(con)

    def get_hypervisor_profiles(self):
        body = self._con.get(uri['hypervisor-host-profiles'])
        return get_members(body)

    def get_hypervisor_profile_by_uri(self, hypervisor_host_profile_uri):
        body = self._con.get(hypervisor_host_profile_uri)
        return body

    def get_hypervisor_host_by_uri(self, hypervisor_host_uri):
        body = self._con.get(hypervisor_host_uri)
        return body

    def get_hypervisor_manager_by_uri(self, hypervisor_manager_uri):
        body = self._con.get(hypervisor_manager_uri)
        return body

    def update_hypervisor_profile_patch(
            self, hypervisor_host_profile_uri, payload):
        install_patch_uri = hypervisor_host_profile_uri + "/customupdate"
        task, body = self._con.put(install_patch_uri, payload)
        return task

    def update_hypervisor_profile(
            self,
            hypervisor_profile,
            blocking=True,
            verbose=False):
        task, body = self._con.put(
            hypervisor_profile['uri'], hypervisor_profile)
        if blocking:
            return self._task_monitor.wait_for_task(task, timeout=constants.INFINITE)
        return task

    def wait_for_hypervisor_profile_terminal_state(
            self, tout, hypervisor_host_profile_uri, verbose=False):
        global HypervisorProfilesTerminalStates
        if hypervisor_host_profile_uri is None:
            return None
        hypervisor_profile = self.get_hypervisor_profile_by_uri(
            hypervisor_host_profile_uri)

        count = 0
        while True:
            if hypervisor_profile is not None and 'state' in hypervisor_profile and hypervisor_profile[
                    'state'] not in HypervisorProfilesTerminalStates:
                if verbose:
                    sys.stdout.write(
                        'Hypervisor profile is still not moved to terminal state after %d seconds   \r' %
                        count)
                    sys.stdout.flush()
                time.sleep(1)
                count += 1
                hypervisor_profile = self.get_hypervisor_profile_by_uri(
                    hypervisor_host_profile_uri)
                if count > tout:
                    raise HPOneViewTimeout(
                        'Waited ' + str(tout) + ' seconds for task to complete, aborting')
            else:
                break
        hypervisor_profile = self.get_hypervisor_profile_by_uri(
            hypervisor_host_profile_uri)
        if hypervisor_profile is not None and 'state' in hypervisor_profile and hypervisor_profile[
                'state'] not in HypervisorProfilesTerminalStates:
            raise HPOneViewTaskError(
                'Hypervisor state did not move to terminal state')
        return hypervisor_profile
