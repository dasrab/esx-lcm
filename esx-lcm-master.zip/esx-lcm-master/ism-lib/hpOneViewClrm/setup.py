# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from setuptools import setup

setup(name='hpOneViewClrm',
      version='0.1',
      description='HP OneView Python Library add-ons required for NCS',
      url='http://hp.com/go/OneViewCommunity',
      author='Hewlett Packard Enterprise Development LP',
      license='MIT',
      packages=['hpOneViewClrm'],
      install_requires=['hpOneView==4.2.0'])
