# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

# This script helps to install python packages inside a python virtualenv
#
# To create virtualenv
# 1. pip install virtualenv
# 2. virtualenv <anyname>
# 3. source <anyname>/bin/activate
#
#ATTENTION:
#If installation of requirements fail your OS might be missing the following packages:
#sudo apt-get install build-essential libssl-dev libffi-dev python-dev

BASEDIR=$(cd $(dirname "$0"); pwd)
ISM_LIB_DIR=${BASEDIR}
HPONEVIEW_CLRM_DIR=${BASEDIR}/hpOneViewClrm/
ORCH_LIB_DIR=${BASEDIR}/orchLib

echo "Installing ISM Lib"
cd ${ISM_LIB_DIR}
#Careful here, some of these packages might be OS owned, if so, you'll have to remove them from /usr/lib/python2.7/dist-packages
pip install -r requirements.txt ||  {
    echo 'Installing ism python libs failed' ;
    exit 1;
}

echo "Installing hpOneViewClrm package"
cd ${HPONEVIEW_CLRM_DIR}
pip install . --upgrade || {
    echo 'Installing OneView CLRM python SDK failed' ;
    exit 1;
}

cd ${ORCH_LIB_DIR}
echo "Installing OrchLib"

pip install . --upgrade ||  {
    echo 'Installing OrchLib failed' ;
    exit 1;
}
