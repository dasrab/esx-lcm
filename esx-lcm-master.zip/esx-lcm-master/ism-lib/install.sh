#!/bin/sh
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

#ATTENTION:
#If installation of requirements fail your OS might be missing the following packages:
#sudo apt-get install build-essential libssl-dev libffi-dev python-dev

BASEDIR=$(cd $(dirname "$0"); pwd)
ISM_LIB_DIR=${BASEDIR}
HPONEVIEW_CLRM_DIR=${BASEDIR}/hpOneViewClrm/
ORCH_LIB_DIR=${BASEDIR}/orchLib

echo "Installing ISM Lib"
cd ${ISM_LIB_DIR}
#Careful here, some of these packages might be OS owned, if so, you'll have to remove them from /usr/lib/python2.7/dist-packages
pip install --user -r requirements.txt ||  {
    echo 'Installing ism python libs failed' ;
    exit 1;
}

echo "Installing hpOneViewClrm package"
cd ${HPONEVIEW_CLRM_DIR}
pip install . --user --upgrade || {
    echo 'Installing OneView CLRM python SDK failed' ;
    exit 1;
}

cd ${ORCH_LIB_DIR}
echo "Installing OrchLib"

pip install . --user --upgrade ||  {
    echo 'Installing OrchLib failed' ;
    exit 1;
}
