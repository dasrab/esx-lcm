#!/bin/bash
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

# Script to deploy mysql and esx-lcm through helm

set -eux

DEV_NAMESPACE=dev
ESXLCM_POD_NAME=esx-lcm
MYSQL_ESXLCM_POD_NAME=mysql-esxlcm
NCS_API_POD_NAME=ncs_api

wait_till_pod() {
  count=0
  namespace=$1
  pod_name=$2
  echo "Checking the status of Pod ${pod_name}"
  status=$(kubectl get pods --namespace ${namespace} | grep "${pod_name}" | awk '{print $3}')
  while [ "${status}" != "Running" ]
  do
    if [[ $count -eq 10 ]]; then echo "Pod ${pod_name} failed to start (${count} retries). Exiting !" && exit 1; fi
    echo "Pod ${pod_name} not yet started. Retrying..."
    status=$(kubectl get pods --namespace ${namespace} | grep "${pod_name}" | awk '{print $3}')
    sleep 10
    count=$(( $count + 1 ))
  done
  echo "Pod ${pod_name} is ready"
}

install_dependencies() {
  # Install socat package. Required for running mysql through helm chart
  echo "Installing socat package.."
  dpkg -s socat > /dev/null 2>&1
  if [[ $? -eq 1 ]]; then
    sudo apt-get install socat
    echo "Installed socat package"
  else
    echo "socat package already installed"
  fi

}

set_environment_variables() {
  # Set the required environment variables for executing minikube commands
  echo "Set the required environment variables"
  export MINIKUBE_HOME=$HOME
  export CHANGE_MINIKUBE_NONE_USER=true
  export MINIKUBE_WANTUPDATENOTIFICATION=false
  export MINIKUBE_WANTREPORTERRORPROMPT=false
  export KUBE_HOME=$HOME
  export HELM_HOME=$HOME
  export http_proxy=$http_proxy
  export https_proxy=$https_proxy
  export no_proxy=$no_proxy

}

install_minikube() {
  echo "Installing kubernetes..."
  # Install kubernetes
  if [ ! -f "/usr/local/bin/kubectl" ]; then
    k8s_version=$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)
    curl -LO https://storage.googleapis.com/kubernetes-release/release/${k8s_version}/bin/linux/amd64/kubectl
    chmod +x ./kubectl
    sudo mv ./kubectl /usr/local/bin/
  fi
  echo "Installed kubernetes"

  echo "Installing minikube..."
  # Install minikube
  if [ ! -f "/usr/local/bin/minikube" ]; then
    minikube_version=v0.21.0
    curl -Lo minikube https://storage.googleapis.com/minikube/releases/${minikube_version}/minikube-linux-amd64
    chmod +x minikube
    sudo mv minikube /usr/local/bin/
  fi
  echo "Installed minikube"

}

start_minikube() {
  echo "Starting the minikube with $MINIKUBE_DRIVER driver..."
  # Run minikube
  if [ $MINIKUBE_DRIVER == "kvm" ]; then
      minikube start \
      --docker-env HTTP_PROXY=$http_proxy --docker-env http_proxy=$http_proxy \
      --docker-env HTTPS_PROXY=$http_proxy --docker-env https_proxy=$http_proxy \
      --docker-env NO_PROXY=$no_proxy --docker-env no_proxy=$no_proxy \
      --vm-driver=kvm
      echo "Exporting 'no_proxy' with 'minikube ip'... $(minikube ip)"
      export no_proxy=$no_proxy,$(minikube ip)
  else
      sudo -E minikube start \
      --docker-env HTTP_PROXY=$http_proxy --docker-env http_proxy=$http_proxy \
      --docker-env HTTPS_PROXY=$http_proxy --docker-env https_proxy=$http_proxy \
      --docker-env NO_PROXY=$no_proxy --docker-env no_proxy=$no_proxy \
      --vm-driver=none
  fi

  sleep 10
  minikube update-context

  echo "Waiting for k8s pods to be ready..."
  wait_till_pod kube-system kube-dns
  wait_till_pod kube-system kube-addon-manager
  wait_till_pod kube-system kubernetes-dashboard
  sleep 5

  minikube status
  echo "minikube started successfully"

}

install_helm() {
  echo "Installing helm..."
  # Install helm
  if [ ! -f "/usr/local/bin/helm" ]; then
    curl -Lo helm-v2.5.1-linux-amd64.tar.gz https://kubernetes-helm.storage.googleapis.com/helm-v2.5.1-linux-amd64.tar.gz
    tar -xvf helm-v2.5.1-linux-amd64.tar.gz
    chmod u+x ./linux-amd64/helm
    sudo mv ./linux-amd64/helm /usr/local/bin/
    rm -rf ./linux-amd64/
    rm helm-v2.5.1-linux-amd64.tar.gz
  fi
  echo "Installed helm"

}

init_helm() {
  echo "Initializing helm"
  # Init helm
  helm init

  echo "Waiting for tiller pod to be ready..."
  wait_till_pod kube-system tiller
  sleep 5
  echo "helm initialized successfully"

}

install_mysql() {
  echo "Starting mysql pod..."
  # Install mysql
  namespace=$1
  pod_name=$2
  helm repo add stable https://kubernetes-charts.storage.googleapis.com
  helm install --namespace ${namespace} --name ${pod_name} -f mysql-values.yaml stable/mysql
  wait_till_pod ${namespace} ${pod_name}
  echo "Pod: ${pod_name} is up"

}

install_esx_lcm() {
  echo "Starting esx-lcm pod..."
  # Install esx-lcm
  namespace=$1
  pod_name=$2
  mysql_ip=$(kubectl get pods --namespace ${DEV_NAMESPACE} -o wide | grep "${MYSQL_ESXLCM_POD_NAME}" | awk '{print $6}')
  sed -i "s/db.ncs.com/${mysql_ip}/" ../helm/esx-lcm/values.yaml
  helm install --namespace ${namespace} --name ${pod_name} ../helm/esx-lcm
  wait_till_pod ${namespace} ${pod_name}
  esxlcm_ip=$(kubectl get pods --namespace ${DEV_NAMESPACE} -o wide | grep "${ESXLCM_POD_NAME}" | awk '{print $6}')
  echo "Pod: ${pod_name} is up"

}

install_ncs_api() {
  echo "NCS API deployment: To be implemented"
}

setup() {
  install_dependencies
  set_environment_variables
  install_minikube
  start_minikube
  install_helm
  init_helm
  install_mysql ${DEV_NAMESPACE} ${MYSQL_ESXLCM_POD_NAME}
  install_esx_lcm ${DEV_NAMESPACE} ${ESXLCM_POD_NAME}
  install_ncs_api ${DEV_NAMESPACE} ${NCS_API_POD_NAME}

  set +x
  unset http_proxy && unset https_proxy
  curl http://${esxlcm_ip}:8083/ --connect-timeout 10 > /dev/null 2>&1
  if [[ $? -eq 0 ]]; then
    echo "=========================================================================="
    echo "esx-lcm dev environment is up !" && echo ""
    kubectl get pods --namespace ${DEV_NAMESPACE}
    echo "esx-lcm service is available at http://${esxlcm_ip}:8083/"
    echo "=========================================================================="
  else
    echo "=========================================================================="
    echo "Installation of the components completed" && echo ""
    echo "esx-lcm service not available"
    echo "=========================================================================="
  fi

}

helm_cleanup() {
  # helm delete --purge ${NCS_API_POD_NAME}
  helm delete --purge ${ESXLCM_POD_NAME}
  helm delete --purge ${MYSQL_ESXLCM_POD_NAME}
  helm reset --force
  rm -rf $HOME/.helm
  sudo rm -f /usr/local/bin/helm

}

minikube_cleanup() {
  minikube stop
  minikube delete
  rm -rf $HOME/.minikube
  sudo rm -f /usr/local/bin/minikube
  rm -rf $HOME/.kube
  sudo rm -f /usr/local/bin/kubectl
  sudo rm -f /usr/local/bin/localkube

}

teardown() {
  helm_cleanup
  sed -i "s/host: .* \#DND/host: db.ncs.com \#DND/" ../helm/esx-lcm/values.yaml
  minikube_cleanup

}

usage() {
  echo "Script to deploy mysql and esx-lcm containers through helm chart
  Execute from the \'dev\' folder
  Example:
  1. To setup - ./kube-cluster-setup.sh --driver kvm/none
  2. To teardown - ./kube-cluster-setup.sh --clean"

}

main() {
  if [[ $# -eq 0 ]]; then export MINIKUBE_DRIVER="none" && setup && exit 0;
  elif [[ $# -eq 1 && $1 == "--help" ]]; then usage && exit 0;
  elif [[ $# -eq 1 && $1 == "--clean" ]]; then teardown && exit 0;
  elif [[ $# -eq 2 && $1 == "--driver" ]]; then
      if [[ $2 == "kvm" ]]; then
          export MINIKUBE_DRIVER="kvm"
          setup && exit 0;
      else
          export MINIKUBE_DRIVER="none"
          setup && exit 0;
      fi

  else
    echo "Invalid Option ($1)!" && usage && exit 1
  fi

}

main $@
