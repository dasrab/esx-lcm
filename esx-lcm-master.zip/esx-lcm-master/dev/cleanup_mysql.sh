#!/bin/sh
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
set -v
set -e

# >>> Removing mysql-esxlcm Container...
docker rm -f mysql-esxlcm
# >>> Done
