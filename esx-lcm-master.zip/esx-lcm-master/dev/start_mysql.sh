#!/bin/bash
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
set -e

MYSQL_ESXLCM_VERSION="hub.docker.hpecorp.net/ncs-vmware/mysql-esxlcm:latest"
MYSQL_CONTAINER_NAME=mysql-esxlcm

if [[ $# -eq 1 && $1 -eq 1 ]]; then
   echo "Cleaning up mysql container"
   docker rm -f ${MYSQL_CONTAINER_NAME}
fi

echo "Starting mysql container"
docker run --name ${MYSQL_CONTAINER_NAME} -d -p 3306:3306 $MYSQL_ESXLCM_VERSION
