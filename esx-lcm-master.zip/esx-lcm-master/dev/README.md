# Development Setup
---

## Install GO

Below are the steps captured in my test machine. **You should change the directory structures**

- wget https://storage.googleapis.com/golang/go1.8.3.linux-amd64.tar.gz
- tar xvzf go1.8.3.linux-amd64.tar.gz
- mkdir -p NCS/bin
- export GOROOT=/home/<USER>/go
- export GOPATH=/home/<USER>/NCS
- export PATH=$PATH:$GOROOT/bin:$GOPATH/bin

## Get esx-lcm repo

Clone `esx-lcm` to your `$GOPATH/src` directory

- mkdir -p /home/<USER>/NCS/src/github.hpe.com/ncs-vmware
- cd /home/<USER>/NCS/src/github.hpe.com/ncs-vmware
- git clone git@github.hpe.com:ncs-vmware/esx-lcm

Make sure your directory tree is setup correctly: Otherewise go code will not compile

**$GOPATH/src/github.hpe.com/ncs-vmware/esx-lcm**

## Install GLIDE ( go dependency package management tool )

glide need `go` package and `GOPATH` to be set before intalling.

Once all steps under `Install GO` is done

- curl https://glide.sh/get | sh
- glide -v # check the version

## Download vendor packages

- cd $GOPATH/src/github.hpe.com/ncs-vmware/esx-lcm/ism
- glide install

## Running ESX-LCM service locally (i.e not a container)

1. Option 1: Install all libs, start mysql container, build and start esx-lcm services
   bash ./dev/start_esxlcm.sh -a
   If you want to clean up DB, export CLEAN_MYSQL_DB=1

2. Option 2: Start esx-lcm only
   bash ./dev/start_esxlcm.sh -e

3. Option 3: Clean and start mysql only
   bash ./dev/start_esxlcm.sh -m

4. Option 4: Install python libs only  ( install required libraries available under `ism-lib`)
   bash ./dev/start_esxlcm.sh -p

5. Option 5: This help text
   bash ./dev/start_esxlcm.sh -h

## Running ESX-LCM service locally (i.e as a container)

    - docker build -f Dockerfile -t esx-lcm:devtest3 --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy --build-arg no_proxy=$no_proxy .

  # start mysql container
    - ./dev/start_esxlcm.sh -m

  # Get ip of the container
    - docker inspect --format '{{ .NetworkSettings.IPAddress }}' $(docker ps --filter name=mysql-esxlcm -q)

  # Run container
    # Presenlty MONASCA_API_URL is taking k8s environment variable, so while deploying in local dev docker environment fetching of that value will be skipped. If you want esx-lcm to connect to MONASCA
      docker run --name esx-lcm -e MONASCA_API_URL=http://localhost:999 -e DB_HOST=xx.xx.xx.xx -e DB_NAME=esxlcm_db -e DB_PASS=esxlcmPassword -e DB_PORT=3306 -e DB_USER=esxlcm -p 8083:8083 esx-lcm:devtest3

## Unit Testing
How to invoke unit-test? ( under esx-lcm directory )
    # All test cases and lint checks
        - bash ./ci/check.sh
    # Go unit-tests ( you need mysql to run. use /dev/start_esxlcm.sh -m )
        - bash ./ism/unit_test.sh
    # Python Unit-tests
        - bash ./ci/python/pyunit_tests.sh
