#!/bin/sh
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

set -eux

DOCKER_HUB="hub.docker.hpecorp.net"
ORAGNIZATION="ncs-vmware"
IMAGE="mysql-esxlcm"

MYSQL_IMAGE_NAME=${DOCKER_HUB}/${ORAGNIZATION}/${IMAGE}
MYSQL_IMAGE_TAG="latest"
MYSQL_IMAGE_BASE_VERSION="5.7.14"

MYSQL_IMAGE_ID=$(docker images | grep "${MYSQL_IMAGE_NAME}.*${MYSQL_IMAGE_TAG}" | awk '{print $3}')

if ["${MYSQL_IMAGE_ID}" == ""]; then
    echo "No previous MySQL docker image found"
else
    echo "Cleanup existing MySQL docker image if present..."
    docker rmi ${MYSQL_IMAGE_NAME}:${MYSQL_IMAGE_TAG}
    echo "Cleaned previous MySQL docker image"
fi

echo "Building the MySQL docker image '${MYSQL_IMAGE_NAME}:${MYSQL_IMAGE_TAG}' for esx-lcm ..."
docker build -t ${MYSQL_IMAGE_NAME}:${MYSQL_IMAGE_TAG} .
echo "MySQL docker image built successfully"

MYSQL_IMAGE_ID=$(docker images | grep "${MYSQL_IMAGE_NAME}.*${MYSQL_IMAGE_TAG}" | awk '{print $3}')

set +x

echo "
===============================================================================
MYSQL DOCKER IMAGE:- ${MYSQL_IMAGE_NAME}:${MYSQL_IMAGE_TAG}
MYSQL DOCKER IMAGE ID:- ${MYSQL_IMAGE_ID}
===============================================================================

Usage:

# docker run --name mysql-container -d ${MYSQL_IMAGE_NAME}:${MYSQL_IMAGE_TAG}
"

