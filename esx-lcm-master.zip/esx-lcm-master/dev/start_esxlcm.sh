#!/bin/bash
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
set -e

BASEDIR=$(cd $(dirname "$0"); pwd)
CLEAN_MYSQL_DB=${CLEAN_MYSQL_DB:-0}

usage() {
    echo "------------------------------------------------------------"
    echo "                    Options to execute this script"
    echo ""
    echo "Option 1: Install all libs, start mysql container and esx-lcm"
    echo "bash $0 -a"
    echo "If you want to clean up DB, export CLEAN_MYSQL_DB=1"
    echo ""
    echo "Option 2: Start esx-lcm only"
    echo "bash $0 -e"
    echo ""
    echo "Option 3: Clean and start mysql only"
    echo "bash $0 -m"
    echo ""
    echo "Option 4: Install python libs only"
    echo "bash $0 -p"
    echo ""
    echo "Option 5: This help text"
    echo "bash $0 -h"
    echo ""
    echo "-------------------------------------------------------------"
}

install_libs() {
    echo "Installing Python libraries..."
    sh ${BASEDIR}/install_python_libs.sh
}

start_mysql() {
    echo "Checking mysql container running or not...."
    MYSQL_STATUS=$(docker ps -q -a -f "name=mysql-esxlcm")
    if [ -z ${MYSQL_STATUS} ]; then
       echo "mysql container not running. Starting...."
       ${BASEDIR}/start_mysql.sh
    else
       if [ ${CLEAN_MYSQL_DB} -eq 1 ]; then
           echo "mysql container not running. Starting...."
           ${BASEDIR}/start_mysql.sh 1
       else
           echo "mysql container is running : ${MYSQL_STATUS} "
       fi
    fi
}

start_esx_lcm() {
    unset http_proxy
    unset https_proxy
    cd ${BASEDIR}/../ism
    echo "Starting esx-lcm service..."
    echo ""
    go run main.go
}

unset OPTIND

while getopts aehpm opt; do
    case $opt in
        a)
            install_libs
            start_mysql
            sleep 5
            start_esx_lcm
            ;;
        e)
            start_esx_lcm
            ;;
        h)
            usage
            exit 0
            ;;
        p)
            install_libs
            ;;
        m)
            CLEAN_MYSQL_DB=1
            start_mysql
            ;;
        *)
            usage >&2
            exit 1
            ;;
    esac
done
shift "$((OPTIND-1))"

if [ $# -ne 2 ] ; then
    usage
    exit 1
fi
