#!/bin/bash
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
# Install ism-common and ism-recipes python lib
set -e

DIR=$(cd $(dirname "$0"); cd ..; pwd)

sh $DIR/ism-lib/install.sh

# >>> Done!
