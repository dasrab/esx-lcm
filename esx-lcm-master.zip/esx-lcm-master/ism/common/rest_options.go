//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package common

type RestOptions struct {
	APIVersion int
	Lang       string
	Filters    map[string][]string
}

func NewRestOptions() RestOptions {
	options := RestOptions{}
	//TODO: Default language of the system, depends on system locale. For now it is set to english US
	options.Lang = "en-US"
	return options
}
