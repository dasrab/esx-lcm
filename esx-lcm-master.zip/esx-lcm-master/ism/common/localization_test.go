//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package common

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func init() {
	StartLogs()
}

func createFakeCatalogues() {
	catalogs = make(map[string]map[string]string)

	catalogs["en-US"] = make(map[string]string)
	catalogs["en-US"]["SYN_ISM_TEST_1"] = "This is test 1"
	catalogs["en-US"]["SYN_ISM_TEST_2"] = "This is test 2"
	catalogs["en-US"]["SYN_ISM_TEST_3"] = "This is test 3"
	catalogs["en-US"]["SYN_ISM_TEST_REPLACE"] = "It's true that a {{index .Data 1}} has {{index .Data 0}}."

	catalogs["fr-FR"] = make(map[string]string)
	catalogs["fr-FR"]["SYN_ISM_TEST_1"] = "Test 1"
	catalogs["fr-FR"]["SYN_ISM_TEST_2"] = "Test 2"
	catalogs["fr-FR"]["SYN_ISM_TEST_3"] = "Test 3"
}

func createBadCatalogues() {
	catalogs = make(map[string]map[string]string)

	catalogs["en-US"] = make(map[string]string)
	catalogs["en-US"]["SYN_ISM_TEST_1"] = "This is test 1"
	catalogs["en-US"]["SYN_ISM_TEST_2"] = "This is test 2"
	catalogs["en-US"]["SYN_ISM_TEST_3"] = "This is test 3"
	catalogs["en-US"]["SYN_ISM_MISSING_BRACKET"] = "This entry is missing a bracket {{index .Data 0} :("
}

func TestReadCatalogues(t *testing.T) {
	readCatalogues("./../languages")
}

func TestReadCataloguesWithBadFolder(t *testing.T) {
	assert := assert.New(t)
	assert.Panics(func() {
		readCatalogues("NonexistentFolder")
	})
}

func TestPanicsOnBadCatalogues(t *testing.T) {
	assert := assert.New(t)
	createBadCatalogues()
	assert.Panics(validateCatalogues)
}

func TestFileNameRegex(t *testing.T) {
	assert := assert.New(t)
	languageName := reValidLang.FindString("../languages/en-US.json")
	assert.Equal("en-US", languageName)

	languageName = reValidLang.FindString("../languages/recipes_en-US.json")
	assert.Equal("en-US", languageName)

	languageName = reValidLang.FindString("../languages/en-US_recipes.json")
	assert.Equal("en-US", languageName)

	languageName = reValidLang.FindString("../languages/fr-FR_recipes.json")
	assert.Equal("fr-FR", languageName)

}

func TestGetLocalizedMessage(t *testing.T) {
	assert := assert.New(t)
	createFakeCatalogues()

	assert.Equal("This is test 1", GetLocalizedString("en-US", "SYN_ISM_TEST_1", nil))
	assert.Equal("Test 1", GetLocalizedString("fr-FR", "SYN_ISM_TEST_1", nil))
	assert.Equal("This is test 2", GetLocalizedString("en-US", "SYN_ISM_TEST_2", nil))
	assert.Equal("Test 2", GetLocalizedString("fr-FR", "SYN_ISM_TEST_2", nil))
	assert.Equal("This is test 3", GetLocalizedString("en-US", "SYN_ISM_TEST_3", nil))
	assert.Equal("Test 3", GetLocalizedString("fr-FR", "SYN_ISM_TEST_3", nil))
}

func TestUnknownLanguageDefaultsToEnglish(t *testing.T) {
	assert := assert.New(t)
	createFakeCatalogues()

	assert.Equal(GetLocalizedString("en-AR", "SYN_ISM_TEST_1", nil), "This is test 1")
}

func TestUnknownKeyReturnsEmpty(t *testing.T) {
	assert := assert.New(t)
	createFakeCatalogues()
	assert.Empty(GetLocalizedString("en-US", "NOT_A_KEY", nil))
}

func TestGetLocalizedMessageWithParameters(t *testing.T) {
	assert := assert.New(t)
	createFakeCatalogues()
	params := []string{"Wheels", "Car"}
	assert.Equal("It's true that a Car has Wheels.", GetLocalizedString("en-US", "SYN_ISM_TEST_REPLACE", params))
}

func TestGetLocalizedMessages(t *testing.T) {
	assert := assert.New(t)
	createFakeCatalogues()

	expectedOutput := []string{"It's true that a Car has Wheels.", "This is test 1"}

	params := []string{"Wheels", "Car"}
	keys := []string{"SYN_ISM_TEST_REPLACE", "SYN_ISM_TEST_1"}
	assert.Equal(expectedOutput, GetListLocalizedMessages("en-US", keys, params))
}
