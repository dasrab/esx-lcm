//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package version

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

const (
	validResourceVersion   = APIVersion1
	invalidResourceVersion = "999999"
)

func TestResourceVersion(t *testing.T) {
	a := assert.New(t)

	tests := []struct {
		version Version
		valid   bool
	}{
		{validResourceVersion, true},
		{invalidResourceVersion, false},
	}

	for _, tc := range tests {
		a.NotPanics(func() { tc.version.IsSupported() }, "Calling version.IsSupported() should NOT panic!")
		a.Equal(tc.valid, tc.version.IsSupported())
	}

}
