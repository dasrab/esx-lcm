//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package version

type Version string

const (
	APIVersion0 Version = "0.0" // version 0 is used only for testing
	APIVersion1 Version = "1.0" // release version
)

// resVersionList is a list of all valid API versions
var resVersionList = []Version{
	APIVersion0,
	APIVersion1,
}

func SupportedValues() []Version {
	return resVersionList
}

func (v Version) IsSupported() bool {
	for _, version := range resVersionList {
		if string(v) == string(version) {
			return true
		}
	}
	return false
}
