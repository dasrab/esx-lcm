//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package version

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

const (
	testAPIVersion = "9999999"
)

var (
	testValidVersionFile = []byte(testAPIVersion)
)

func TestLoadAPIVersion(t *testing.T) {
	a := assert.New(t)

	err := LoadAPI(testValidVersionFile)
	a.NoError(err)
	a.Equal(Version(testAPIVersion), API())
}
