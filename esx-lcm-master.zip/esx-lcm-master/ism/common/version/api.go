//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package version

import (
	"fmt"
	"io/ioutil"
	"strings"
)

var api Version

// API returns the API version
func API() Version {
	return api
}

// LoadAPI sets the API Version by reading either a file (string) or a stream of bytes ([]byte)
func LoadAPI(source interface{}) error {
	v, err := read(source)

	if err != nil {
		return err
	}

	api = Version(strings.Trim(string(v), " \n"))
	return nil
}

func read(src interface{}) ([]byte, error) {
	switch s := src.(type) {
	case string:
		return ioutil.ReadFile(s)
	case []byte:
		return src.([]byte), nil
	default:
		return nil, fmt.Errorf("Error parsing data source: unknown type '%s'", s)
	}
}
