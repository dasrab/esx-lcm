//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package common

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestGetLocalizedError(t *testing.T) {
	catalogs = make(map[string]map[string]string)
	catalogs["en-US"] = make(map[string]string)
	catalogs["en-US"]["ISM_ERROR_1_MSG"] = "This is localized error 1"

	err := NewApplicationError("ISM_ERROR_1", "Error 1 details")
	locErr := err.GetLocalizedError("en-US")

	assert.Equal(t, "ISM_ERROR_1_MSG", err.Message)
	assert.Equal(t, "Error 1 details", err.Details)
	assert.Equal(t, "This is localized error 1", locErr.Message)

	assert.Equal(t, "[ISM_ERROR_1] This is localized error 1 (Error 1 details)", fmt.Sprintf("%s", err))
	assert.Equal(t, "[ISM_ERROR_1] (Error 1 details)", fmt.Sprintf("%s", locErr))
}

func TestGetNotLocalizedError(t *testing.T) {
	catalogs = make(map[string]map[string]string)
	catalogs["en-US"] = make(map[string]string)
	catalogs["en-US"]["ISM_ERROR_1_MSG"] = "This is localized error 1"

	err := NewApplicationError("ISM_ERROR_2", "Error 2 details")
	locErr := err.GetLocalizedError("en-US")

	assert.Equal(t, "ISM_ERROR_2_MSG", err.Message)
	assert.Equal(t, "Error 2 details", err.Details)
	assert.Equal(t, "", locErr.Message) // not localized

	assert.Equal(t, "[ISM_ERROR_2] (Error 2 details)", fmt.Sprintf("%s", err))
	assert.Equal(t, "[ISM_ERROR_2] (Error 2 details)", fmt.Sprintf("%s", locErr))
}
