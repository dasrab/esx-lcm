//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package properties

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestPropertiesHappyPath(t *testing.T) {
	a := assert.New(t)

	a.NotPanics(func() {
		load(testProperties, &properties{ISM})
	}, "Calling Load(testProperties) should NOT panic!")

	// Testing overridden properties
	a.Equal(9000, ISM.Server.SecurePort)
	a.Equal(true, ISM.Server.Debug)

	a.Equal("127.0.0.1", ISM.Database.Host)
	a.Equal("3306", ISM.Database.Port)
	a.Equal("lcmuser", ISM.Database.User)
	a.Equal(time.Duration(30), ISM.Database.Timeout)

}

func TestPassword(t *testing.T) {
	a := assert.New(t)
	a.NotPanics(func() {
		load(testPassword, &properties{ISM})
	}, "Calling Load(testProperties) should NOT panic!")

	a.Equal("esx#lcmPassword", ISM.Database.Pass)
	a.Equal("esxlcm#Password", ISM.Keystone.Pass)
	a.Equal("#esxlcmPassword#", ISM.MonascaAgent.Pass)
}

var testProperties = []byte(`
[ism]
[ism.server]
    SecurePort = 9000
    Debug     = true
[ism.database]
    SSL = false
    Host = 127.0.0.1
    Port = 3306
    User = lcmuser
    Pass = esxlcmPassword
    Name = esxlcm_db
    Timeout = 30
`)

var testPassword = []byte(`
[ism]
[ism.database]
    Pass = esx#lcmPassword
[ism.keystone]
    Pass    = esxlcm#Password
[ism.monascaAgent]
    Pass    = #esxlcmPassword#
`)
