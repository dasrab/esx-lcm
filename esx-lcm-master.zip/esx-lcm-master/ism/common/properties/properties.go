//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package properties

import (
	"errors"
	"fmt"
	"os"
	"path"
	"runtime"
	"time"

	"github.com/go-ini/ini"
)

var (
	ISM ismProperties
)

const ism_properties_filepath = "../../ism.properties"

func init() {
	loadPropertiesFromFile()
}

func loadPropertiesFromFile() {

	ism := ismProperties{
		Server: serverProperties{
			SecurePort: 8083,
			Debug:      false,
		},
		Log: logProperties{
			LogFilePath: "/tmp/infrastructure-system.log",
			LogToFile:   false,
			LogLevel:    "info",
		},
		Engine: engineProperties{
			EnginePath: "../../../ism-recipes/engine/engine.py",
		},
		Keystone: keystoneProperties{
			User:    "esx-lcm",
			Pass:    "esxlcmPassword",
			Project: "demo",
			Domain:  "default",
			AuthURL: "127.0.0.1",
		},
		SecurityMgr: securityMgrProperties{
			Enabled: true,
		},
		MonascaAgent: monascaAgentProperties{
			User:    "esx-lcm",
			Pass:    "esxlcmPassword",
			Project: "demo",
			Domain:  "default",
		},

		Monasca: monascaProperties{
			"ApiURI",
		},
		CapacityHandler: capacityHandler{
			EnabledFilters: []string{},
			MaxClusters:    12,
			MaxNodes:       32,
			MinimumNodes:   4,
			ScaleType:      "Horizontal",
		},
		Database: databaseProperties{
			SSL:     true,
			Host:    "127.0.0.1",
			Port:    "3306",
			Name:    "esxlcm_db",
			Timeout: 20,
		},
		ApplianceManager: applianceManager{
			Host: "127.0.0.1",
			Port: "5000",
		},
		CommsLcm: commsLcm{
			Host:    "comms-lcm",
			Port:    "6000",
			Enabled: false,
		},
		VsanConfigParameters: vsanConfig{
			ConfigureVsan:             true,
			EnablePerformanceService:  false,
			ForceMarkLocalDiskAsFlash: true,
			WipeDisks:                 false,
		},
		DatacenterConfig: datacenterConfig{
			DatacenterPathSuffix: "dc",
			HostPassword:         "MG4zQHNwaDNyMw==",
		},
		HpeGateway: hpeGateway{
			ClusterScaleCount: 12,
			VCpus:             4,
			Memory:            4096,
			PollingInterval:   10 * (time.Minute),
		},
		FeatureToggle: featureToggle{
			VMwareNeutron:      false,
			VMwareHostMetadata: false,
			KvmHostMetadata:    false,
		},
	}

	p := &properties{ISM: ism}

	filepath := getAbsoluteFilepath(ism_properties_filepath)

	// If file does not exist, try importing it directly
	if _, err := os.Stat(filepath); os.IsNotExist(err) {
		filepath = ism_properties_filepath
	}

	// Merge ism.properties (file) with type properties
	load(filepath, p)

}

func load(source interface{}, p *properties) {
	prop, err := ini.LoadSources(ini.LoadOptions{IgnoreInlineComment: true}, source)
	if err != nil {
		err := errors.New(fmt.Sprintf("General failure! Not able to read properties.ini: %v", err))
		panic(err)
	}
	err = prop.MapTo(p)
	if err != nil {
		err := errors.New(fmt.Sprintf("General failure! Not able to Map default properties: %v", err))
		panic(err)
	}

	ISM = p.ISM
	ISM.Engine.EnginePath = getAbsoluteFilepath(ISM.Engine.EnginePath)
}

func getAbsoluteFilepath(filepath string) string {
	_, filename, _, _ := runtime.Caller(1)
	return path.Join(path.Dir(filename), filepath)
}

type properties struct {
	ISM ismProperties `ini:"ism"`
}

type ismProperties struct {
	Server               serverProperties       `ini:"ism.server"`
	Log                  logProperties          `ini:"ism.log"`
	Engine               engineProperties       `ini:"ism.engine"`
	Keystone             keystoneProperties     `ini:"ism.keystone"`
	SecurityMgr          securityMgrProperties  `ini:"ism.securityMgr"`
	Monasca              monascaProperties      `ini:"ism.monasca"`
	MonascaAgent         monascaAgentProperties `ini:"ism.monascaAgent"`
	CapacityHandler      capacityHandler        `ini:"ism.capacityHandler"`
	Database             databaseProperties     `ini:"ism.database"`
	ApplianceManager     applianceManager       `ini:"ism.applianceManager"`
	CommsLcm             commsLcm               `ini:"ism.commsLcm"`
	VsanConfigParameters vsanConfig             `ini:"ism.vsanConfig"`
	DatacenterConfig     datacenterConfig       `ini:"ism.datacenterConfig"`
	HpeGateway           hpeGateway             `ini:"ism.hpeGateway"`
	FeatureToggle        featureToggle          `ini:"ism.featureToggle"`
}

type featureToggle struct {
	VMwareNeutron      bool
	VMwareHostMetadata bool
	KvmHostMetadata    bool
}

type serverProperties struct {
	SecurePort int
	Debug      bool
}

type logProperties struct {
	LogFilePath string
	LogToFile   bool
	LogLevel    string
}

type engineProperties struct {
	EnginePath string
}

type databaseProperties struct {
	SSL     bool
	Host    string
	Port    string
	Pass    string
	Name    string
	User    string
	Timeout time.Duration
}

type keystoneProperties struct {
	User    string
	Pass    string
	Project string
	Domain  string
	AuthURL string
}

type securityMgrProperties struct {
	Enabled bool
}

type monascaAgentProperties struct {
	User    string
	Pass    string
	Project string
	Domain  string
}

type monascaProperties struct {
	ApiURI string
}

type capacityHandler struct {
	EnabledFilters []string
	MaxClusters    int
	MaxNodes       int
	MinimumNodes   int
	ScaleType      string
}

type applianceManager struct {
	Host string
	Port string
}

type commsLcm struct {
	Host      string
	Port      string
	ProxyHost string
	Enabled   bool
}

type vsanConfig struct {
	ConfigureVsan             bool
	EnablePerformanceService  bool
	ForceMarkLocalDiskAsFlash bool
	WipeDisks                 bool
}

type datacenterConfig struct {
	DatacenterPathSuffix string
	HostPassword         string
}

type hpeGateway struct {
	ClusterScaleCount int
	VCpus             int
	Memory            int
	PollingInterval   time.Duration
}
