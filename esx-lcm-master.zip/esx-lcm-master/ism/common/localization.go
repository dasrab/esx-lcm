//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package common

import (
	"bytes"
	"encoding/json"
	"fmt"
	log "github.hpe.com/kronos/kelog"
	"os"
	"path/filepath"
	"regexp"
	"text/template"
)

type LocalizedData struct {
	Data []string
}

type LocString LocKey
type LocKey string

const (
	//Base language and language folder will not be configurable
	langFolder   = "./languages"
	baseLanguage = "en-US"
)

var (
	catalogs    = make(map[string]map[string]string)
	reValidLang = regexp.MustCompile(`[a-z]{2}(\-([A-Z]{2,3}|[0-9]{3}))`)
)

func ReadCatalogues() {
	log.Printf("Reading Catalogues\n")
	currPath, _ := os.Getwd()
	readCatalogues(currPath + "/" + langFolder)
}

func readCatalogues(langDir string) {
	if !folderExists(langDir) {
		panic(fmt.Errorf("Unable to find language folder at %s\n", langDir))
	}

	// Find all language files in this directory
	// omit all directories
	files, err := filepath.Glob(langDir + "/*.json")

	// Check if it was possible to read the language
	// folder with different locales
	if err != nil {
		panic(fmt.Errorf("Unable to read language folder contents at %q: %s \n", langDir, err.Error()))
	}

	// Check if we found at least one language
	if len(files) == 0 {
		panic(fmt.Errorf("No language files found in the language folder at %q \n", langDir))
	}

	// Check if we found the default language
	baselang := filepath.Join(langDir, fmt.Sprintf("%v.json", baseLanguage))
	if !inslice(files, baselang) {
		panic(fmt.Errorf("Unable to find default language %q in the language folder %q \n", baseLanguage, langDir))
	}

	// Load all languages
	for _, name := range files {
		log.Infof("Reading catalogue files: lang = %s", name)
		parseCatalogFile(name)
	}

	// Perform a diff and report the differences to the log
	diffLangCheck()
	validateCatalogues()

	log.Infof("Catalogues Read succesfully. Language Count: %d, Word Count: %d", len(catalogs), len(catalogs[baseLanguage]))
}

func GetListLocalizedMessages(lang string, keys []string, args []string) []string {
	var list []string

	for _, key := range keys {
		localizedString := getLocalizedMessage(lang, key, LocalizedData{args})
		if localizedString != "" {
			list = append(list, localizedString)
		}
	}
	return list
}

func AppendLocalizationTag(key LocKey, tag string) LocKey {
	keyString := string(key)
	return LocKey(keyString + tag)
}

func GetLocalizedMessage(lang string, key LocKey, args []string) LocString {
	return LocString(GetLocalizedString(lang, string(key), args))
}

func GetLocalizedString(lang string, key string, args []string) string {
	mapOfInterfaces := make([]interface{}, len(args))
	for i, v := range args {
		mapOfInterfaces[i] = v
	}
	return getLocalizedMessage(lang, key, LocalizedData{args})
}

func validateCatalogues() {
	errorsFound := false
	for lang, lcatalog := range catalogs {
		for key, message := range lcatalog {
			_, err := template.New(key).Parse(message)
			if err != nil {
				log.Errorf("Catalogue key %s for language %s has syntax errors: %v\n", key, lang, err)
				errorsFound = true
			}
		}
	}
	if errorsFound {
		panic("Syntax Errors on Catalogues. Please check logs and fix the issue")
	}
}

// GetLocalizedMessage returns a string containing the localized
// version of the message with a given key and a language. No language
// detection is performed. If the language wasn't found, it'll fall back to the default one.
//func GetLocalizedMessage(lang string, key string, args ...interface{}) string {
func getLocalizedMessage(lang string, key string, args LocalizedData) string {
	// Try finding the appropiate language for the given string
	lcatalog, found := catalogs[lang]

	// If we couldn't find the given language, we fall back to english
	if !found {
		log.Warnf("Unable to find Language key %q, fall back to default %q for key %q", lang, baseLanguage, key)
		lcatalog = catalogs[baseLanguage]
		lang = baseLanguage
	}

	// Find the localized string
	strfmt, found := lcatalog[key]

	// Check if we did find it, if we didn't
	// we can only return empty string
	if !found {
		log.Warnf("Unable to find localized string in %q language for key %q.", lang, key)
		return ""
	}

	template, err := template.New(key).Parse(strfmt)
	if err != nil {
		log.Errorf("Unable to find localized string in %q language for key %q. Error: %v", lang, key, err)
		return fmt.Sprintf(strfmt)
	}

	var b bytes.Buffer
	template.Execute(&b, args)

	return fmt.Sprintf(b.String())
}

func parseCatalogFile(filename string) {
	f, err := os.Open(filename)

	// If there's an error, report it, since it's most likely
	// a human error in the JSON file.
	if err != nil {
		panic(fmt.Errorf("Unable to open catalog file %q: %s \n", filename, err.Error()))
	}

	defer f.Close()

	// Try parsing the file contents
	contents := make(map[string]string)
	if err := json.NewDecoder(f).Decode(&contents); err != nil {
		panic(fmt.Errorf("Unable to parse catalog file %q: %s", filename, err.Error()))
	}

	// Create a holder for the given language
	languageName := reValidLang.FindString(filename)

	if _, present := catalogs[languageName]; present {
		//If language is already there, merge contents with current catalogue
		for key, value := range contents {
			catalogs[languageName][key] = value
		}
	} else {
		catalogs[languageName] = contents
	}

}

// DiffLangCheck performs a checking and detects if there's any difference between two
func diffLangCheck() {
	// Create a map to hold the differences
	var buf bytes.Buffer

	// Iterate over all the languages
	for lang := range catalogs {
		// We don't want to diff the base language, since, well
		// it's the base one
		if lang == baseLanguage {
			continue
		}

		// Iterate over the master language
		for key := range catalogs[baseLanguage] {
			if _, found := catalogs[lang][key]; !found {
				if len(buf.Bytes()) == 0 {
					buf.WriteString("Language files are missing certain strings: \n")
				}

				buf.WriteString(fmt.Sprintf("  - %q: missing key: %q \n", lang, key))
			}
		}
	}

	// Check if we found at least something
	if s := buf.String(); s != "" {
		log.Warn(s)
	}
}

func folderExists(path string) bool {
	if _, err := os.Stat(path); err == nil {
		return true
	}
	return false
}

func inslice(a []string, s string) bool {
	for _, v := range a {
		if v == s {
			return true
		}
	}
	return false
}
