//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package common

import (
	"fmt"
)

type ErrorType string

//TODO: Temporary so we don't have to refactor the whole code
func (errCode ErrorType) String() string {
	return string(errCode)
}

/***************************
* Application Error Model
* Error message that explains why the operation failed
****************************/
//TODO: Careful when changing this model, you might need to change GetLocalizedError as well
type ApplicationError struct {
	//clear and concise description of error condition
	Message string `json:"message"`
	//optional verbose description of error
	Details string `json:"details"`
	//steps that an end-user can perform to correct error condition
	RecommendedActions []string `json:"recommendedActions"`
	//list of subsidiary errors that led to this condition
	NestedErrors []ApplicationError `json:"nestedErrors"`
	//identifies some element of the request that caused the error
	//TODO: This should not be a string
	ErrorSource string `json:"errorSource"`
	//an opaque string uniquely identifying the error
	//TODO: This should not be a string
	ErrorCode ErrorType `json:"errorCode"`
	//arbitrary data for programmatic use
	Data []string `json:"data"`
	//whether this error condition can be ignored by resending the request with force=true
	CanForce bool `json:"canForce"`
}

// TODO should eventually support already localized
func (appError ApplicationError) Error() string {
	if appError.IsEmpty() {
		return ""
	}

	// Use appError.ErrorCode + "_MSG" explicitly, in case appError has already been localized
	message := GetLocalizedString(baseLanguage, appError.Message, appError.Data)

	errString := fmt.Sprintf("[%s]", appError.ErrorCode)

	if message != "" {
		errString += " " + message
	}

	if appError.Details != "" {
		errString = fmt.Sprintf("%s (%s)", errString, appError.Details)
	}

	return errString
}

func (appError ApplicationError) IsEmpty() bool {
	return appError.ErrorCode.String() == ""
}

func ConvertError(e interface{}) ApplicationError {
	var err ApplicationError

	if e != nil {
		switch appError := e.(type) {
		case ApplicationError:
			err = appError
		default:
			err = NewApplicationError(ErrorExecutionFailure, fmt.Sprintf("%v", appError))
		}
	}
	return err
}

func (appError *ApplicationError) AppendNestedError(err error) {
	if err != nil {
		switch nestedErr := err.(type) {
		case ApplicationError:
			appError.NestedErrors = append(appError.NestedErrors, nestedErr)
		default:
			newNestedErr := NewApplicationError(ErrorExecutionFailure, err.Error())
			appError.NestedErrors = append(appError.NestedErrors, newNestedErr)
		}
	}
}

func (appError *ApplicationError) AddDefaultRecommendedActions() {
	appError.RecommendedActions = []string{string(appError.ErrorCode) + "_ACT"}
}

func (appError *ApplicationError) AddData(data ...string) {
	appError.Data = append(appError.Data, data...)
}

func (appError ApplicationError) GetLocalizedError(lang string) ApplicationError {
	// Translate nested errors
	var nestedErrs []ApplicationError
	for _, nestedErr := range appError.NestedErrors {
		nestedErrs = append(nestedErrs, nestedErr.GetLocalizedError(lang))
	}

	if appError.IsEmpty() {
		return appError
	}

	appError.Message = GetLocalizedString(lang, appError.Message, appError.Data)
	appError.RecommendedActions = GetListLocalizedMessages(lang, appError.RecommendedActions, appError.Data)
	appError.NestedErrors = nestedErrs
	return appError
}

//Application error Constructor
func NewApplicationError(code ErrorType, details string) ApplicationError {
	appError := ApplicationError{
		ErrorCode:   code,
		Details:     details,
		ErrorSource: "",
		//TODO: Use Append method.
		Message: code.String() + "_MSG",
	}
	return appError
}

var (
	ErrorResourceNotFound                 ErrorType = "HCOE_ISM_RESOURCE_NOT_FOUND"
	ErrorDatabase                         ErrorType = "HCOE_ISM_DATABASE_FAILURE"
	ErrorDatabaseConflict                 ErrorType = "HCOE_ISM_DATABASE_CONFLICT_ERROR"
	ErrorGeneralFailure                   ErrorType = "HCOE_ISM_GENERAL_FAILURE"
	ErrorExecutionFailure                 ErrorType = "HCOE_ISM_EXECUTION_FAILURE"
	ErrorAddVolumeAttachment              ErrorType = "HCOE_ISM_UNABLE_TO_ADD_VOLUME_ATTACHMENT"
	ErrorInvalidJson                      ErrorType = "HCOE_ISM_INVALID_JSON"
	ErrorInvalidUuid                      ErrorType = "HCOE_ISM_INVALID_UUID"
	ErrorInvalidParameters                ErrorType = "HCOE_ISM_INVALID_PARAMETERS"
	ErrorUnsupportedOperation             ErrorType = "HCOE_ISM_UNSUPPORTED_OPERATION"
	ErrorInvalidUri                       ErrorType = "HCOE_ISM_INVALID_URI"
	ErrorRequiredResource                 ErrorType = "HCOE_ISM_REQUIRED_RESOURCE"
	ErrorFieldLength                      ErrorType = "HCOE_ISM_INVALID_FIELD_LENGTH"
	ErrorMinValue                         ErrorType = "HCOE_ISM_INVALID_FIELD_MIN_ELEMENTS"
	ErrorMaxValue                         ErrorType = "HCOE_ISM_INVALID_FIELD_MAX_ELEMENTS"
	ErrorQuorumType                       ErrorType = "HCOE_ISM_INVALID_QUORUM_PARAMETERS"
	ErrorIPAddress                        ErrorType = "HCOE_ISM_INVALID_IP_ADDRESS"
	ErrorMismatchNetwork                  ErrorType = "HCOE_ISM_INVALID_NETWORK_SPECIFICATION"
	ErrorGatewayInRange                   ErrorType = "HCOE_ISM_GATEWAY_IN_RANGE"
	ErrorInvalidGateway                   ErrorType = "HCOE_ISM_INVALID_GATEWAY"
	ErrorOption                           ErrorType = "HCOE_ISM_INVALID_OPTION"
	ErrorDuplicatedNetNames               ErrorType = "HCOE_ISM_DUPLICATED_NET_NAMES"
	ErrorDuplicatedIPPoolNames            ErrorType = "HCOE_ISM_DUPLICATED_POOL_NAMES"
	ErrorOverlappingIPPools               ErrorType = "HCOE_ISM_OVERLAPPING_POOLS"
	ErrorDuplicatedVLanIds                ErrorType = "HCOE_ISM_DUPLICATED_VLAN_IDS"
	ErrorOverlappingNetworks              ErrorType = "HCOE_ISM_OVERLAPPING_NETWORKS"
	ErrorTaggedNetwork                    ErrorType = "HCOE_ISM_MGMT_TAGGED_NETWORK"
	ErrorInvalidAssociatedResource        ErrorType = "HCOE_ISM_INVALID_ASSOC_RESOURCE"
	ErrorPublicAuth                       ErrorType = "HCOE_ISM_PUB_AUTH_FAILURE"
	ErrorPrivateAuth                      ErrorType = "HCOE_ISM_PRI_AUTH_FAILURE"
	ErrorSeedNodeUnavailable              ErrorType = "HCOE_ISM_UNAVAILABLE_SEEDNODE"
	ErrorInvalidDNSNameServer             ErrorType = "HCOE_ISM_INVALID_DNS_NAME_SERVER"
	ErrorGreaterEqThanValue               ErrorType = "HCOE_ISM_INVALID_GREATER_EQ_VALUE"
	ErrorMisformattedMessage              ErrorType = "HCOE_ISM_MISFORMATTED_MESSAGE"
	ErrorInvalidVLanIds                   ErrorType = "HCOE_ISM_INVALID_VLAN_IDS"
	ErrorInvalidVLanIdsForTaggedNet       ErrorType = "HCOE_ISM_INVALID_VLAN_ID_FOR_TAGGED_NETWORK"
	ErrorInvalidIPV4                      ErrorType = "HCOE_ISM_INVALID_IPV4"
	ErrorCollectLogsRunning               ErrorType = "HCOE_ISM_COLLECT_LOGS_RUNNING"
	ErrorInvalidHost                      ErrorType = "HCOE_ISM_INVALID_HOSTNAME"
	ErrorHcoeRequest                      ErrorType = "HCOE_ISM_REQUEST_FAILURE"
	ErrorIdmClient                        ErrorType = "HCOE_ISM_IDM_CLIENT_FAILURE"
	ErrorDecodePEMData                    ErrorType = "HCOE_ISM_INCORRECT_PEM_DATA"
	ErrorRSAPrivateKey                    ErrorType = "HCOE_ISM_INCORRECT_PRIVATE_KEY_TYPE"
	ErrorCredentialClient                 ErrorType = "HCOE_ISM_CREDENTIAL_CLIENT_FAILURE"
	ErrorDecryption                       ErrorType = "HCOE_ISM_DECRYPTION_FAILURE"
	ErrorShutdownPreOperation             ErrorType = "HCOE_ISM_SHUTDOWN_PRE_OPERATION_FAILURE"
	ErrorInvalidChapCredentialCombination ErrorType = "HCOE_ISM_INVALID_CHAP_CREDENTIAL_COMBINATION"
	ErrorInvalidState                     ErrorType = "HCOE_ISM_INVALID_STATE"
	ErrorUnableToDiscoverNodes            ErrorType = "HCOE_ISM_UNABLE_TO_DISCOVER_NODES"
	ErrorApplianceImageDownloadFailure    ErrorType = "HCOE_ISM_APPLIANCE_IMAGE_DOWNLOAD_FAILURE"
	ErrorIPListAllocation                 ErrorType = "HCOE_ISM_IP_LIST_ALLOCATION_FAILURE"
	ErrorIPCountAllocation                ErrorType = "HCOE_ISM_IP_COUNT_ALLOCATION_FAILURE"
	ErrorIPCollection                     ErrorType = "HCOE_ISM_IP_COLLECTION_FAILURE"
	ErrorInvalidClusterPrefix             ErrorType = "HCOE_ISM_INVALID_CLUSTER_PREFIX"
	ErrorInvalidTransition                ErrorType = "HCOE_ISM_INVALID_OPERATION"
	ErrorUnableToUnmapVMFS                ErrorType = "HCOE_ISM_UNABLE_TO_UNMAP_VMFS"
	ErrorInvalidIPPoolRange               ErrorType = "HCOE_ISM_INVALID_IP_POOL_RANGE"
	ErrorInvalidDHCPConfiguration         ErrorType = "HCOE_ISM_INVALID_DHCP_CONFIGURATION"
	ErrorNoIPPoolsAllowedWithDHCP         ErrorType = "HCOE_ISM_NO_IP_POOLS_ALLOWED_WITH_DHCP"
	ErrorMissingIPPools                   ErrorType = "HCOE_ISM_MISSING_IP_ADDRESS_POOLS"
	ErrorMismatchIPPool                   ErrorType = "HCOE_ISM_INVALID_IP_POOL_SPECIFICATION"
	ErrorDuplicatedServer                 ErrorType = "HCOE_ISM_DUPLICATED_SERVERS"
	ErrorDuplicatedUnmanagedServer        ErrorType = "HCOE_ISM_DUPLICATED_UNMANAGED_SERVERS"
	ErrorInvalidNTPServer                 ErrorType = "HCOE_ISM_INVALID_NTP_SERVER"
	ErrorOperationFailure                 ErrorType = "HCOE_ISM_OPERATION_FAILED"
	ErrorUnableCreateInfrastructureLogs   ErrorType = "HCOE_ISM_UNABLE_TO_CREATE_INFRA_LOGS"
	ErrorUnableToUpdatePowerState         ErrorType = "HCOE_ISM_UNABLE_TO_UPDATE_POWER_STATE"
	ErrorDeleteVolumeAttachment           ErrorType = "HCOE_ISM_UNABLE_TO_DELETE_VOLUME_ATTACHMENT"
	ErrorInvalidHTTPResponse              ErrorType = "HCOE_ISM_INVALID_HTTP_RESPONSE"
	ErrorPreconditionFailure              ErrorType = "PRECONDITION_FAILED"
	// Common LCM
	ErrorEnableAndDisableResource ErrorType = "LCM_UNABLE_TO_ENABLE_AND_DISABLE_RESOURCE"
	ErrorGetUnmanagedResource     ErrorType = "LCM_UNABLE_TO_FETCH_UNMANAGED_RESOURCE"
	// ESX LCM
	ErrorGetUnmanagedCluster                   ErrorType = "ESX_LCM_UNABLE_TO_FETCH_UNMANAGED_RESOURCE"
	ErrorRegisterSPTBlueprintFailure           ErrorType = "ESX_LCM_UNABLE_TO_REGISTER_SPT_BLUEPRINT"
	ErrorRegisterZone                          ErrorType = "ESX_LCM_UNABLE_TO_REGISTER_ZONE"
	ErrorRecoverClusters                       ErrorType = "ESX_LCM_UNABLE_TO_RECOVER_CLUSTERS"
	ErrorAddCapacity                           ErrorType = "ESX_LCM_ADD_CAPACITY_FAILURE"
	ErrorVcenterCredsUpdate                    ErrorType = "ESX_LCM_VCENTER_CREDS_UPDATE_FAILURE"
	ErrorGetClusters                           ErrorType = "ESX_LCM_UNABLE_TO_FETCH_CLUSTERS"
	ErrorZoneDeleteClustersPreconditionFailure ErrorType = "ESX_LCM_DELETE_ZONE_CLUSTERS_PRECONDITION_FAILED"

	ErrorZoneGetServers                          ErrorType = "LCM_UNABLE_TO_GET_ZONE_SERVERS"
	ErrorZoneUpdateServers                       ErrorType = "LCM_UNABLE_TO_UPDATE_ZONE_SERVERS"
	ErrorSynchronizeInfraSystems                 ErrorType = "LCM_UNABLE_TO_SYNCHRONIZE_INFRA"
	ErrorEnablingInfraSystems                    ErrorType = "LCM_UNABLE_TO_ENABLE_INFRA"
	ErrorDisablingInfraSystems                   ErrorType = "LCM_UNABLE_TO_DISABLE_INFRA"
	ErrorZoneDeleteServersPreconditionFailure    ErrorType = "LCM_DELETE_ZONE_SERVERS_PRECONDITION_FAILED"
	ErrorDeleteZone                              ErrorType = "LCM_UNABLE_TO_DELETE_ZONE"
	ErrorZoneServersRoleApplyPreconditionFailure ErrorType = "LCM_ZONE_SERVERS_ROLE_APPLY_PRECONDITION_FAILED"
	ErrorZoneRoleApplyPreconditionFailure        ErrorType = "LCM_ZONE_ROLE_APPLY_PRECONDITION_FAILED"

	ErrorHPEGatewayNotResponding  ErrorType = "LCM_HPE_GATEWAY_NOT_RESPONDING"
	ErrorConfiguringNeutronServer ErrorType = "LCM_UNABLE_TO_CONFIGURE_NEUTRON_SERVER"
	ErrorHPEKVMGateway            ErrorType = "LCM_HPE_GATEWAY_KVM_ERROR"
)
