//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package common

import (
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestServiceResolution(t *testing.T) {
	StartLogs()
	assert := assert.New(t)

	host, err := resolve("127.0.0.1", "", time.Duration(time.Second), false, 10)

	assert.NoError(err)
	assert.Equal("127.0.0.1", host)
}
