//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package common

import (
	log "github.hpe.com/kronos/kelog"
	"io"
	"net/http"
	"os"
	"time"
)

var outputStream io.Writer

func init() {
	StartLogs()
}

func GetLogOutputStream() io.Writer {
	return outputStream
}

// FIXME make StartLogs private
func StartLogs() {

	// Testing has shown that calling StartLogs multiple times would cause the file to be partially rewritten, which
	// is why this check is necessary. Making StartLogs private and delegating its startup to init() would solve it.
	if outputStream == nil {
		outputStream = os.Stdout
	}
}

func Logger(fn http.HandlerFunc, name string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		start := time.Now().UTC()

		fn(w, r)

		log.Debugf(
			"%s %s %s %s",
			r.Method,
			r.RequestURI,
			name,
			time.Since(start),
		)
	}
}
