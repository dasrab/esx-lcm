//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package common

import (
	"reflect"
	"strings"
)

/*
Dive in a struct and trim space of any string (left and right spaces)
It has to be passed a pointer to the struct (E.g. TrimSpace(&structName))
*/
func TrimSpace(obj interface{}) {
	elem := reflect.ValueOf(obj).Elem()
	trimSpaceRecursive(elem)
}

func trimSpaceRecursive(elem reflect.Value) {
	switch elem.Kind() {
	case reflect.Struct:
		for i := 0; i < elem.NumField(); i += 1 {
			trimSpaceRecursive(elem.Field(i))
		}
	case reflect.Slice:
		for i := 0; i < elem.Len(); i += 1 {
			trimSpaceRecursive(elem.Index(i))
		}
	case reflect.String:
		curr := elem.String()
		elem.SetString(strings.TrimSpace(curr))
	}
}
