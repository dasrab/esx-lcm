//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package common

import (
	"time"

	"github.com/miekg/dns"
	log "github.hpe.com/kronos/kelog"
)

// Attempts to resolve a service namespace by using a dns server:
//
//	host, err := ResolveServiceHostname("syn-postgres.hellfire.svc.cluster.local")
//
// The dns server option has to be enabled in the ism.properties file. The dns server and timeout are also configurable.
//
// If it manages to resolve a service, the IP of that service is returned, which can then be used to connect to the
// service, i.e, for a postgres database connection through sqlx:
//
//	data := fmt.Sprintf("user=test_user dbname=test_db sslmode=disable host=%s port=5432", svc)
//	con.db, _ = sqlx.Connect("postgres", data)
//
// However, if the operation fails with an error (or if no service is found) the function assumes that the given service
// namespace may be the service hostname itself, and returns its value. This allows this function to provide a very
// flexible yet robust service resolution.
//
// For the Hellfire use case, when running under kubernetes a service namespace is expected, which this resolver will
// use to return the service hostname. If, however, the container is running without kubernetes, it might receive either
// an IP (when running at the host network stack) or the hostname of a linked container. In either case, this resolver
// will fail, and return the namespace parameter as service hostname -- which is the expected host value in the given
// environment for connecting with other containers.
/*
func ResolveServiceHostname(namespace string) (string, error) {
	timeout := time.Duration(properties.ISM.DNS.Timeout * time.Millisecond)
	server := properties.ISM.DNS.Server
	enable := properties.ISM.DNS.Enable
	retries := properties.ISM.DNS.Retries
	return resolve(namespace, server, timeout, enable, retries)
}
*/
func resolve(namespace string, server string, timeout time.Duration, enable bool, retries int) (host string, err error) {

	if enable == false {
		return namespace, nil
	}

	for reqCount := 1; reqCount <= retries; reqCount++ {
		log.Infof("Run request (attempt = %v)", reqCount)
		log.Infof("Searching for hosts in namespace %s @ dns server %s", namespace, server)

		hosts, err := lookupHosts(namespace, server, timeout)

		// The logs are set to Warning, because a failure to get a host does not equal to an error; indeed, as per the
		// function description, it might simply mean that this is not running in a kubernetes environment and that the
		// namespace provided is the service hostname itself.
		if err != nil || len(hosts) == 0 {
			host = namespace
			log.Warnf("Failed to get a service for namespace %s @ dns server %s - Will attempt to resolve "+
				"namespace %d more time(s).", namespace, server, retries-reqCount)
			//If last retry fails, then panic
			if reqCount == retries {
				log.Errorf("Failed to resolve namespace %s", namespace)
				panic(err)
			}
			continue
		}
		if len(hosts) > 1 {
			host = hosts[0]
			log.Warnf("Found %d hostnames for namespace %s @ dns server %s: %v - this warning was "+
				"not expected and the resolver will pick %s as hostname for this service", len(hosts),
				namespace, server, hosts, host)
			break
		}
		if len(hosts) == 1 {
			host = hosts[0]
			log.Infof("Found service %s for namespace %s @ dns server %s", host, namespace, server)
			break
		}
	}

	return host, err
}

// Search for hostnames in the given namespace using a dns server.
func lookupHosts(namespace string, server string, timeout time.Duration) (hosts []string, err error) {
	c := dns.Client{Timeout: timeout, SingleInflight: true}
	m := dns.Msg{}

	m.SetQuestion(namespace+".", dns.TypeA)
	r, _, err := c.Exchange(&m, server+":53")

	if err != nil {
		log.Warnf("Error connecting to host in namespace %s @ %s: %s", namespace, server, err)
		return hosts, err
	}

	for _, ans := range r.Answer {
		record := ans.(*dns.A)
		hosts = append(hosts, record.A.String())
	}

	return hosts, err
}
