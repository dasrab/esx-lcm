//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package common

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestGetNameAndUuidFromURI(t *testing.T) {
	assert := assert.New(t)
	StartLogs()

	assert.Equal("tasks", GetResourceNameFromUri("/rest/tasks/1"))
	assert.Equal("1", GetResourceUuidFromUri("/rest/tasks/1"))

	assert.Equal("tasks", GetResourceNameFromUri("/rest/tasks"))
	assert.Equal("", GetResourceUuidFromUri("/rest/tasks"))

	assert.Equal("", GetResourceNameFromUri("tasks/1"))
	assert.Equal("", GetResourceUuidFromUri("tasks/1"))
}

func TestGetIsmURIFromURI(t *testing.T) {
	assert := assert.New(t)
	StartLogs()

	myType, err := GetIsmURIFromURI("/rest/tasks/1")
	assert.NoError(err)
	assert.Equal(URITaskResource, myType)

	myType, err = GetIsmURIFromURI("/rest/infrastructure-systems/1")
	assert.NoError(err)
	assert.Equal(URIInfrastructureSystem, myType)

}

func TestNegativeUnknownURI(t *testing.T) {
	assert := assert.New(t)
	StartLogs()

	myType, err := GetIsmURIFromURI("/rest/lala/1")
	assert.Error(err)
	assert.Empty(string(myType))
}

func TestNegativeInvalidURI(t *testing.T) {
	assert := assert.New(t)
	StartLogs()

	myType, err := GetIsmURIFromURI("/lala/1")
	assert.Error(err)
	assert.Empty(string(myType))
}

func TestNegativeInvalidURI2(t *testing.T) {
	assert := assert.New(t)
	StartLogs()

	myType, err := GetIsmURIFromURI("2221")
	assert.Error(err)
	assert.Empty(string(myType))
}
