//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package common

import (
	"fmt"
	"strings"
)

type IsmURI string

const ExpectedSlashCountOnURI int = 2
const ExpectedSlashCountOnURIWithUUID int = 3

const (
	URITaskResource                   IsmURI = "/rest/tasks"
	URIInfrastructureSystem           IsmURI = "/rest/infrastructure-systems"
	URIInfrastructureSystemAllocate   IsmURI = "/rest/infrastructure-systems/allocate"
	URIInfrastructureSystemDeAllocate IsmURI = "/rest/infrastructure-systems/deallocate"
	URIResourceProfileName            IsmURI = "/rest/resource-profiles"
	URIFileServer                     IsmURI = "/rest/scripts"

	//Zones Clusters API
	URIZone IsmURI = "/rest/zones"

	//Zone Environment API
	URIZoneEnvironment = "/rest/zone-environment"
	URIZoneController  = "/rest/zone-controller"
)

var ismURIs = []IsmURI{
	URITaskResource,
	URIInfrastructureSystem,
	URIResourceProfileName,
}

func GetIsmURIFromURI(fullURI string) (IsmURI, error) {
	fullURIStrings := strings.Split(fullURI, "/")
	if len(fullURIStrings) >= 3 {
		targetResource := fullURIStrings[2]
		for _, uriType := range ismURIs {
			if GetResourceNameFromUri(uriType) == targetResource {
				return uriType, nil
			}
		}
	}
	errorDetails := fmt.Sprintf("Could not find a suitable URI for %s", fullURI)
	return "", NewApplicationError(ErrorInvalidUri, errorDetails)
}

//TODO: Improve validations and error if invalid URI
func GetResourceNameFromUri(fullURI IsmURI) string {
	fullURIStrings := strings.Split(string(fullURI), "/")
	if len(fullURIStrings) > ExpectedSlashCountOnURI {
		return fullURIStrings[2]
	} else {
		return ""
	}
}

//TODO: Improve validations and error if invalid URI
func GetResourceUuidFromUri(fullURI IsmURI) string {
	fullURIStrings := strings.Split(string(fullURI), "/")
	if len(fullURIStrings) > ExpectedSlashCountOnURIWithUUID {
		return fullURIStrings[3]
	} else {
		return ""
	}
}

//BuildURI concatenates a base URL with an ID to generate an object URI
func BuildUri(baseUrl IsmURI, uuid string) string {
	return string(baseUrl) + "/" + uuid
}
