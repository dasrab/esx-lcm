//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package common

const (
	AuthTokenHeader        = "X-Auth-Token"
	ApiVersionHeader       = "X-API-Version"
	HTTPBasicAuthHeader    = "Authorization"
	HTTPBasicAuthMethod    = "Basic"
	AcceptHeader           = "Accept"
	AcceptHeaderValue      = "application/json"
	ContentTypeHeader      = "Content-Type"
	ContentTypeHeaderValue = "application/json"
	DefaultHostname        = "http://localhost:"
)

type HTTPRequestType int

const (
	HTTPPublicRequest HTTPRequestType = iota
	HTTPPrivateRequest
)
