// (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"fmt"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"strconv"
)

type (
	OperationType string
)

const (
	Create   = "Create"
	Expand   = "Expand"
	Contract = "Contract"
	Delete   = "Delete"
)

var (
	maxNoOfClusters   = properties.ISM.CapacityHandler.MaxClusters
	maximumNoOfNodes  = properties.ISM.CapacityHandler.MaxNodes
	minimumNofOfNodes = properties.ISM.CapacityHandler.MinimumNodes
)

var runFilters = RunFilters

type CapacityExecutorInterface interface {
	HorizontalScaleOut(model.Zone, int) CapacityOperationResult
	VerticalScaleUp(model.Zone, int) CapacityOperationResult
}

type CapacityOperationResult struct {
	Clusters []ClusterResult
}

type ClusterResult struct {
	ClusterName string
	NodeCount   int
	Operation   OperationType
}

type CapacityExecutor struct{}

type ScaleUpResult struct{}

var CapacityExecutorInst CapacityExecutorInterface

func init() {
	CapacityExecutorInst = CapacityExecutor{}
}

func distributeNodes(totalClustersInZone, noOfRemainingNodes int, clusters []ClusterResult) int {
	addOnNodes := int(noOfRemainingNodes / len(clusters))
	if totalClustersInZone < maxNoOfClusters {
		if addOnNodes <= 1 {
			for c := 0; c < noOfRemainingNodes; c++ {
				clusters[c].NodeCount += 1
			}
			noOfRemainingNodes = 0
			log.Infof("Successfully distributed all nodes.")
		} else if addOnNodes > 1 {
			for c := 0; c < len(clusters); c++ {
				clusters[c].NodeCount += 1
			}
			noOfRemainingNodes -= len(clusters)
		}
	} else {
		if addOnNodes < 1 {
			for c := 0; c < noOfRemainingNodes; c++ {
				clusters[c].NodeCount += 1
			}
			noOfRemainingNodes = 0
			log.Infof("Successfully distributed all nodes.")
		} else if addOnNodes >= 1 {
			for c := 0; c < len(clusters); c++ {
				clusters[c].NodeCount += 1
			}
			noOfRemainingNodes -= len(clusters)
		}
	}
	return noOfRemainingNodes
}

func (c CapacityExecutor) HorizontalScaleOut(zone model.Zone, capacity int) CapacityOperationResult {
	clusterPrefix := zone.Name + "-cluster-"
	no_of_remaining_nodes := capacity
	actual_clusters_in_zone := len(zone.Clusters)
	total_clusters_in_zone := actual_clusters_in_zone
	newClusters := []ClusterResult{}
	expandClusters := []ClusterResult{}
	expand_cluster_names := []string{}
	for no_of_remaining_nodes > 0 {
		if total_clusters_in_zone < maxNoOfClusters {
			if no_of_remaining_nodes/minimumNofOfNodes >= 1 {
				// Create cluster with minimumNofOfNodes
				newCluster := ClusterResult{
					ClusterName: clusterPrefix + strconv.Itoa(total_clusters_in_zone),
					NodeCount:   minimumNofOfNodes,
					Operation:   Create,
				}
				log.Infof("Creating cluster... ClusterResult: %v", newCluster)
				newClusters = append(newClusters, newCluster)
				// A cluster is created with minimumNofOfNodes. Subtract the remaining with minimumNofOfNodes.
				no_of_remaining_nodes = no_of_remaining_nodes - minimumNofOfNodes
				log.Debugf("No of remaining nodes: %v", no_of_remaining_nodes)
				// Increment the count of total_clusters_in_zone.
				total_clusters_in_zone = total_clusters_in_zone + 1
				log.Debugf("Total clusters in zone: %v", total_clusters_in_zone)
			} else {
				if len(newClusters) > 0 {
					// After creating cluster with minimumNoOfNodes,
					// If there are any remaining nodes then distribute them.
					log.Infof("Distributing the remaining nodes '%v' after creating the "+
						"clusters.", no_of_remaining_nodes)
					no_of_remaining_nodes = distributeNodes(total_clusters_in_zone, no_of_remaining_nodes, newClusters)
					if no_of_remaining_nodes == 0 {
						continue
					}
				}
				// After distribution, still there are some remaining nodes !
				// Run minimum host count filter and get the clusters with minimum host count.
				// Distribute the remaining nodes among these clusters.
				log.Infof("Remaining nodes %v will be distributed after getting the clusters "+
					"with minimum host count from One View.", no_of_remaining_nodes)
				if total_clusters_in_zone-len(newClusters) > 0 {
					filterContext := FilterContext{
						Zone:           &zone,
						TargetClusters: []string{},
					}
					cluster_names, err := runFilters(filterContext)
					if len(cluster_names) == 0 {
						panic(common.NewApplicationError(common.ErrorAddCapacity,
							fmt.Sprintf("Couldn't get any clusters from One View with minimum host count "+
								"that mathes the clusters of zone")))
					}
					expand_cluster_names = cluster_names
					if err != nil {
						panic(err)
					}
					log.Infof("Distributing the remaining nodes %v by expanding the clusters %v",
						no_of_remaining_nodes, expand_cluster_names)
					// Distribute the remaining nodes by Expanding the cluster.
					for i, clusterName := range expand_cluster_names {
						if i == no_of_remaining_nodes {
							// expandClusters should not be greater than no_of_remaining_nodes
							break
						}
						existingCluster := ClusterResult{
							ClusterName: clusterName,
							NodeCount:   0,
							Operation:   Expand,
						}
						expandClusters = append(expandClusters, existingCluster)
					}
					no_of_remaining_nodes = distributeNodes(total_clusters_in_zone, no_of_remaining_nodes, expandClusters)
				}
			}
		} else {
			if actual_clusters_in_zone >= 1 {
				log.Infof("All clusters are created, Nodes will be now distributed by " +
					"expanding clusters.")
				// Pure Expand logic
				// hostCountFilter should run only once for the first time
				if len(expandClusters) < 1 {
					log.Infof("Running host count filter only once to get clusters with " +
						"minimum host count...")
					filterContext := FilterContext{
						Zone:           &zone,
						TargetClusters: []string{},
					}
					cluster_names, err := runFilters(filterContext)
					if len(cluster_names) == 0 {
						panic(common.NewApplicationError(common.ErrorAddCapacity,
							fmt.Sprintf("Couldn't get any clusters from One View with minimum host count "+
								"that mathes the clusters of zone")))
					}
					expand_cluster_names = cluster_names
					if err != nil {
						panic(err)
					}
					log.Infof("Creating expand cluster object for clusters %v", expand_cluster_names)
					for _, clusterName := range expand_cluster_names {
						existingCluster := ClusterResult{
							ClusterName: clusterName,
							NodeCount:   0,
							Operation:   Expand,
						}
						expandClusters = append(expandClusters, existingCluster)
					}
				} else {
					// "Create (maxClusters reached) + Expand" scenario. Expand the nodes in the created newCluster object.
					if len(newClusters) >= 1 {
						log.Infof("Distributing nodes to the newly created cluster objects...")
						for c := 0; c < len(newClusters); c++ {
							newClusters[c].NodeCount += 1
						}
						no_of_remaining_nodes -= len(newClusters)
					}
				}
				no_of_remaining_nodes = distributeNodes(total_clusters_in_zone, no_of_remaining_nodes, expandClusters)
			} else {
				// Part of the Create flow  >36
				if len(newClusters) > 0 {
					// After creating cluster with minimumNoOfNodes,
					// If there are any remaining nodes then distribute them.
					log.Infof("All the %v clusters are created with %v nodes. And still there are "+
						"some remaining nodes %v. Will distribute them among all clusters.",
						maxNoOfClusters, minimumNofOfNodes, no_of_remaining_nodes)
					no_of_remaining_nodes = distributeNodes(total_clusters_in_zone, no_of_remaining_nodes, newClusters)
				}
			}
		}
	}
	// TODO: We should create nodes based on no_of_remaining_nodes instead of expand_cluster_names
	// This will help us to get rid of this removing 0 node count and distribution will be in order.
	// Remove 0 NodeCount from expandClusters
	k := 0
	for _, expandCluster := range expandClusters {
		if expandCluster.NodeCount > 0 {
			expandClusters[k] = expandCluster
			k++
		}
	}
	expandClusters = expandClusters[:k]

	// Append both new clusters and expand clusters list
	newClusters = append(newClusters, expandClusters...)
	capacityOperationResult := CapacityOperationResult{
		Clusters: newClusters,
	}
	return capacityOperationResult
}

func (c CapacityExecutor) VerticalScaleUp(zone model.Zone, capacity int) CapacityOperationResult {
	return CapacityOperationResult{}
}
