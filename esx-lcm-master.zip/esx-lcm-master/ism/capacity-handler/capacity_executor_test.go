// (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"strconv"
	"testing"
)

type fakeHostFilter struct {
	context FilterContext
}

func (f *fakeHostFilter) RunFilters(context FilterContext) ([]string, error) {
	f.context = context
	clusterNames := []string{}
	zone := f.context.Zone
	filteredOVClusters := []Member{}
	for _, cluster := range zone.Clusters {
		hostURIs := []string{}
		for c := 0; c < cluster.NodeCount; c++ {
			hostURIs = append(hostURIs, "host-"+strconv.Itoa(c))
		}
		member := Member{
			Name:               cluster.Name,
			HypervisorHostUris: hostURIs,
		}
		filteredOVClusters = append(filteredOVClusters, member)
	}
	minHostCount := getMinHostCount(zone.Clusters)
	for _, cluster := range zone.Clusters {
		if cluster.NodeCount == minHostCount {
			clusterNames = append(clusterNames, cluster.Name)
		}
	}
	return clusterNames, nil
}

func GetFakeZone(existingClusters int) model.Zone {
	zoneName := "fakeZone"
	clusterPrefix := zoneName + "-cluster-"
	clusters := []model.InfrastructureSystem{}
	for c := 0; c < existingClusters; c++ {
		ism := model.InfrastructureSystem{Name: clusterPrefix + strconv.Itoa(c),
			NodeCount: c + 1}
		clusters = append(clusters, ism)
	}
	return model.Zone{Clusters: clusters, Name: zoneName}
}

func GetFakeZoneFullClusters(existingClusters int) model.Zone {
	zoneName := "fakeZone"
	clusterPrefix := zoneName + "-cluster-"
	clusters := []model.InfrastructureSystem{}
	for c := 0; c < existingClusters; c++ {
		ism := model.InfrastructureSystem{Name: clusterPrefix + strconv.Itoa(c),
			NodeCount: 4}
		clusters = append(clusters, ism)
	}
	return model.Zone{Clusters: clusters, Name: zoneName}
}

func TestCapacityExecutorMultipleOfMinimumNodes(t *testing.T) {
	// Happy path: Multiple of minimumNodes test when there are no existing clusters !
	existing_clusters := 0
	zone := GetFakeZone(existing_clusters)
	for i := 1; i <= maxNoOfClusters; i++ {
		capacity := minimumNofOfNodes * i
		result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
		for _, cluster := range result.Clusters {
			assert.Equal(t, cluster.NodeCount, minimumNofOfNodes)
		}
	}
}

func TestCapacityExecutorOperationType(t *testing.T) {
	// Happy path: Multiple of minimumNodes test operation is "Create" for all clusters
	existing_clusters := 0
	zone := GetFakeZone(existing_clusters)
	for i := 1; i <= maxNoOfClusters; i++ {
		capacity := minimumNofOfNodes * i
		result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
		for _, cluster := range result.Clusters {
			assert.Equal(t, cluster.Operation, OperationType(Create))
		}
	}
}

func TestCapacityExecutorExistingCluster2(t *testing.T) {
	// Happy path: One existing cluster is there and requested capacity is 4.
	// The algo should create One cluster with 4 node.
	existing_clusters := 1
	capacity := 4
	zone := GetFakeZone(existing_clusters)
	result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
	assert.Equal(t, len(result.Clusters), 1)
	assert.Equal(t, result.Clusters[0].Operation, OperationType(Create))
	assert.Equal(t, result.Clusters[0].NodeCount, capacity)
}

func TestCapacityExecutorMinHostFilter1(t *testing.T) {
	// One existing cluster is there and requested capacity is 5.
	// The algo should "Create" One cluster with 4+1 node.
	// And should "Expand" another cluster with 1 node
	existing_clusters := 1
	capacity := 6
	zone := GetFakeZoneFullClusters(existing_clusters)
	for c := 0; c < len(zone.Clusters); c++ {
		zone.Clusters[c].NodeCount = minimumNofOfNodes
	}
	f := &fakeHostFilter{
		context: FilterContext{
			Zone:           &zone,
			TargetClusters: []string{},
		},
	}
	runFilters = f.RunFilters
	result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
	for _, cluster := range result.Clusters {
		if cluster.Operation == OperationType(Create) {
			assert.Equal(t, cluster.NodeCount, minimumNofOfNodes+1)
		} else if cluster.Operation == (OperationType(Expand)) {
			assert.Equal(t, cluster.NodeCount, 1)
		}
	}
}

func TestCapacityExecutorMinHostFilter2(t *testing.T) {
	// 12 clusters * 3 nodes should be created
	// remaining 4 nodes should be distributed
	existing_clusters := 0
	capacity := 52
	zone := GetFakeZone(existing_clusters)
	f := &fakeHostFilter{
		context: FilterContext{
			Zone:           &zone,
			TargetClusters: []string{},
		},
	}
	runFilters = f.RunFilters
	result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
	assert.Equal(t, len(result.Clusters), maxNoOfClusters)
	clusterWithNodeCount4 := 0
	clusterWithNodeCount5 := 0
	for _, cluster := range result.Clusters {
		assert.Equal(t, cluster.Operation, OperationType(Create))
		if cluster.NodeCount == 4 {
			clusterWithNodeCount4++
		} else if cluster.NodeCount == 5 {
			clusterWithNodeCount5++
		}
	}
	assert.Equal(t, clusterWithNodeCount4, 8)
	assert.Equal(t, clusterWithNodeCount5, 4)
}

func TestCapacityExecutorExpand1(t *testing.T) {
	// No new clusters will be created.
	// All 40 nodes will be expanded 4 x 4 + 8 x 3
	existing_clusters := 12
	capacity := 40
	zone := GetFakeZoneFullClusters(existing_clusters)
	f := &fakeHostFilter{
		context: FilterContext{
			Zone:           &zone,
			TargetClusters: []string{},
		},
	}
	runFilters = f.RunFilters
	result := CapacityExecutorInst.HorizontalScaleOut(zone, capacity)
	assert.Equal(t, len(result.Clusters), maxNoOfClusters)
	clusterWithNodeCount4 := 0
	clusterWithNodeCount3 := 0
	for _, cluster := range result.Clusters {
		assert.Equal(t, cluster.Operation, OperationType(Expand))
		if cluster.NodeCount == 4 {
			clusterWithNodeCount4++
		} else if cluster.NodeCount == 3 {
			clusterWithNodeCount3++
		}
	}
	assert.Equal(t, clusterWithNodeCount4, 4)
	assert.Equal(t, clusterWithNodeCount3, 8)
}
