// (C) Copyright 2017 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"fmt"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

type CapacityHandlerIf interface {
	AddCapacity(CapacityContext) (CapacityOperationResult, error)
	ReduceCapacity(CapacityContext) (CapacityOperationResult, error)
}

type ZoneCapacityHandler struct{}

var CapacityHandler CapacityHandlerIf

func init() {
	CapacityHandler = ZoneCapacityHandler{}
}

func addCapacityPreCheck(context CapacityContext) error {
	log.Infof("Requested capacity: %v", context.Capacity)
	log.Infof("No. of clusters in zone: %v", len(context.Zone.Clusters))
	if len(context.Zone.Clusters) == 0 {
		// 1st cluster ! Min nodes are required to create a cluster
		if context.Capacity < minimumNofOfNodes {
			return common.NewApplicationError(common.ErrorAddCapacity,
				fmt.Sprintf("Requested number of nodes [%v] are lesser than minimum required nodes "+
					"[%v] to create a cluster", context.Capacity, minimumNofOfNodes))
		}
	}
	if context.Capacity > (maxNoOfClusters * maximumNoOfNodes) {
		return common.NewApplicationError(common.ErrorAddCapacity,
			fmt.Sprintf("Requested nodes %v exceded maximum supported nodes %v",
				context.Capacity, maxNoOfClusters*maximumNoOfNodes))
	}
	return nil
}

func (z ZoneCapacityHandler) AddCapacity(context CapacityContext) (CapacityOperationResult, error) {
	var result CapacityOperationResult
	err := addCapacityPreCheck(context)
	if err != nil {
		return result, err
	}
	log.Infof("Performing add Capacity %vly", context.ScaleType)
	if context.ScaleType == Horizontal {
		result = CapacityExecutorInst.HorizontalScaleOut(context.Zone, context.Capacity)
	} else if context.ScaleType == Vertical {
		result = CapacityExecutorInst.VerticalScaleUp(context.Zone, context.Capacity)
	}
	log.Infof("Add Capacity result: %v", result)
	return result, nil
}

func (z ZoneCapacityHandler) ReduceCapacity(context CapacityContext) (CapacityOperationResult, error) {
	return CapacityOperationResult{}, nil
}
