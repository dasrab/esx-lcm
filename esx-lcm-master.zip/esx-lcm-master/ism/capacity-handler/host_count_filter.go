// (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type hostCountFilter struct {
}

type Member struct {
	Name               string   `json:"name"`
	HypervisorHostUris []string `json:"hypervisorHostUris"`
}

type HypervisorClusters struct {
	Members []Member
}

func (hc hostCountFilter) Run(filterContext FilterContext) ([]string, error) {
	zone := *filterContext.Zone
	filteredInfrastructureSystems := filterContext.TargetClusters
	minHostCount := getMinHostCount(zone.Clusters)

	for _, member := range zone.Clusters {
		if member.NodeCount == minHostCount {
			filteredInfrastructureSystems = append(filteredInfrastructureSystems, member.Name)
		}
	}
	log.Infof("Clusters with minimum host count %v are %v", minHostCount, filteredInfrastructureSystems)
	return filteredInfrastructureSystems, nil
}

func getMinHostCount(clusters []model.InfrastructureSystem) int {
	minHostCount := clusters[0].NodeCount
	for _, cluster := range clusters {
		if cluster.NodeCount < minHostCount {
			minHostCount = cluster.NodeCount
		}
	}
	return minHostCount
}
