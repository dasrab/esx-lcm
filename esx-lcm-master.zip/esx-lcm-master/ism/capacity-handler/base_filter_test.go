// (C) Copyright 2017 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"github.com/stretchr/testify/mock"
	"testing"
)

type FilterMock struct {
	mock.Mock
}

func (hc FilterMock) Run(filterContext FilterContext) ([]string, error) {
	args := hc.Called(filterContext)
	return args.Get(0).([]string), args.Error(1)
}

func SetMockedFilterType(fm Filter) {
	FilterTypes = map[string]Filter{
		HostCountFilterType: fm,
	}
}

func doesitContain(infralist []string, infra string) bool {
	for _, item := range infralist {
		if item == infra {
			return true
		}
	}
	return false
}

func TestRunFilterScheduler(t *testing.T) {
	testCases := []struct {
		ctx FilterContext
	}{
		{
			ctx: FilterContext{},
		},
	}

	for _, tc := range testCases {
		mockFilter := new(FilterMock)
		mockedClusters := []string{"c1", "c2"}
		mockFilter.On("Run", tc.ctx).Return(mockedClusters, nil)
		SetMockedFilterType(mockFilter)
		filteredInfra, _ := RunFilters(tc.ctx)
		for _, item := range mockedClusters {
			if !doesitContain(filteredInfra, item) {
				t.Fail()
			}
		}
	}
}
