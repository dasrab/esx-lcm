//(C) Copyright 2017 Hewlett Packard Enterprise Development LP

package capacity_handler

import (
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type Filter interface {
	Run(FilterContext) ([]string, error)
}

const (
	HostCountFilterType = "hostCountFilter"
)

var FilterTypes = map[string]Filter{
	HostCountFilterType: hostCountFilter{},
}

type FilterContext struct {
	Zone           *model.Zone
	TargetClusters []string
}

func RunFilters(context FilterContext) ([]string, error) {
	var targetClusters []string
	var err error
	enabledFilters := properties.ISM.CapacityHandler.EnabledFilters
	for _, filterType := range enabledFilters {
		log.Infof("Loading filter : [ %v ]", filterType)
		filter := FilterTypes[filterType].(Filter)
		targetClusters, err = filter.Run(context)
		context.TargetClusters = targetClusters
		if err != nil {
			return nil, err
		}
		log.Infof("Filter : [ %v ] returned [ %v ] clusters", filterType, targetClusters)
	}
	return targetClusters, nil
}
