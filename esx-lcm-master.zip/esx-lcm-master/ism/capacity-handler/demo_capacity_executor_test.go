// (C) Copyright 2017 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"fmt"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"strconv"
	"testing"
)

var minClusters = 0

func TestDemo(t *testing.T) {
	capacities := []int{4, 5, 1, 1, 2, 4, 1, 1}
	//capacities := []int{36, 40, 2}
	//capacities := []int{77, 40, 2}
	//capacities := []int{170, 18}
	zone := GetFakeZone(minClusters)

	for _, capacity := range capacities {

		f := fakeHostFilter{
			context: FilterContext{
				Zone:           &zone,
				TargetClusters: []string{},
			},
		}
		runFilters = f.RunFilters

		cc := CapacityContext{
			Zone:      zone,
			Capacity:  capacity,
			ScaleType: Horizontal,
		}

		results, err := ZoneCapacityHandler{}.AddCapacity(cc)
		if err != nil {
			panic(err)
		}

		fmt.Println("Allocation for Capacity : ", capacity)
		fmt.Println("\n", results)

		for _, result := range results.Clusters {
			if result.Operation == Expand {
				for c := 0; c < len(zone.Clusters); c++ {
					if result.ClusterName == zone.Clusters[c].Name {
						zone.Clusters[c].NodeCount += result.NodeCount
					}
				}
			} else if result.Operation == Create {
				cluster := model.InfrastructureSystem{
					Name:      result.ClusterName,
					NodeCount: result.NodeCount,
				}
				zone.Clusters = append(zone.Clusters, cluster)
			}
		}

		fmt.Println("\nAggregated Cluster node count:")
		fmt.Println()
		for _, cluster := range zone.Clusters {
			fmt.Print(" " + cluster.Name + " = " + strconv.Itoa(cluster.NodeCount))
		}
		fmt.Println()
		fmt.Println()
		fmt.Println()

		minClusters++
	}
}
