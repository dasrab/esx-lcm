// (C) Copyright 2017 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type (
	Scaletype string
)

const (
	Horizontal = Scaletype("Horizontal")
	Vertical   = Scaletype("Vertical")
)

type CapacityContext struct {
	ScaleType Scaletype
	Capacity  int
	Zone      model.Zone
}

func NewCapacityContext() CapacityContext {
	c := CapacityContext{}
	return c
}
