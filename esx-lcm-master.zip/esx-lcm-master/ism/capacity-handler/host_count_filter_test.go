// (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package capacity_handler

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

var (
	fakeClusters = HypervisorClusters{}
)

type fakeToken struct {
}

type fakeOVClusters struct {
}

type fakeSession struct {
}

func TestRunHostCountSchedulerSingleMinHost(t *testing.T) {
	// ZoneClusters : Cluster1, Cluster2, Cluster3
	// OV clusters: Cluster1=2hosts, Cluster2=4hosts, Cluster3=6hosts
	// Filter should return Cluster1 if Cluster1 exists in zone
	zoneClusters := 3
	zone := GetFakeZone(zoneClusters)
	ctx := FilterContext{
		Zone:           &zone,
		TargetClusters: []string{},
	}

	clusters, _ := hostCountFilter{}.Run(ctx)

	assert.Equal(t, len(clusters), 1)
}

func TestRunHostCountSchedulerMultipleMinHost(t *testing.T) {
	// ZoneClusters : Cluster1, Cluster2, Cluster3
	// OV clusters: Cluster1=1host, Cluster2=1host, Cluster3=2hosts
	// Filter should return Cluster1 & Cluster2 if Cluster1 & Cluster2 exists in zone
	zoneClusters := 3
	zone := GetFakeZone(zoneClusters)
	minClusterNames := []string{}
	for _, cluster := range zone.Clusters {
		minClusterNames = append(minClusterNames, cluster.Name)
	}
	zone.Clusters[1].NodeCount = 1
	ctx := FilterContext{
		Zone:           &zone,
		TargetClusters: []string{},
	}

	members := []Member{}

	fakeClusters = HypervisorClusters{
		Members: members,
	}

	clusters, _ := hostCountFilter{}.Run(ctx)
	for _, cluster := range clusters {
		for _, minCluster := range minClusterNames {
			if cluster == minCluster {
				assert.Equal(t, cluster, minCluster)
			}
		}
	}
	assert.NotEqual(t, len(zone.Clusters), len(clusters))

}
