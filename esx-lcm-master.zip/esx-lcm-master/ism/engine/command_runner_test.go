//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package engine

import (
	"bytes"
	"fmt"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"log"
	"testing"
)

const fakeEnginePath = "../../ism-recipes/tests/helper/engineDebug.py"

var (
	buffer *bytes.Buffer
	logger *log.Logger
)

// Mocking Logs so every information that's printed there shows up in buffer
func mockLogs() {
	properties.ISM.Log.LogToFile = false
	buffer = new(bytes.Buffer)
	logger = log.New(buffer, fmt.Sprintf("%s: ", "Test"), log.Ldate|log.Ltime|log.Lshortfile)
}

func TestEngineDebug(t *testing.T) {
	assert := assert.New(t)
	mockLogs()
	cRunner := NewCommandRunner(logger)

	returnJSON := "{\"playbookDetails\": [\"This mock executed successfully\"], \"playbookStatus\": \"WARNING\"}"

	errOut := cRunner.execute("python", []string{fakeEnginePath, "file.yml", fmt.Sprintf("--returnValue=%s", returnJSON)})

	assert.Equal(string(errOut), returnJSON, "StdErr from engineDebug is not expected")
	assert.Contains(buffer.String(), "Mocked engine executing", "StdOut should be printed in the logs")
}

func TestEngineDebugFailure(t *testing.T) {
	assert := assert.New(t)
	mockLogs()
	cRunner := NewCommandRunner(logger)

	returnJSON := fmt.Sprint("This\nis\na\nmulti\nline\nerror")

	errOut := cRunner.execute("python", []string{fakeEnginePath, "file.yml", fmt.Sprintf("--returnValue=%s", returnJSON)})

	assert.Equal(string(errOut), returnJSON, "StdErr from engineDebug is not expected")
	assert.Contains(buffer.String(), "Mocked engine executing", "StdOut should be printed in the logs")
}

func TestCommandRunnerNotFound(t *testing.T) {
	assert := assert.New(t)
	mockLogs()
	cRunner := NewCommandRunner(logger)

	defer func() {
		if err := recover(); err != nil {
			if appError, ok := err.(common.ApplicationError); ok {
				if appError.ErrorCode == common.ErrorExecutionFailure {
					return
				}
			}
		}
		assert.Fail("Expected %v exception - Application not found", common.ErrorExecutionFailure)
	}()

	cRunner.execute("not_an_exec_file", []string{})
	assert.Fail("Expected %v exception - No response from engine error", common.ErrorExecutionFailure)
}
