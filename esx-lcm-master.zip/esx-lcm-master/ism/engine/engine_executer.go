//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

//Package engine is responsible for interfacing the ISM service with the orchestration engine
package engine

import (
	"encoding/json"
	"os"
	"regexp"
	"strings"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	internalLog "github.hpe.com/ncs-vmware/esx-lcm/ism/engine/internal/log"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/playbook"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

const pythonCmd = "python"

type ExecutorInterface interface {
	ExecuteEngine(resource interface{}, playbookType PlaybookType, tags []playbook.Tag,
		ctx playbook.Context, env interface{}) PlaybookResult
}

type EngineExecutor struct {
	commandRunner CommandRunnerInterface
}

//EngineExecutorInstance is the entry point to execute every engine call
var EngineExecutorInstance ExecutorInterface

func init() {
	engineLogger := internalLog.New(common.GetLogOutputStream())
	EngineExecutorInstance = newEngineExecutor(NewCommandRunner(engineLogger))
}

func newEngineExecutor(cRunner CommandRunnerInterface) *EngineExecutor {
	engineExecutor := EngineExecutor{}
	engineExecutor.commandRunner = cRunner
	return &engineExecutor
}

func (eng *EngineExecutor) ExecuteEngine(resource interface{}, playbookType PlaybookType, tags []playbook.Tag,
	ctx playbook.Context, env interface{}) PlaybookResult {
	//check if engine file exists
	log.Debug("Initiating execute engine to call recipes..")
	if _, err := os.Stat(properties.ISM.Engine.EnginePath); os.IsNotExist(err) {
		panic(common.NewApplicationError(common.ErrorExecutionFailure, err.Error()))
	}
	if resource != nil {
		model.ClearSecretInfo(resource)
	}
	pythonArgs, err := eng.createCommandLineArgs(resource, playbookType, tags, ctx, env)
	if err != nil {
		log.Errorf("Creating command line args: %v\n", err)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, err.Error()))
	}

	//Removing secrets for logging
	//TODO During cleanup move this to a fuction
	pythonArgsLog := make([]string, len(pythonArgs))
	copy(pythonArgsLog, pythonArgs)
	regexpKeystonePass := regexp.MustCompile(`"keystonePassword":\s?"(..)+"`)
	regexpMonascaPass := regexp.MustCompile(`"monascaAgentPassword":\s?"(..)+"`)
	regexpHostPass := regexp.MustCompile(`"hostPassword":\s?"(..)+"`)
	regexpPassword := regexp.MustCompile(`"password":\s?"(..)+"`)
	regexpSlash := regexp.MustCompile(`\"+`)

	for i, _ := range pythonArgsLog {
		pythonArgsLog[i] = regexpKeystonePass.ReplaceAllString(pythonArgsLog[i],
			`"keystonePassword": "************************"`)
		pythonArgsLog[i] = regexpMonascaPass.ReplaceAllString(pythonArgsLog[i],
			`"monascaAgentPassword": "************************"`)
		pythonArgsLog[i] = regexpHostPass.ReplaceAllString(pythonArgsLog[i],
			`"hostPassword": "************************"`)
		pythonArgsLog[i] = regexpPassword.ReplaceAllString(pythonArgsLog[i],
			`"password": "************************"`)
		pythonArgsLog[i] = regexpSlash.ReplaceAllString(pythonArgsLog[i],
			``)
		pythonArgsLog[i] = strings.Replace(pythonArgsLog[i], "\n", "", -1)
		pythonArgsLog[i] = strings.Replace(pythonArgsLog[i], "\t", "", -1)
	}

	log.Debugf("Calling engine: %s %v", pythonCmd, pythonArgsLog)
	errOut := eng.commandRunner.execute(pythonCmd, pythonArgs)
	errorMessage := string(errOut)

	log.Debugf("Result from engine:\n\tstdErr: %s", errorMessage)

	// parse errOut to only find our PlaybookResult message so we don't unmarshal extra errors
	r := regexp.MustCompile(`{"playbookDetails":.*"playbookStatus": ".*"}$|{"playbookStatus":.*"playbookDetails":.*}$`)
	matches := r.FindStringSubmatch(errorMessage)

	if len(matches) == 0 {
		log.Errorf("Playbook execution returned an invalid output format")
		panic(common.NewApplicationError(common.ErrorExecutionFailure,
			"Playbook execution returned an invalid output format"))
	}

	playbookOutput := matches[0]

	var result PlaybookResult
	err = json.Unmarshal([]byte(playbookOutput), &result)
	if err != nil {
		log.Errorf("Error unmarshalling engine result: %v", err)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, err.Error()))
	}

	//TODO: json.unmarshal only verifies if the output of the engine is a valid Json
	//We need to validate whether the contents/fields of the json are expected
	return result
}

func (eng *EngineExecutor) createCommandLineArgs(resource interface{}, playbookType PlaybookType, tags []playbook.Tag,
	ctx playbook.Context, env interface{}) ([]string, error) {
	var args []string
	eArg, err := playbook.NewExtraVars(resource, ctx, env)
	if err != nil {
		return nil, err
	}
	if len(tags) == 0 {
		args = []string{properties.ISM.Engine.EnginePath, string(playbookType), eArg}
	} else {
		tagsArg := playbook.NewTags(tags)
		if tagsArg == "" {
			return nil, common.NewApplicationError(common.ErrorExecutionFailure, "Misformatted tags")
		}
		args = []string{properties.ISM.Engine.EnginePath, string(playbookType), tagsArg, eArg}

	}
	return args, nil
}
