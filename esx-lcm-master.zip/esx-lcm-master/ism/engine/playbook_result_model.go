//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package engine

import (
	"fmt"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"strings"
)

type EngineStatus string

const EngineSuccess EngineStatus = "SUCCESS"
const EngineWarning EngineStatus = "WARNING"
const EngineFail EngineStatus = "FAIL"

type PlaybookResult struct {
	Status string                    `json:"playbookStatus"`
	Errors []common.ApplicationError `json:"playbookDetails"`
}

func (pr PlaybookResult) GetHealthStatus() model.HealthStatus {
	status := strings.ToUpper(pr.Status)
	if strings.EqualFold(status, fmt.Sprintf("%s", EngineSuccess)) {
		return model.OK
	} else if strings.EqualFold(status, fmt.Sprintf("%s", EngineWarning)) {
		return model.Warning
	} else if strings.EqualFold(status, fmt.Sprintf("%s", EngineFail)) {
		return model.Critical
	}
	panic("Failed to translate correct status from Engine")
}

func (pr PlaybookResult) GetErrors() []common.ApplicationError {
	if len(pr.Errors) == 0 {
		//Return empty error list
		return []common.ApplicationError{}
	}

	return pr.Errors
}
