//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package engine

import (
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"testing"
)

func TestSuccessResult(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	playbookOutput := "{" +
		"\"playbookStatus\":\"SUCCESS\"," +
		"\"playbookDetails\":[]}"

	var result PlaybookResult
	err := json.Unmarshal([]byte(playbookOutput), &result)
	assert.NoError(err)

	assert.Equal(model.OK, result.GetHealthStatus())
	assert.Equal(0, len(result.GetErrors()))
}

func TestWarningResult(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	playbookOutput := "{" +
		"\"playbookStatus\":\"WARNING\"," +
		"\"playbookDetails\": [" +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_MSG\", " +
		"\"details\":\"I failed\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE\", " +
		"\"data\": [\"example01\"], " +
		"\"canForce\": true" +
		"}" +
		"]}"

	var result PlaybookResult
	err := json.Unmarshal([]byte(playbookOutput), &result)
	assert.NoError(err)

	assert.Equal(model.Warning, result.GetHealthStatus())
	//Warning errors found.
	assert.Equal(1, len(result.GetErrors()))
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_MSG", result.GetErrors()[0].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE", string(result.GetErrors()[0].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_ACT"}, result.GetErrors()[0].RecommendedActions)
	assert.Equal([]string{"example01"}, result.GetErrors()[0].Data)
}

func TestWarningResults(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	playbookOutput := "{" +
		"\"playbookStatus\":\"WARNING\"," +
		"\"playbookDetails\": [" +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_1_MSG\", " +
		"\"details\":\"I failed 1\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_1_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE_1\", " +
		"\"data\": [\"example01\"], " +
		"\"canForce\": true" +
		"}," +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_2_MSG\", " +
		"\"details\":\"I failed 2\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_2_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE_2\", " +
		"\"data\": [\"example02\"], " +
		"\"canForce\": true" +
		"}" +
		"]}"

	var result PlaybookResult
	err := json.Unmarshal([]byte(playbookOutput), &result)
	assert.NoError(err)

	assert.Equal(model.Warning, result.GetHealthStatus())
	//Errors found.
	assert.Equal(2, len(result.GetErrors()))
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_2_MSG", result.GetErrors()[1].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_2", string(result.GetErrors()[1].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_2_ACT"}, result.GetErrors()[1].RecommendedActions)
	assert.Equal([]string{"example02"}, result.GetErrors()[1].Data)

	assert.Equal("HCOE_ISM_ERROR_SAMPLE_1_MSG", result.GetErrors()[0].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_1", string(result.GetErrors()[0].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_1_ACT"}, result.GetErrors()[0].RecommendedActions)
	assert.Equal([]string{"example01"}, result.GetErrors()[0].Data)
}

func TestCriticalResult(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	playbookOutput := "{" +
		"\"playbookStatus\":\"FAIL\"," +
		"\"playbookDetails\": [" +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_MSG\", " +
		"\"details\":\"I failed\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE\", " +
		"\"data\": [\"example01\"], " +
		"\"canForce\": true" +
		"}" +
		"]}"

	var result PlaybookResult
	err := json.Unmarshal([]byte(playbookOutput), &result)
	assert.NoError(err)

	assert.Equal(model.Critical, result.GetHealthStatus())
	//Critical errors found.
	assert.Equal(1, len(result.GetErrors()))
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_MSG", result.GetErrors()[0].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE", string(result.GetErrors()[0].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_ACT"}, result.GetErrors()[0].RecommendedActions)
	assert.Equal([]string{"example01"}, result.GetErrors()[0].Data)
}

func TestCriticalResults(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	playbookOutput := "{" +
		"\"playbookStatus\":\"FAIL\"," +
		"\"playbookDetails\": [" +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_1_MSG\", " +
		"\"details\":\"I failed 1\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_1_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE_1\", " +
		"\"data\": [\"example01\"], " +
		"\"canForce\": true" +
		"}," +
		"{" +
		"\"message\":\"HCOE_ISM_ERROR_SAMPLE_2_MSG\", " +
		"\"details\":\"I failed 2\", " +
		"\"recommendedActions\":[\"HCOE_ISM_ERROR_SAMPLE_2_ACT\"], " +
		"\"nestedErrors\":[], " +
		"\"errorSource\":\"orchestration\", " +
		"\"errorCode\":\"HCOE_ISM_ERROR_SAMPLE_2\", " +
		"\"data\": [\"example02\"], " +
		"\"canForce\": true" +
		"}" +
		"]}"

	var result PlaybookResult
	err := json.Unmarshal([]byte(playbookOutput), &result)
	assert.NoError(err)

	assert.Equal(model.Critical, result.GetHealthStatus())
	//Critical errors found.
	assert.Equal(2, len(result.GetErrors()))
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_2_MSG", result.GetErrors()[1].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_2", string(result.GetErrors()[1].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_2_ACT"}, result.GetErrors()[1].RecommendedActions)
	assert.Equal([]string{"example02"}, result.GetErrors()[1].Data)

	assert.Equal("HCOE_ISM_ERROR_SAMPLE_1_MSG", result.GetErrors()[0].Message)
	assert.Equal("HCOE_ISM_ERROR_SAMPLE_1", string(result.GetErrors()[0].ErrorCode))
	assert.Equal([]string{"HCOE_ISM_ERROR_SAMPLE_1_ACT"}, result.GetErrors()[0].RecommendedActions)
	assert.Equal([]string{"example01"}, result.GetErrors()[0].Data)
}
