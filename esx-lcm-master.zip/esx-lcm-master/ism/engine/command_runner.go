//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package engine

import (
	"bufio"
	"fmt"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	internalLog "github.hpe.com/ncs-vmware/esx-lcm/ism/engine/internal/log"
	"os/exec"
	"strings"
)

type CommandRunnerInterface interface {
	execute(command string, args []string) []byte
}

type commandRunner struct {
	cmd    *exec.Cmd
	logger internalLog.Logger
}

func NewCommandRunner(logger internalLog.Logger) CommandRunnerInterface {
	c := new(commandRunner)
	c.logger = logger
	return c
}

func (this *commandRunner) execute(command string, args []string) []byte {
	//This line creates the command to be executed
	this.cmd = exec.Command(command, args...)

	cmdErrorReader, err := this.cmd.StderrPipe()
	if err != nil {
		message := fmt.Sprintf("Error getting StdErrOutputPipe: %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, message))
	}

	//Create a scanner to the stdErrorInterface
	stdErrScanner := bufio.NewScanner(cmdErrorReader)
	stdErrChannel := make(chan []byte)
	go func() {
		//Scanner.scan is a block call that waits for either the process to stop or something to go in the errBuffer]
		var errLines []string
		for stdErrScanner.Scan() {
			errLine := stdErrScanner.Text()
			errLines = append(errLines, errLine)

		}
		//If the process is killed and returns nothing, stdErrScanner will return an empty byte array
		stdErrChannel <- []byte(strings.Join(errLines[:], "\n"))
	}()

	//Handles in runtime the stdOut of the engine
	cmdOutReader, err := this.cmd.StdoutPipe()
	if err != nil {
		message := fmt.Sprintf("Error getting StdOutPipe: %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, message))
	}

	// Scan stdout
	go internalLog.Scan(cmdOutReader, this.logger)

	// Start the process
	err = this.cmd.Start()
	if err != nil {
		message := fmt.Sprintf("Error starting engine: %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, message))
	}

	//Wait for the process to complete with error
	err = this.cmd.Wait()
	if err == nil {
		message := fmt.Sprint("No response from engine")
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorExecutionFailure, message))
	}

	//Blocking call that waits for the scanner to get the error information from the stdErr
	return <-stdErrChannel
}
