// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import (
	"io"
	"log"
)

// Logger is a common interface shared by the EngineLogger as well as Go's official log package
type Logger interface {
	Printf(format string, v ...interface{})
}

type engineLogger struct {
	logger *log.Logger
}

// New returns a custom logger that redirects the Engine log
func New(writer io.Writer) Logger {
	eLogger := new(engineLogger)
	eLogger.logger = log.New(writer, "", 0)
	return eLogger
}

func (e engineLogger) Printf(format string, v ...interface{}) {
	e.logger.Printf(format, v...)
}
