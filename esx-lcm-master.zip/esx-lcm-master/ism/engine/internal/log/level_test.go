// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestEngineLogLevel(t *testing.T) {
	var tests = []struct {
		level    string
		expected string
	}{
		{"debug", "DEBUG"},
		{"info", "INFO"},
		{"warning", "WARNING"},
		{"error", "ERROR"},
		{"", "NOTSET"},
	}

	for _, test := range tests {
		level := GetLevel(test.level)
		assert.Equal(t, test.expected, level, fmt.Sprintf(
			"GetLevel(%v) => %q, want %q",
			test.level, level, test.expected,
		))
	}
}
