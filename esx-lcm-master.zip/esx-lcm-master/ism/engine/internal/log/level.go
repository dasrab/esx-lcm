// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import "strings"

const (
	Debug   string = "DEBUG"
	Info    string = "INFO"
	Warning string = "WARNING"
	Error   string = "ERROR"
	NotSet  string = "NOTSET"
)

func GetLevel(logLevel string) string {
	if strings.ToUpper(logLevel) == Debug {
		return Debug
	} else if strings.ToUpper(logLevel) == Info {
		return Info
	} else if strings.ToUpper(logLevel) == Warning {
		return Warning
	} else if strings.ToUpper(logLevel) == Error {
		return Error
	}
	return NotSet
}
