// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import (
	"bytes"
	"fmt"
	"log"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
)

func TestScanner(t *testing.T) {
	var buffer *bytes.Buffer
	var logger *log.Logger

	properties.ISM.Log.LogToFile = false

	buffer = new(bytes.Buffer)
	logger = log.New(buffer, fmt.Sprintf("%s: ", "Test"), log.Ldate|log.Ltime|log.Lshortfile)

	output := "engine.py: MainThread: DEBUG: execute_playbook:389: Play Name is Discover Nodes Playbook"

	reader := bytes.NewReader([]byte(output))

	Scan(reader, logger)

	assert.Contains(t, buffer.String(), output)
}
