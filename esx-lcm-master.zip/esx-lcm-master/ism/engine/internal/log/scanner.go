// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import (
	"bufio"
	"io"
)

// Scan creates a new bufio.NewScanner with the reader scanner.Scan(), printing the text to the given logger.
func Scan(reader io.Reader, logger Logger) {
	scanner := bufio.NewScanner(reader)

	// Scanner.scan is a block call that waits for either the process to stop or something to go in the outBuffer
	for scanner.Scan() {
		logger.Printf("%s\n", scanner.Text())
	}
}
