// (C) Copyright 2017 Hewlett Packard Enterprise Development LP

package log

import (
	"bytes"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
)

var (
	buffer *bytes.Buffer
)

func TestEngineLogger(t *testing.T) {
	properties.ISM.Log.LogToFile = false

	var tests = []struct {
		engineOutput string
		loggerOutput string
	}{
		{
			"DEBUG: 2017/03/27 19:14:57 [MainThread] engine.py:402: Play Name is Discover Nodes Playbook",
			"DEBUG: 2017/03/27 19:14:57 [MainThread] engine.py:402: Play Name is Discover Nodes Playbook\n",
		},
		{
			"INFO: 2017/03/27 19:14:57 [MainThread] crypto.py:31: Successfully Decrypted",
			"INFO: 2017/03/27 19:14:57 [MainThread] crypto.py:31: Successfully Decrypted\n",
		},
		{
			"WARNING: 2017/03/27 19:14:57 [MainThread] moduleBase.py:64: Parent Task UUID is empty.",
			"WARNING: 2017/03/27 19:14:57 [MainThread] moduleBase.py:64: Parent Task UUID is empty.\n",
		},
		{
			"ERROR: 2017/03/27 19:14:57 [MainThread] connect:36: Session invalid so creating new session",
			"ERROR: 2017/03/27 19:14:57 [MainThread] connect:36: Session invalid so creating new session\n",
		},
	}
	for _, test := range tests {
		buffer = new(bytes.Buffer)
		reader := bytes.NewReader([]byte(test.engineOutput))

		Scan(reader, New(buffer))

		bufStr := buffer.String()
		assert.Equal(t, test.loggerOutput, bufStr)
	}
}
