//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package engine

import (
	"encoding/json"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/playbook"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"testing"
)

type CommandRunnerMock struct {
	mock.Mock
}

type idmClientMock struct {
	mock.Mock
}

func (m *CommandRunnerMock) execute(command string, args []string) []byte {
	mockArgs := m.Mock.Called()
	return mockArgs.Get(0).([]byte)
}

func (m *idmClientMock) GetToken() (string, error) {
	return "magic token", nil
}

var executorInstance ExecutorInterface

func init() {
	common.StartLogs()
}

func buildPlayBookResult(details []common.ApplicationError, status string) []byte {
	result := PlaybookResult{}
	result.Errors = details
	result.Status = status
	out, _ := json.Marshal(result)
	return out
}

func buildInvalidPlayBookResult() []byte {
	out, _ := json.Marshal("This is a bad output since it doesn't contain a playbook result object")
	return out
}

func TestEngineExecution(t *testing.T) {
	commandRunnerMock := new(CommandRunnerMock)
	mockedError := common.NewApplicationError(common.ErrorExecutionFailure, "This is a mocked success run")
	successPlayBookResult := buildPlayBookResult([]common.ApplicationError{mockedError}, "SUCCESS")
	commandRunnerMock.On("execute").Return(successPlayBookResult)
	executorInstance = newEngineExecutor(commandRunnerMock)

	playbook_result := executorInstance.ExecuteEngine(
		&model.InfrastructureSystem{},
		BuildSystemPlaybook,
		[]playbook.Tag{},
		playbook.NewContext("1"),
		&model.Zone{})

	assert.EqualValues(t, model.OK, playbook_result.GetHealthStatus(), "OK status is expected when calling the engineDebug. Got %s", playbook_result.GetHealthStatus())
	assert.True(t, len(playbook_result.Errors) > 0, "Details are expected to not be empty when calling engineDebug. Got %s", len(playbook_result.Errors))
}

func TestEngineExecutionInvalidOutputFormat(t *testing.T) {
	commandRunnerMock := new(CommandRunnerMock)
	invalidPlaybookResult := buildInvalidPlayBookResult()
	commandRunnerMock.On("execute").Return(invalidPlaybookResult)
	executorInstance = newEngineExecutor(commandRunnerMock)

	assert.Panics(t, func() {
		executorInstance.ExecuteEngine(model.InfrastructureSystem{},
			BuildSystemPlaybook,
			[]playbook.Tag{},
			playbook.NewContext("1"),
			&model.Zone{})

	}, "Calling Execute Engine should panic because output has invalid format")
}

func TestEngineExecutionMixedOutputFormat(t *testing.T) {
	commandRunnerMock := new(CommandRunnerMock)
	mockedError := common.NewApplicationError(common.ErrorExecutionFailure, "This is a mocked success run")
	successPlayBookResult := buildPlayBookResult([]common.ApplicationError{mockedError}, "SUCCESS")
	invalidPlaybookResult := buildInvalidPlayBookResult()
	commandRunnerMock.On("execute").Return(append(invalidPlaybookResult, successPlayBookResult...))
	executorInstance = newEngineExecutor(commandRunnerMock)

	playbook_result := executorInstance.ExecuteEngine(
		&model.InfrastructureSystem{},
		BuildSystemPlaybook,
		[]playbook.Tag{},
		playbook.NewContext("1"),
		&model.Zone{})

	assert.EqualValues(t, model.OK, playbook_result.GetHealthStatus(), "OK status is expected when calling the engineDebug. Got %s", playbook_result.GetHealthStatus())
	assert.True(t, len(playbook_result.Errors) > 0, "Details are expected to not be empty when calling engineDebug. Got %s", len(playbook_result.Errors))
}
