//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP

package engine

import (
	"path"
	"runtime"
)

type (
	PlaybookType string
)

var playBookPath = getAbsoluteFilepath("../../ism-recipes/playbooks/")
var hpeGatewayPath = "tasks/hpe-gateway/"
var kvmPath = "kvm/"

func getAbsoluteFilepath(filepath string) string {
	_, filename, _, _ := runtime.Caller(1)
	playbookpath := path.Join(path.Dir(filename), filepath)
	return playbookpath + "/"
}

var (
	BuildSystemPlaybook               PlaybookType = PlaybookType(playBookPath + "build_system.yml")
	BuildSystemValidationPlaybook     PlaybookType = PlaybookType(playBookPath + "build_system_validation.yml")
	ConfigureSystemValidationPlaybook PlaybookType = PlaybookType(playBookPath + "config_system_validation.yml")
	DiscoverNodesPlaybook             PlaybookType = PlaybookType(playBookPath + "discover_nodes.yml")
	UpdatePlaybook                    PlaybookType = PlaybookType(playBookPath + "update_system.yml")
	UpdateValidationPlaybook          PlaybookType = PlaybookType(playBookPath + "update_system_validation.yml")
	ExpandPlaybook                    PlaybookType = PlaybookType(playBookPath + "expand_system.yml")
	ExpandValidationPlaybook          PlaybookType = PlaybookType(playBookPath + "expand_system_validation.yml")
	ContractPlaybook                  PlaybookType = PlaybookType(playBookPath + "contract_system.yml")
	DeletePlaybook                    PlaybookType = PlaybookType(playBookPath + "delete_system.yml")
	ForceDeletePlaybook               PlaybookType = PlaybookType(playBookPath + "force_delete_system.yml")
	ContractValidationPlaybook        PlaybookType = PlaybookType(playBookPath + "contract_system_validation.yml")
	DeleteValidationPlaybook          PlaybookType = PlaybookType(playBookPath + "delete_system_validation.yml")
	ReconfigurePlaybook               PlaybookType = PlaybookType(playBookPath + "reconfigure_system.yml")
	ReconfigureValidationPlaybook     PlaybookType = PlaybookType(playBookPath + "reconfigure_system_validation.yml")
	NoPlaybook                        PlaybookType = ""
	ShutdownPlaybook                  PlaybookType = PlaybookType(playBookPath + "shutdown_system.yml")
	ShutdownValidationPlaybook        PlaybookType = PlaybookType(playBookPath + "shutdown_system_validation.yml")
	BackupPlaybook                    PlaybookType = PlaybookType(playBookPath + "backup_system.yml")
	BackupValidationPlaybook          PlaybookType = PlaybookType(playBookPath + "backup_system_validation.yml")
	RestorePlaybook                   PlaybookType = PlaybookType(playBookPath + "restore_system.yml")
	RestoreValidationPlaybook         PlaybookType = PlaybookType(playBookPath + "restore_system_validation.yml")
	RestoreFailedPlaybook             PlaybookType = PlaybookType(playBookPath + "restore_failed_system.yml")
	FactoryResetPlaybook              PlaybookType = PlaybookType(playBookPath + "factory_reset.yml")
	FactoryResetValidationPlaybook    PlaybookType = PlaybookType(playBookPath + "factory_reset_validation.yml")
	DeploymentCleanUpPlaybook         PlaybookType = PlaybookType(playBookPath + "build_system_clean_up.yml")
	CollectLogsPlaybook               PlaybookType = PlaybookType(playBookPath + "collect_logs.yml")
	AddVolumeAttachmentPlaybook       PlaybookType = PlaybookType(playBookPath + "add_volume_attachment.yml")
	RemoveVolumeAttachmentPlaybook    PlaybookType = PlaybookType(playBookPath + "remove_volume_attachment.yml")
	UnmapVMFSPlaybook                 PlaybookType = PlaybookType(playBookPath + "unmap_datastore.yml")
	AllocateResourcePlaybook          PlaybookType = PlaybookType(playBookPath + "allocate_resource.yml")
	EnableAndDisableResourcePlaybook  PlaybookType = PlaybookType(playBookPath + "enable_and_disable_resource.yml")
	ConfigureNeutronServerPlaybook    PlaybookType = PlaybookType(playBookPath + "configure_neutron_server.yml")
	GetUnmanagedResourcePlaybook      PlaybookType = PlaybookType(playBookPath + "get_unmanaged_resource.yml")
	DeAllocateResourcePlaybook        PlaybookType = PlaybookType(playBookPath + "deallocate_resource.yml")
	OvaDownloadPlaybook               PlaybookType = PlaybookType(playBookPath + hpeGatewayPath + "download_hpe_gateway_ova.yml")
	RegisterZonePlaybook              PlaybookType = PlaybookType(playBookPath + "register_zone.yml")
	UnregisterZonePlaybook            PlaybookType = PlaybookType(playBookPath + "unregister_zone.yml")
	ExpandCleanUpPlaybook             PlaybookType = PlaybookType(playBookPath + "expand_clean_up.yml")
	UpdateZonePlaybook                PlaybookType = PlaybookType(playBookPath + "update_zone.yml")
	KVMHostAgentConnectionPlaybook    PlaybookType = PlaybookType(playBookPath + kvmPath + "check_kvm_host_agent_connection_status.yml")
	KVMGetUnmanagedServersPlaybook    PlaybookType = PlaybookType(playBookPath + kvmPath + "get_unmanaged_kvm_servers.yml")
	KVMEnableKVMServerPlaybook        PlaybookType = PlaybookType(playBookPath + kvmPath + "enable_kvm_server.yml")
	KVMDisableKVMServerPlaybook       PlaybookType = PlaybookType(playBookPath + kvmPath + "disable_kvm_server.yml")
	KVMCheckRecoveryStatusPlaybook    PlaybookType = PlaybookType(playBookPath + kvmPath + "synchronize_kvm_server_roles.yml")
)
