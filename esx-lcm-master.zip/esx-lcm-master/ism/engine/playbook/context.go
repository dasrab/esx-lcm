//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

package playbook

import (
	"fmt"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/internal/log"
)

type Context struct {
	IsmHostname                   string `json:"ismHostname"`
	AssociatedTaskUri             string `json:"associatedTaskUri"`
	AssociatedTaskUuid            string `json:"associatedTaskUuid"`
	KeystoneUser                  string `json:"keystoneUser"`
	KeystonePassword              string `json:"keystonePassword"`
	KeystoneProject               string `json:"keystoneProject"`
	KeystoneDomain                string `json:"keystoneDomain"`
	KeystoneAuthURL               string `json:"keystoneAuthURL"`
	MonascaAgentUser              string `json:"monascaAgentUser"`
	MonascaAgentPassword          string `json:"monascaAgentPassword"`
	MonascaAgentProject           string `json:"monascaAgentProject"`
	MonascaAgentDomain            string `json:"monascaAgentDomain"`
	MonascaURL                    string `json:"monascaURL"`
	CapacityHandlerMaxClusters    int    `json:"capacityHandlerMaxClusters"`
	CapacityHandlerMaxNodes       int    `json:"capacityHandlerMaxNodes"`
	CapacityHandlerMinimumNodes   int    `json:"capacityHandlerMinNodes"`
	CapacityHandlerScaleType      string `json:"capacityHandlerScaleType"`
	LogLevel                      string `json:"logLevel"`
	ApplianceManagerHost          string `json:"applianceManagerHost"`
	ApplianceManagerPort          string `json:"applianceManagerPort"`
	ConfigureVsan                 bool   `json:"configureVsan"`
	VsanEnablePerformanceService  bool   `json:"vsanEnablePerformanceService"`
	VsanForceMarkLocalDiskAsFlash bool   `json:"vsanForceMarkLocalDiskAsFlash"`
	VsanWipeDisks                 bool   `json:"vsanWipeDisks"`
	DatacenterPathSuffix          string `json:"datacenterPathSuffix"`
	HostPassword                  string `json:"hostPassword"`
	ClusterScaleCount             int    `json:"clusterScaleCount"`
	VCpus                         int    `json:"vCpus"`
	Memory                        int    `json:"memory"`
	VmwareNeutron                 bool   `json:"vmwareNeutron"`
	VMwareHostMetadata            bool   `json:"vmwareHostMetadata"`
	KvmHostMetadata               bool   `json:"kvmHostMetadata"`
}

var NewContext = newContext

// Create a context with an IDM token used by the shutdown operation
// Notice the shutdown script needs a 'System' token to access ISM (ApiServer)
func NewContextWithIDMToken(taskId string) Context {
	ctx := NewContext(taskId)
	return ctx
}

// Create a regular context
func newContext(taskId string) Context {
	var err error
	ctx := Context{}
	ctx.AssociatedTaskUuid = taskId
	ctx.AssociatedTaskUri = common.BuildUri(common.URITaskResource, taskId)
	ctx.IsmHostname = fmt.Sprintf("%s%d", common.DefaultHostname, properties.ISM.Server.SecurePort)
	ctx.KeystoneAuthURL = properties.ISM.Keystone.AuthURL
	ctx.KeystoneUser = properties.ISM.Keystone.User
	ctx.KeystonePassword = properties.ISM.Keystone.Pass
	ctx.KeystoneDomain = properties.ISM.Keystone.Domain
	ctx.KeystoneProject = properties.ISM.Keystone.Project
	ctx.MonascaAgentDomain = properties.ISM.MonascaAgent.Domain
	ctx.MonascaAgentPassword = properties.ISM.MonascaAgent.Pass
	ctx.MonascaAgentUser = properties.ISM.MonascaAgent.User
	ctx.MonascaAgentProject = properties.ISM.MonascaAgent.Project
	ctx.MonascaURL = properties.ISM.Monasca.ApiURI
	ctx.CapacityHandlerMaxClusters = properties.ISM.CapacityHandler.MaxClusters
	ctx.CapacityHandlerMaxNodes = properties.ISM.CapacityHandler.MaxNodes
	ctx.CapacityHandlerMinimumNodes = properties.ISM.CapacityHandler.MinimumNodes
	ctx.ApplianceManagerHost = properties.ISM.ApplianceManager.Host
	ctx.ApplianceManagerPort = properties.ISM.ApplianceManager.Port
	ctx.ConfigureVsan = properties.ISM.VsanConfigParameters.ConfigureVsan
	ctx.VsanEnablePerformanceService = properties.ISM.VsanConfigParameters.EnablePerformanceService
	ctx.VsanForceMarkLocalDiskAsFlash = properties.ISM.VsanConfigParameters.ForceMarkLocalDiskAsFlash
	ctx.VsanWipeDisks = properties.ISM.VsanConfigParameters.WipeDisks
	ctx.DatacenterPathSuffix = properties.ISM.DatacenterConfig.DatacenterPathSuffix
	ctx.HostPassword = properties.ISM.DatacenterConfig.HostPassword
	ctx.ClusterScaleCount = properties.ISM.HpeGateway.ClusterScaleCount
	ctx.VCpus = properties.ISM.HpeGateway.VCpus
	ctx.Memory = properties.ISM.HpeGateway.Memory
	ctx.VmwareNeutron = properties.ISM.FeatureToggle.VMwareNeutron
	ctx.VMwareHostMetadata = properties.ISM.FeatureToggle.VMwareHostMetadata
	ctx.KvmHostMetadata = properties.ISM.FeatureToggle.KvmHostMetadata
	ctx.LogLevel = string(log.GetLevel(
		properties.ISM.Log.LogLevel,
	))
	if err != nil {
		panic(err)
	}

	return ctx
}
