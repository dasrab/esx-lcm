//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package playbook

import (
	"bytes"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

type FakeResource1 struct {
	Name          string `json:"name"`
	FakeResource2 `json:"nestedResource"`
}

type FakeResource2 struct {
	Domain string `json:"domain"`
}

var res map[string]interface{} = map[string]interface{}{
	"resource": FakeResource1{
		Name: "abc",
		FakeResource2: FakeResource2{
			Domain: "xyz",
		},
	},
}

var ctx Context = Context{
	IsmHostname:          "ih",
	KeystoneAuthURL:      "",
	KeystoneDomain:       "",
	KeystonePassword:     "",
	KeystoneProject:      "",
	KeystoneUser:         "",
	AssociatedTaskUri:    "aruri",
	AssociatedTaskUuid:   "atuuid",
	LogLevel:             "INFO",
	MonascaAgentDomain:   "",
	MonascaAgentPassword: "",
	MonascaAgentProject:  "",
	MonascaAgentUser:     "",
	MonascaURL:           "",
}

type Zone struct {
	Id      string `json:"id"`
	Name    string `json:"name"`
	Managed bool   `json:"managed"`
}

var aggregate = []byte(`{
	"applianceManagerHost": "",
	"applianceManagerPort": "",
	"associatedTaskUri": "aruri",
	"associatedTaskUuid": "atuuid",
	"capacityHandlerMaxClusters": 0,
	"capacityHandlerMaxNodes": 0,
	"capacityHandlerMinNodes": 0,
	"capacityHandlerScaleType": "",
	"clusterScaleCount": 0,
	"configureVsan": false,
	"datacenterPathSuffix": "",
	"env": {
		"id": "",
		"managed": false,
		"name": ""
	},
	"hostPassword": "",
	"ismHostname": "ih",
	"keystoneAuthURL": "",
	"keystoneDomain": "",
	"keystonePassword": "",
	"keystoneProject": "",
	"keystoneUser": "",
	"kvmHostMetadata": false,
	"logLevel": "INFO",
	"memory": 0,
	"monascaAgentDomain": "",
	"monascaAgentPassword": "",
	"monascaAgentProject": "",
	"monascaAgentUser": "",
	"monascaURL": "",
	"resource": {
		"name": "abc",
		"nestedResource": {
			"domain": "xyz"
		}
	},
	"vCpus": 0,
	"vmwareHostMetadata": false,
	"vmwareNeutron": false,
	"vsanEnablePerformanceService": false,
	"vsanForceMarkLocalDiskAsFlash": false,
	"vsanWipeDisks": false
}
`)

func TestNewExtraVars(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)
	buf := bytes.NewBuffer(aggregate)
	ev, err := NewExtraVars(res, ctx, Zone{})
	assert.Equal(ev, "-e "+buf.String())
	assert.NoError(err)
}
