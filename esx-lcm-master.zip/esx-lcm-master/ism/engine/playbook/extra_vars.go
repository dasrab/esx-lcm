//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

package playbook

import (
	"bytes"
	"encoding/json"

	log "github.hpe.com/kronos/kelog"
)

const extraVarsName = "e"
const extraVarsEnv = "env"

type extraVars struct {
	param
}

// Make the extra-vars parameter
func NewExtraVars(resource interface{}, ctx Context, env interface{}) (string, error) {
	var err error
	e := new(extraVars)
	e.name = extraVarsName
	e.kind = oldConvention
	log.Debug("Creating new extra vars")
	e.value, err = e.combine(resource, ctx, env)
	if err != nil {
		return "", err
	}
	return e.format(), nil
}

// Put together resource and playbook context
func (e extraVars) combine(resource interface{}, context Context, env interface{}) (string, error) {

	// Currently it just support flat properties

	//
	// FIXME: Engine extra-vars should be built from JSON objects instead of appending properties
	//

	var err error
	buf := new(bytes.Buffer)
	// Decode resource to a JSON-like map
	res := make(map[string]interface{})
	if resource != nil {
		if err = json.NewEncoder(buf).Encode(resource); err != nil {
			return "", err
		}
		if err = json.NewDecoder(buf).Decode(&res); err != nil {
			return "", err
		}
	}

	// Decode context to a JSON-like map
	var ctx map[string]interface{}
	if err = json.NewEncoder(buf).Encode(context); err != nil {
		return "", err
	}
	if err = json.NewDecoder(buf).Decode(&ctx); err != nil {
		return "", err
	}
	// Append context to resource
	for k, v := range ctx {
		// Workaround to skip empty idmToken
		if (k == "idmToken") && (len(v.(string)) == 0) {
			continue
		}
		res[k] = v
	}

	// Decode env to a JSON-like map
	var resEnv map[string]interface{}
	if err = json.NewEncoder(buf).Encode(env); err != nil {
		return "", err
	}
	if err = json.NewDecoder(buf).Decode(&resEnv); err != nil {
		return "", err
	}
	// Append context to resource
	res[extraVarsEnv] = resEnv

	// Encode final object
	json.NewEncoder(buf).Encode(res)

	// Indent JSON
	var prettyJSON bytes.Buffer
	if err = json.Indent(&prettyJSON, buf.Bytes(), "", "\t"); err != nil {
		return "", err
	}
	return prettyJSON.String(), err
}
