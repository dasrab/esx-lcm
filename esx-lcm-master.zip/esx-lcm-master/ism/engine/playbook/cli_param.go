//(C) Copyright 2017 Hewlett Packard Enterprise Development LP

package playbook

import (
	"fmt"
)

type paramType string

const (
	gnu           paramType = "gnu"           // two hyphens then a word (e.g. --tags)
	oldConvention paramType = "oldConvention" // one hyphen then one letter (e.g. -e)
)

type param struct {
	name  string
	value string
	kind  paramType
}

func (b param) format() string {
	var str string
	switch b.kind {
	case gnu:
		str = fmt.Sprintf("--%s=%s", b.name, b.value)
	case oldConvention:
		str = fmt.Sprintf("-%s %s", b.name, b.value)
	default:
		str = fmt.Sprintf("-%s %s", b.name, b.value)
	}
	return str
}
