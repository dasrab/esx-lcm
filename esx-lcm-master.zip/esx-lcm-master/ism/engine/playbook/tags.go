//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package playbook

import "strings"

const tagsName = "tags"

type Tag string

const (
	HypervisorManagerTag          Tag = "hv_manager"
	HypervisorHostTag             Tag = "hv_host"
	NetworksTag                   Tag = "network_settings"
	ManagementNetworksTag         Tag = "mgmt_networks"
	HypervisoriScsiNetworksTag    Tag = "hv_iscsi_networks"
	HypervisorMovementNetworksTag Tag = "hv_mov_networks"
	FaultToleranceNetworksTag     Tag = "hv_ft_networks"
	ProductionNetworksTag         Tag = "hv_prod_networks"
	UnmanagedServersTag           Tag = "unmanaged_servers"
	StorageSystemTag              Tag = "storage_system"
	NTPServersTag                 Tag = "ntp_servers"
	DNSServersTag                 Tag = "dns_servers"
	QuorumTag                     Tag = "quorum"
	UntaggedTag                   Tag = "untagged"
	NoTag                         Tag = ""
)

type tags struct {
	param
}

func NewTags(values []Tag) string {
	t := new(tags)
	t.name = tagsName
	t.kind = gnu
	t.value = t.build(values)
	return t.format()
}

func (t tags) build(values []Tag) string {
	str := make([]string, len(values))
	for i, t := range values {
		str[i] = string(t)
	}
	return strings.Join(str, ",")
}
