//(C) Copyright 2018 Hewlett Packard Enterprise Development LP

package appmanager

import (
	"bytes"
	"encoding/json"
	"fmt"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"net/http"

	"io/ioutil"
)

const (
	scheme               = "http://"
	appManOVEndpointType = "/endpoints?endpoint_type=OneView"
)

var headers = map[string]string{"Content-Type": "application/json"}
var get_http_response = getHTTPResponse

type ApplianceEndpoints []struct {
	ProxyEndpoint string `json:"proxy_endpoint"`
}

func getOVEndpointURI(applianceURI string) string {
	// Note: applianceURI will be in "/rest/appliances/<uri>" format
	return fmt.Sprintf("%v%v:%v%v%v", scheme, properties.ISM.ApplianceManager.Host,
		properties.ISM.ApplianceManager.Port, applianceURI, appManOVEndpointType)
}

func getHTTPResponse(method string, _url string, body []byte, headers map[string]string) (*http.Response, error) {
	req, err := http.NewRequest(method, _url, bytes.NewBuffer(body))
	if err != nil {
		log.Errorf("Error in NewRequest: %v", err)
		return nil, err
	}
	if headers != nil {
		for k, v := range headers {
			req.Header.Set(k, v)
		}
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Errorf("Error while receiving response: %v", err)
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		msg := fmt.Sprintf("Got Invalid status code while performing '%v' operation on url '%v'. "+
			"Status Code: %v", method, _url, resp.StatusCode)
		err := common.NewApplicationError(common.ErrorInvalidHTTPResponse, msg)
		return nil, err
	}
	return resp, nil
}

func GetOneViewEndPoint(applianceURI string) (string, error) {
	ovEndPointUri := getOVEndpointURI(applianceURI)
	resp, err := get_http_response(http.MethodGet, ovEndPointUri, []byte{}, headers)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	var ovEndpoints ApplianceEndpoints
	bodyBytes, _ := ioutil.ReadAll(resp.Body)
	err = json.Unmarshal(bodyBytes, &ovEndpoints)
	if err != nil {
		log.Errorf("Error occurred while unmarshalling response body %v . Error: %v", string(bodyBytes), err)
		return "", err
	}
	proxyEndpoint := ovEndpoints[0].ProxyEndpoint
	log.Infof("OneView Proxy Endpoint: %v", proxyEndpoint)
	return proxyEndpoint, nil
}
