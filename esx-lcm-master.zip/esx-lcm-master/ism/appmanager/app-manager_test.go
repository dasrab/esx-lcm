//(C) Copyright 2018 Hewlett Packard Enterprise Development LP

package appmanager

import (
	"fmt"
	"github.com/stretchr/testify/assert"
	"io"
	"net/http"
	"strings"
	"testing"
)

var (
	responseBody string
	status       int
)

type fakeHttpResponse struct{}

func NewRespBodyFromString(body string) io.ReadCloser {
	return &dummyReadCloser{strings.NewReader(body)}
}

type dummyReadCloser struct {
	body io.ReadSeeker
}

func (d *dummyReadCloser) Read(p []byte) (n int, err error) {
	n, err = d.body.Read(p)
	if err == io.EOF {
		d.body.Seek(0, 0)
	}
	return n, err
}

func (d *dummyReadCloser) Close() error {
	return nil
}

func (f fakeHttpResponse) getHTTPResponse(method string, _url string, body []byte, headers map[string]string) (*http.Response, error) {
	resp := &http.Response{
		StatusCode: status,
		Body:       NewRespBodyFromString(responseBody),
	}
	return resp, nil
}

func TestGetOneViewEndPointSuccess(t *testing.T) {
	ovEndPoint := "192.192.192.192:443"
	responseBody = fmt.Sprintf(`[{"proxy_endpoint": "%v"}]`, ovEndPoint)
	status = 200
	get_http_response = fakeHttpResponse{}.getHTTPResponse

	proxyEndPoint, err := GetOneViewEndPoint("fake-appliance-uri")

	assert.Equal(t, proxyEndPoint, ovEndPoint)
	assert.Equal(t, err, nil)
}

func TestGetOneViewEndPointFailure(t *testing.T) {
	ovEndPoint := "192.192.192.192:443"
	responseBody = fmt.Sprintf(`[{"proxy_endpoint": %v}]`, ovEndPoint)
	status = 200
	get_http_response = fakeHttpResponse{}.getHTTPResponse

	proxyEndPoint, err := GetOneViewEndPoint("fake-appliance-uri")

	assert.NotEqual(t, proxyEndPoint, ovEndPoint)
	assert.EqualError(t, err, "invalid character '.' after object key:value pair")
}

// Keep this method for actual testing
//func TestGetOneViewEndPoint(t *testing.T) {
//	ep, _ := GetOneViewEndPoint("/rest/appliances/586218a3-90a3-49ae-a0e7-103b5d4d2bd0")
//	fmt.Println("OV End Point: ", ep)
//}
