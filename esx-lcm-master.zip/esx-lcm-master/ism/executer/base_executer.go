//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"fmt"
	"reflect"

	"time"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/playbook"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

var waitTaskPeriod time.Duration = 1 * time.Second
var waitTaskTimeout time.Duration = 5 * time.Second

type ResourceExecutorInterface interface {
	BaseGetAll(filters map[string][]string) (interface{}, error)
	BaseGet(uuid string) (interface{}, error)
	BaseCreate(resource model.IManagedResource) (model.TaskResource, error)
	BaseUpdate(resource model.IManagedResource) (model.TaskResource, error)
	BaseDelete(uuid string) (model.TaskResource, error)
	BaseFlushAll()
	BaseAbortAll()
}

type ResourceExecutor struct {
	dao              dal.ManagedResourceDAO
	resourceTypeName model.ResourceType
	resourceBaseURI  common.IsmURI
	resourceType     reflect.Type
	resourceListType reflect.Type
	operations       operation.Operations
}

//TODO: Improve this input here so it gets easier to input this information to baseExecutor
func NewBaseResourceExecutor(
	dao dal.ManagedResourceDAO,
	resourceName model.ResourceType,
	resourceBaseUri common.IsmURI,
	resourceType reflect.Type,
	resourceListType reflect.Type,
	operations operation.Operations) ResourceExecutor {
	return ResourceExecutor{dao, resourceName, resourceBaseUri, resourceType, resourceListType, operations}
}

func (e ResourceExecutor) BaseGetAll(filters map[string][]string) (interface{}, error) {
	log.Debugf("Getting all %v", e.resourceType)
	resource := reflect.New(e.resourceListType).Interface()
	err := e.dao.BaseGetAll(&resource, filters)
	if err != nil {
		message := fmt.Sprintf("Could not retrieve list of %s. %v", e.resourceTypeName, err)
		log.Errorf(message)
		return nil, common.NewApplicationError(common.ErrorDatabase, message)
	}

	return resource, nil
}

func (e ResourceExecutor) BaseGet(id string) (interface{}, error) {
	log.Debugf("Getting resource %s with UUID %v", e.resourceTypeName, id)
	resource := reflect.New(e.resourceType).Interface()
	err := e.dao.BaseGet(id, resource)
	if err != nil {
		message := fmt.Sprintf("Could not retrieve resource %s with UUID %s. Details: %v", e.resourceTypeName, id, err)
		log.Errorf(message)
		return nil, common.NewApplicationError(common.ErrorResourceNotFound, message)
	}
	return resource, nil
}

func (e ResourceExecutor) BaseCreate(resource model.IManagedResource) (model.TaskResource, error) {
	log.Debugf("Received Creation request for resource %s with contents: %v", e.resourceTypeName, resource)

	op, err := createOperation(
		e.operations,
		model.ReadyChangeOperation,
		model.CreatingChangeOperation,
		e.resourceTypeName,
		resource,
	)

	if err != nil {
		return model.TaskResource{}, err
	}

	return runOperation(op, e.executeCreateResource)
}

func (e ResourceExecutor) executeCreateResource(op operation.Operation) {
	log.Debugf("Starting resource %s creation with contents: %v", e.resourceTypeName, op.Resource())

	//Do DB stuff
	if err := e.dao.BaseCreate(op.Resource()); err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error creating resource %s in Database: %v", e.resourceTypeName, err)))
	}

	op.RefreshResource(op.Resource())

	log.Debugf("Done Creating resource %s with UUID %s", e.resourceTypeName, op.ResourceUUID())
}

func (e ResourceExecutor) BaseUpdate(resource model.IManagedResource) (model.TaskResource, error) {
	log.Debugf("Received Update request for resource %s with contents: %v", e.resourceTypeName, resource)

	//Get Resource from DB
	r, err := e.BaseGet(resource.GetUUID())
	if err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error getting resource %s from Database: %v", e.resourceTypeName, err)))
	}

	actualResource, ok := r.(model.IManagedResource)
	if !ok {
		logAndPanic(common.NewApplicationError(common.ErrorInvalidJson, fmt.Sprintf("Error unmarshaling JSON from DB: %v", err)))
	}

	op, err := createOperation(
		e.operations,
		actualResource.GetOperationState(),
		resource.GetOperationState(),
		e.resourceTypeName,
		resource,
	)

	if err != nil {
		return model.TaskResource{}, err
	}

	var f operation.HandlerFunc
	if resource.GetOperationState() == model.AbortChangeOperation {
		op.Resource().SetOperationState(actualResource.GetOperationState())
		f = e.executeAbortResource
	} else {
		if resource.GetOperationState() == model.DeletingChangeOperation {
			f = e.executeDeleteResource
		} else {
			f = e.executeUpdateResource
		}
	}

	return runOperation(op, f)
}

func (e ResourceExecutor) executeUpdateResource(op operation.Operation) {
	log.Debugf("Starting resource %s update with contents: %v", e.resourceTypeName, op.Resource())

	//Do DB stuff
	if err := e.dao.BaseUpdate(op.Resource().GetUUID(), op.Resource()); err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error updating resource %s in Database: %v", e.resourceTypeName, err)))
	}

	log.Debugf("Done Creating resource %s with UUID %s", e.resourceTypeName, op.ResourceUUID())
}

func (e ResourceExecutor) BaseDelete(UUID string) (model.TaskResource, error) {
	return model.TaskResource{}, common.NewApplicationError(common.ErrorUnsupportedOperation, "Delete operation is not supported for inventory elements")
}

func (e ResourceExecutor) executeDeleteResource(op operation.Operation) {
	log.Debugf("Deleting resource %s with UUID %s", e.resourceTypeName, op.ResourceUUID())

	//Do DB stuff
	if err := e.dao.BaseDelete(op.ResourceUUID()); err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error deleting resource %s in Database: %v", e.resourceTypeName, err)))
	}

	log.Debugf("Done Deleting resource %s with UUID %s", e.resourceTypeName, op.ResourceUUID())
}

func (e ResourceExecutor) BaseFlushAll() {
	log.Debugf("Flushing all operations on %v", e.resourceType)
	e.updateState(model.ReadyChangeOperation)
}

func (e ResourceExecutor) BaseAbortAll() {
	log.Debugf("Aborting all operations on %v", e.resourceType)
	e.updateState(model.AbortChangeOperation)
}

func (e ResourceExecutor) updateState(s model.StateType) {
	resources := reflect.New(e.resourceListType).Interface()

	err := e.dao.BaseGetAll(&resources, nil)
	if err != nil {
		message := fmt.Sprintf("Could not retrieve list of %s. %v", e.resourceTypeName, err)
		log.Errorf(message)
		panic(common.NewApplicationError(common.ErrorDatabase, message))
	}

	resourceList := reflect.Indirect(reflect.ValueOf(resources))
	for i := 0; i < resourceList.Len(); i++ {
		resource := resourceList.Index(i).Addr().Interface().(model.IManagedResource)
		if resource.GetOperationState() != model.ReadyChangeOperation {
			resource.SetOperationState(s)
			e.BaseUpdate(resource)
		}
	}
}

func (e ResourceExecutor) executeAbortResource(op operation.Operation) {
	log.Debugf("Starting resource %s abortion with contents: %v", e.resourceTypeName, op.Resource())

	r := op.Resource()

	switch r.GetOperationState() {
	case model.CreatingChangeOperation:
		if err := e.dao.BaseDelete(r.GetUUID()); err != nil {
			logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error deleting resource %s in Database: %v", e.resourceTypeName, err)))
		}
	default:
		r.SetOperationState(model.ReadyChangeOperation)
		if err := e.dao.BaseUpdate(r.GetUUID(), r); err != nil {
			logAndPanic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error updating resource %s in Database: %v", e.resourceTypeName, err)))
		}
	}

	log.Debugf("Done Aborting resource %s with UUID %s", e.resourceTypeName, r.GetUUID())
}

//
// Utilities
//
func createOperation(ops operation.Operations, origin, target model.StateType, resType model.ResourceType, res model.IManagedResource) (operation.Operation, error) {
	opConfig, ok := ops[operation.OperationKey{Origin: origin, Target: target}]
	if !ok {
		ismErr := common.NewApplicationError(common.ErrorInvalidTransition, fmt.Sprintf("No operation {%v, %v} associated to %v", origin, target, resType))
		ismErr.AddData(fmt.Sprintf("[%s]", target), fmt.Sprintf("[%s]", origin))
		return nil, ismErr
	}

	op := operation.NewAsyncOperation(
		opConfig,
		resType,
		res,
		availableDispatchers,
	)
	return op, nil
}

func runOperation(op operation.Operation, h ...operation.HandlerFunc) (model.TaskResource, error) {
	var t model.TaskResource
	var e error

	if op.TaskUUID() == "" {
		op.Run(h...)
		return t, e
	}

	if op.Mode() == operation.AsyncOp {
		t, e = GetTaskExecutor().Get(op.TaskUUID())
		op.Run(h...)
	} else {
		op.Run(h...)
		t, e = GetTaskExecutor().Get(op.TaskUUID())
	}

	return t, e
}

func logAndPanic(err error) {
	log.Error(fmt.Sprintf("%v", err))
	panic(err)
}

func runEngine(op operation.Operation, p engine.PlaybookType, opErr common.ApplicationError) {
	log.Debug("Fetching result in run Engine")
	result := engine.EngineExecutorInstance.ExecuteEngine(
		op.Resource(),
		p,
		[]playbook.Tag{},
		playbook.NewContext(op.TaskUUID()),
		op.ResourceEnv(),
	)
	log.Debug("Fetched result in run Engine")
	op.SetStatus(result.GetHealthStatus())

	if len(result.GetErrors()) != 0 {
		opErr.NestedErrors = result.GetErrors()
		op.SetExecutionError(opErr)
	} else {
		//Empty error
		op.SetExecutionError(common.ApplicationError{})
	}
}

func WaitForTask(uri string, timeout time.Duration) (*model.TaskResource, error) {
	uuid := common.GetResourceUuidFromUri(common.IsmURI(uri))
	var waitedPeriod time.Duration
	for i := 0; waitedPeriod.Seconds() <= timeout.Seconds(); i++ {
		currTask, err := GetTaskExecutor().Get(uuid)
		if err != nil {
			return nil, err
		}
		if currTask.TaskFailed {
			return &currTask, currTask.Error
		}
		if currTask.IsCompleted() {
			return &currTask, nil
		}
		log.Debugf("[%d] [%.2f seconds] - Waiting task %s to complete\n", i, waitedPeriod.Seconds(), uuid)
		time.Sleep(waitTaskPeriod)
		waitedPeriod += waitTaskPeriod
	}
	log.Debugf("Waited %.2f seconds for task %s to complete\n", waitedPeriod.Seconds(), uuid)
	return nil, common.NewApplicationError(common.ErrorExecutionFailure, "Task never got to Completed state!")
}
