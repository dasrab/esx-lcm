//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package executer

import (
	"reflect"

	"github.com/golang/mock/gomock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// MockResourceProfileExecutor is a mock of ResourceProfileExecutor interface
type MockResourceProfileExecutor struct {
	ctrl     *gomock.Controller
	recorder *MockResourceProfileExecutorMockRecorder
}

// MockResourceProfileExecutorMockRecorder is the mock recorder for MockResourceProfileExecutor
type MockResourceProfileExecutorMockRecorder struct {
	mock *MockResourceProfileExecutor
}

// NewMockResourceProfileExecutor creates a new mock instance
func NewMockResourceProfileExecutor(ctrl *gomock.Controller) *MockResourceProfileExecutor {
	mock := &MockResourceProfileExecutor{ctrl: ctrl}
	mock.recorder = &MockResourceProfileExecutorMockRecorder{mock}
	return mock
}

// EXPECT returns an object that allows the caller to indicate expected use
func (m *MockResourceProfileExecutor) EXPECT() *MockResourceProfileExecutorMockRecorder {
	return m.recorder
}

// GetAll mocks base method
func (m *MockResourceProfileExecutor) GetAll(arg0 map[string][]string) model.ResourceProfileList {
	ret := m.ctrl.Call(m, "GetAll", arg0)
	ret0, _ := ret[0].(model.ResourceProfileList)
	return ret0
}

// GetAll indicates an expected call of GetAll
func (mr *MockResourceProfileExecutorMockRecorder) GetAll(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetAll", reflect.TypeOf((*MockResourceProfileExecutor)(nil).GetAll), arg0)
}

// Get mocks base method
func (m *MockResourceProfileExecutor) Get(arg0 string) (model.ResourceProfile, error) {
	ret := m.ctrl.Call(m, "Get", arg0)
	ret0, _ := ret[0].(model.ResourceProfile)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// Get indicates an expected call of Get
func (mr *MockResourceProfileExecutorMockRecorder) Get(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Get", reflect.TypeOf((*MockResourceProfileExecutor)(nil).Get), arg0)
}

// Create mocks base method
func (m *MockResourceProfileExecutor) Create(arg0 model.ResourceProfile) (model.TaskResource, error) {
	ret := m.ctrl.Call(m, "Create", arg0)
	ret0, _ := ret[0].(model.TaskResource)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// Create indicates an expected call of Create
func (mr *MockResourceProfileExecutorMockRecorder) Create(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Create", reflect.TypeOf((*MockResourceProfileExecutor)(nil).Create), arg0)
}

// Update mocks base method
func (m *MockResourceProfileExecutor) Update(arg0 model.ResourceProfile) (model.TaskResource, error) {
	ret := m.ctrl.Call(m, "Update", arg0)
	ret0, _ := ret[0].(model.TaskResource)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// Update indicates an expected call of Update
func (mr *MockResourceProfileExecutorMockRecorder) Update(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Update", reflect.TypeOf((*MockResourceProfileExecutor)(nil).Update), arg0)
}

// Delete mocks base method
func (m *MockResourceProfileExecutor) Delete(arg0 model.ResourceProfile) error {
	ret := m.ctrl.Call(m, "Delete", arg0)
	ret0, _ := ret[0].(error)
	return ret0
}

// Delete indicates an expected call of Delete
func (mr *MockResourceProfileExecutorMockRecorder) Delete(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Delete", reflect.TypeOf((*MockResourceProfileExecutor)(nil).Delete), arg0)
}
