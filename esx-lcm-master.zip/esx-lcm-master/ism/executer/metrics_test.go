// (C) Copyright 2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"reflect"
	"testing"

	"github.com/prometheus/client_golang/prometheus"
	dto "github.com/prometheus/client_model/go"
	"github.com/stretchr/testify/assert"
)

func Test_getEsxLcmMetrics(t *testing.T) {
	tests := []struct {
		name string
		want *externalCallMetricRecorder
	}{
	// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := getEsxLcmMetrics(); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("getEsxLcmMetrics() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_SetEsxLcmMetrics(t *testing.T) {
	tests := []struct {
		op                                       string
		zoneID, zoneType, hostAgent, metricsName string
		healthyState                             bool
	}{
		{"normal", "1234", "vCenter", "", "hpeGatewayState", false},
		{"normal", "1234", "vCenter", "", "hpeGatewayState", true},
		{"normal", "1234", "vCenter", "", "hpeGatewayAgentState", false},
		{"normal", "1234", "vCenter", "", "hpeGatewayAgentState", true},
		{"panicable", "1234", "vCenter", "", "otherMetric", false},
		{"normal", "4321", "KVM", "", "hpeGatewayState", false},
		{"normal", "4321", "KVM", "", "hpeGatewayState", true},
		{"normal", "4321", "KVM", "CentOS-NCS", "hpeGatewayAgentState", false},
		{"normal", "4321", "KVM", "Ubuntu-NCS", "hpeGatewayAgentState", true},
		{"panicable", "4321", "KVM", "Ubuntu-NCS", "otherMetric", true},
	}

	for _, tt := range tests {
		switch tt.op {
		case "normal":
			SetEsxLcmMetrics(tt.zoneID, tt.zoneType, tt.hostAgent, tt.metricsName, tt.healthyState)
			pb := &dto.Metric{}
			if tt.metricsName == "hpeGatewayAgentState" {
				getEsxLcmMetrics().hpeGatewayAgentState.With(prometheus.Labels{"zoneID": tt.zoneID, "zoneType": tt.zoneType, "hostAgent": tt.hostAgent}).Write(pb)
				val := pb.GetGauge().GetValue()
				if tt.healthyState {
					assert.Equal(t, 0, int(val))
				} else {
					assert.Equal(t, 1, int(val))
				}
			} else if tt.metricsName == "hpeGatewayState" {
				getEsxLcmMetrics().hpeGatewayState.With(prometheus.Labels{"zoneID": tt.zoneID, "zoneType": tt.zoneType}).Write(pb)
				val := pb.GetGauge().GetValue()
				if tt.healthyState {
					assert.Equal(t, 0, int(val))
				} else {
					assert.Equal(t, 1, int(val))
				}
			}
		case "panicable":
			assert.Panics(t, func() {
				SetEsxLcmMetrics(tt.zoneID, tt.zoneType, tt.hostAgent, tt.metricsName, tt.healthyState)
			})
		}
	}
}

func Test_RegisterEsxLcmMetrics(t *testing.T) {
	tests := []struct {
		name string
	}{
	// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			RegisterEsxLcmMetrics()
		})
	}
}
