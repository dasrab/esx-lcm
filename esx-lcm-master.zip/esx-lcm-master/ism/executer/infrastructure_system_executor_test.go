//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"testing"
	"time"

	"github.com/stretchr/testify/mock"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/playbook"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/state-machine"
)

type InfrastructureDAOMock struct {
	mock.Mock
}

func SetPlaybookContextMock() {
	playbook.NewContext = func(string) playbook.Context {
		return playbook.Context{}
	}

}

func (m *InfrastructureDAOMock) Get(id interface{}) (model.InfrastructureSystem, error) {
	args := m.Called()
	return args.Get(0).(model.InfrastructureSystem), args.Error(1)
}

func (m *InfrastructureDAOMock) GetAll(map[string][]string) ([]model.InfrastructureSystem, error) {
	args := m.Called()
	return args.Get(0).([]model.InfrastructureSystem), args.Error(1)
}

func (m *InfrastructureDAOMock) Create(resource *model.InfrastructureSystem) error {
	return nil
}

func (m *InfrastructureDAOMock) Update(resource *model.InfrastructureSystem) error {
	return nil
}

func (m *InfrastructureDAOMock) Delete(id interface{}) error {
	return nil
}

func (m *InfrastructureSystemExecutorMock) BaseGetTotal(interface{}, map[string][]string) (int, error) {
	return 0, nil
}
func (m *InfrastructureSystemExecutorMock) BaseGetStart(filters map[string][]string) int {
	return 0
}

func TestInfrastructureSystemOperations(t *testing.T) {
	common.StartLogs()
	SetPlaybookContextMock()
	defer func() { GetTaskExecutor = getTaskExecutor }()
	defer func() { GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor }()

	smExec := state_machine.StateMachineExecutor
	defer func() { state_machine.StateMachineExecutor = smExec }()

	testCases := []struct {
		dalOp         string
		currentInfra  model.InfrastructureSystem
		desiredInfra  model.InfrastructureSystem
		hasKafka      bool
		stateMachExec bool
		zone          model.Zone
	}{
		{"Create", model.InfrastructureSystem{}, getInfra(model.ConfiguringState), false, false, model.Zone{}},
		{"Update", getInfra(model.ConfiguringState), getInfra(model.ConfiguringState), true, true, model.Zone{}},
		{"Update", getInfra(model.ConfiguringState), getInfra(model.DeployingState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.ContractingState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.UpdatingState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.ReconfiguringState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.ExpandingState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.ShuttingdownState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.FactoryResettingState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.BackingUpState), true, true, model.Zone{}},
		{"Update", getInfra(model.RunningState), getInfra(model.RestoringState), true, true, model.Zone{}},
		{"GetAllManaged", getInfra(model.ConfiguringState), getInfra(model.RunningState), false, true, model.Zone{}},
	}

	for _, tc := range testCases {
		mockDal := new(InfrastructureDAOMock)
		mockDal.On("Get").Return(tc.currentInfra, nil)
		mockDal.On("GetAll").Return([]model.InfrastructureSystem{getInfra(model.ConfiguringState)}, nil)
		mockDal.On(tc.dalOp).Return(nil)
		SetTaskExecutorMock(NewTaskExecutorMock(model.OK, common.ApplicationError{}))
		setMockedInfrastructureSystemDAL(mockDal)
		smMock := state_machine.NewStateMachineExecutorMock(common.ApplicationError{}, model.OK)
		state_machine.SetStateMachineExecutor(smMock)

		switch tc.dalOp {
		case "Create":
			GetInfrastructureSystemExecutor().Create(tc.desiredInfra)
		case "Update":
			GetInfrastructureSystemExecutor().Update(tc.zone, tc.desiredInfra)
		case "GetAllManaged":
			filters := make(map[string][]string)
			infraList, _ := GetInfrastructureSystemExecutor().GetAll(filters)
			managedResource := infraList.GetMembers()[0]
			if managedResource.InfraState != model.ConfiguringState {
				t.Error("Getall didn't return resource in configuring state")
			}
		}

		// wait for go routine to finish
		time.Sleep(time.Millisecond * 10)

	}
}

func TestSynchronizeInfraWithGateway(t *testing.T) {
	common.StartLogs()
	SetPlaybookContextMock()
	defer func() { GetTaskExecutor = getTaskExecutor }()
	defer func() { GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor }()

	smExec := state_machine.StateMachineExecutor
	defer func() { state_machine.StateMachineExecutor = smExec }()

	testCases := []struct {
		dalOp         string
		currentInfra  model.InfrastructureSystem
		desiredInfra  model.InfrastructureSystem
		hasKafka      bool
		stateMachExec bool
		zone          model.Zone
	}{
		{"UpdateUnmanaged", getInfra(model.ConfiguringState), getInfra(model.RunningState), false, true, model.Zone{}},
	}

	for _, tc := range testCases {
		mockDal := new(InfrastructureDAOMock)
		mockDal.On("Get").Return(tc.currentInfra, nil)
		mockDal.On("GetAll").Return([]model.InfrastructureSystem{getInfra(model.ConfiguringState)}, nil)
		mockDal.On(tc.dalOp).Return(nil)
		SetTaskExecutorMock(NewTaskExecutorMock(model.OK, common.ApplicationError{}))
		setMockedInfrastructureSystemDAL(mockDal)
		smMock := state_machine.NewStateMachineExecutorMock(common.ApplicationError{}, model.OK)
		state_machine.SetStateMachineExecutor(smMock)

		switch tc.dalOp {
		case "UpdateUnmanaged":
			infraSysExecutor := GetInfrastructureSystemExecutor()
			e := engine.EngineExecutorInstance
			defer func() { engine.EngineExecutorInstance = e }()

			engineMock := NewEngineExecutorMock()
			log.Info("Initializaing fake engine")
			engine.EngineExecutorInstance = engineMock

			defer func() { GetTaskExecutor = getTaskExecutor }()
			tMock := NewTaskExecutorMock(model.OK, common.ApplicationError{})

			SetTaskExecutorMock(tMock)
			log.Info("MAking the getall test call")
			infraSysExecutor.SynchronizeInfraWithGateway(tc.zone)
			engineMock.AssertCalled(t, "ExecuteEngine")
		}

		// wait for go routine to finish
		time.Sleep(time.Millisecond * 10)

	}
}

func getInfra(state model.StateType) model.InfrastructureSystem {
	var infra model.InfrastructureSystem
	infra.Name = "TestInfraSystem"
	infra.InfraState = state

	return infra
}

func setMockedInfrastructureSystemDAL(dal dal.InfrastructureSystemDAO) {
	GetInfrastructureSystemExecutor = func() InfrastructureSystemExecutor {
		infraExecutor := new(infrastructureSystemExecutor)
		infraExecutor.dal = dal
		infraExecutor.operations = GetInfraSystemOperations()
		return infraExecutor
	}
}
