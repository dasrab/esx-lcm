//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

package executer

import (
	"reflect"

	"errors"
	"testing"

	"fmt"

	"github.com/golang/mock/gomock"
	"github.com/prometheus/common/log"
	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

func TestNewBaseResourceExecutor(t *testing.T) {
	var dao dal.ManagedResourceDAO
	var resourceTypeName model.ResourceType = "/rest/zone"
	var resourceBaseURI common.IsmURI = "/rest/zone"
	var resourceType reflect.Type = nil
	var resourceListType reflect.Type = nil
	var operations operation.Operations = nil
	NewBaseResourceExecutor(dao, resourceTypeName, resourceBaseURI, resourceType, resourceListType, operations)

}

func TestResourceExecutor_BaseGetAll(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	MockManagedResourceDAO := dal.NewMockManagedResourceDAO(mockCtrl)
	testUser := &ResourceExecutor{dao: MockManagedResourceDAO, resourceListType: reflect.TypeOf("test"), resourceTypeName: "zone",
		resourceBaseURI: "/rest/api", resourceType: reflect.TypeOf("test")}
	filters := make(map[string][]string)
	filter := make(map[string][]string)

	resources := reflect.New(reflect.TypeOf("test")).Interface()
	MockManagedResourceDAO.EXPECT().BaseGetAll(&resources, filter).Return(nil)
	testUser.BaseGetAll(filters)
}

func TestResourceExecutor_BaseGet(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	MockManagedResourceDAO := dal.NewMockManagedResourceDAO(mockCtrl)
	testUser := &ResourceExecutor{dao: MockManagedResourceDAO, resourceListType: reflect.TypeOf("test"), resourceTypeName: "zone",
		resourceBaseURI: "/rest/api", resourceType: reflect.TypeOf("test")}
	resources := reflect.New(reflect.TypeOf("test")).Interface()
	MockManagedResourceDAO.EXPECT().BaseGet("test", resources).Return(nil)
	testUser.BaseGet("test")
}

func TestResourceExecutor_BaseCreate(t *testing.T) {
	var arg model.ResourceType
	e := ResourceExecutor{operations: nil, resourceTypeName: arg}
	var resource model.IManagedResource
	e.BaseCreate(resource)

}

func TestResourceExecutor_executeCreateResource(t *testing.T) {
	e := ResourceExecutor{}
	e1 := e.executeCreateResource
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)
	mockdao := new(dal.ManagedResourceDAOMock)
	mockdao.On("BaseCreate").Return(nil)
	runOperation(op, e1)

}

func TestResourceExecutor_executeUpdateResource(t *testing.T) {
	e := ResourceExecutor{}
	e1 := e.executeUpdateResource
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)
	mockdao := new(dal.ManagedResourceDAOMock)
	mockdao.On("BaseUpdate").Return(nil)
	runOperation(op, e1)

}

func TestResourceExecutor_BaseDelete(t *testing.T) {
	e := ResourceExecutor{}
	e.BaseDelete("1234")
}

func TestResourceExecutor_executeDeleteResource(t *testing.T) {
	e := ResourceExecutor{}
	e1 := e.executeDeleteResource
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)
	mockdao := new(dal.ManagedResourceDAOMock)
	mockdao.On("BaseDelete").Return(nil)
	runOperation(op, e1)

}

func TestResourceExecutor_BaseFlushAll(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	MockManagedResourceDAO := dal.NewMockManagedResourceDAO(mockCtrl)
	testUser := &ResourceExecutor{dao: MockManagedResourceDAO, resourceListType: reflect.TypeOf("test"), resourceTypeName: "zone",
		resourceBaseURI: "/rest/api", resourceType: reflect.TypeOf("test")}
	//filters := make(map[string][]string)
	resources := reflect.New(reflect.TypeOf("test")).Interface()
	MockManagedResourceDAO.EXPECT().BaseGetAll(&resources, nil).Return(nil)
	testUser.BaseFlushAll()
}

func TestResourceExecutor_updateState(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	MockManagedResourceDAO := dal.NewMockManagedResourceDAO(mockCtrl)
	testUser := &ResourceExecutor{dao: MockManagedResourceDAO, resourceListType: reflect.TypeOf("test"), resourceTypeName: "zone",
		resourceBaseURI: "/rest/api", resourceType: reflect.TypeOf("test")}
	//filters := make(map[string][]string)
	resources := reflect.New(reflect.TypeOf("test")).Interface()
	MockManagedResourceDAO.EXPECT().BaseGetAll(&resources, nil).Return(nil)
	testUser.updateState(model.AbortChangeOperation)

}

func TestResourceExecutor_executeAbortResource(t *testing.T) {
	e := ResourceExecutor{}
	e1 := e.executeAbortResource
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)

	runOperation(op, e1)

}

func Test_runOperation(t *testing.T) {
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)
	f := func(op operation.Operation) {

		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Update vCenter credentials Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorVcenterCredsUpdate, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorVcenterCredsUpdate,
			"Unable to update vCenter credentials with success.")
		runEngine(op, engine.UpdateZonePlaybook, opErr)
	}

	o, err := runOperation(op, f)
	assert.NotNil(t, o)
	assert.Nil(t, err)

}

func assertPanic(t *testing.T, f func(err error)) {
	defer func() {
		if r := recover(); r == nil {
			t.Errorf("The code did not panic")
		}
	}()
	var err = errors.New("error panic")
	f(err)
}

func Test_logAndPanic(t *testing.T) {
	//var err error
	assertPanic(t, logAndPanic)

}

func Test_runEngine(t *testing.T) {
	zone := model.Zone{}
	op := operation.NewOperation(
		"Update zone vCenter credentials",
		model.ZonesResourceType,
		&zone,
		operation.AsyncOp,
	)
	f := func(op operation.Operation) {

		defer func() {
			if r := recover(); r != nil {

				log.Errorf(fmt.Sprintf("Update vCenter credentials Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorVcenterCredsUpdate, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorVcenterCredsUpdate,
			"Unable to update vCenter credentials with success.")
		runEngine(op, engine.UpdateZonePlaybook, opErr)
	}
	runOperation(op, f)
}

func TestWaitForTask(t *testing.T) {
	mocktask := new(TaskExecuterMock)
	taskresource := model.TaskResource{}
	mocktask.On("Get").Return(taskresource, nil)
	op, err := WaitForTask("get", 6)
	if assert.Errorf(t, err, "error message %s", "formatted") {
		assert.NotNil(t, err)
	}
	assert.Nil(t, op)
}
