//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package executer

import (
	"fmt"
	"io/ioutil"
	"os"
	"sync"

	"github.com/antonholmquist/jason"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"

	"path"
	"runtime"
)

type ResourceProfileExecutor interface {
	GetAll(map[string][]string) model.ResourceProfileList
	Get(string) (model.ResourceProfile, error)
	Create(model.ResourceProfile) (model.TaskResource, error)
	Update(model.ResourceProfile) (model.TaskResource, error)
	Delete(model.ResourceProfile) error
}

type resourceProfileExecutor struct {
	operations operation.Operations
	names      model.ResourceProfile
}

var (
	rsOnce sync.Once
)
var jsonPath = getAbsoluteFilepath("../../ism-recipes/templates/platform_profile_template.json")

func getAbsoluteFilepath(filepath string) string {
	_, filename, _, _ := runtime.Caller(1)
	path := path.Join(path.Dir(filename), filepath)
	return path
}

var resourceProfileExecutorInstance ResourceProfileExecutor
var GetResourceProfileSExecutor = getResourceProfileExecutor

func getResourceProfileExecutor() ResourceProfileExecutor {
	rsOnce.Do(func() {
		rs := new(resourceProfileExecutor)
		rs.operations = BaseInventoryOperations
		rs.names = model.ResourceProfile{}
		resourceProfileExecutorInstance = rs
	})
	return resourceProfileExecutorInstance
}

func (this resourceProfileExecutor) GetAll(filters map[string][]string) model.ResourceProfileList {
	file, err := ioutil.ReadFile(jsonPath)
	if err != nil {
		fmt.Printf("File read error: %v\n", err)
		os.Exit(1)
	}
	var ResourceProfileNameMembers = []model.ResourceProfile{}

	// parse the bytes from the file
	v, err := jason.NewObjectFromBytes([]byte(file))
	if err != nil {
		panic(err)
	}
	// get the array for the string profile_templagtes
	s, err := v.GetObjectArray("profile_templates")
	// iterate over the array
	for _, n := range s {
		id, err := n.GetString("id")
		name, err := n.GetString("name")
		description, err := n.GetString("description")
		ResourceProfileNameMembers = append(ResourceProfileNameMembers, model.ResourceProfile{name, id, description})
		if err != nil {
			panic(err)
		}

	}
	resourceprofileList := model.NewResourceProfileList(ResourceProfileNameMembers)
	return resourceprofileList

}

func (rp resourceProfileExecutor) Create(r model.ResourceProfile) (model.TaskResource, error) {
	return model.TaskResource{}, nil
}
func (rp resourceProfileExecutor) Update(r model.ResourceProfile) (model.TaskResource, error) {
	return model.TaskResource{}, nil
}
func (rp resourceProfileExecutor) Delete(r model.ResourceProfile) error {
	return nil
}
func (rp resourceProfileExecutor) Get(r string) (model.ResourceProfile, error) {
	return model.ResourceProfile{}, nil
}
