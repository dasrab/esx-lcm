//(C) Copyright 2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"flag"
	"fmt"
	"net/http"
	"sync"

	"github.com/prometheus/client_golang/prometheus"
	log "github.hpe.com/kronos/kelog"
)

const (
	esxLcmNamespace = "esxlcm"
)

var (
	listenAddr  = flag.String("listen-address", "8085", "The address to listen on for HTTP requests")
	metricsPath = flag.String("telemetry-path", "/support/metrics", "Metric endpoint")
)

var (
	metricRecorderInitSync sync.Once
	metricRecorder         *externalCallMetricRecorder
)

type externalCallMetricRecorder struct {
	hpeGatewayAgentState *prometheus.GaugeVec
	hpeGatewayState      *prometheus.GaugeVec
}

// getEsxLcmMetrics ...
func getEsxLcmMetrics() *externalCallMetricRecorder {
	metricRecorderInitSync.Do(func() {
		metricRecorder = &externalCallMetricRecorder{
			hpeGatewayAgentState: prometheus.NewGaugeVec(
				prometheus.GaugeOpts{
					Namespace: esxLcmNamespace,
					Name:      "hpe_gateway_agent_state",
					Help:      fmt.Sprintf("Status of HPE Gateway Agent.")},
				[]string{"zoneID", "zoneType", "hostAgent"},
			),
			hpeGatewayState: prometheus.NewGaugeVec(
				prometheus.GaugeOpts{
					Namespace: esxLcmNamespace,
					Name:      "hpe_gateway_state",
					Help:      fmt.Sprintf("Status of HPE Gateway.")},
				[]string{"zoneID", "zoneType"},
			),
		}
	})
	return metricRecorder
}

// SetEsxLcmMetrics ...
func SetEsxLcmMetrics(zoneID, zoneType, hostAgent, metricsName string, healthyState bool) {
	recorder := getEsxLcmMetrics()
	// value of '0'(zero) consider as healthy
	switch metricsName {
	case "hpeGatewayAgentState":
		if healthyState {
			recorder.hpeGatewayAgentState.With(prometheus.Labels{"zoneID": zoneID, "zoneType": zoneType, "hostAgent": hostAgent}).Set(0)
		} else {
			recorder.hpeGatewayAgentState.With(prometheus.Labels{"zoneID": zoneID, "zoneType": zoneType, "hostAgent": hostAgent}).Set(1)
		}
	case "hpeGatewayState":
		if healthyState {
			recorder.hpeGatewayState.With(prometheus.Labels{"zoneID": zoneID, "zoneType": zoneType}).Set(0)
		} else {
			recorder.hpeGatewayState.With(prometheus.Labels{"zoneID": zoneID, "zoneType": zoneType}).Set(1)
		}
	default:
		panic("Unrecognised Metric")
	}
}

// RegisterEsxLcmMetrics for prometheus client
func RegisterEsxLcmMetrics() {
	flag.Parse()
	listenPort := ":" + *listenAddr
	metricsSet := getEsxLcmMetrics()
	prometheus.MustRegister(metricsSet.hpeGatewayAgentState)
	prometheus.MustRegister(metricsSet.hpeGatewayState)
	http.Handle(*metricsPath, prometheus.Handler())
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(`<html>
			<head><title>Esx-Lcm Exporter</title></head>
			<body>
			<h1>Esx-Lcm Exporter</h1>
			<p><a href='` + *metricsPath + `'>Metrics</a></p>
			</body>
			</html>`))
	})
	log.Infof("Starting ESX-LCM exporter to listen on %s port", listenPort)
	log.Fatal(http.ListenAndServe(listenPort, nil))
}
