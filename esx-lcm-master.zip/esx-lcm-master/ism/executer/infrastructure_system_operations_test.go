//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

package executer

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestGetInfraSystemOperations(t *testing.T) {

	op := GetInfraSystemOperations()
	assert.NotNil(t, op)
}
