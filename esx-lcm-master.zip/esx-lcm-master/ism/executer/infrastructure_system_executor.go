//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"fmt"
	"sync"

	log "github.hpe.com/kronos/kelog"

	"strings"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/state-machine"
)

type InfrastructureSystemExecutor interface {
	GetAll(map[string][]string) (model.InfrastructureSystemList, error)
	Get(string) (model.InfrastructureSystem, error)
	Create(model.InfrastructureSystem) (model.TaskResource, error)
	InternalUpdate(model.InfrastructureSystem) error
	Update(model.Zone, model.InfrastructureSystem) (model.TaskResource, error)
	Delete(string, model.Zone, map[string][]string) (model.TaskResource, error)
	SetInfrastructureBackup(infra model.InfrastructureSystem) error
	GetInfrastructureBackup() (model.InfrastructureSystem, error)
	GetOperations() operation.Operations
	Recover(model.Zone, model.InfrastructureSystem) (model.TaskResource, error)
	SynchronizeInfraWithGateway(zone model.Zone) error
}

type infrastructureSystemExecutor struct {
	dal             dal.InfrastructureSystemDAO
	infraContextDal dal.InfrastructureSystemContextDAO
	operations      operation.Operations
	iEnv            model.Zone
}

var (
	infraOnce      sync.Once
	updateMutex    = &sync.Mutex{}
	createMutex    = &sync.Mutex{}
	createEnvMutex = &sync.Mutex{}
)
var infraExecutorInstance InfrastructureSystemExecutor
var GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor

func getInfrastructureSystemExecutor() InfrastructureSystemExecutor {
	infraOnce.Do(func() {
		infraExec := new(infrastructureSystemExecutor)
		infraExec.dal = dal.NewInfrastructureSystemDAO()
		infraExec.infraContextDal = dal.NewInfrastructureSystemContextDAO()
		infraExec.operations = GetInfraSystemOperations()
		infraExec.iEnv = model.Zone{}
		infraExecutorInstance = infraExec
	})
	return infraExecutorInstance
}

func (e infrastructureSystemExecutor) SynchronizeInfraWithGateway(zone model.Zone) error {
	log.Debugf("Fetch all clusters from the gateway")
	var err error
	op := operation.NewOperation(
		"Fetching Managed Clusters",
		model.InfrastructureSystemsResourceTypeList,
		nil,
		operation.SyncOp,
	)
	op.SetResourceEnv(&zone)
	f := func(op operation.Operation) {
		opErr := common.NewApplicationError(common.ErrorGetUnmanagedResource,
			"Unable to fetch unmanaged resource")
		runEngine(op, engine.GetUnmanagedResourcePlaybook, opErr)
		if err != nil {
			log.Errorf("Failed while update state to running: %v", err)
			op.SetExecutionError(opErr)
			return

		}
		log.Infof("Done Allocating resources. Result Status: [%v] - Result Error: [%v]",
			op.Status(), op.ExecutionError())
	}
	runOperation(op, f)
	if op.ExecutionError().Message != "" {
		return op.ExecutionError()

	}
	return nil
}

func (e infrastructureSystemExecutor) GetAll(filters map[string][]string) (model.InfrastructureSystemList, error) {
	log.Debugf("Getting all Infrastructures")
	var infraListMembers []model.InfrastructureSystem
	var err error
	infraListMembers, err = e.dal.GetAll(filters)
	if err != nil {
		log.Errorf("Could not get Infrastructure System List: %v", err)
		return model.InfrastructureSystemList{}, common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("%v", err))

	}
	infraList := model.NewInfrastructureSystemList(infraListMembers)
	return infraList, nil
}

func (e infrastructureSystemExecutor) Get(id string) (model.InfrastructureSystem, error) {
	log.Debugf("Getting Infrastructure (%s)", id)

	infra, err := e.dal.Get(id)
	if err != nil {
		message := fmt.Sprintf("Infrastructure System with Id %s was not found", id)
		log.Errorf(message)
		return model.InfrastructureSystem{}, common.NewApplicationError(common.ErrorResourceNotFound, message)
	}
	return infra, nil
}

//
// Create
//
func (e infrastructureSystemExecutor) Create(infra model.InfrastructureSystem) (model.TaskResource, error) {
	if infra.Managed == "True" {
		log.Infof("Creating a managed Infrastructure (%s)", infra.Name)
		infra.InfraState = model.ConfiguringState
		infra.State = model.DisabledState
	} else {
		infra.InfraState = model.RunningState
		log.Infof("Creating an unmanaged infra %v with state %v", infra.Name, infra.State)
	}
	if infra.Status == "" {
		// set the default state is nothing has been passed
		infra.Status = model.OK
	}
	if infra.Managed == "True" {
		infra.Id = infra.Name
		//e.InternalUpdate(infra)
	}

	//infra.ServerSettings.DeploymentType = model.Spread

	//FIXME QXCR1001512880 - Not standard call to database in infrastructure-systems-executor
	if err := e.dal.Create(&infra); err != nil {
		message := fmt.Sprintf("Error creating Infrastructure System in Database: %v", err)

		// Handle database conflict Error explicitly
		if err.Error() == common.ErrorDatabaseConflict.String() {
			databaseError := common.NewApplicationError(common.ErrorDatabaseConflict, message)
			return model.TaskResource{}, databaseError
		}

		return model.TaskResource{}, common.NewApplicationError(common.ErrorDatabase, message)
	}

	op, err := createOperation(
		e.operations,
		model.InitialState,
		model.ConfiguringState,
		model.InfrastructureSystemsResourceType,
		&infra,
	)

	if err != nil {
		log.Errorf("Error creating Infrastructure System: %v", err)
		return model.TaskResource{}, err
	}

	op.AddErrorHandler(panicHandler)

	defer func() {
		log.Infof("Done Creating Infrastructure (%s) -- Task (%s)", infra.Name, op.TaskUUID())
	}()
	return runOperation(op, e.executeInitializeInfrastructureSystem)
}

// Execute Create Infrastructure Task
// FIXME if 'task' is updated by another process while this thread runs the update might be lost
// This is a very rare race condition that should be treated in 2.
func (e infrastructureSystemExecutor) executeInitializeInfrastructureSystem(op operation.Operation) {
	//createMutex.Lock()
	//defer createMutex.Unlock()

	log.Debugf("Creating Infrastructure (%v) asynchronously -- Task (%v)", op.ResourceUUID(), op.TaskUUID())

	op.SetStatus(model.OK)
	log.Debugf("Done Creating Infrastructure (%v) asynchronously -- Task (%v)", op.ResourceUUID(), op.TaskUUID())
}

//
// Update
//
func (e infrastructureSystemExecutor) InternalUpdate(infra model.InfrastructureSystem) error {
	log.Debugf("Update Infrastructure (%s)", infra.GetUUID())

	infra.Uri = common.BuildUri(common.URIInfrastructureSystem, infra.GetUUID())

	if err := e.dal.Update(&infra); err != nil {
		message := fmt.Sprintf("Error Updating Infrastructure (%s) - %v", infra.Name, err)
		log.Errorf(message)
		return common.NewApplicationError(common.ErrorDatabase, message)
	}

	log.Debugf("Done Update Infrastructure (%s)", infra.GetUUID())
	return nil
}

func (e infrastructureSystemExecutor) Update(zone model.Zone, infra model.InfrastructureSystem) (model.TaskResource, error) {
	log.Debugf("Updating Infrastructure (%v)", infra.GetUUID())

	infra.SetURI(common.BuildUri(common.URIInfrastructureSystem, infra.GetUUID()))

	// Get Current InfraState
	currentInfra, err := e.Get(infra.GetUUID())
	if err != nil {
		return model.TaskResource{}, err
	}

	if (currentInfra.InfraState == model.RunningState) && (infra.InfraState == model.RunningState) {
		e.InternalUpdate(infra)
		// todo: FIX THIS
		// NCSVMW-907: TaskResource should never be empty if error is nil
		return model.TaskResource{}, nil
	}

	op, err := createOperation(
		e.operations,
		currentInfra.InfraState,
		infra.InfraState,
		model.InfrastructureSystemsResourceType,
		&infra,
	)

	op.SetResourceEnv(&zone)
	if err != nil {
		return model.TaskResource{}, err
	}

	op.AddErrorHandler(panicHandler)

	defer func() {
		log.Debugf("Done Updating Infrastructure (%v) -- Task (%v)", infra.GetUUID(), op.TaskUUID())
	}()
	return runOperation(op, e.executeUpdateInfrastructureSystem)
}

func (e infrastructureSystemExecutor) executeUpdateInfrastructureSystem(op operation.Operation) {
	//updateMutex.Lock()
	//defer updateMutex.Unlock()

	log.Debugf("Updating Infrastructure (%v) asynchronously -- Task (%v)", op.ResourceUUID(), op.TaskUUID())

	infra := op.Resource().(*model.InfrastructureSystem)

	// Complement context
	currentInfra, err := e.dal.Get(op.ResourceUUID())
	if err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorResourceNotFound, fmt.Sprintf("InfrastructureSystem %s was not found", op.ResourceUUID())))
	}

	c := state_machine.NewInfrastructureSystemContext()
	c.ActualInfra = currentInfra
	c.DesiredInfra = *infra
	c.TaskUUID = op.TaskUUID()
	//c.Tags = e.getPlaybookTags(c)
	c.SetActualState(c.ActualInfra.InfraState)
	c.SetTargetState(c.DesiredInfra.InfraState)
	zone := op.ResourceEnv().(*model.Zone)
	c.Env = *zone

	// Let's do it
	retContext := state_machine.StateMachineExecutor().Execute(c)

	op.SetStatus(retContext.ExecutionStatus())
	op.SetExecutionError(retContext.ExecutionError())

	log.Debugf("Done Updating Infrastructure (%v) asynchronously -- Task (%v)", op.ResourceUUID(), op.TaskUUID())
}

//
// Delete
//
func (e infrastructureSystemExecutor) Delete(id string, zone model.Zone, params map[string][]string) (model.TaskResource, error) {
	log.Infof("Deleting Infrastructure (%v)", id)

	// Get fresh resource
	infra, err := e.Get(id)
	if err != nil {
		return model.TaskResource{}, err
	}

	op, err := createOperation(
		e.operations,
		model.ReadyChangeOperation,
		model.DeletingChangeOperation,
		model.InfrastructureSystemsResourceType,
		&infra,
	)

	op.SetExtraParams(params)
	op.SetResourceEnv(&zone)
	if err != nil {
		return model.TaskResource{}, err
	}

	//TODO: set infrastructure-system to deleteFailed state
	/*errHandler := func(op Operation) {
		currentInfra, _ := e.dal.Get(op.ResourceUUID())
		currentInfra.Status = model.DeleteFailed
		e.dal.Update(&currentInfra)
	}
	op.AddErrorHandler(errHandler)*/
	successHandler := func(op operation.Operation) {
		// Perform changes in db
		if err := e.dal.Delete(op.ResourceUUID()); err != nil {
			log.Errorf("Error deleting Infrastructure System in Database: %v", err)
			panic(common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("%v", err)))
		}
		log.Infof("Done Deleting Infrastructure (%v) asynchronously from ISM Inventory -- Task (%v)",
			op.ResourceUUID(), op.TaskUUID())
	}
	op.AddSuccessHandler(successHandler)
	defer func() {
		log.Infof("Done Deleting Infrastructure (%v) -- Task (%v)", infra.GetUUID(), op.TaskUUID())
	}()
	return runOperation(op, e.executeDeleteInfrastructureSystem)
}

func (e infrastructureSystemExecutor) executeDeleteInfrastructureSystem(op operation.Operation) {
	log.Infof("Deleting Infrastructure (%v) asynchronously -- Task (%v)", op.ResourceUUID(), op.TaskUUID())
	currentInfra, err := e.dal.Get(op.ResourceUUID())
	if err != nil {
		logAndPanic(common.NewApplicationError(common.ErrorResourceNotFound, fmt.Sprintf("InfrastructureSystem %s was not found", op.ResourceUUID())))
	}
	params := op.ExtraParams()
	targetState := model.DeletingState
	if val, ok := params["force"]; ok && strings.EqualFold(val[0], "true") {
		targetState = model.ForceDeletingState
	}
	if (currentInfra.InfraState == model.RunningState) || (currentInfra.InfraState == model.DeletingErrorState) || (currentInfra.InfraState == model.DeploymentErrorState) {
		infra := op.Resource().(*model.InfrastructureSystem)
		c := state_machine.NewInfrastructureSystemContext()
		c.ActualInfra = currentInfra
		c.DesiredInfra = *infra
		c.TaskUUID = op.TaskUUID()
		//c.Tags = e.getPlaybookTags(c)
		c.SetActualState(c.ActualInfra.InfraState)
		c.SetTargetState(targetState)
		zone := op.ResourceEnv().(*model.Zone)
		c.Env = *zone
		if currentInfra.Managed == "True" {
			// Let's do it
			log.Infof("Deleting the managed resource %v from the DB", infra.Name)
			retContext := state_machine.StateMachineExecutor().Execute(c)
			op.SetStatus(retContext.ExecutionStatus())
			op.SetExecutionError(retContext.ExecutionError())
		} else {
			log.Infof("Deleting the unmanaged resource %v from the DB", infra.Name)
			op.SetStatus(model.OK)
			op.SetExecutionError(common.ApplicationError{})
		}
	}

	log.Infof("Done Deleting Infrastructure (%v) asynchronously on OneView -- Task (%v)",
		op.ResourceUUID(), op.TaskUUID())
}

// Recover

func (e infrastructureSystemExecutor) recoverExpandErrorClusters(zone model.Zone, infra model.InfrastructureSystem) (model.TaskResource, error) {
	op := operation.NewOperation(
		"Recover from Expanding Error state",
		model.InfrastructureSystemsResourceType,
		&infra,
		operation.AsyncOp,
	)
	successHandler := func(op operation.Operation) {
		infra, _ := getInfrastructureSystemExecutor().Get(op.ResourceUUID())
		infra.InfraState = model.RunningState
		e.InternalUpdate(infra)
	}
	op.SetResourceEnv(&zone)
	op.AddSuccessHandler(successHandler)
	op.AddDispatcher(NewTaskDispatcher("Recovering from Expand error state", op))
	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Recover from Expand Error Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorAddCapacity, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorRegisterSPTBlueprintFailure, "Unable to recover from Expand Error state.")
		runEngine(op, engine.ExpandCleanUpPlaybook, opErr)

		log.Infof("Recovering from Expand Failure. Result Status: [%v] - Result Error: [%v]",
			op.Status(),
			op.ExecutionError())
	}

	log.Infof("Triggering Recovering of Expand failure Async")
	return runOperation(op, f)

}
func (e infrastructureSystemExecutor) Recover(zone model.Zone, infra model.InfrastructureSystem) (model.TaskResource, error) {
	log.Infof("Recovering Infrastructure (%v)", infra.Uuid)
	var task model.TaskResource
	var err error

	if infra.InfraState == model.DeploymentErrorState {
		log.Infof("Recovering from Provision failure ")
		params := map[string][]string{}
		params["force"] = []string{"true"}
		task, err = e.Delete(infra.Uuid, zone, params)

	} else if infra.InfraState == model.ExpandingErrorState {
		log.Infof("Recovering from Expand failure ")
		task, err = e.recoverExpandErrorClusters(zone, infra)
	}

	return task, err
}

//
// Utils
//

func (e infrastructureSystemExecutor) SetInfrastructureBackup(infraToBackup model.InfrastructureSystem) error {
	infraToBackupLog := infraToBackup
	model.ClearSecretInfo(&infraToBackupLog)
	log.Debugf("Setting Infrastructure Backup: (%v)", infraToBackupLog)

	infraSystemContextList, err := e.infraContextDal.GetAll(nil)
	if err != nil {
		return err
	}

	for _, infraSystemBackup := range infraSystemContextList {
		if err := e.infraContextDal.Delete(infraSystemBackup.GetUUID()); err != nil {
			return err
		}
	}

	var infraContext model.InfrastructureSystemContext
	infraContext.CreatedInfrastructureSystem = infraToBackup

	if err := e.infraContextDal.Create(&infraContext); err != nil {
		message := fmt.Sprintf("Error creating Infrastructure System Context in Database: %v", err)
		return common.NewApplicationError(common.ErrorDatabase, message)
	}

	return nil
}

func (e infrastructureSystemExecutor) GetInfrastructureBackup() (model.InfrastructureSystem, error) {
	log.Info("Getting Infrastructure Backup")

	infraContextList, err := e.infraContextDal.GetAll(nil)

	if err != nil {
		message := fmt.Sprintf("Infrastructure System Context was not found")
		log.Errorf(message)
		return model.InfrastructureSystem{}, common.NewApplicationError(common.ErrorResourceNotFound, message)
	}

	if len(infraContextList) > 0 {
		return infraContextList[0].CreatedInfrastructureSystem, nil
	}

	return model.InfrastructureSystem{}, nil
}

//func (e infrastructureSystemExecutor) getPlaybookTags(ctx state_machine.InfrastructureSystemContext) []playbook.Tag {
//	// TODO: Tie state and playbook smoothly. Keep playbook capabilities (e.g. supported tags) into playbook metadata
//	if IsStateTagBased(ctx.DesiredInfra.InfraState) {
//		log.Infof("InfraState %v requires tags", ctx.DesiredInfra.InfraState)
//		tags, err := GetTagFinder().Do(ctx)
//		if err != nil {
//			panic(err)
//		}
//		return tags
//
//	} else {
//		log.Infof("InfraState %v does not require tags", ctx.DesiredInfra.InfraState)
//	}
//	return []playbook.Tag{}
//}

func (e infrastructureSystemExecutor) GetOperations() operation.Operations {
	return e.operations
}

//
// Handlers
//
func CleanInfraTransientData(op operation.Operation) {
	currentInfra, _ := getInfrastructureSystemExecutor().Get(op.ResourceUUID())
	//currentInfra.CleanTransientData()
	getInfrastructureSystemExecutor().InternalUpdate(currentInfra)
}

func panicHandler(op operation.Operation) {
	// Set the Infrastructure as critical
	//TODO: What happens if we fail here?
	currentInfra, _ := getInfrastructureSystemExecutor().Get(op.ResourceUUID())
	currentInfra.Status = model.Critical
	getInfrastructureSystemExecutor().InternalUpdate(currentInfra)
}
