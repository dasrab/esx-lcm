//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

var availableDispatchers operation.AvailableDispatchersType = operation.AvailableDispatchersType{
	operation.TaskDispatcher: NewTaskDispatcher,
}

//
// TASK DISPATCHER
//
func NewTaskDispatcher(taskName string, op operation.Operation) operation.Dispatcher {
	var assocResUri string = ""
	if op.Resource() != nil {
		assocResUri = op.Resource().GetUri()
	}

	taskUUID := GetTaskExecutor().Create(taskName, assocResUri).GetUUID()
	op.SetTaskUUID(taskUUID)

	d := operation.NewDispatcher(taskDispatcherOnStart, taskDispatcherOnEnd, taskDispatcherOnEnd)
	return d
}

func taskDispatcherOnStart(op operation.Operation) {
	task, err := GetTaskExecutor().Get(op.TaskUUID())
	if err != nil {
		return
	}

	task.State = model.Running

	if (task.AssociatedResourceInstanceUri == "") && (op.Resource() != nil) {
		task.SetAssociatedResourceWithoutName(
			op.Resource().GetUri(),
			op.ResourceUUID(),
			op.ResourceType(),
		)
	}

	GetTaskExecutor().Update(task)
}

func taskDispatcherOnEnd(op operation.Operation) {
	if op.Resource() != nil {
		// Check if task's fields are ok
		task, err := GetTaskExecutor().Get(op.TaskUUID())
		if err != nil {
			return
		}

		if (task.AssociatedResourceInstanceUri == "") ||
			(task.AssociatedResourceInstanceId == "") ||
			(task.AssociatedResourceType == "") {
			task.SetAssociatedResourceWithoutName(
				op.Resource().GetUri(),
				op.ResourceUUID(),
				op.ResourceType(),
			)
			GetTaskExecutor().Update(task)
		}
	}

	GetTaskExecutor().CompleteTaskWithError(op.TaskUUID(), op.Status(), op.ExecutionError())
}
