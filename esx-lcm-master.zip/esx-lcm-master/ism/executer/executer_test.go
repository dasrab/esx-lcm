//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/suite"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine/playbook"
)

// Base Mock for DAOs
type MockDAO struct {
	mock.Mock
}

func (m *MockDAO) Delete(interface{}) error {
	args := m.Called()
	return args.Error(0)
}

// Mock for Engine calls
type EngineExecutorMock struct {
	mock.Mock
}

func (e *EngineExecutorMock) ExecuteEngine(resource interface{}, playbookType engine.PlaybookType, tags []playbook.Tag,
	ctx playbook.Context, env interface{}) engine.PlaybookResult {
	args := e.Called()
	return args.Get(0).(engine.PlaybookResult)
}

func NewEngineExecutorMock() *EngineExecutorMock {
	e := new(EngineExecutorMock)
	e.On("ExecuteEngine").Return(engine.PlaybookResult{Status: "SUCCESS", Errors: []common.ApplicationError{}})
	return e
}

func NewEngineExecutorFailMock() *EngineExecutorMock {
	e := new(EngineExecutorMock)
	e.On("ExecuteEngine").Return(
		engine.PlaybookResult{
			Status: "FAIL",
			Errors: []common.ApplicationError{
				{ErrorCode: "HCOE_ISM_ERROR"},
			},
		})
	return e
}

// Executor Test Suite
type ExecutorTestSuite struct {
	suite.Suite
	taskExec func() TaskExecutorInterface
}

func (s *ExecutorTestSuite) setupSuite() {
	common.StartLogs()

	s.taskExec = GetTaskExecutor
}

func (s *ExecutorTestSuite) tearDownSuite() {
	GetTaskExecutor = s.taskExec
}
