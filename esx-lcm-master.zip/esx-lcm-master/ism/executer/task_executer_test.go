//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

package executer

import (
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"

	"reflect"
	"sync"

	"github.com/golang/mock/gomock"
)

func Test_getTaskExecutor(t *testing.T) {
	taskOnce.Do(func() {
		exec := new(taskExecutor)
		exec.dal = dal.NewTaskDAO()
		exec.mux = &sync.Mutex{}
		taskExecutorInstance = exec
	})
	taskExecutorInstance1 := getTaskExecutor()
	if !reflect.DeepEqual(taskExecutorInstance, taskExecutorInstance1) {
		t.Errorf("Error")
	}
}

func Test_taskExecutor_GetAll(t *testing.T) {
	filter := make(map[string][]string)
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	mockTaskDAO := dal.NewMockTaskDAO(mockCtrl)
	testUser := &taskExecutor{dal: mockTaskDAO}
	mockTaskDAO.EXPECT().GetAll(filter).Return(nil, nil).Times(1)
	mockTaskDAO.EXPECT().GetTotal(filter).Return(0, nil).Times(1)
	mockTaskDAO.EXPECT().GetStart(filter).Return(0).Times(1)

	testUser.GetAll(filter)

}

func Test_taskExecutor_Get(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	mockTaskDAO := dal.NewMockTaskDAO(mockCtrl)
	testUser := &taskExecutor{dal: mockTaskDAO}
	mockTaskDAO.EXPECT().Get("abc").Return(model.TaskResource{}, nil).Times(1)
	testUser.Get("abc")
}

func Test_taskExecutor_Delete(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	mockTaskDAO := dal.NewMockTaskDAO(mockCtrl)
	testUser := &taskExecutor{dal: mockTaskDAO}
	mockTaskDAO.EXPECT().Delete("fdf").Return(nil).Times(1)

	testUser.Delete("fdf")
}

func Test_taskExecutor_Create(t *testing.T) {

}

func Test_taskExecutor_CreateSubTask(t *testing.T) {

}

func Test_taskExecutor_UpdateSubTask(t *testing.T) {

}

func Test_taskExecutor_WaitForChildTask(t *testing.T) {

}

func Test_taskExecutor_PollTaskForCompletion(t *testing.T) {

}

func Test_taskExecutor_Update(t *testing.T) {

}

func Test_taskExecutor_CompleteTask(t *testing.T) {

}

func Test_taskExecutor_CompleteTaskWithError(t *testing.T) {

}

func Test_taskExecutor_completeSubTasks(t *testing.T) {

}

func Test_taskExecutor_insertTask(t *testing.T) {

}

func Test_taskExecutor_updateTask(t *testing.T) {

}
