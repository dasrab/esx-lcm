//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

const (
	ConfigureEventType    string = "Configuration"
	DeployEventType       string = "Deployment"
	ContractEventType     string = "Contraction"
	DeleteEventType       string = "Deletion"
	ReconfigureEventType  string = "Reconfiguration"
	UpdateEventType       string = "Update"
	ExpandEventType       string = "Expansion"
	BackupEventType       string = "Backup"
	RestoreEventType      string = "Restore"
	FactoryResetEventType string = "FactoryReset"
	ShutdownEvenType      string = "Shutdown"
)

// TODO: Check witch operations have inventory changes to better configure success/failure callbacks
func GetInfraSystemOperations() operation.Operations {
	infraOperations := operation.Operations{}

	infraOperations = make(map[operation.OperationKey]operation.OperationConfig)

	initOp := operation.OperationConfig{
		Name: "Create Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_CREATE_INFRASTRUCTURE",
		},
	}
	infraOperations[operation.OperationKey{Origin: model.InitialState, Target: model.ConfiguringState}] = initOp

	configOp := operation.OperationConfig{
		Name: "Configure Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_CONFIGURE_INFRASTRUCTURE",
		},
	}
	infraOperations[operation.OperationKey{Origin: model.ConfiguringState, Target: model.ConfiguringState}] = configOp
	infraOperations[operation.OperationKey{Origin: model.DeploymentErrorState, Target: model.ConfiguringState}] = configOp

	deployOp := operation.OperationConfig{
		Name: "Deploy Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_DEPLOY_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.ConfiguringState, Target: model.DeployingState}] = deployOp
	infraOperations[operation.OperationKey{Origin: model.DeploymentErrorState, Target: model.DeployingState}] = deployOp

	contractOp := operation.OperationConfig{
		Name: "Contract Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_CONTRACT_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.ContractingState}] = contractOp
	infraOperations[operation.OperationKey{Origin: model.UpdateErrorState, Target: model.ContractingState}] = contractOp

	// New Allocate operation
	allocateOp := operation.OperationConfig{
		Name: "Allocate Resource",
	}
	// Configuring to Allocated State transition is added temporarily for enabling testing
	infraOperations[operation.OperationKey{Origin: model.ConfiguringState, Target: model.EnablingState}] = allocateOp
	infraOperations[operation.OperationKey{Origin: model.DisabledState, Target: model.EnablingState}] = allocateOp
	infraOperations[operation.OperationKey{Origin: model.EnabledState, Target: model.EnablingState}] = allocateOp

	// New DeAllocate operation
	deallocateOp := operation.OperationConfig{
		Name: "DeAllocate Resource",
	}
	infraOperations[operation.OperationKey{Origin: model.EnabledState, Target: model.DisablingState}] = deallocateOp
	infraOperations[operation.OperationKey{Origin: model.DisabledState, Target: model.DisablingState}] = deallocateOp

	// New Delete operation
	deleteOp := operation.OperationConfig{
		Name: "Delete Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_DELETE_INFRASTRUCTURE",
		},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.DeletingState}] = deleteOp

	reconfigureOp := operation.OperationConfig{
		Name: "Reconfigure Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_RECONFIGURE_INFRASTRUCTURE",
		},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.ReconfiguringState}] = reconfigureOp
	infraOperations[operation.OperationKey{Origin: model.ReconfiguringErrorState, Target: model.ReconfiguringState}] = reconfigureOp

	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.ExpandingState}] = operation.OperationConfig{
		Name: "Expand Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_EXPAND_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}

	updateOp := operation.OperationConfig{
		Name: "Update Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_UPDATE_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.UpdatingState}] = updateOp
	infraOperations[operation.OperationKey{Origin: model.UpdateErrorState, Target: model.UpdatingState}] = updateOp

	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.ShuttingdownState}] = operation.OperationConfig{
		Name: "Shutdown Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_SHUTDOWN_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}

	facResetOp := operation.OperationConfig{
		Name: "Factory Reset Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_FACTORY_RESET_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.FactoryResettingState}] = facResetOp
	infraOperations[operation.OperationKey{Origin: model.UpdateErrorState, Target: model.FactoryResettingState}] = facResetOp
	infraOperations[operation.OperationKey{Origin: model.ReconfiguringErrorState, Target: model.FactoryResettingState}] = facResetOp
	infraOperations[operation.OperationKey{Origin: model.RestoreErrorState, Target: model.FactoryResettingState}] = facResetOp

	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.BackingUpState}] = operation.OperationConfig{
		Name: "Backup Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_BACKUP_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}

	restoreOp := operation.OperationConfig{
		Name: "Restore Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_RESTORE_INFRASTRUCTURE",
		},
		SuccessCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
		FailureCallbacks: []operation.HandlerFunc{CleanInfraTransientData},
	}
	infraOperations[operation.OperationKey{Origin: model.RunningState, Target: model.RestoringState}] = restoreOp
	infraOperations[operation.OperationKey{Origin: model.RestoreErrorState, Target: model.RestoringState}] = restoreOp

	infraOperations[operation.OperationKey{Origin: model.ReadyChangeOperation, Target: model.DeletingChangeOperation}] = operation.OperationConfig{
		Name: "Delete Infrastructure System",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_DELETE",
		},
	}

	return infraOperations
}
