//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// Mock for Task Executor
type TaskExecuterMock struct {
	mock.Mock
}

func (m *TaskExecuterMock) GetAll(filters map[string][]string) (model.TaskResourceList, error) {
	args := m.Called()
	return args.Get(0).(model.TaskResourceList), args.Error(1)
}

func (m *TaskExecuterMock) Get(id string) (model.TaskResource, error) {
	args := m.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (m *TaskExecuterMock) Delete(id string) error {
	args := m.Called()
	return args.Error(0)
}

func (m *TaskExecuterMock) Create(name string, associatedResource string) model.TaskResource {
	m.Called()
	t := model.NewParentTaskResource(name, associatedResource)
	t.Uuid = "123"
	return t
}

func (m *TaskExecuterMock) CreateSubTask(subTask model.TaskResource) (model.TaskResource, error) {
	args := m.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (m *TaskExecuterMock) UpdateSubTask(subTask model.TaskResource) (model.TaskResource, error) {
	args := m.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (m *TaskExecuterMock) Update(task model.TaskResource) (model.TaskResource, error) {
	args := m.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (m *TaskExecuterMock) CompleteTask(id string, status model.HealthStatus) error {
	args := m.Called(status)
	return args.Error(0)
}

func (m *TaskExecuterMock) CompleteTaskWithError(id string, status model.HealthStatus, error common.ApplicationError) error {
	args := m.Called(status, error)
	return args.Error(0)
}

func (m *TaskExecuterMock) WaitForChildTask(*model.TaskResource) common.ApplicationError {
	args := m.Called()
	return args.Get(0).(common.ApplicationError)
}

func NewTaskExecutorMock(status model.HealthStatus, err common.ApplicationError) *TaskExecuterMock {
	e := new(TaskExecuterMock)
	e.On("GetAll").Return(model.TaskResourceList{}, nil)
	e.On("Get").Return(model.TaskResource{State: "Completed"}, nil)
	e.On("Create").Return(model.TaskResource{}, nil)
	e.On("CreateSubTask").Return(model.TaskResource{}, nil)
	e.On("UpdateSubTask").Return(model.TaskResource{}, nil)
	e.On("Update").Return(model.TaskResource{}, nil)
	e.On("Delete").Return(nil)
	e.On("CompleteTask", status).Return(nil)
	e.On("CompleteTaskWithError", status, err).Return(nil)
	e.On("WaitForChildTask").Return(nil)
	return e
}

func SetTaskExecutorMock(t TaskExecutorInterface) {
	GetTaskExecutor = func() TaskExecutorInterface {
		return t
	}
}
