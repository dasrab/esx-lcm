//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

type InfrastructureSystemExecutorMock struct {
	mock.Mock
}

func (e *InfrastructureSystemExecutorMock) GetAll(f map[string][]string) (model.InfrastructureSystemList, error) {
	args := e.Called()
	return args.Get(0).(model.InfrastructureSystemList), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) SynchronizeInfraWithGateway(zone model.Zone) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemExecutorMock) Get(id string) (model.InfrastructureSystem, error) {
	args := e.Called()
	return args.Get(0).(model.InfrastructureSystem), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) Create(infra model.InfrastructureSystem) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) InternalUpdate(infra model.InfrastructureSystem) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemExecutorMock) Update(zone model.Zone, infra model.InfrastructureSystem) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) Delete(id string, zone model.Zone, params map[string][]string) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) SetInfrastructureBackup(infra model.InfrastructureSystem) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemExecutorMock) GetInfrastructureBackup() (model.InfrastructureSystem, error) {
	args := e.Called()
	return args.Get(0).(model.InfrastructureSystem), args.Error(1)
}

func (e *InfrastructureSystemExecutorMock) CreateInfrastructureSystemEnvironment(infra model.Zone) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemExecutorMock) GetInfrastructureSystemEnvironment() model.Zone {
	args := e.Called()
	return args.Get(0).(model.Zone)
}

func (e *InfrastructureSystemExecutorMock) GetOperations() operation.Operations {
	args := e.Called()
	return args.Get(0).(operation.Operations)
}

func (e *InfrastructureSystemExecutorMock) Recover(zone model.Zone, infra model.InfrastructureSystem) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func SetMockedInfrastructureSystemExecutor(e *InfrastructureSystemExecutorMock) {
	GetInfrastructureSystemExecutor = func() InfrastructureSystemExecutor {
		return e
	}
}
