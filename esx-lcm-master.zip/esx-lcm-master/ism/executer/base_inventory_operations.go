//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

var BaseInventoryOperations operation.Operations = operation.Operations{
	{Origin: model.ReadyChangeOperation, Target: model.CreatingChangeOperation}: operation.OperationConfig{
		Name: "Creating",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_CREATE",
		},
	},
	{Origin: model.CreatingChangeOperation, Target: model.CreatingChangeOperation}: operation.OperationConfig{
		Name: "Create",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_CREATE",
		},
	},
	{Origin: model.CreatingChangeOperation, Target: model.ReadyChangeOperation}: operation.OperationConfig{
		Name: "Create",
	},
	{Origin: model.CreatingChangeOperation, Target: model.AbortChangeOperation}: operation.OperationConfig{
		Name: "Abort Create",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_ABORT",
		},
	},
	{Origin: model.ReadyChangeOperation, Target: model.UpdatingChangeOperation}: operation.OperationConfig{
		Name: "Updating",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_UPDATE",
		},
	},
	{Origin: model.UpdatingChangeOperation, Target: model.ReadyChangeOperation}: operation.OperationConfig{
		Name: "Update",
	},
	{Origin: model.UpdatingChangeOperation, Target: model.UpdatingChangeOperation}: operation.OperationConfig{
		Name: "Update",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_UPDATE",
		},
	},
	{Origin: model.UpdatingChangeOperation, Target: model.AbortChangeOperation}: operation.OperationConfig{
		Name: "Abort Update",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_ABORT",
		},
	},
	{Origin: model.ReadyChangeOperation, Target: model.DeletingChangeOperation}: operation.OperationConfig{
		Name: "Deleting",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_DELETE",
		},
	},
	{Origin: model.DeletingChangeOperation, Target: model.ReadyChangeOperation}: operation.OperationConfig{
		Name: "Delete",
	},
	{Origin: model.DeletingChangeOperation, Target: model.AbortChangeOperation}: operation.OperationConfig{
		Name: "Abort Delete",
		Dispatchers: operation.DispatchersConfig{
			Task: "HCOE_ISM_INVENTORY_ABORT",
		},
	},
}

func copyBaseInventoryOperations() operation.Operations {
	ops := operation.Operations{}
	for k, v := range BaseInventoryOperations {
		ops[k] = v
	}
	return ops
}
