//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

func setMockedInfrastructureSystemExecutor(dal dal.InfrastructureSystemDAO) {
	GetInfrastructureSystemExecutor = func() InfrastructureSystemExecutor {
		infraExecutorInstance := new(infrastructureSystemExecutor)
		infraExecutorInstance.dal = dal
		infraExecutorInstance.operations = GetInfraSystemOperations()
		return infraExecutorInstance
	}
}

func getInfraList(state model.StateType) model.InfrastructureSystemList {
	var infraList model.InfrastructureSystemList
	var infra model.InfrastructureSystem
	infra.Name = "TestInfraSystem"
	infra.InfraState = state
	infra.Uuid = "123"
	infraList.SetMembers([]model.InfrastructureSystem{infra})
	return infraList
}

func TestAllocateResources(t *testing.T) {
	common.StartLogs()

	SetPlaybookContextMock()
	defer func() { GetTaskExecutor = getTaskExecutor }()
	defer func() { GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor }()

	e := engine.EngineExecutorInstance
	defer func() { engine.EngineExecutorInstance = e }()

	testCases := []struct {
		success      bool
		currentInfra model.InfrastructureSystem
		engineMock   *EngineExecutorMock
	}{
		{
			success:      true,
			currentInfra: getInfra(model.DisabledState),
			engineMock:   NewEngineExecutorMock(),
		},
		{
			success:      false,
			currentInfra: getInfra(model.DisabledState),
			engineMock:   NewEngineExecutorFailMock(),
		},
	}

	for _, tc := range testCases {
		mockDal := new(InfrastructureDAOMock)
		mockDal.On("Get").Return(tc.currentInfra, nil)
		mockDal.On("Update").Return(nil)
		tMock := NewTaskExecutorMock(model.OK, common.ApplicationError{})
		SetTaskExecutorMock(tMock)
		setMockedInfrastructureSystemExecutor(mockDal)

		engine.EngineExecutorInstance = tc.engineMock
		zone := model.Zone{}
		e := GetInfrastructureSystemOpsExecutor()
		e.EnableInfraSystems(zone, getInfraList(model.DisabledState), engine.NoPlaybook)

		//mockDal.AssertCalled(t, "Get")

	}
}

func TestDeAllocateResources(t *testing.T) {
	common.StartLogs()

	SetPlaybookContextMock()
	defer func() { GetTaskExecutor = getTaskExecutor }()
	defer func() { GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor }()

	e := engine.EngineExecutorInstance
	defer func() { engine.EngineExecutorInstance = e }()

	testCases := []struct {
		success      bool
		currentInfra model.InfrastructureSystem
		engineMock   *EngineExecutorMock
	}{
		{
			success:      true,
			currentInfra: getInfra(model.EnabledState),
			engineMock:   NewEngineExecutorMock(),
		},
		{
			success:      false,
			currentInfra: getInfra(model.EnabledState),
			engineMock:   NewEngineExecutorFailMock(),
		},
	}

	for _, tc := range testCases {
		mockDal := new(InfrastructureDAOMock)
		mockDal.On("Get").Return(tc.currentInfra, nil)
		mockDal.On("Update").Return(nil)
		tMock := NewTaskExecutorMock(model.OK, common.ApplicationError{})
		SetTaskExecutorMock(tMock)
		setMockedInfrastructureSystemExecutor(mockDal)

		engine.EngineExecutorInstance = tc.engineMock

		e := GetInfrastructureSystemOpsExecutor()
		zone := model.Zone{}
		e.DisableInfraSystems(zone, getInfraList(model.EnabledState), engine.NoPlaybook)

		//		mockDal.AssertCalled(t, "Get", "123")

	}

}

func TestConfigureNeutronServer(t *testing.T) {
	common.StartLogs()

	SetPlaybookContextMock()
	defer func() { GetTaskExecutor = getTaskExecutor }()
	defer func() { GetInfrastructureSystemExecutor = getInfrastructureSystemExecutor }()

	e := engine.EngineExecutorInstance
	defer func() { engine.EngineExecutorInstance = e }()

	testCases := []struct {
		success      bool
		currentInfra model.InfrastructureSystem
		engineMock   *EngineExecutorMock
	}{
		{
			success:    true,
			engineMock: NewEngineExecutorMock(),
		},
		{
			success:    false,
			engineMock: NewEngineExecutorFailMock(),
		},
	}

	for _, tc := range testCases {
		mockDal := new(InfrastructureDAOMock)
		mockDal.On("Update").Return(nil)
		tMock := NewTaskExecutorMock(model.OK, common.ApplicationError{})
		SetTaskExecutorMock(tMock)
		setMockedInfrastructureSystemExecutor(mockDal)

		engine.EngineExecutorInstance = tc.engineMock

		e := GetInfrastructureSystemOpsExecutor()
		zone := model.Zone{}
		e.ConfigureNeutronServer(zone)

	}

}

func TestValidateEnableAndDisableResources(t *testing.T) {
	i := infrastructureSystemOpsExecutor{}
	op := i.ValidateEnableAndDisableResources(model.InfrastructureSystemList{}, model.InfrastructureSystemList{})
	assert.Nil(t, op)

}

func TestEnableAndDisableResources(t *testing.T) {
	i := infrastructureSystemOpsExecutor{}
	op, err := i.EnableAndDisableResources(model.Zone{}, model.InfrastructureSystemList{})
	assert.NotNil(t, op)
	assert.Nil(t, err)

}
