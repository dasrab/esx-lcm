// (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type InfrastructureSystemOpsExecutorMock struct {
	mock.Mock
}

func (e *InfrastructureSystemOpsExecutorMock) SynchronizeInfraSystems(
	z model.Zone, p engine.PlaybookType) error {
	return nil
}

func (e *InfrastructureSystemOpsExecutorMock) EnableInfraSystems(
	z model.Zone, infraSysList model.InfrastructureSystemList, p engine.PlaybookType) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemOpsExecutorMock) DisableInfraSystems(
	zone model.Zone, infraSysList model.InfrastructureSystemList, p engine.PlaybookType) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemOpsExecutorMock) ValidateEnableAndDisableResources(
	model.InfrastructureSystemList, model.InfrastructureSystemList) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemOpsExecutorMock) ValidateEnableInfraSystems(
	resourceList model.InfrastructureSystemList) error {
	args := e.Called()
	return args.Error(0)
}

func (e *InfrastructureSystemOpsExecutorMock) EnableAndDisableResources(
	model.Zone, model.InfrastructureSystemList) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemOpsExecutorMock) ConfigureNeutronServer(
	zone model.Zone) (model.TaskResource, error) {
	args := e.Called()
	return args.Get(0).(model.TaskResource), args.Error(1)
}

func (e *InfrastructureSystemOpsExecutorMock) CreateInfrastructureSystemEnvironment(
	z model.Zone) error {
	return nil
}

func SetInfrastructureSystemOpsExecutorMock(o InfrastructureSystemOpsExecutor) {
	GetInfrastructureSystemOpsExecutor = func() InfrastructureSystemOpsExecutor {
		return o
	}
}
