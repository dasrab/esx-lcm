//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

package executer

import (
	"testing"
)

func Test_resourceProfileExecutor_GetAll(t *testing.T) {

	filters := make(map[string][]string)
	jsonPath = getAbsoluteFilepath("../../ism-recipes/templates/platform_profile_template.json")
	e := GetResourceProfileSExecutor()
	e.GetAll(filters)

}
