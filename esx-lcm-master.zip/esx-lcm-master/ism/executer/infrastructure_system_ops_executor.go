//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"fmt"

	log "github.hpe.com/kronos/kelog"

	"sync"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/engine"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/operation"
)

type InfrastructureSystemOpsExecutor interface {
	SynchronizeInfraSystems(model.Zone, engine.PlaybookType) error
	EnableInfraSystems(model.Zone, model.InfrastructureSystemList, engine.PlaybookType) (model.TaskResource, error)
	DisableInfraSystems(model.Zone, model.InfrastructureSystemList, engine.PlaybookType) (model.TaskResource, error)
	ValidateEnableAndDisableResources(model.InfrastructureSystemList, model.InfrastructureSystemList) error
	EnableAndDisableResources(model.Zone, model.InfrastructureSystemList) (model.TaskResource, error)
	ConfigureNeutronServer(zone model.Zone) (model.TaskResource, error)
	ValidateEnableInfraSystems(resourceList model.InfrastructureSystemList) error
}

type infrastructureSystemOpsExecutor struct {
	exec InfrastructureSystemExecutor
}

var (
	infraOpsOnce sync.Once
)
var infraExecutorOpsInstance InfrastructureSystemOpsExecutor
var GetInfrastructureSystemOpsExecutor = getInfrastructureSystemOpsExecutor

func getInfrastructureSystemOpsExecutor() InfrastructureSystemOpsExecutor {
	infraOpsOnce.Do(func() {
		infraExecOpsInstance := new(infrastructureSystemOpsExecutor)
		infraExecOpsInstance.exec = GetInfrastructureSystemExecutor()
		infraExecutorOpsInstance = infraExecOpsInstance
	})
	return infraExecutorOpsInstance
}

func (e infrastructureSystemOpsExecutor) SynchronizeInfraSystems(zone model.Zone, p engine.PlaybookType) error {
	log.Debugf("Synchronize infrastructure systems for Zone (%s)", zone.Id)
	op := operation.NewOperation(
		"Synchronize infrastructure systems",
		model.InfrastructureSystemsResourceTypeList,
		nil,
		operation.SyncOp,
	)
	op.SetResourceEnv(&zone)
	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				err := common.NewApplicationError(common.ErrorSynchronizeInfraSystems, fmt.Sprintf("%v", r))
				op.SetExecutionError(err)
			}
		}()
		opErr := common.NewApplicationError(common.ErrorSynchronizeInfraSystems,
			"Unable to synchronize infrastructure systems for Zone")
		runEngine(op, p, opErr)
		log.Debugf("Done synchronizing infrastructure systems for Zone (%s). Result Status: [%v] - Result Error: [%v]",
			zone.Id, op.Status(), op.ExecutionError())
	}
	op.Run(f)
	if op.ExecutionError().Message != "" {
		return op.ExecutionError()

	}
	return nil
}

func (e infrastructureSystemOpsExecutor) EnableInfraSystems(zone model.Zone, infraList model.InfrastructureSystemList, p engine.PlaybookType) (model.TaskResource, error) {
	log.Infof("Enabling Infrastructure Systems for Zone (%s) ", zone.Id)

	op := operation.NewOperation(
		"Enabling Infrastrucuture systems",
		model.InfrastructureSystemsResourceTypeList,
		&infraList,
		operation.AsyncOp,
	)

	op.SetResourceEnv(&zone)
	op.AddDispatcher(NewTaskDispatcher("Enable Infrastructure Systems", op))
	op.AddSuccessHandler(e.updateInfraSystemEnabled)
	op.AddFailureHandler(e.updateInfraSystemDisabled)
	e.updateInfraSystemEnabling(op)

	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Enabling Infrastructure Systems execution Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorEnablingInfraSystems, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorEnablingInfraSystems, "Enable infrastructure systems failed")

		runEngine(op, p, opErr)

		log.Infof("Done Enable infrastructure systems for Zone (%s). Result Status: [%v] - Result Error: [%v]",
			zone.Id,
			op.Status(),
			op.ExecutionError())
	}

	log.Debugf("Triggering Enabling Infrastructure Systems Async")
	return runOperation(op, f)
}

func (e infrastructureSystemOpsExecutor) DisableInfraSystems(zone model.Zone, infraList model.InfrastructureSystemList, p engine.PlaybookType) (model.TaskResource, error) {
	log.Infof("Disabling Infrastructure Systems for Zone (%s) ", zone.Id)

	err := e.ValidateDisableInfraSystems(infraList)
	if err != nil {
		return model.TaskResource{}, err
	}

	op := operation.NewOperation(
		"Disabling Infrastrucuture systems",
		model.InfrastructureSystemsResourceTypeList,
		&infraList,
		operation.AsyncOp,
	)
	op.SetResourceEnv(&zone)
	op.AddDispatcher(NewTaskDispatcher("Disable Infrastructure Systems", op))
	op.AddSuccessHandler(e.updateInfraSystemDisabled)
	op.AddFailureHandler(e.updateInfraSystemEnabled)
	e.updateInfraSystemDisabling(op)

	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Disabling Infrastructure Systems execution Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorDisablingInfraSystems, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorDisablingInfraSystems, "Disable infrastructure systems failed")

		runEngine(op, p, opErr)

		log.Infof("Done Disable infrastructure systems for Zone (%s). Result Status: [%v] - Result Error: [%v]",
			zone.Id,
			op.Status(),
			op.ExecutionError())
	}

	log.Debugf("Triggering Disabling Infrastructure Systems Async")
	return runOperation(op, f)
}

func (e infrastructureSystemOpsExecutor) ValidateEnableInfraSystems(resourceList model.InfrastructureSystemList) error {
	for _, v := range resourceList.GetMembers() {
		log.Infof("Validating Enabling Infrastructure Systems %v", v.GetUUID())
		currentInfra, err := e.exec.Get(v.GetUUID())
		if err != nil {
			return err
		}
		_, ok := e.exec.GetOperations()[operation.OperationKey{Origin: currentInfra.State, Target: model.EnablingState}]
		if !ok {
			ismErr := common.NewApplicationError(common.ErrorInvalidTransition, fmt.Sprintf("No operation {%v, %v} associated to %v", currentInfra.State, model.EnablingState, v.GetType()))
			ismErr.AddData(fmt.Sprintf("[%s]", model.EnablingState), fmt.Sprintf("[%s]", currentInfra.State))
			return ismErr
		}
	}
	return nil

}

func (e infrastructureSystemOpsExecutor) ValidateDisableInfraSystems(resourceList model.InfrastructureSystemList) error {
	for _, v := range resourceList.GetMembers() {
		log.Infof("Validating Disabling Infrastructure Systems %v", v.GetUUID())
		currentInfra, err := e.exec.Get(v.GetUUID())
		if err != nil {
			return err
		}
		_, ok := e.exec.GetOperations()[operation.OperationKey{Origin: currentInfra.State, Target: model.DisablingState}]
		if !ok {
			ismErr := common.NewApplicationError(common.ErrorInvalidTransition, fmt.Sprintf("No operation {%v, %v} associated to %v", currentInfra.State, model.DisablingState, v.GetType()))
			ismErr.AddData(fmt.Sprintf("[%s]", model.DisablingState), fmt.Sprintf("[%s]", currentInfra.State))
			return ismErr
		}
	}
	return nil

}

func (e infrastructureSystemOpsExecutor) updateInfraSystemEnabled(op operation.Operation) {
	log.Infof("Updating infrastructure system state to Enabled state")
	e.UpdateInfraSystemState(op, model.EnabledState)
}

func (e infrastructureSystemOpsExecutor) updateInfraSystemDisabled(op operation.Operation) {
	log.Infof("Updating infrastructure system state to Disabled state")
	e.UpdateInfraSystemState(op, model.DisabledState)
}

func (e infrastructureSystemOpsExecutor) updateInfraSystemEnabling(op operation.Operation) {
	log.Infof("Updating infrastructure system state to Enabling state")
	e.UpdateInfraSystemState(op, model.EnablingState)
}

func (e infrastructureSystemOpsExecutor) updateInfraSystemDisabling(op operation.Operation) {
	log.Infof("Updating infrastructure system state to Disabling state")
	e.UpdateInfraSystemState(op, model.DisablingState)
}

// ESX Clusters

func (e infrastructureSystemOpsExecutor) EnableAndDisableResources(zone model.Zone, resourceList model.InfrastructureSystemList) (model.TaskResource, error) {
	log.Infof("Enabling and Disabling Resources")

	op := operation.NewOperation(
		"EnableAndDisable Resources",
		model.InfrastructureSystemsResourceTypeList,
		&resourceList,
		operation.AsyncOp,
	)

	log.Infof("Resource to be Enabled and Disabled %v", resourceList)

	op.SetResourceEnv(&zone)
	op.AddDispatcher(NewTaskDispatcher("EnableAndDisable Resources", op))
	op.AddSuccessHandler(e.OnSuccessEnableAndDisableResources)
	op.AddFailureHandler(e.OnFailureEnableAndDisableResources)

	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Enabling and Disabling resources execution Failure: [%v]", r))
				err := common.NewApplicationError(common.ErrorEnableAndDisableResource, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorEnableAndDisableResource, "Unable to complete EnableAndDisable resources operation with success.")

		runEngine(op, engine.EnableAndDisableResourcePlaybook, opErr)

		log.Infof("Done Enabling And Disabling resources. Result Status: [%v] - Result Error: [%v]",
			op.Status(),
			op.ExecutionError())
	}

	log.Infof("Triggering EnableAndDisable resources Async")
	return runOperation(op, f)
}

func (e infrastructureSystemOpsExecutor) ConfigureNeutronServer(zone model.Zone) (model.TaskResource, error) {
	log.Infof("Configuring Neutron Server")

	op := operation.NewOperation(
		"Configuring Neutron Server",
		model.InfrastructureSystemsResourceTypeList,
		nil,
		operation.AsyncOp,
	)

	log.Infof("COnfiguring Neutron Server with physical networks %v", zone.NetworkSettings.PhysicalNetworks)

	op.SetResourceEnv(&zone)
	op.AddDispatcher(NewTaskDispatcher("Configuring Neutron Server", op))

	f := func(op operation.Operation) {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf(fmt.Sprintf("Failure in configuring neutron server: [%v]", r))
				err := common.NewApplicationError(common.ErrorConfiguringNeutronServer, fmt.Sprintf("%v", r))
				err.AppendNestedError(op.ExecutionError())
				op.SetExecutionError(err)
			}
		}()

		opErr := common.NewApplicationError(common.ErrorConfiguringNeutronServer, "Unable to configure neutron server with given physical networks.")

		runEngine(op, engine.ConfigureNeutronServerPlaybook, opErr)

		log.Infof("Done Configuring Neutron Server. Result Status: [%v] - Result Error: [%v]",
			op.Status(),
			op.ExecutionError())
	}

	log.Infof("Triggering Configuration of Neutron Server Async")
	return runOperation(op, f)
}

func (e infrastructureSystemOpsExecutor) ValidateEnableAndDisableResources(enableResourceList model.InfrastructureSystemList, disbaleResourceList model.InfrastructureSystemList) error {
	err := e.ValidateEnableInfraSystems(enableResourceList)
	if err != nil {
		return err
	}
	err = e.ValidateDisableInfraSystems(disbaleResourceList)
	if err != nil {
		return err
	}
	return nil
}

func (e infrastructureSystemOpsExecutor) UpdateInfraSystemState(op operation.Operation, state model.StateType) {
	resourceList := op.Resource().(*model.InfrastructureSystemList)
	for _, v := range resourceList.GetMembers() {
		v.State = state
		e.exec.InternalUpdate(v)
	}
}

func (e infrastructureSystemOpsExecutor) OnSuccessEnableAndDisableResources(op operation.Operation) {
	log.Infof("Updating Resource state on success of Enable and Disable Resources")
	resourceList := op.Resource().(*model.InfrastructureSystemList)
	log.Infof("Resource list %v", resourceList)
	for _, v := range resourceList.GetMembers() {
		log.Infof("Resource %v", v)
		if v.State == model.EnablingState {
			v.State = model.EnabledState
			e.exec.InternalUpdate(v)
		} else if v.State == model.DisablingState {
			v.State = model.DisabledState
			e.exec.InternalUpdate(v)
		}
	}
}

func (e infrastructureSystemOpsExecutor) OnFailureEnableAndDisableResources(op operation.Operation) {
	log.Infof("Updating Resource state on failure of Enable and Disable Resources")
	resourceList := op.Resource().(*model.InfrastructureSystemList)
	log.Infof("Resource list %v", resourceList)
	for _, v := range resourceList.GetMembers() {
		log.Infof("Resource %v", v)
		if v.State == model.EnablingState {
			v.State = model.DisabledState
			e.exec.InternalUpdate(v)
		} else if v.State == model.DisablingState {
			v.State = model.EnabledState
			e.exec.InternalUpdate(v)
		}
	}
}
