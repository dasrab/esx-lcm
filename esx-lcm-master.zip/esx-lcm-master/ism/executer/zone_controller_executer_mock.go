// (C) Copyright 2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type ZoneControllerExecuterMock struct {
	mock.Mock
}

func (e *ZoneControllerExecuterMock) Create(z model.ZoneController) (model.TaskResource, error) {
	return model.TaskResource{}, nil
}

func (e *ZoneControllerExecuterMock) Update(z model.ZoneController) error {
	return nil
}

func (e *ZoneControllerExecuterMock) loadZoneController(m map[string][]string) ([]model.ZoneController, error) {
	return []model.ZoneController{}, nil

}

func (e *ZoneControllerExecuterMock) Delete(zID string) (model.ZoneController, error) {
	return model.ZoneController{}, nil
}

func (e *ZoneControllerExecuterMock) Get(zID string) (model.ZoneController, error) {
	return model.ZoneController{}, nil

}

func (e *ZoneControllerExecuterMock) GetAll(m map[string][]string) (model.ZoneControllerList, error) {
	return model.ZoneControllerList{}, nil

}
func (e *ZoneControllerExecuterMock) GetControllerStatus(zone model.ZoneController, recover bool) (model.TaskResource, error) {
	return model.TaskResource{}, nil
}

func SetZoneControllerExecuterMock() {
	GetZoneControllerExecutor = func() ZoneControllerExecutor {
		exec := new(ZoneControllerExecuterMock)
		return exec
	}

}
