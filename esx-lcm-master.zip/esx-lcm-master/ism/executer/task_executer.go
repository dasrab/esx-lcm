//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package executer

import (
	"fmt"
	"sync"

	"time"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type TaskExecutorInterface interface {
	GetAll(filters map[string][]string) (model.TaskResourceList, error)
	Get(id string) (model.TaskResource, error)
	Create(name string, associatedResource string) model.TaskResource
	Update(task model.TaskResource) (model.TaskResource, error)
	Delete(id string) error
	CompleteTaskWithError(id string, status model.HealthStatus, error common.ApplicationError) error
	CompleteTask(id string, status model.HealthStatus) error
	CreateSubTask(subTask model.TaskResource) (model.TaskResource, error)
	UpdateSubTask(subTask model.TaskResource) (model.TaskResource, error)
	WaitForChildTask(parentTask *model.TaskResource) common.ApplicationError
}

type taskExecutor struct {
	dal dal.TaskDAO
	mux *sync.Mutex
}

type WaitForTaskConfig struct {
	SleepTimePeriod    time.Duration
	IncrementSleepTime time.Duration
	Timeout            time.Duration
}

var taskOnce sync.Once
var taskExecutorInstance TaskExecutorInterface

var GetTaskExecutor = getTaskExecutor

func getTaskExecutor() TaskExecutorInterface {
	taskOnce.Do(func() {
		exec := new(taskExecutor)
		exec.dal = dal.NewTaskDAO()
		exec.mux = &sync.Mutex{}
		taskExecutorInstance = exec
	})
	return taskExecutorInstance
}

func (e taskExecutor) GetAll(filters map[string][]string) (model.TaskResourceList, error) {
	taskListMembers, err := e.dal.GetAll(filters)

	if err != nil {
		log.Errorf("Could not get Task List - %v", err)
		return model.TaskResourceList{}, common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("%v", err))
	}

	total, err := e.dal.GetTotal(filters)
	start := e.dal.GetStart(filters)
	taskList := model.NewTaskResourceList(taskListMembers, start, total)
	return taskList, nil
}

func (e taskExecutor) Get(id string) (model.TaskResource, error) {
	log.Debugf("Getting Task (%s)", id)

	task, err := e.dal.Get(id)
	if err != nil {
		message := fmt.Sprintf("Task with Id %s was not found", id)
		log.Errorf(message)
		return model.TaskResource{}, common.NewApplicationError(common.ErrorResourceNotFound, message)
	}
	return task, nil
}

func (e taskExecutor) Delete(id string) error {
	//log.Debugf("Getting Task (%s)", id)

	err := e.dal.Delete(id)
	if err != nil {
		message := fmt.Sprintf("Task with Id %s couldn't be deleted - %v", id, err)
		log.Errorf(message)
		return common.NewApplicationError(common.ErrorDatabase, message)
	}
	return nil
}

func (e taskExecutor) Create(name string, associatedResource string) model.TaskResource {
	log.Debugf("Creating Task - %s", name)
	task := model.NewParentTaskResource(name, associatedResource)
	return e.insertTask(&task)
}

func (e taskExecutor) CreateSubTask(subTask model.TaskResource) (model.TaskResource, error) {
	log.Debugf("Creating SubTask - %s as {%v}", subTask.Name, subTask)

	//Attention: There is a race condition here today, where multiple requests enter e function simultaneuosly
	//This lock/unlock mechanism prevents more than one thread to get in here, avoiding errors when picking
	//Next database Id.
	e.mux.Lock()
	defer e.mux.Unlock()

	// Get Parent Task to make sure it's valid
	parentTask, err := e.dal.Get(subTask.ParentId)

	if err != nil {
		message := "Parent Task is not valid"
		log.Errorf(message)
		return model.TaskResource{}, common.NewApplicationError(common.ErrorInvalidUuid, message)
	}

	log.Debugf("Subtask to be inserted: { %v }", subTask)

	subTask.SetCreatedState()
	subTask.SetAssociatedResourceUri(parentTask.AssociatedResourceInstanceUri)
	subTask = e.insertTask(&subTask)

	// Add child task to parentTask
	parentTask.ChildTasks = append(parentTask.ChildTasks, subTask.Uuid)
	log.Debugf("Parent Task to be updated: { %v }", parentTask)
	_, err = e.Update(parentTask)

	if err != nil {
		message := "Failed to update parent Task."
		log.Errorf(message)
		return model.TaskResource{}, err
	}

	return subTask, err
}

func (e taskExecutor) UpdateSubTask(subTask model.TaskResource) (model.TaskResource, error) {
	log.Debugf("Updating SubTask - %s as {%v}", subTask.Name, subTask)

	//Attention: There is a race condition here today, where multiple requests enter e function simultaneuosly
	//This lock/unlock mechanism prevents more than one thread to get in here, avoiding errors when picking
	//Next database Id.
	e.mux.Lock()
	defer e.mux.Unlock()

	// Get Parent Task to make sure it's valid
	parentTask, err := e.dal.Get(subTask.ParentId)

	if err != nil {
		message := "Parent Task is not valid"
		log.Errorf(message)
		return model.TaskResource{}, common.NewApplicationError(common.ErrorInvalidUuid, message)
	}

	log.Debugf("Subtask to be updated: { %v }", subTask)

	subTask.SetAssociatedResourceUri(parentTask.AssociatedResourceInstanceUri)
	subTask = e.updateTask(&subTask)

	// Add child task to parentTask
	parentTask.ChildTasks = append(parentTask.ChildTasks, subTask.Uuid)
	log.Debugf("Parent Task to be updated: { %v }", parentTask)
	_, err = e.Update(parentTask)

	if err != nil {
		message := "Failed to update parent Task."
		log.Errorf(message)
		return model.TaskResource{}, err
	}

	return subTask, err
}

func (e taskExecutor) WaitForChildTask(parentTask *model.TaskResource) common.ApplicationError {
	waitTaskConfig := WaitForTaskConfig{
		SleepTimePeriod:    1 * time.Minute,
		IncrementSleepTime: 1 * time.Minute,
		Timeout:            180 * time.Minute,
	}
	applicationErr := common.ApplicationError{}
	var wg sync.WaitGroup
	for _, taskUuid := range parentTask.ChildTasks {
		if taskUuid == "" {
			continue
			// a case when there's no task created
		}
		task, _ := e.Get(taskUuid)
		taskuri := task.GetUri()
		log.Debugf("Waiting for child task %v to complete..", taskUuid)
		wg.Add(1)
		go e.PollTaskForCompletion(taskuri, &applicationErr,
			waitTaskConfig,
			&wg)
		wg.Wait()
	}
	if applicationErr.ErrorCode != "" {
		errorMsg := "One or more tasks failed to complete. See child tasks for errors"
		applicationErr.Message = errorMsg
		applicationErr.ErrorCode = "CHILD_TASK_FAILED"
		log.Error(errorMsg)
		parentTask.Error = applicationErr
		e.updateTask(parentTask)
	}

	return applicationErr
}

func (e taskExecutor) PollTaskForCompletion(uri string, taskWaitError *common.ApplicationError,
	waitTaskConfig WaitForTaskConfig,
	wg *sync.WaitGroup) {
	defer func() {
		wg.Done()
	}()
	uuid := common.GetResourceUuidFromUri(common.IsmURI(uri))
	var waitedPeriod time.Duration
	sleepTimePeriod := waitTaskConfig.SleepTimePeriod
	for i := 0; waitedPeriod.Seconds() <= waitTaskConfig.Timeout.Seconds(); i++ {
		currTask, err := GetTaskExecutor().Get(uuid)
		if err != nil {
			taskWaitError.ErrorCode = common.ErrorExecutionFailure
			taskWaitError.AppendNestedError(err)
			log.Errorf("Current task %v failed : %v", uuid, err)
			return
		}
		if currTask.TaskFailed {
			taskWaitError.ErrorCode = common.ErrorExecutionFailure
			taskWaitError.AppendNestedError(currTask.Error)
			log.Errorf("Current task %v failed : %v", uuid, currTask.Error)
			return
		}
		if currTask.IsCompleted() {
			log.Debugf("Current Task %s completed successfully\n", uuid)
			return
		}
		log.Debugf("[%d] [%.2f seconds] - Waiting for child task %s to complete\n", i, sleepTimePeriod.Seconds(), uuid)
		time.Sleep(sleepTimePeriod)
		waitedPeriod += sleepTimePeriod
	}
	log.Errorf("Waited %.2f seconds for task %s to complete\n", waitedPeriod.Seconds(), uuid)
	taskWaitError.ErrorCode = common.ErrorExecutionFailure
	taskWaitError.Details = "Task never got to Completed state!"
}

func (e taskExecutor) Update(task model.TaskResource) (model.TaskResource, error) {
	log.Debugf("Updating Task - [%s] with contents [%v]", task.GetUUID(), task)

	if err := e.dal.Update(&task); err != nil {
		message := fmt.Sprintf("Error Updating Task (%s) - %v", task.GetUUID(), err)
		log.Errorf(message)
		return model.TaskResource{}, common.NewApplicationError(common.ErrorDatabase, message)
	}

	log.Debugf("Done Updating Task - %s", task.GetUUID())
	return task, nil
}

func (e taskExecutor) CompleteTask(id string, status model.HealthStatus) error {
	return e.CompleteTaskWithError(id, status, common.ApplicationError{})
}

func (e taskExecutor) CompleteTaskWithError(id string, status model.HealthStatus, error common.ApplicationError) error {
	log.Debugf("Completing Task [%s] to Status [%v] and error [%s]", id, status, error.Error())

	task, err := e.dal.Get(id)
	if err != nil {
		return err
	}

	task.SetCompletedState(status, error)

	// Get the worst Status of the subTasks and set as Task Status
	if len(task.ChildTasks) > 0 {
		if err = e.completeSubTasks(task.ChildTasks); err != nil {
			return err
		}
	}

	_, err = e.Update(task)
	return err
}

func (e taskExecutor) completeSubTasks(subTaskIds []string) error {
	log.Debugf("Completing SubTasks")

	for _, subTaskId := range subTaskIds {
		task, err := e.dal.Get(subTaskId)
		if err != nil {
			return common.NewApplicationError(common.ErrorDatabase, fmt.Sprintf("Error on Completing SubTask %s - %v", subTaskId, err))
		}

		if !task.IsCompleted() {
			task.SetCompletedState(model.Critical, common.NewApplicationError(common.ErrorExecutionFailure, ""))
			_, err = e.Update(task)
			if err != nil {
				log.Warnf("Error Completing SubTask %s - %v\n", subTaskId, err)
			}
		}

	}
	log.Debugf("Done Completing SubTasks")
	return nil
}

func (e taskExecutor) insertTask(task *model.TaskResource) model.TaskResource {
	if err := e.dal.Create(task); err != nil {
		message := fmt.Sprintf("Could not insert Task on Database - %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorDatabase, message))
	}

	return *task
}

func (e taskExecutor) updateTask(task *model.TaskResource) model.TaskResource {
	if err := e.dal.Update(task); err != nil {
		message := fmt.Sprintf("Could not update Task on Database - %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorDatabase, message))
	}
	return *task
}
