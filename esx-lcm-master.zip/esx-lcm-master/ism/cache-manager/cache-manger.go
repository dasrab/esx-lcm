//(C) Copyright 2018 Hewlett Packard Enterprise Development LP

package cache_manager

import (
	"errors"
	"fmt"
	"sync"

	log "github.hpe.com/kronos/kelog"

	"github.com/patrickmn/go-cache"
)

type CacheManagerIf interface {
	GetKey(string) (ZoneCacheItems, error)
	SetKey(string, ZoneCacheItems) error
	DeleteKey(string) error
	PersistCache(ZoneCacheItems) error
	CleanPersistedKey(string) error
	IsCachePersisted(string) bool
	IsCacheOnline(string) bool
}

type ZoneCacheItems struct {
	OsRegion       string
	PollingCh      chan bool
	PollingStopped chan bool
}

var zoneCache *cache.Cache

var (
	cacheManagerOnce sync.Once
)

var GetCacheManager = getCacheManager

func getCacheManager() CacheManagerIf {
	cacheManagerOnce.Do(func() {
		zoneCache = cache.New(0, 0)
		log.Infof("Initialized Cache Manager")
	})
	return ZoneCacheItems{}
}

func (zcI ZoneCacheItems) GetKey(key string) (ZoneCacheItems, error) {
	zc, found := zoneCache.Get(key)
	if !found {
		return ZoneCacheItems{}, errors.New(fmt.Sprintf("Key %v not found in the cache", key))
	}
	return zc.(ZoneCacheItems), nil
}

func (zcI ZoneCacheItems) SetKey(key string, zc ZoneCacheItems) error {
	zoneCache.Set(key, zc, 0)
	return nil
}

func (zcI ZoneCacheItems) DeleteKey(key string) error {
	zoneCache.Delete(key)
	return nil
}

func (zcI ZoneCacheItems) PersistCache(ZoneCacheItems) error {
	return nil
}

func (zcI ZoneCacheItems) CleanPersistedKey(string) error {
	return nil
}

func (zcI ZoneCacheItems) IsCachePersisted(string) bool {
	return false
}

func (zcI ZoneCacheItems) IsCacheOnline(key string) bool {
	_, err := zcI.GetKey(key)
	if err != nil {
		return false
	}
	return true
}
