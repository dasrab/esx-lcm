//(C) Copyright 2018 Hewlett Packard Enterprise Development LP

package cache_manager

import (
	"errors"
	"fmt"

	"github.com/stretchr/testify/mock"
)

// MockCacheManagerIf is a mock of CacheManagerIf interface
type MockCacheManagerIf struct {
	mock.Mock
}

func (zcI *MockCacheManagerIf) GetKey(key string) (ZoneCacheItems, error) {
	zc, found := zoneCache.Get(key)
	if !found {
		return ZoneCacheItems{}, errors.New(fmt.Sprintf("Key %v not found in the cache", key))
	}
	return zc.(ZoneCacheItems), nil
}

func (zcI *MockCacheManagerIf) SetKey(key string, zc ZoneCacheItems) error {
	zoneCache.Set(key, zc, 0)
	return nil
}

func (zcI *MockCacheManagerIf) DeleteKey(key string) error {
	zoneCache.Delete(key)
	return nil
}

func (zcI *MockCacheManagerIf) PersistCache(ZoneCacheItems) error {
	return nil
}

func (zcI *MockCacheManagerIf) CleanPersistedKey(string) error {
	return nil
}

func (zcI *MockCacheManagerIf) IsCachePersisted(string) bool {
	return false
}

func (zcI *MockCacheManagerIf) IsCacheOnline(key string) bool {
	return true
}

func SetCacheMgrMock() {
	GetCacheManager = func() CacheManagerIf {
		cacheMgr := new(MockCacheManagerIf)
		return cacheMgr
	}

}
