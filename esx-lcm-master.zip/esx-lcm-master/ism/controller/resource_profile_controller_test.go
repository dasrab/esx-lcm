//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func TestResourceProfileController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getResourceList",
			"GET",
			string(common.URIResourceProfileName),
			nil,
		},
	}
	envCtrl := ResourceProfileController{}
	routes := envCtrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("Error in Resource Profile Controller")
		}
	}
}
