//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ZoneServerController struct {
	AsyncBaseController
}

func NewZoneServerController() ControllerInterface {
	ctrl := new(ZoneServerController)
	ctrl.service = service.NewZoneServerService()
	return ctrl
}

func (this *ZoneServerController) Post(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPost(w, r)
}

func (this *ZoneServerController) Put(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPut(w, r)
}

func (this *ZoneServerController) Delete(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncDelete(w, r)
}

func (this *ZoneServerController) Patch(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPatch(w, r)
}

func (this *ZoneServerController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getZoneServers",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			AuthPublicRequest(this.GetWithFilters),
		},
		Route{
			"putZoneServers",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			AuthPublicRequest(this.Put),
		},
		Route{
			"deleteZoneServers",
			"DELETE",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			AuthPublicRequest(this.DeleteServers),
		},
	}
	return routes
}

func (this *ZoneServerController) GetWithFilters(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from GET Zone Servers operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	id := getUUIDFromRequest(r)
	responseBody = service.NewZoneServerService().GetWithFilters(id, options.Filters)
}

func (this *ZoneServerController) DeleteServers(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from DELETE Zone Servers operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneServerService().DeleteServers(id, options.Filters, body)
}
