//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"net/http/httptest"
	"testing"
)

func TestShowIndex(t *testing.T) {

	req, err := http.NewRequest("PATCH", "/infra", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ShowIndex)
	handler.ServeHTTP(rr, req)
}
