//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

//TODO: Implement filters/pagination
type InfrastructureController struct {
	AsyncBaseController
}

func NewInfrastructureController() ControllerInterface {
	ctrl := new(InfrastructureController)
	ctrl.service = service.NewInfrastructureService()
	return ctrl
}

func (this *InfrastructureController) Post(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPost(w, r)
}

func (this *InfrastructureController) Put(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPut(w, r)
}

func (this *InfrastructureController) Delete(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncDelete(w, r)
}

func (this *InfrastructureController) Patch(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPatch(w, r)
}

func (this *InfrastructureController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getInfrastructureList",
			"GET",
			string(common.URIInfrastructureSystem),
			AuthPublicRequest(this.GetAll), // Public API
		},
		Route{
			"getInfrastructure",
			"GET",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			AuthPublicRequest(this.Get), // Public API
		},
		Route{
			"postInfrastructure",
			"POST",
			string(common.URIInfrastructureSystem),
			AuthPublicRequest(this.Post), // Public API
		},
		Route{
			"putInfrastructure",
			"PUT",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			AuthPublicRequest(this.Put), // Public API
		},
		Route{
			"deleteInfrastructure",
			"DELETE",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			AuthPublicRequest(this.Delete), // Public API
		},
		Route{
			"patchInfrastructure",
			"PATCH",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			AuthPublicRequest(this.Patch), // Public API
		},
	}
	return routes
}
