//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package controller

import (
	"fmt"
	"net/http"
)

func ShowIndex(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, "Welcome! Please access REST server at /rest/infrastructure\n")
}
