//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
	"path"
	"runtime"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

type FileServerController struct {
	BaseController
}

func getAbsoluteFilepath(filepath string) string {
	_, filename, _, _ := runtime.Caller(1)
	connectapp := path.Join(path.Dir(filename), filepath)
	return connectapp + "/"
}

var (
	dirServe = getAbsoluteFilepath("../scripts")
)

func NewFileServerController() ControllerInterface {
	ctrl := new(FileServerController)
	return ctrl
}

func (this *FileServerController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"scripts",
			"GET",
			common.BuildUri(common.URIFileServer, "{files}"),
			AuthPublicRequest(this.ServerScripts()),
		},
		Route{
			"list scripts",
			"GET",
			string(common.URIFileServer),
			AuthPublicRequest(this.ServerScripts()),
		},
	}
	return routes
}

func (this *FileServerController) ServerScripts() http.HandlerFunc {
	log.Infof("Serving directory %v", dirServe)
	return http.StripPrefix(string(common.URIFileServer), http.FileServer(http.Dir(dirServe))).(http.HandlerFunc)
}

func (this *FileServerController) Delete(w http.ResponseWriter, r *http.Request) {

}

func (this *FileServerController) Patch(w http.ResponseWriter, r *http.Request) {

}

func (this *FileServerController) Post(w http.ResponseWriter, r *http.Request) {

}

func (this *FileServerController) Put(w http.ResponseWriter, r *http.Request) {

}
