//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
	"testing"

	"net/http/httptest"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func Test_patch(t *testing.T) {
	m := InfrastructureController{}
	req, err := http.NewRequest("PATCH", "/infrastructure-system", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Patch)
	handler.ServeHTTP(rr, req)

}

func Test_post(t *testing.T) {
	m := InfrastructureController{}
	req, err := http.NewRequest("POST", "/infrastructure-system", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Post)
	handler.ServeHTTP(rr, req)

}

func Test_put(t *testing.T) {
	m := InfrastructureController{}
	req, err := http.NewRequest("PUT", "/infrastructure-system", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Put)
	handler.ServeHTTP(rr, req)
}

func Test_delete(t *testing.T) {
	m := InfrastructureController{}
	req, err := http.NewRequest("DELETE", "/infrastructure-system", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Delete)
	handler.ServeHTTP(rr, req)
}

func TestInfrastructureSystemController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getInfrastructureList",
			"GET",
			string(common.URIInfrastructureSystem),
			nil,
		},
		Route{
			"getInfrastructure",
			"GET",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			nil,
		},
		Route{
			"postInfrastructure",
			"POST",
			string(common.URIInfrastructureSystem),
			nil,
		},
		Route{
			"AllocateResource",
			"POST",
			string(common.URIInfrastructureSystemAllocate),
			nil,
		},
		Route{
			"DeAllocateResource",
			"POST",
			string(common.URIInfrastructureSystemDeAllocate),
			nil,
		},
		Route{
			"putInfrastructure",
			"PUT",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			nil,
		},
		Route{
			"deleteInfrastructure",
			"DELETE",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			nil,
		},
		Route{
			"patchInfrastructure",
			"PATCH",
			common.BuildUri(common.URIInfrastructureSystem, "{uuid}"),
			nil,
		},
	}
	envCtrl := InfrastructureController{}
	routes := envCtrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			log.Info("error")
		}
	}
}
