//(C) Copyright 2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func TestZoneControllerController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getZoneControllerList",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections"),
			nil,
		},
		Route{
			"getZoneController",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			nil,
		},
		Route{
			"postZoneController",
			"POST",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections"),
			nil,
		},
		Route{
			"putZoneController",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			nil,
		},
		Route{
			"deleteZoneController",
			"DELETE",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			nil,
		},
		Route{
			"patchZoneController",
			"PATCH",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			nil,
		},
	}
	zoneCtrl := ZoneControllerController{}
	routes := zoneCtrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("error in zone controller test")
		}
	}
}
