//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"

	"net/http/httptest"
	"reflect"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func TestNewZoneEnvironmentController(t *testing.T) {
	ctrl := new(ZoneEnvironmentController)
	ctrl.service = service.NewZoneEnvironmentService()
	ctrl1 := NewZoneEnvironmentController()
	if !reflect.DeepEqual(ctrl, ctrl1) {
		t.Errorf("Error")
	}
}

func Test_Patch_Zone_Env(t *testing.T) {
	m := ZoneEnvironmentController{}
	req, err := http.NewRequest("PATCH", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Patch)
	handler.ServeHTTP(rr, req)

}

func Test_Post_Zone_Env(t *testing.T) {
	m := ZoneEnvironmentController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Post)
	handler.ServeHTTP(rr, req)

}

func Test_Put_Zone_Env(t *testing.T) {
	m := ZoneEnvironmentController{}
	req, err := http.NewRequest("PUT", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Put)
	handler.ServeHTTP(rr, req)
}

func Test_Delete_Zone_Env(t *testing.T) {
	m := ZoneEnvironmentController{}
	req, err := http.NewRequest("DELETE", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Delete)
	handler.ServeHTTP(rr, req)
}

func TestZoneEnvironmentController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getZoneEnvironment",
			"GET",
			string(common.URIZoneEnvironment),
			nil,
		},
		Route{
			"getZoneEnvironment",
			"GET",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			nil,
		},
		Route{
			"putZoneEnvironment",
			"PUT",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			nil,
		},
		Route{
			"patchZoneEnvironment",
			"PATCH",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			nil,
		},
		Route{
			"deleteZoneEnvironment",
			"DELETE",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			nil,
		},
	}
	envCtrl := ZoneEnvironmentController{}
	routes := envCtrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("error in zone environment test")
		}
	}
}
