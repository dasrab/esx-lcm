//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
)

const (
	whitespace = " "
	colon      = ":"
)

// Middleware to authenticate a private request using HTTP Basic Auth
func AuthPrivateRequest(fn http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Run HandlerFunc
		fn(w, r)
	}
}
