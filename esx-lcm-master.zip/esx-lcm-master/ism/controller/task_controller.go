//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
	"net/http"
)

type TaskController struct {
	SyncBaseController
}

func NewTaskController() ControllerInterface {
	ctrl := new(TaskController)
	ctrl.service = service.NewTaskService()
	return ctrl
}

func (this *TaskController) Post(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPost(w, r)
}

func (this *TaskController) Put(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPut(w, r)
}

func (this *TaskController) Delete(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncDelete(w, r)
}

func (this *TaskController) Patch(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPatch(w, r)
}

func (this *TaskController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getTaskList",
			"GET",
			string(common.URITaskResource),
			AuthPublicRequest(this.GetAll), // Public API
		},
		Route{
			"getTask",
			"GET",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			AuthPublicRequest(this.Get), // Public API
		},
		Route{
			"putTask",
			"PUT",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			AuthPrivateRequest(this.Put), // Private API
		},
		Route{
			"postTask",
			"POST",
			string(common.URITaskResource),
			AuthPrivateRequest(this.Post), // Private API
		},
		Route{
			"patchTask",
			"PATCH",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			AuthPrivateRequest(this.Patch), // Private API
		},
		Route{
			"patchTask",
			"DELETE",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			AuthPrivateRequest(this.Delete), // Private API
		},
	}
	return routes
}
