//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"

	"github.com/gorilla/mux"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ControllerInterface interface {
	Get(w http.ResponseWriter, r *http.Request)
	GetAll(w http.ResponseWriter, r *http.Request)
	Delete(w http.ResponseWriter, r *http.Request)
	Post(w http.ResponseWriter, r *http.Request)
	Put(w http.ResponseWriter, r *http.Request)
	Patch(w http.ResponseWriter, r *http.Request)
	GetRoutes() Routes
}

type BaseController struct {
	service service.ServiceInterface
}

/********************
 *Base HTTP Decoding
 ********************/
func getHTTPHeaders(opt common.RestOptions, r *http.Request) (common.RestOptions, error) {
	opt.Filters = r.URL.Query()
	opt.APIVersion = 1
	//TODO: For v1, ISM lang will be fixed in en_US
	opt.Lang = "en-US"
	return opt, nil
}

func localizeResponse(lang string, value interface{}) interface{} {
	switch object := value.(type) {
	case common.ApplicationError:
		return object.GetLocalizedError(lang)
	case model.TaskResource:
		return object.GetLocalizedTask(lang)
	case model.TaskResourceList:
		return object.GetLocalizedTasks(lang)
	default:
		return object
	}
}

func writeResponse(w http.ResponseWriter, options common.RestOptions, status int, value interface{}) {
	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.Header().Set("Content-Language", string(options.Lang))
	w.WriteHeader(status)

	localizedValue := localizeResponse(options.Lang, value)

	//TODO: It's dangerous to have a synchronous panic here
	if err := json.NewEncoder(w).Encode(localizedValue); err != nil {
		message := fmt.Sprintf("Error writing response header - %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorGeneralFailure, message))
	}
}

func getUUIDFromRequest(r *http.Request) (id interface{}) {
	vars := mux.Vars(r)
	return vars["uuid"]
}

func getBodyFromRequest(r *http.Request) []byte {
	//TODO: Investigate better ways to define this
	body, err := ioutil.ReadAll(io.LimitReader(r.Body, 1048576))
	if err != nil {
		message := fmt.Sprintf("Couldn't read HTTP body: %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorGeneralFailure, message))
	}
	if err := r.Body.Close(); err != nil {
		message := fmt.Sprintf("Couldn't close HTTP body stream: %v", err)
		log.Error(message)
		panic(common.NewApplicationError(common.ErrorGeneralFailure, message))
	}
	return body
}

/******************************
 *Base HTTP CRUD Functionality
 ******************************/
func (this *BaseController) GetAll(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusOK
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Get All - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	responseBody = this.service.GetAll(options.Filters)
}

func (this *BaseController) Get(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusOK
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Get - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}

	responseBody = this.service.Get(getUUIDFromRequest(r))
}

func (this *BaseController) _post(w http.ResponseWriter, r *http.Request, httpStatus int) {
	options := common.NewRestOptions()
	responseStatus := httpStatus
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Post - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	responseBody = this.service.Create(getBodyFromRequest(r))
}

func (this *BaseController) _put(w http.ResponseWriter, r *http.Request, httpStatus int) {
	options := common.NewRestOptions()
	responseStatus := httpStatus
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Put - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = this.service.Update(id, body)
}

func (this *BaseController) _delete(w http.ResponseWriter, r *http.Request, httpStatus int) {
	options := common.NewRestOptions()
	responseStatus := httpStatus
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Put - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	responseBody = this.service.Delete(getUUIDFromRequest(r))
}

func (this *BaseController) _patch(w http.ResponseWriter, r *http.Request, httpStatus int) {
	options := common.NewRestOptions()
	responseStatus := httpStatus
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from Patch - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()

	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = this.service.Patch(id, body)
}

type AsyncBaseController struct {
	BaseController
}

func (this *AsyncBaseController) AsyncPost(w http.ResponseWriter, r *http.Request) {
	this.BaseController._post(w, r, http.StatusAccepted)
}

func (this *AsyncBaseController) AsyncPut(w http.ResponseWriter, r *http.Request) {
	this.BaseController._put(w, r, http.StatusAccepted)
}

func (this *AsyncBaseController) AsyncDelete(w http.ResponseWriter, r *http.Request) {
	this.BaseController._delete(w, r, http.StatusAccepted)
}

func (this *AsyncBaseController) AsyncPatch(w http.ResponseWriter, r *http.Request) {
	this.BaseController._patch(w, r, http.StatusAccepted)
}

type SyncBaseController struct {
	BaseController
}

func (this *SyncBaseController) SyncPost(w http.ResponseWriter, r *http.Request) {
	this.BaseController._post(w, r, http.StatusCreated)
}

func (this *SyncBaseController) SyncPut(w http.ResponseWriter, r *http.Request) {
	this.BaseController._put(w, r, http.StatusOK)
}

func (this *SyncBaseController) SyncDelete(w http.ResponseWriter, r *http.Request) {
	this.BaseController._delete(w, r, http.StatusOK)
}

func (this *SyncBaseController) SyncPatch(w http.ResponseWriter, r *http.Request) {
	this.BaseController._patch(w, r, http.StatusOK)
}

func getHTTPStatus(err interface{}) (int, interface{}) {
	var (
		responseStatus int
		responseBody   common.ApplicationError
	)

	switch appError := err.(type) {
	case common.ApplicationError:
		responseBody = appError
		switch appError.ErrorCode {
		case common.ErrorInvalidJson, common.ErrorInvalidParameters:
			responseStatus = http.StatusBadRequest
		case common.ErrorPublicAuth, common.ErrorPrivateAuth, common.ErrorInvalidChapCredentialCombination:
			responseStatus = http.StatusUnauthorized
		case common.ErrorResourceNotFound, common.ErrorDatabase, common.ErrorInvalidUuid, common.ErrorInvalidUri:
			responseStatus = http.StatusNotFound
		case common.ErrorInvalidState, common.ErrorUnsupportedOperation, common.ErrorInvalidTransition:
			responseStatus = http.StatusMethodNotAllowed
		case common.ErrorCollectLogsRunning, common.ErrorDatabaseConflict:
			responseStatus = http.StatusConflict
		default:
			log.Warn("Default error: Internal Server Error")
			responseStatus = http.StatusInternalServerError
		}
	default:
		log.Warn("Undefined error. Assuming Internal Server Error")
		responseStatus = http.StatusInternalServerError
		responseBody = common.NewApplicationError(common.ErrorGeneralFailure, fmt.Sprintf("%v", err))
	}
	return responseStatus, responseBody
}
