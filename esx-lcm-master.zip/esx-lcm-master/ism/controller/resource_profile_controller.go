//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ResourceProfileController struct {
	SyncBaseController
}

func NewResourceProfileController() ControllerInterface {
	ctrl := new(ResourceProfileController)
	ctrl.service = service.NewResourceProfileService()
	return ctrl
}

func (this *ResourceProfileController) Post(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPost(w, r)
}

func (this *ResourceProfileController) Put(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPut(w, r)
}

func (this *ResourceProfileController) Delete(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncDelete(w, r)
}

func (this *ResourceProfileController) Patch(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPatch(w, r)
}

func (this *ResourceProfileController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getResourceList",
			"GET",
			string(common.URIResourceProfileName),
			AuthPublicRequest(this.GetAll),
		},
	}
	return routes
}
