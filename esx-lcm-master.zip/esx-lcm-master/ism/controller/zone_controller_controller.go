//(C) Copyright 2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ZoneControllerController struct {
	AsyncBaseController
}

func NewZoneControllerController() ControllerInterface {
	ctrl := new(ZoneControllerController)
	ctrl.service = service.NewZoneControllerService()
	return ctrl
}

func (this *ZoneControllerController) Post(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPost(w, r)
}

func (this *ZoneControllerController) Put(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPut(w, r)
}

func (this *ZoneControllerController) Delete(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncDelete(w, r)
}

func (this *ZoneControllerController) Patch(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPatch(w, r)
}

func (this *ZoneControllerController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getZoneControllerList",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections"),
			AuthPublicRequest(this.GetAll),
		},
		Route{
			"getZoneController",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			AuthPublicRequest(this.Get),
		},
		Route{
			"postZoneController",
			"POST",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections"),
			AuthPublicRequest(this.Post),
		},
		Route{
			"putZoneController",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			AuthPublicRequest(this.Put),
		},
		Route{
			"deleteZoneController",
			"DELETE",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			AuthPublicRequest(this.Delete),
		},
		Route{
			"patchZoneController",
			"PATCH",
			common.BuildUri(common.IsmURI(common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "connections")), "{uuid}"),
			AuthPublicRequest(this.Patch),
		},
	}
	return routes
}
