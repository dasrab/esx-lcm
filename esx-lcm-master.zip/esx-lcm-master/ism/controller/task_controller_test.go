//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"

	"net/http/httptest"
	"reflect"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func TestNewTaskController(t *testing.T) {
	ctrl := new(TaskController)
	ctrl.service = service.NewTaskService()
	ctrl1 := NewTaskController()
	if !reflect.DeepEqual(ctrl1, ctrl) {
		t.Errorf("Error")
	}
}

func Test_Patch(t *testing.T) {
	m := TaskController{}
	req, err := http.NewRequest("PATCH", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Patch)
	handler.ServeHTTP(rr, req)

}

func Test_Post(t *testing.T) {
	m := TaskController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Post)
	handler.ServeHTTP(rr, req)

}

func Test_Put(t *testing.T) {
	m := TaskController{}
	req, err := http.NewRequest("PUT", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Put)
	handler.ServeHTTP(rr, req)
}

func Test_Delete(t *testing.T) {
	m := TaskController{}
	req, err := http.NewRequest("DELETE", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Delete)
	handler.ServeHTTP(rr, req)
}

func TestTaskController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getTaskList",
			"GET",
			string(common.URITaskResource),
			nil,
		},
		Route{
			"getTask",
			"GET",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			nil,
		},
		Route{
			"putTask",
			"PUT",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			nil,
		},
		Route{
			"postTask",
			"POST",
			string(common.URITaskResource),
			nil,
		},
		Route{
			"patchTask",
			"PATCH",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			nil,
		},
		Route{
			"patchTask",
			"DELETE",
			common.BuildUri(common.URITaskResource, "{uuid}"),
			nil,
		},
	}
	envCtrl := TaskController{}
	routes := envCtrl.GetRoutes()
	assert.NotNil(t, routes, "Not nil")
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("error in task controller test")
		}
	}
}
