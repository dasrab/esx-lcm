//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
)

// Middleware to authenticate a public request through IDM token or Basic Auth
func AuthPublicRequest(fn http.HandlerFunc) http.HandlerFunc {

	return func(w http.ResponseWriter, r *http.Request) {
		// Run HandlerFunc
		fn(w, r)
	}
}
