//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewRouter(t *testing.T) {
	op := NewRouter()
	assert.NotNil(t, op)

}
