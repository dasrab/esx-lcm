//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"os"
	"path"
	"reflect"
	"strings"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func TestNewFileServerController(t *testing.T) {
	ctrl := new(FileServerController)
	ctrl1 := NewFileServerController()
	if !reflect.DeepEqual(ctrl1, ctrl) {
		t.Errorf("Error")
	}
}

func Test_getAbsoluteFilepath(t *testing.T) {
	pwd, err := os.Getwd()
	if err != nil {
		os.Exit(1)
	}
	op := path.Join(pwd, "a.txt", " /")

	want := getAbsoluteFilepath("a.txt")
	check := strings.Compare(op, want)

	if check != 1 {
		t.Errorf("op = %v, want %v", op, want)
	}

}

func TestFileServerController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"scripts",
			"GET",
			common.BuildUri(common.URIFileServer, "{files}"),
			nil,
		},
		Route{
			"list scripts",
			"GET",
			string(common.URIFileServer),
			nil,
		},
	}
	envCtrl := FileServerController{}
	routes := envCtrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("error in file server controller test")
		}
	}
}

func TestFileServerController_ServerScripts(t *testing.T) {
	ctrl := FileServerController{}
	r := bytes.NewReader([]byte(`some dummy file content`))
	uri := common.BuildUri(common.URIFileServer, "dummyFile")
	req, err := http.NewRequest("GET", uri, r)
	if err != nil {
		t.Fatal(err)
	}
	//create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.ServerScripts())

	// handlers satisfy http.Handler, so we can call their ServeHTTP method
	// directly and pass in our Request and ResponseRecorder.
	handler.ServeHTTP(rr, req)
}

func TestDelete(t *testing.T) {
	ctrl := FileServerController{}

	// We create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	recorder := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.Delete)
	assert.NotNil(t, recorder)
	assert.NotNil(t, handler)
}

func TestPatch(t *testing.T) {
	ctrl := FileServerController{}

	// We create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	recorder := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.Patch)
	assert.NotNil(t, recorder)
	assert.NotNil(t, handler)
}

func TestPost(t *testing.T) {
	ctrl := FileServerController{}

	// We create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	recorder := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.Post)
	assert.NotNil(t, recorder)
	assert.NotNil(t, handler)
}

func TestPut(t *testing.T) {
	ctrl := FileServerController{}

	// We create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	recorder := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.Put)
	assert.NotNil(t, recorder)
	assert.NotNil(t, handler)

}
