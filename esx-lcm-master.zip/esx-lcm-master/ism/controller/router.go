//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"github.com/gorilla/mux"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

type (
	Route struct {
		Name        string
		Method      string
		Pattern     string
		HandlerFunc http.HandlerFunc
	}

	Routes []Route
)

var controllers []ControllerInterface

func NewRouter() *mux.Router {

	controllers = []ControllerInterface{
		NewTaskController(),
		NewInfrastructureController(),
		NewZoneController(),
		NewZoneServerController(),
		NewResourceProfileController(),
		NewZoneEnvironmentController(),
		NewZoneControllerController(),
		NewFileServerController(),
	}

	routes := Routes{
		Route{
			"Index",
			"GET",
			"/",
			ShowIndex,
		},
	}

	// Add Routes of each Controller
	for _, controller := range controllers {
		routes = append(routes, controller.GetRoutes()...)
	}

	router := mux.NewRouter().StrictSlash(true)
	for _, route := range routes {
		// Notice Controller routes are chaining two or more HandlerFunc.
		// Any change here might break AuthN/AuthZ.
		router.
			Methods(route.Method).
			Path(route.Pattern).
			Name(route.Name).
			Handler(common.Logger(route.HandlerFunc, route.Name))
	}

	return router
}
