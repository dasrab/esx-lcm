//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ZoneEnvironmentController struct {
	SyncBaseController
}

func NewZoneEnvironmentController() ControllerInterface {
	ctrl := new(ZoneEnvironmentController)
	ctrl.service = service.NewZoneEnvironmentService()
	return ctrl
}

func (this *ZoneEnvironmentController) Post(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPost(w, r)
}

func (this *ZoneEnvironmentController) Put(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPut(w, r)
}

func (this *ZoneEnvironmentController) Delete(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncDelete(w, r)
}

func (this *ZoneEnvironmentController) Patch(w http.ResponseWriter, r *http.Request) {
	this.SyncBaseController.SyncPatch(w, r)
}

func (this *ZoneEnvironmentController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getZoneEnvironment",
			"GET",
			string(common.URIZoneEnvironment),
			AuthPublicRequest(this.GetAll),
		},
		Route{
			"getZoneEnvironment",
			"GET",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			AuthPublicRequest(this.Get),
		},
		Route{
			"putZoneEnvironment",
			"PUT",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			AuthPrivateRequest(this.Put),
		},
		Route{
			"patchZoneEnvironment",
			"PATCH",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			AuthPrivateRequest(this.Patch),
		},
		Route{
			"deleteZoneEnvironment",
			"DELETE",
			common.BuildUri(common.URIZoneEnvironment, "{uuid}"),
			AuthPrivateRequest(this.Delete),
		},
	}
	return routes
}
