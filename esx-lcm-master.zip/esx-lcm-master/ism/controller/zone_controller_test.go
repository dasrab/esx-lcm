//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

func Test_Patch_Zone(t *testing.T) {
	m := ZoneController{}
	req, err := http.NewRequest("PATCH", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Patch)
	handler.ServeHTTP(rr, req)

}

func Test_Post_Zone(t *testing.T) {
	m := ZoneController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Post)
	handler.ServeHTTP(rr, req)

}

func Test_Put_Zone(t *testing.T) {
	m := ZoneController{}
	req, err := http.NewRequest("PUT", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Put)
	handler.ServeHTTP(rr, req)
}

func Test_Delete_Zone(t *testing.T) {
	m := ZoneController{}
	req, err := http.NewRequest("DELETE", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Delete)
	handler.ServeHTTP(rr, req)
}

func TestZoneController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getZonesList",
			"GET",
			string(common.URIZone),
			nil,
		},
		Route{
			"getZone",
			"GET",
			common.BuildUri(common.URIZone, "{uuid}"),
			nil,
		},
		Route{
			"getZoneMetadata",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetMetadata"),
			nil,
		},
		Route{
			"getApplianceImage",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetApplianceImage"),
			nil,
		},
		Route{
			"postZone",
			"POST",
			string(common.URIZone),
			nil,
		},
		Route{
			"getZoneClusters",
			"GET",
			string(common.URIZone),
			nil,
		},
		Route{
			"putUpdateZoneClusters",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "UpdateClusters"),
			nil,
		},
		Route{
			"putDeleteZoneClusters",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "DeleteClusters"),
			nil,
		},
		Route{
			"AddCapacity",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "AddCapacity"),
			nil,
		},
		Route{
			"putDeleteZone",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "DeleteZone"),
			nil,
		},
		Route{
			"putZone",
			"PUT",
			common.BuildUri(common.URIZone, "{uuid}"),
			nil,
		},
		Route{
			"deleteZone",
			"DELETE",
			common.BuildUri(common.URIZone, "{uuid}"),
			nil,
		},
		Route{
			"patchZone",
			"PATCH",
			common.BuildUri(common.URIZone, "{uuid}"),
			nil,
		},
		Route{
			"RecoverZoneClusters",
			"PUT",
			common.BuildUri(common.URIZone, "{uuid}"),
			nil,
		},
	}
	ctrl := ZoneController{}
	routes := ctrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("Error in Zone controller test")
		}
	}
}

func TestZoneController_UpdateClusters(t *testing.T) {
	ctrl := ZoneController{}
	r := bytes.NewReader([]byte(`"regionURI": "/rest/regions/3904e276-74b7-428d-ad63-91ed42c4e15b",
    			             "providerURI": "/rest/providers/ipl",
    				     "osRegionName": "ncs-ncs",
    				     "name": "ncs"`))
	ur := common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "UpdateClusters")
	req, err := http.NewRequest("PUT", ur, r)
	if err != nil {
		t.Fatal(err)
	}
	//create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.UpdateClusters)

	// handlers satisfy http.Handler, so we can call their ServeHTTP method
	// directly and pass in our Request and ResponseRecorder.
	handler.ServeHTTP(rr, req)

}

func TestZoneController_DeleteClusters(t *testing.T) {
	ctrl := ZoneController{}
	r := bytes.NewReader([]byte(`"id": "1223", "name": "zone1", "managed": true, "platformProfileName": "platform_profile_used_above"`))
	ur := common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "DeleteClusters")
	req, err := http.NewRequest("PUT", ur, r)
	if err != nil {
		t.Fatal(err)
	}
	//create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.AddCapacity)

	// handlers satisfy http.Handler, so we can call their ServeHTTP method
	// directly and pass in our Request and ResponseRecorder.
	handler.ServeHTTP(rr, req)

}

func TestZoneController_AddCapacity(t *testing.T) {
	ctrl := ZoneController{}
	r := bytes.NewReader([]byte(`"id": "1223", "name": "zone1", "managed": true, "platformProfileName": "platform_profile_used_above"`))
	ur := common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "1223")), "AddCapacity")
	req, err := http.NewRequest("PUT", ur, r)
	if err != nil {
		t.Fatal(err)
	}
	//create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.AddCapacity)

	//handlers satisfy http.Handler, so we can call their ServeHTTP method
	// directly and pass in our Request and ResponseRecorder.
	handler.ServeHTTP(rr, req)
}

func TestZoneController_GetApplianceImage(t *testing.T) {
	ctrl := ZoneController{}
	r := bytes.NewReader([]byte(`"id": "1223", "name": "zone1", "managed": true, "platformProfileName": "platform_profile_used_above"`))
	ur := common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetApplianceImage")
	req, err := http.NewRequest("PUT", ur, r)
	if err != nil {
		t.Fatal(err)
	}
	//create a ResponseRecorder (which satisfies http.ResponseWriter) to record the response.
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(ctrl.AddCapacity)

	// handlers satisfy http.Handler, so we can call their ServeHTTP method
	// directly and pass in our Request and ResponseRecorder.
	handler.ServeHTTP(rr, req)
}
