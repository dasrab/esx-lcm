//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/service"
)

type ZoneController struct {
	AsyncBaseController
}

func NewZoneController() ControllerInterface {
	ctrl := new(ZoneController)
	ctrl.service = service.NewZoneService()
	return ctrl
}

func (this *ZoneController) Post(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPost(w, r)
}

func (this *ZoneController) Put(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPut(w, r)
}

func (this *ZoneController) Delete(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncDelete(w, r)
}

func (this *ZoneController) Patch(w http.ResponseWriter, r *http.Request) {
	this.AsyncBaseController.AsyncPatch(w, r)
}

func (this *ZoneController) GetRoutes() Routes {
	routes := Routes{
		Route{
			"getZonesList",
			"GET",
			string(common.URIZone),
			AuthPublicRequest(this.GetAll),
		},
		Route{
			"getZone",
			"GET",
			common.BuildUri(common.URIZone, "{uuid}"),
			AuthPublicRequest(this.Get),
		},
		Route{
			"getZoneMetadata",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetMetadata"),
			AuthPublicRequest(this.GetMetadata),
		},
		Route{
			"getApplianceImage",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetApplianceImage"),
			AuthPublicRequest(this.GetApplianceImage),
		},
		Route{
			"postZone",
			"POST",
			string(common.URIZone),
			AuthPublicRequest(this.Post),
		},
		Route{
			"getZoneClusters",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "GetClusters"),
			AuthPublicRequest(this.GetClusters),
		},
		Route{
			"putUpdateZoneClusters",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "UpdateClusters"),
			AuthPublicRequest(this.UpdateClusters),
		},
		Route{
			"putDeleteZoneClusters",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "DeleteClusters"),
			AuthPublicRequest(this.DeleteClusters),
		},
		Route{
			"putDeleteZone",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "DeleteZone"),
			AuthPublicRequest(this.DeleteZone),
		},
		Route{
			"AddCapacity",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "AddCapacity"),
			AuthPublicRequest(this.AddCapacity),
		},
		Route{
			"RecoverZoneClusters",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "RecoverClusters"),
			AuthPublicRequest(this.RecoverClusters),
		},
		Route{
			"putZone",
			"PUT",
			common.BuildUri(common.URIZone, "{uuid}"),
			AuthPublicRequest(this.Put),
		},
		Route{
			"deleteZone",
			"DELETE",
			common.BuildUri(common.URIZone, "{uuid}"),
			AuthPublicRequest(this.Delete),
		},
		Route{
			"patchZone",
			"PATCH",
			common.BuildUri(common.URIZone, "{uuid}"),
			AuthPublicRequest(this.Patch),
		},
	}
	return routes
}

func (this *ZoneController) UpdateClusters(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from UpdateClusters operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneService().UpdateClusters(id, body)
}

func (this *ZoneController) GetClusters(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from GetClusters operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	id := getUUIDFromRequest(r)
	responseBody = service.NewZoneService().GetClusters(id, options.Filters)
}

func (this *ZoneController) DeleteClusters(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from DeleteClusters operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneService().DeleteClusters(id, options.Filters, body)
}

func (this *ZoneController) RecoverClusters(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from RecoverClusters operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneService().RecoverClusters(id, body)
}

func (this *ZoneController) DeleteZone(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from DeleteZone operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	options, err := getHTTPHeaders(options, r)
	if err != nil {
		panic(err)
	}
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneService().DeleteZone(id, body)
}

func (this *ZoneController) AddCapacity(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from AddCapacity operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	id := getUUIDFromRequest(r)
	body := getBodyFromRequest(r)
	responseBody = service.NewZoneService().AddCapacity(id, body)
}

func (this *ZoneController) GetApplianceImage(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from GetApplianceImage operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	id := getUUIDFromRequest(r)
	service.NewZoneService().GetApplianceImage(id)
}

func (this *ZoneController) GetMetadata(w http.ResponseWriter, r *http.Request) {
	options := common.NewRestOptions()
	responseStatus := http.StatusAccepted
	var responseBody interface{}

	defer func() {
		if err := recover(); err != nil {
			log.Errorf("Recovering from GetMetadata operation - %v", err)
			responseStatus, responseBody = getHTTPStatus(err)
		}
		writeResponse(w, options, responseStatus, responseBody)
	}()
	id := getUUIDFromRequest(r)
	responseBody = service.NewZoneService().GetMetadata(id)
}
