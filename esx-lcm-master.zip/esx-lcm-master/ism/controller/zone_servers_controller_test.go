//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package controller

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
)

/*
func TestZoneServerController(t *testing.T){
	ctrl := new(ZoneServerController)
	ctrl.service = service.NewZoneServerService()
	ctrl1 := ZoneServerController()
	if !reflect.DeepEqual(ctrl, ctrl1){
		t.Errorf("Error")
	}
}
*/

func Test_Patch_Zone_Server(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("PATCH", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Patch)
	handler.ServeHTTP(rr, req)

}

func Test_Post_Zone_Server(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Post)
	handler.ServeHTTP(rr, req)

}

func Test_Put_Zone_Server(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("PUT", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Put)
	handler.ServeHTTP(rr, req)
}

func Test_Delete_Zone_Server(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("DELETE", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.Delete)
	handler.ServeHTTP(rr, req)
}

func TestGetWithFilters(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.GetWithFilters)
	handler.ServeHTTP(rr, req)
}

func TestDeleteServers(t *testing.T) {
	m := ZoneServerController{}
	req, err := http.NewRequest("POST", "/zone", nil)
	if err != nil {
		t.Fatal(err)
	}
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(m.DeleteServers)
	handler.ServeHTTP(rr, req)

}
func TestZoneServerController_GetRoutes(t *testing.T) {
	output := Routes{
		Route{
			"getZoneServers",
			"GET",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			nil,
		},
		Route{
			"putZoneServers",
			"PUT",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			nil,
		},
		Route{
			"deleteZoneServers",
			"DELETE",
			common.BuildUri(common.IsmURI(common.BuildUri(common.URIZone, "{uuid}")), "servers"),
			nil,
		},
	}
	ctrl := ZoneServerController{}
	routes := ctrl.GetRoutes()
	for index, r := range routes {
		if output[index].Name != r.Name && output[index].Pattern != r.Pattern && output[index].Method != r.Method {
			t.Error("Error in ZoneServer controller test")
		}
	}
}
