//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package comms_lcm

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
)

const (
	commsLcmBasePath     = "/rest/comms-lcm"
	commsLcmReadinessEP  = "/readiness"
	commsLcmLivenessEP   = "/liveness"
	commsLcmSectunnelsEP = "/sectunnels"
)

var (
	defaultHTTPClient = getHTTPClient()
)

func GetCommsLcmURI() string {
	return fmt.Sprintf("http://%v:%v", properties.ISM.CommsLcm.Host, properties.ISM.CommsLcm.Port)
}

func getHTTPClient() *http.Client {
	return &http.Client{
		Timeout: time.Duration(30 * time.Second),
	}
}

func getCommsLcmBaseRequest(method string, path string, body io.Reader) (*http.Request, error) {
	commsLcmURI := GetCommsLcmURI()
	req, err := http.NewRequest(method, commsLcmURI+path, body)
	if err != nil {
		return nil, err
	}
	// place holder for any additional custom headers

	return req, err
}

// DoTokenJSONRequest Does a JSON Request with the token
func DoTokenJSONRequest(token string, req *http.Request) (*http.Response, error) {
	req.Header.Set("Content-Type", "application/json; charset=utf-8")
	req.Header.Set("X-Auth-Token", token)
	// Note: HTTP Client is supposed to optimize connections with HTTP
	// but observable slowness was happening that seemed to go away with not caching the client??
	// Need to go back and investigate.
	return defaultHTTPClient.Do(req)
}

// SecTunnel is a struct representing sectunnel attributes
type SecTunnel struct {
	Name       string `json:"name"`
	RemoteHost string `json:"remote_host"`
	RemotePort int32  `json:"remote_port"`
	RegionURI  string `json:"region_uri"`
	ProxyHost  string `json:"proxy_host"`
	ProxyPort  int32  `json:"proxy_port"`
	Ready      bool   `json:"ready"`
	URI        string `json:"uri"`
}

// createSecTunnel is a struct representing sectun attributes for create sectun
type createSecTunnel struct {
	Name       string `json:"name"`
	RemoteHost string `json:"remote_host"`
	RemotePort int32  `json:"remote_port"`
	RegionURI  string `json:"region_uri"`
}

type CommsLcmHealth struct {
	Check string `json:"check"`
}

const (
	CommsLcmHealthOK = "ok"
)

// CommsLcmIf an interface to CommsLcmHttpClient
type CommsLcmIf interface {
	IsCommsLcmReady() (string, error)
	IsCommsLcmAlive() (string, error)
	GetSecTunnel(uri string) (SecTunnel, error)
	DeleteSecTunnel(uri string) error
	RegisterSecTunnel(name, ipAddress string, port int32, regionUri string) (SecTunnel, error)
	IsSecTunnelReady(secTunnel SecTunnel, timeout, pollInterval time.Duration) error
}

var commsLcmInstance CommsLcmIf
var GetCommsLcm = getCommsLcm

func getCommsLcm() CommsLcmIf {
	commsLcmInstance = &SecTunnel{}
	return commsLcmInstance
}

// IsCommsLcmReady successful response indicates the comms API is Ready
func (commsLcm *SecTunnel) IsCommsLcmReady() (string, error) {
	req, err := getCommsLcmBaseRequest(http.MethodGet, commsLcmBasePath+commsLcmReadinessEP, nil)
	if err != nil {
		return "", err
	}
	res, err := DoTokenJSONRequest("", req)
	if res != nil {
		defer res.Body.Close()
	}
	if err != nil {
		return "", err
	}
	var commsLcmHealth CommsLcmHealth
	err = json.NewDecoder(res.Body).Decode(&commsLcmHealth)
	if err != nil {
		return "", err
	}
	return commsLcmHealth.Check, nil
}

// IsCommsLcmAlive successful response indicates the comms API is ok and alive
func (commsLcm *SecTunnel) IsCommsLcmAlive() (string, error) {
	req, err := getCommsLcmBaseRequest(http.MethodGet, commsLcmBasePath+commsLcmLivenessEP, nil)
	if err != nil {
		return "", err
	}
	res, err := DoTokenJSONRequest("", req)
	if res != nil {
		defer res.Body.Close()
	}
	if err != nil {
		return "", err
	}
	var commsLcmHealth CommsLcmHealth
	err = json.NewDecoder(res.Body).Decode(&commsLcmHealth)
	if err != nil {
		return "", err
	}
	return commsLcmHealth.Check, nil
}

// RegisterSecTunnelEndPoint registers a sectunnel
func (commsLcm *SecTunnel) RegisterSecTunnel(name, ipAddress string, port int32, regionUri string) (SecTunnel, error) {
	var secTunnelReg SecTunnel
	inputSectun := createSecTunnel{
		Name:       name,
		RemoteHost: ipAddress,
		RemotePort: port,
		RegionURI:  regionUri,
	}
	log.Infof("Creating a sectunnel for the %v:%v", inputSectun.RemoteHost, inputSectun.RemotePort)
	b := new(bytes.Buffer)
	json.NewEncoder(b).Encode(inputSectun)
	req, err := getCommsLcmBaseRequest(http.MethodPost, commsLcmBasePath+commsLcmSectunnelsEP, b)
	if err != nil {
		log.Errorf("An error occured while creating the request %v", err)
		return secTunnelReg, err
	}
	res, err := DoTokenJSONRequest("", req)
	if res != nil {
		defer res.Body.Close()
	}
	if err != nil {
		log.Errorf("An error response returned %v", err)
		return secTunnelReg, err
	}
	if res.StatusCode == http.StatusOK {
		err = json.NewDecoder(res.Body).Decode(&secTunnelReg)
		if err != nil {
			log.Errorf("An error occurred while decoding the response %v", err)
			return secTunnelReg, err
		}
	} else {
		invalidResponseMsg := fmt.Sprintf("Comms lcm returned an invalid response %v", res.Status)
		log.Errorf(invalidResponseMsg)
		invalidResponseErr := errors.New(invalidResponseMsg)
		return secTunnelReg, invalidResponseErr
	}
	log.Infof("Registered sectunnel details are : %v", secTunnelReg)
	return secTunnelReg, nil
}

// GetSecTunnel gets a sectunnel from the id
func (commsLcm *SecTunnel) GetSecTunnel(secTunnelUri string) (SecTunnel, error) {
	req, err := getCommsLcmBaseRequest(http.MethodGet, secTunnelUri, nil)
	var secTunnelReg SecTunnel
	if err != nil {
		return secTunnelReg, err
	}
	res, err := DoTokenJSONRequest("", req)
	if res != nil {
		defer res.Body.Close()
	}
	if err != nil {
		return secTunnelReg, err
	}
	err = json.NewDecoder(res.Body).Decode(&secTunnelReg)
	if err != nil {
		return secTunnelReg, err
	}
	return secTunnelReg, nil
}

// DeleteSecTunnel gets a sectunnel from the id
func (commsLcm *SecTunnel) DeleteSecTunnel(secTunnelUri string) error {
	req, err := getCommsLcmBaseRequest(http.MethodDelete, secTunnelUri, nil)
	if err != nil {
		return err
	}
	res, err := DoTokenJSONRequest("", req)
	if res != nil {
		defer res.Body.Close()
	}
	if err != nil {
		return err
	}
	return nil
}

func (commsLcm *SecTunnel) IsSecTunnelReady(secTunnel SecTunnel, timeout, pollInterval time.Duration) error {
	var err error
	var secTun SecTunnel
	tick := time.Tick(pollInterval * time.Second)
	timedOut := time.After(timeout * time.Second)
	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				log.Errorf("Panic recovered while attempting to poll secTunnel: %v", r)
			}
			log.Infof("Polling for sectunnel %v to be ready stopped.", secTunnel.Name)
			wg.Done()
		}()
		var tickCount time.Duration
		for {
			select {
			case <-timedOut:
				errorMsg := fmt.Sprintf("Sectunnel %v couldn't get ready %v seconds.", secTunnel.Name, timeout)
				err = errors.New(errorMsg)
				panic(err)
			case <-tick:
				log.Debugf("Time elapsed while polling the Sectunnel %v", time.Duration(tickCount)*time.Second)
				tickCount = tickCount + pollInterval
				secTun, err = commsLcm.GetSecTunnel(secTunnel.URI)
				if err != nil {
					panic(err)
				}
				if !secTun.Ready {
					log.Debugf("Sectunnel %v is not yet ready", secTunnel.URI)
					continue
				} else {
					log.Infof("Sectunnel %v is ready", secTunnel.URI)
					return
				}
			}
		}
	}()
	// wait for the go routine to get over
	wg.Wait()
	return err
}
