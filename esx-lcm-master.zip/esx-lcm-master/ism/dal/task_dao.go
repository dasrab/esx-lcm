//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type TaskDAO interface {
	Get(id interface{}) (model.TaskResource, error)
	Delete(id interface{}) error
	GetAll(map[string][]string) ([]model.TaskResource, error)
	GetTotal(map[string][]string) (int, error)
	GetStart(filters map[string][]string) int
	Create(resource *model.TaskResource) error
	Update(resource *model.TaskResource) error
}

type taskDAO struct {
	ManagedResourceDAO
}

func NewTaskDAO() TaskDAO {
	dao := new(taskDAO)
	dao.ManagedResourceDAO = NewManagedResourceDAO(taskResourceDB)
	return dao
}

func (dao taskDAO) Create(resource *model.TaskResource) error {
	return dao.BaseCreate(resource)
}

func (dao taskDAO) Get(id interface{}) (model.TaskResource, error) {
	var task model.TaskResource
	err := dao.BaseGet(id, &task)
	return task, err
}

func (dao taskDAO) Delete(id interface{}) error {
	return dao.BaseDelete(id)
}

func (dao taskDAO) GetAll(filters map[string][]string) ([]model.TaskResource, error) {
	var dbList []model.TaskResource
	err := dao.BaseGetAll(&dbList, filters)
	return dbList, err
}

func (dao taskDAO) GetTotal(filters map[string][]string) (int, error) {
	var dbList []model.TaskResource
	count, err := dao.BaseGetTotal(&dbList, filters)
	return count, err
}
func (dao taskDAO) GetStart(filters map[string][]string) int {
	return dao.BaseGetStart(filters)
}

func (dao taskDAO) Update(resource *model.TaskResource) error {
	return dao.BaseUpdate(resource.Uuid, resource)
}
