//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type ZoneEnvironmentDAO interface {
	Get(id string) (model.ZoneEnvironment, error)
	GetAll(map[string][]string) ([]model.ZoneEnvironment, error)
	Create(resource model.IManagedResource) error
	Update(resource model.IManagedResource) error
	Delete(id string) error
}

type zoneEnvironmentDAO struct {
	ManagedResourceDAO
}

func NewZoneEnvironmentDAO() ZoneEnvironmentDAO {
	dao := new(zoneEnvironmentDAO)
	dao.ManagedResourceDAO = NewManagedResourceDAO(zoneEnvironmentDB)
	return dao
}

func (dao zoneEnvironmentDAO) Get(id string) (model.ZoneEnvironment, error) {
	var ovSettings model.ZoneEnvironment
	err := dao.BaseGet(id, &ovSettings)
	return ovSettings, err
}

func (dao zoneEnvironmentDAO) GetAll(filters map[string][]string) ([]model.ZoneEnvironment, error) {
	var dbList []model.ZoneEnvironment
	err := dao.BaseGetAll(&dbList, filters)
	return dbList, err
}

func (dao zoneEnvironmentDAO) Create(resource model.IManagedResource) error {
	return dao.BaseCreate(resource)
}

func (dao zoneEnvironmentDAO) Update(resource model.IManagedResource) error {
	return dao.BaseUpdate(resource.GetUUID(), resource)
}

func (dao zoneEnvironmentDAO) Delete(id string) error {
	return dao.BaseDelete(id)
}
