//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type ZoneControllerDAO interface {
	Get(id string) (model.ZoneController, error)
	GetAll(map[string][]string) ([]model.ZoneController, error)
	Create(resource model.IManagedResource) error
	Update(resource model.IManagedResource) error
	Delete(id string) error
}

type zoneControllerDAO struct {
	ManagedResourceDAO
}

func NewZoneControllerDAO() ZoneControllerDAO {
	dao := new(zoneControllerDAO)
	dao.ManagedResourceDAO = NewManagedResourceDAO(zoneControllerDB)
	return dao
}

func (dao zoneControllerDAO) Get(id string) (model.ZoneController, error) {
	var zoneController model.ZoneController
	err := dao.BaseGet(id, &zoneController)
	return zoneController, err
}

func (dao zoneControllerDAO) GetAll(filters map[string][]string) ([]model.ZoneController, error) {
	var dbList []model.ZoneController
	err := dao.BaseGetAll(&dbList, filters)
	return dbList, err
}

func (dao zoneControllerDAO) Create(resource model.IManagedResource) error {
	return dao.BaseCreate(resource)
}

func (dao zoneControllerDAO) Update(resource model.IManagedResource) error {
	return dao.BaseUpdate(resource.GetUUID(), resource)
}

func (dao zoneControllerDAO) Delete(id string) error {
	return dao.BaseDelete(id)
}
