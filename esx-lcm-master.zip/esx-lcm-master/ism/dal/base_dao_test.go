//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"testing"
)

type testResource struct {
	model.ManagedResource
	Name     string           `json:"name"`
	Password model.SecretInfo `json:"password"`
}

const testResourceType model.ResourceType = "test-resource"
const testResourceURI common.IsmURI = "test-resources"

var testResourceDB resourceAssociation = resourceAssociation{
	Table:        "resource",
	ResourceURI:  testResourceURI,
	ResourceType: testResourceType,
}

func newTestDAO() ManagedResourceDAO {
	dao := new(baseDAO)
	dao.initialize(testResourceDB)
	return dao
}

func TestInsertResource(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r := makeTestResource()

	err := dao.BaseCreate(&r)
	assert.NoError(err)

	var query testResource

	err = dao.BaseGet(r.GetUUID(), &query)
	assert.NoError(err)

	assertEqualResource(t, r, query)
}

func TestInsertResourceWithUUID(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r := makeTestResource()
	r.SetUUID("TestUUID")

	err := dao.BaseCreate(&r)
	assert.NoError(err)

	var query testResource

	err = dao.BaseGet(r.GetUUID(), &query)
	assert.NoError(err)

	assert.Equal("TestUUID", r.GetUUID())
	assertEqualResource(t, r, query)
}

func TestInsertResourceWithUUIDConflict(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r1 := makeTestResource()
	r1.SetUUID("TestUUID")

	r2 := makeTestResource()
	r2.SetUUID("TestUUID")

	err := dao.BaseCreate(&r1)
	assert.NoError(err)

	err = dao.BaseCreate(&r2)
	assert.Error(err)
}

func TestUpdateMultipleResources(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r1 := makeTestResource()
	r2 := makeTestResource()

	r2.Name = "test-2"

	dao.BaseCreate(&r1)
	dao.BaseCreate(&r2)

	r1.Name = "test-3"
	r2.Name = "test-4"

	err := dao.BaseUpdate(r1.GetUUID(), &r1)
	assert.NoError(err)

	err = dao.BaseUpdate(r2.GetUUID(), &r2)
	assert.NoError(err)

	var query1, query2 testResource

	err = dao.BaseGet(r1.GetUUID(), &query1)
	assert.NoError(err)

	err = dao.BaseGet(r2.GetUUID(), &query2)
	assert.NoError(err)

	assertEqualResource(t, r1, query1)
	assertEqualResource(t, r2, query2)
}

func TestDeleteResource(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r1 := makeTestResource()
	r2 := makeTestResource()

	r2.Name = "test-2"

	dao.BaseCreate(&r1)
	dao.BaseCreate(&r2)

	err := dao.BaseDelete(r2.GetUUID())
	assert.NoError(err)

	var query testResource

	err = dao.BaseGet(r2.GetUUID(), &query)
	assert.Error(err)
	assert.Equal(testResource{}, query)

	err = dao.BaseGet(r1.GetUUID(), &query)
	assert.NoError(err)
	assertEqualResource(t, r1, query)
}

func TestGetAllResources(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	var query []testResource

	err := dao.BaseGetAll(&query, nil)
	assert.NoError(err)
	assert.Len(query, 0)

	r1 := makeTestResource()
	dao.BaseCreate(&r1)
	err = dao.BaseGetAll(&query, nil)
	assert.NoError(err)
	assert.Len(query, 1)
	assertEqualResource(t, r1, query[0])

	r2 := makeTestResource()
	r2.Name = "infra-system-2"
	dao.BaseCreate(&r2)
	err = dao.BaseGetAll(&query, nil)
	assert.NoError(err)
	assert.Len(query, 2)
	assertEqualResource(t, r1, query[0])
	assertEqualResource(t, r2, query[1])
}

func TestGetAllResourcesWithFilter(t *testing.T) {
	common.StartLogs()
	assert := assert.New(t)
	common.StartLogs()

	dao := newTestDAO()
	defer dropSchema(t, "resource")

	r1 := makeTestResource()
	r2 := makeTestResource()
	r3 := makeTestResource()
	r1.Name = "test-1"
	r2.Name = "test-1"
	r3.Name = "test-3"

	dao.BaseCreate(&r1)
	dao.BaseCreate(&r2)
	dao.BaseCreate(&r3)

	filters := make(map[string][]string)
	filters["query"] = []string{string("name==test-1")}

	var query []testResource

	err := dao.BaseGetAll(&query, filters)
	assert.NoError(err)

	assert.Len(query, 2)
	assertEqualResource(t, r1, query[0])
	assertEqualResource(t, r2, query[1])
}

func TestClearSecretInfo(t *testing.T) {
	common.StartLogs()

	defer dropSchema(t, "resource")

	r1 := makeTestResource()
	r1.Password = "somePassword"
	model.ClearSecretInfo(&r1)

	assert.Equal(t, "test-1", r1.Name)
	assert.Equal(t, model.SecretInfo(""), r1.Password)
}

func assertEqualResource(t *testing.T, expected, actual testResource) {
	assert := assert.New(t)
	assert.Equal(expected.GetType(), actual.GetType())
	assert.Equal(expected.GetUri(), actual.GetUri())
	assert.Equal(expected.GetUUID(), actual.GetUUID())
	assert.Equal(expected.Name, actual.Name)
}

func makeTestResource() testResource {
	r := testResource{
		ManagedResource: model.ManagedResource{},
		Name:            "test-1",
	}

	return r
}

func dropSchema(t *testing.T, table string) {
	drv := connector.GetConnector()
	err := drv.Drop(table)
	assert.NoError(t, err)
}
