//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"fmt"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
)

func Initialize(appVersion version.Version) error {
	log.Infof("Executing database initialization...")

	// Will panic after the timeout if the database is not available
	con := connector.GetConnector()

	// Initialize database handler (handles database versioning and migrations)
	h, err := connector.NewVersionHandler(con, appVersion)

	if err != nil {
		log.Errorf("Error getting handler to database (%v)", err)
		return err
	}

	dbVersion, err := h.Version()

	if err != nil {
		log.Errorf("Error getting database version (%v)", err)
		return err
	}

	log.Infof("Current database version: %s", dbVersion)
	log.Infof("List of valid values for API Version: %v", version.SupportedValues())

	// An application/container will normally support all resources from previous versions, but not resources from
	// more recent containers.
	if !dbVersion.IsSupported() {
		err := fmt.Errorf("General failure! This database's version %s is not supported", dbVersion)
		log.Error(err)
		return err
	}

	log.Infof("Verifying if a database migration is required")

	if appVersion == dbVersion {
		log.Infof("The database version matches this application's API Version %s", appVersion)
		return err
	}

	log.Warnf("This database version %s is outdated and contents will be migrated", dbVersion)

	if err := MigrateDatabase(con, h, appVersion); err != nil {
		log.Errorf("Error on database migration: %v", err)
		return err
	}

	return nil
}
