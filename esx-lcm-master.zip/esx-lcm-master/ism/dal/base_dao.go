//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	"regexp"
	"sync"

	"strconv"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

var mutex = &sync.Mutex{}

type ManagedResourceDAO interface {
	BaseGet(uuid interface{}, result interface{}) error
	BaseGetAll(result interface{}, filters map[string][]string) error
	BaseGetTotal(result interface{}, filters map[string][]string) (int, error)
	BaseGetStart(filters map[string][]string) int
	BaseCreate(resource model.IManagedResource) error
	BaseUpdate(uuid interface{}, resource model.IManagedResource) error
	BaseDelete(uuid interface{}) error
}

type baseDAO struct {
	con   connector.Connector
	table string
	uri   common.IsmURI
	res   model.ResourceType
}

// NewManagedResourceDAO creates a new base DAO for model.IManagedResource structs. This class should be extended by
// more specialized DAO classes, to allow for runtime type checking.
//
// Table name should not include "-" characters.
func NewManagedResourceDAO(resourceDB resourceAssociation) ManagedResourceDAO {
	dao := new(baseDAO)
	dao.initialize(resourceDB)
	return dao
}

func (dao *baseDAO) initialize(resourceDB resourceAssociation) {
	dao.con = connector.GetConnector()
	dao.table = resourceDB.Table
	dao.uri = resourceDB.ResourceURI
	dao.res = resourceDB.ResourceType
	dao.createTable()
}

func (dao baseDAO) BaseCreate(resource model.IManagedResource) error {
	defer mutex.Unlock()
	mutex.Lock()

	resource.SetType(dao.res)

	// remove secret fields before inserting
	// model.ClearSecretInfo(resource)

	return dao.con.Insert(dao.table, resource, dao.uri)
}

func (dao baseDAO) BaseDelete(uuid interface{}) error {
	defer mutex.Unlock()
	mutex.Lock()

	return dao.con.Delete(dao.table, uuid.(string))
}

func (dao baseDAO) BaseGet(uuid interface{}, result interface{}) error {
	return dao.con.Get(result, dao.table, uuid.(string))
}

func (dao *baseDAO) BaseGetAll(result interface{}, filters map[string][]string) error {
	error := dao.con.Select(result, dao.table, dao.createQuery(filters))
	return error
}
func (dao baseDAO) BaseGetTotal(result interface{}, filters map[string][]string) (int, error) {
	total, error := dao.con.SelectCount(dao.table, dao.createQuery(filters))
	return total, error
}

func (dao baseDAO) BaseGetStart(filters map[string][]string) int {
	startV := dao.createQuery(filters)["start"].(string)
	start, _ := strconv.Atoi(startV)
	return start
}

func (dao baseDAO) BaseUpdate(uuid interface{}, resource model.IManagedResource) error {
	defer mutex.Unlock()
	mutex.Lock()

	resource.SetType(dao.res)

	// remove secret fields before updating
	//model.ClearSecretInfo(resource)

	return dao.con.Update(dao.table, uuid.(string), resource)
}

func (dao baseDAO) createTable() error {
	defer mutex.Unlock()
	mutex.Lock()

	return dao.con.Create(dao.table)
}

// CreateQuery receives a map of html queries and responds with bson.M queries for the DB.
//
// Example:
//
// Input HTML Query: /rest/infrastructure?query=Uri==/rest/infrastructure/1
// CreateQuery Input: map{[query],["Uri==/rest/infrastructure/1"]]}
// CreateQuery Output: map{[uri, rest/infrastructure/1]}
// Currently we only support equals operation using query tag.
func (dao *baseDAO) createQuery(filters map[string][]string) map[string]interface{} {
	queryMap := make(map[string]interface{})
	queryMap["start"] = "0"
	for key, _ := range filters {
		log.Debugf("key = %s", key)
		//TODO: Add support for other kinds of filters here
		switch {
		case key == "query":
			query := filters[key][0]
			//TODO: Add support for other conditions if needed
			const EQUALS_PATTERN = "(\\w+)\\s*==\\s*(.+)"
			r, _ := regexp.Compile(EQUALS_PATTERN)
			if r.MatchString(query) {
				collection := r.FindStringSubmatch(query)
				if len(collection) == 3 {
					item := collection[1]
					value := collection[2]
					log.Debugf("Querying if item %s is == to %s", item, value)
					queryMap[item] = value
				}
			}
		// Send Rows beyond "start" only
		case key == "start":
			start := filters[key][0]
			log.Debugf("Getting from record %s", start)
			queryMap["start"] = start
		// Send only "count" rows
		case key == "count":
			count := filters[key][0]
			log.Debugf("Limit to  %s recordss", count)
			queryMap["count"] = count
		default:
		}
	}
	return queryMap
}
