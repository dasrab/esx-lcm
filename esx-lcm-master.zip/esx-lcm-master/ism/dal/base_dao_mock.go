//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.com/stretchr/testify/mock"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type ManagedResourceDAOMock struct {
	mock.Mock
}

//func (m *ManagedResourceDAOMock) BaseGet(uuid interface{}, result interface{}) error {
//	args := m.Called()
//
//	if args.Get(1) == nil {
//		//resource is an interface containing a pointer for an interface. The way to reach interface contents is:
//		// *resource.(*interface{}), so basically here we are just putting a &model.Disk list there
//		disk, _ := args.Get(0).(model.Disk)
//		*result.(*model.Disk) = disk
//		return nil
//	} else {
//		result = model.Disk{}
//		return args.Error(1)
//	}
//}

//func (m *ManagedResourceDAOMock) BaseGetAll(result interface{}, filters map[string][]string) error {
//	args := m.Called()
//
//	if args.Get(1) == nil {
//		diskList, _ := args.Get(0).([]model.Disk)
//		*result.(*interface{}) = &diskList
//		return nil
//	} else {
//		result = nil
//		return args.Error(1)
//	}
//}

func (m *ManagedResourceDAOMock) BaseCreate(resource model.IManagedResource) error {
	args := m.Called()
	return args.Error(0)
}

func (m *ManagedResourceDAOMock) BaseUpdate(uuid interface{}, resource model.IManagedResource) error {
	args := m.Called()
	return args.Error(0)
}

func (m *ManagedResourceDAOMock) BaseDelete(uuid interface{}) error {
	args := m.Called()
	return args.Error(0)
}

func (m *ManagedResourceDAOMock) BaseGetTotal(interface{}, map[string][]string) (int, error) {
	return 0, nil
}
func (m *ManagedResourceDAOMock) BaseGetStart(filters map[string][]string) int {
	return 0
}
