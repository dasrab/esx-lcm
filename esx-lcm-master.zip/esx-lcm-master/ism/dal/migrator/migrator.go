//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
//
// Package migrator implements functions that serve as database migration scripts.
//
// The New() function should be called at the application startup to generate a migrator object which will allow
// upgrading the application database from a given version to a target version (usually, the current API version).
//
// The migrator's Run(Connector) function executes the script.
//
// The database can be reached with the Connector object which is being passed as a parameter. In case database
// operations are necessary the objects need to be loaded as json maps, and then unmarshalled as the current models.
//
// IMPORTANT - this package is meant to be independent from our models. So migrations are done by manipulating JSON
// data directly.
//
// See tests for examples of this implementation.
package migrator

import (
	"fmt"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
)

// migrationMap takes a valid migration and maps it to a given migrator
var migrationMap = map[migration]migrator{
	migration{from: version.APIVersion0, to: version.APIVersion1}: migratorV0toV1{},
}

// migration holds a pair of versions, representing an allowed database version migration
type migration struct {
	from version.Version
	to   version.Version
}

// migrator holds the interface for all migrator scripts
type migrator interface {

	// Run is a custom function that executes all the migration logic for a given target api version
	Run(con connector.Connector) error
}

// migratorAggregator holds an ordered list of migrators, and runs them all in sequence; it also implements the migrator
// interface.
//
//	migratorAtoC := migratorAggregator{
//		migrators: []migrator{
//			testMigratorAtoB{},
//			testMigratorBtoC{},
//		},
//	}
//
// See tests for examples of usage.
type migratorAggregator struct {
	migrators []migrator
}

func (a migratorAggregator) Run(con connector.Connector) error {
	for _, v := range a.migrators {
		if err := v.Run(con); err != nil {
			return err
		}
	}
	return nil
}

// New selects and initializes the correct migrator script from the old version to the current version
func New(from version.Version, to version.Version) (migrator, error) {
	m := migration{
		from: from,
		to:   to,
	}

	migrator, ok := migrationMap[m]

	if !ok {
		return nil, fmt.Errorf("Migration from %s to %s is not allowed", from, to)
	}

	return migrator, nil
}
