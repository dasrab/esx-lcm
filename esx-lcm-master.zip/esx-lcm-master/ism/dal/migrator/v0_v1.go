//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package migrator

import "github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"

// migratorV0toV1 runs the custom startup migration scripts for a migration from V0 to V1
type migratorV0toV1 struct{}

// this method is empty because since V0 is a test version, there's no need to migrate anything
func (m migratorV0toV1) Run(con connector.Connector) error {
	return nil
}
