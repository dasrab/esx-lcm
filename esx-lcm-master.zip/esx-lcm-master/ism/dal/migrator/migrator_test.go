//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package migrator

import (
	"encoding/json"
	"strings"
	"testing"

	"fmt"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

func TestRunMigrator(t *testing.T) {
	a := assert.New(t)

	tests := []struct {
		from     version.Version
		to       version.Version
		valid    bool
		migrator migrator
	}{
		{version.APIVersion0, version.APIVersion1, true, migratorV0toV1{}},
		{version.APIVersion0, version.APIVersion0, false, nil},
		{version.APIVersion1, version.APIVersion1, false, nil},
		{version.APIVersion1, version.APIVersion0, false, nil},
		{version.APIVersion0, version.Version(""), false, nil},
		{version.APIVersion0, version.Version("InvalidVersion"), false, nil},
	}

	for _, tc := range tests {
		m, err := New(tc.from, tc.to)
		a.Equal(m, tc.migrator)

		if tc.valid {
			a.NoError(err)
		} else {
			a.Error(err)
		}
	}
}

const (
	testVersionA = version.Version("TestVersionA")
	testVersionB = version.Version("TestVersionB")
	testVersionC = version.Version("TestVersionC")
)

func TestMigration(t *testing.T) {
	common.StartLogs()
	con := connector.GetConnector()

	// Cleanup
	defer con.Drop(connector.Metatable)
	con.Drop(connector.Metatable)
	defer con.Drop("people")
	con.Create("people")

	// Write our test migrator into map
	migrationMap[migration{from: testVersionA, to: testVersionB}] = testMigratorAtoB{}

	a := assert.New(t)

	person := PersonA{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason Bourne",
		Pet:             Pet{Name: "Rex"},
	}

	// Insert old object on database
	con.Insert("people", &person, "")

	// Try to load it into a new object
	var query PersonB
	err := con.Get(&query, "people", "1")

	// Will throw an error, because data was outdated!
	a.Error(err)

	// Get our test migrator
	m, err := New(testVersionA, testVersionB)
	a.NoError(err)

	// Run our test migrator
	err = m.Run(con)
	a.NoError(err)

	// Get object from DB gain
	err = con.Get(&query, "people", "1")

	// Will NOT throw an error, because data was previously migrated!
	a.NoError(err)

	a.Equal("Jason", query.Name.First)
	a.Equal("Bourne", query.Name.Last)
	a.Equal("Rex", query.Pet[0].Name)
	a.Equal("/1", query.Uri)
	a.Equal("1", query.Uuid)
}

func TestAggregatedMigration(t *testing.T) {
	common.StartLogs()
	con := connector.GetConnector()

	// Cleanup
	defer con.Drop(connector.Metatable)
	con.Drop(connector.Metatable)
	defer con.Drop("people")
	con.Create("people")

	// a migratorAggregator, which will run two migrations (A->B, B->C) in sequence
	migratorAtoC := migratorAggregator{
		migrators: []migrator{
			testMigratorAtoB{},
			testMigratorBtoC{},
		},
	}

	// Write our test migrator from A to C into map
	migrationMap[migration{from: testVersionA, to: testVersionC}] = migratorAtoC

	person := PersonA{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason Bourne",
		Pet:             Pet{Name: "Rex"},
	}

	// Insert old object on database
	con.Insert("people", &person, "")

	a := assert.New(t)

	// Get our test migrator
	m, err := New(testVersionA, testVersionC)
	a.NoError(err)

	// Run our test migrator
	err = m.Run(con)
	a.NoError(err)

	// Try to load it into a new object
	var query PersonC
	err = con.Get(&query, "people", "1")

	a.Equal("Mr. Jason", query.Name.First)
	a.Equal("Bourne", query.Name.Last)
	a.Equal("/1", query.Uri)
	a.Equal("1", query.Uuid)

}

// testMigratorAtoB migreates Person to Person2 on the people table
type testMigratorAtoB struct{}

func (m testMigratorAtoB) Run(con connector.Connector) error {
	// Load data as a map of <string>:<json data> to be able to read old fields
	var data map[string]*json.RawMessage
	if err := con.Get(&data, "people", "1"); err != nil {
		return err
	}

	// Manually migrate name from string to a new Name struct
	var fullname string
	if err := json.Unmarshal(*data["name"], &fullname); err != nil {
		return err
	}

	sp := strings.Split(fullname, " ")

	// Manually migrate pet from struct to slice
	var pets map[string]*json.RawMessage
	if err := json.Unmarshal(*data["pet"], &pets); err != nil {
		return err
	}

	newPerson := map[string]interface{}{
		"uuid":     data["uuid"],
		"uri":      data["uri"],
		"type":     data["type"],
		"created":  data["created"],
		"modified": data["modified"],
		"name": map[string]interface{}{
			"first": sp[0],
			"last":  sp[1],
		},
		"pet": []interface{}{
			pets,
		},
	}

	// Marshal into JSON object
	newPersonJSON, err := json.Marshal(newPerson)
	if err != nil {
		return err
	}

	// Manually get uuid
	var uuid string
	if err := json.Unmarshal(*data["uuid"], &uuid); err != nil {
		return err
	}

	// Update object on database
	err = con.UpdateJSON("people", uuid, newPersonJSON)
	return err
}

// testMigratorBtoC is a simple migrator, which only appends "Mr." to every first name on the table
type testMigratorBtoC struct{}

func (m testMigratorBtoC) Run(con connector.Connector) error {

	// Load data as a map of <string>:<json data> to be able to read old fields
	var data map[string]*json.RawMessage
	if err := con.Get(&data, "people", "1"); err != nil {
		return err
	}

	// Manually migrate name from string to a new Name struct
	var name map[string]*json.RawMessage
	if err := json.Unmarshal(*data["name"], &name); err != nil {
		return err
	}

	// Manually migrate name from string to a new Name struct
	var first string
	if err := json.Unmarshal(*name["first"], &first); err != nil {
		return err
	}

	newPerson := map[string]interface{}{
		"uuid":     data["uuid"],
		"uri":      data["uri"],
		"type":     data["type"],
		"created":  data["created"],
		"modified": data["modified"],
		"name": map[string]interface{}{
			"first": fmt.Sprintf("Mr. %s", first), // append Mr.
			"last":  name["last"],
		},
	}

	// Marshal into JSON object
	newPersonJSON, err := json.Marshal(newPerson)
	if err != nil {
		return err
	}

	// Manually get uuid
	var uuid string
	if err := json.Unmarshal(*data["uuid"], &uuid); err != nil {
		return err
	}

	// Update object on database
	err = con.UpdateJSON("people", uuid, newPersonJSON)
	return err
}

type PersonA struct {
	model.ManagedResource
	Name string `json:"name"`
	Pet  Pet    `json:"pet"`
}

type Pet struct {
	Name string `json:"name"`
}

// Person2 is an updated "Person" object. The Name field is now a struct with "First" and "Last" name fields and the
// Pet field is a slice of Pets.
type PersonB struct {
	model.ManagedResource
	Name Name  `json:"name"`
	Pet  []Pet `json:"pet"`
}

type Name struct {
	First string `json:"first"`
	Last  string `json:"last"`
}

// PersonC needs no Pets anymore!
type PersonC struct {
	model.ManagedResource
	Name Name `json:"name"`
}
