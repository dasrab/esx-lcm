//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package dal

import (
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/migrator"
)

func MigrateDatabase(con connector.Connector, h connector.VersionHandler, target version.Version) error {
	log.Warnf("Starting database migration to application's API Version: %s", target)

	// runMigrationScripts runs a series of iterative scripts that migrate the database to the current version
	if err := runMigrationScripts(con, h, target); err != nil {
		log.Errorf("Error running custom startup migration scripts (%v)", err)
		return err
	}

	// updateResources iterates through all tables and guarantees that all data is either up-to-date with the current
	// version or that it can be loaded into current resources and updated. If any row cannot be unmarshalled into
	// its corresponding resource it will throw an error.
	if err := updateResources(con, h, target); err != nil {
		log.Errorf("Error migrating database resources to newest version %s (%v)", target, err)
		return err
	}

	if err := h.SetVersion(target); err != nil {
		log.Errorf("Error setting database version to %s (%v)", target, err)
		return err
	}

	log.Infof("Database migration to %s finished successfully", target)
	return nil
}

func runMigrationScripts(con connector.Connector, h connector.VersionHandler, appVersion version.Version) error {
	dbVersion, err := h.Version()

	if err != nil {
		log.Errorf("Error getting database version (%v)", err)
		return err
	}

	log.Infof("Running database migration scripts from %s to %s", dbVersion, appVersion)

	if dbVersion != appVersion {
		m, err := migrator.New(dbVersion, appVersion)

		if err != nil {
			log.Errorf("Error initializing migration from %s to %s (%v)", dbVersion, appVersion, err)
			return err
		}

		if err := m.Run(con); err != nil {
			log.Errorf("Error running migration from %s to %s (%v)", dbVersion, appVersion, err)
			return err
		}
	}

	return err
}

func updateResources(con connector.Connector, h connector.VersionHandler, v version.Version) error {
	log.Warnf("Starting update of database resources to new API Version: %s", v)

	tables, err := con.Tables()

	if err != nil {
		log.Errorf("Error getting database tables (%v)", err)
		return err
	}

	// Migrate all the tables on the database to match new resource APIs
	for _, t := range tables {

		// There's no need to update the metadata table
		if t == connector.Metatable {
			continue
		}

		model, err := getResourceModelFromTable(t)

		if err != nil {
			log.Errorf("Error getting resource model for table %s (%v)", t, err)
			return err
		}

		if err := h.MigrateTable(t, model); err != nil {
			log.Errorf("Error updating table %s to version %s (%v)", t, v, err)
			return err
		}
	}

	log.Infof("Resource update to %s finished successfully", v)
	return nil
}
