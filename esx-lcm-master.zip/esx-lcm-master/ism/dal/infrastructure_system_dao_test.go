//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// TestInsertInfrastructureSystem
func TestInsertInfrastructureSystem(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewInfrastructureSystemDAO()
	defer dropInfrastructureSystemSchema(t)

	infra := makeTestInfrastructureSystem()

	err := dao.Create(&infra)
	assert.NoError(err)

	query, err := dao.Get(infra.GetUUID())
	assert.NoError(err)

	assertEqualInfras(t, infra, query)
}

// TestUpdateMultipleInfrastructureSystems
func TestUpdateMultipleInfrastructureSystems(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewInfrastructureSystemDAO()
	defer dropInfrastructureSystemSchema(t)

	infra1 := makeTestInfrastructureSystem()
	infra2 := makeTestInfrastructureSystem()

	infra2.Id = "infra-system-2"

	dao.Create(&infra1)
	dao.Create(&infra2)

	infra1.Id = "UpdatedName1"

	infra2.Id = "UpdatedName2"

	err := dao.Update(&infra1)
	assert.NoError(err)

	err = dao.Update(&infra2)
	assert.NoError(err)

	query1, err := dao.Get(infra1.GetUUID())
	assert.NoError(err)

	query2, err := dao.Get(infra2.GetUUID())
	assert.NoError(err)

	assertEqualInfras(t, infra1, query1)
	assertEqualInfras(t, infra2, query2)

}

// TestDeleteInfrastructureSystem
func TestDeleteInfrastructureSystem(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewInfrastructureSystemDAO()
	defer dropInfrastructureSystemSchema(t)

	infra1 := makeTestInfrastructureSystem()
	infra2 := makeTestInfrastructureSystem()

	infra2.Id = "infra-system-2"

	dao.Create(&infra1)
	dao.Create(&infra2)

	err := dao.Delete(infra2.GetUUID())
	assert.NoError(err)

	query, err := dao.Get(infra2.GetUUID())
	assert.Error(err)

	assert.Equal(model.InfrastructureSystem{}, query)

	query, err = dao.Get(infra1.GetUUID())
	assert.NoError(err)

	assertEqualInfras(t, infra1, query)
}

// TestGetAllInfrastructureSystem
func TestGetAllInfrastructureSystems(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewInfrastructureSystemDAO()
	defer dropInfrastructureSystemSchema(t)

	query, err := dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 0)

	infra1 := makeTestInfrastructureSystem()
	dao.Create(&infra1)
	query, err = dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 1)
	assertEqualInfras(t, infra1, query[0])

	infra2 := makeTestInfrastructureSystem()
	infra2.Id = "infra-system-2"
	dao.Create(&infra2)
	query, err = dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 2)
	assertEqualInfras(t, infra1, query[0])
	assertEqualInfras(t, infra2, query[1])
}

// TestGetAllInfrastructureSystemWithFilter
func TestGetAllInfrastructureSystemWithFilter(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewInfrastructureSystemDAO()
	defer dropInfrastructureSystemSchema(t)

	infra1 := makeTestInfrastructureSystem()
	infra2 := makeTestInfrastructureSystem()
	infra3 := makeTestInfrastructureSystem()

	infra1.Id = "infra-system-1"
	infra1.Status = model.OK

	infra2.Id = "infra-system-2"
	infra2.Status = model.Critical

	infra3.Id = "infra-system-3"
	infra3.Status = model.Critical

	dao.Create(&infra1)
	dao.Create(&infra2)
	dao.Create(&infra3)

	filters := make(map[string][]string)
	filters["query"] = []string{"status==" + string(model.Critical)}

	query, err := dao.GetAll(filters)
	assert.NoError(err)

	assert.Len(query, 2)
	assertEqualInfras(t, infra2, query[0])
	assertEqualInfras(t, infra3, query[1])
}

func assertEqualInfras(t *testing.T, expected model.InfrastructureSystem, actual model.InfrastructureSystem) {
	assert := assert.New(t)
	assert.Equal(expected.GetUUID(), actual.GetUUID())
	assert.Equal(expected.GetType(), actual.ManagedResource.GetType())
	assert.Equal(expected.GetUri(), actual.ManagedResource.GetUri())
	assert.Equal(expected.Id, actual.Id)
	assert.Equal(expected.Status, actual.Status)
	assert.Equal(expected.InfraState, actual.InfraState)

}

func makeTestInfrastructureSystem() model.InfrastructureSystem {
	infra := model.InfrastructureSystem{
		Id:         "infra-system-1",
		Status:     model.OK,
		InfraState: model.ConfiguringState,
	}

	return infra
}

func dropInfrastructureSystemSchema(t *testing.T) {
	dropSchema(t, "infrastructure_systems")
}
