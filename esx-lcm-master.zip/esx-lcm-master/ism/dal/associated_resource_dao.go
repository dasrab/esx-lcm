//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/dal/connector"
)

type AssociatedResourceDAO interface {
	Exists(uri string) (bool, error)
}

type AssociateResourceType struct {
}

func (ar AssociateResourceType) Exists(uri string) (bool, error) {
	log.Infof("Validating %s exists on DB\n", uri)
	resourceAssociation, err := getResourceAssociationFromUri(uri)
	if err != nil {
		log.Infof("Resource %s not found on DB %v\n", uri, resourceAssociation)
		return false, err
	}

	driver := connector.GetConnector()
	return driver.Find(resourceAssociation.Table, getUUIDFromUri(uri))
}
