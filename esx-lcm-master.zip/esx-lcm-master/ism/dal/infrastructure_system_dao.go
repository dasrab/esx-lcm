//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"errors"
	"fmt"

	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type InfrastructureSystemDAO interface {
	Get(id interface{}) (model.InfrastructureSystem, error)
	GetAll(map[string][]string) ([]model.InfrastructureSystem, error)
	Create(resource *model.InfrastructureSystem) error
	Update(resource *model.InfrastructureSystem) error
	Delete(id interface{}) error
}

type infrastructureSystemDAO struct {
	ManagedResourceDAO
}

func NewInfrastructureSystemDAO() InfrastructureSystemDAO {
	dao := new(infrastructureSystemDAO)
	dao.ManagedResourceDAO = NewManagedResourceDAO(infrastructureSystemDB)
	return dao
}

func (dao infrastructureSystemDAO) Get(id interface{}) (model.InfrastructureSystem, error) {
	var infra model.InfrastructureSystem
	err := dao.BaseGet(id, &infra)
	return infra, err
}

func (dao infrastructureSystemDAO) GetAll(filters map[string][]string) ([]model.InfrastructureSystem, error) {
	var dbList []model.InfrastructureSystem
	err := dao.BaseGetAll(&dbList, filters)
	return dbList, err
}

func (dao infrastructureSystemDAO) Create(resource *model.InfrastructureSystem) error {
	filters := make(map[string][]string)
	queryString := "id==%s"
	// todo: replace resource.Name with resource.Id
	queryString = fmt.Sprintf(queryString, resource.Id)
	filters["query"] = []string{queryString}
	dbList, err := dao.GetAll(filters)
	if err != nil {
		return err
	}
	if len(dbList) > 0 {
		// It means somehow the infrastructure was already created
		// Probably somebody made two get calls on the zone simultaneously
		errorMsg := "Inrastructure create failed. Inrastructure with id - %v is already existing"
		log.Errorf(fmt.Sprintf(errorMsg, resource.Id))
		dbError := errors.New(common.ErrorDatabaseConflict.String())
		return dbError
	}

	return dao.BaseCreate(resource)
}

func (dao infrastructureSystemDAO) Update(resource *model.InfrastructureSystem) error {
	return dao.BaseUpdate(resource.Uuid, resource)
}

func (dao infrastructureSystemDAO) Delete(id interface{}) error {
	return dao.BaseDelete(id)
}
