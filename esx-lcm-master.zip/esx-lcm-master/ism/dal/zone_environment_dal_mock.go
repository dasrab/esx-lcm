//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

// Package mock_dal is a generated GoMock package.
package dal

import (
	reflect "reflect"

	gomock "github.com/golang/mock/gomock"
	model "github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// MockZoneEnvironmentDAO is a mock of ZoneEnvironmentDAO interface
type MockZoneEnvironmentDAO struct {
	ctrl     *gomock.Controller
	recorder *MockZoneEnvironmentDAOMockRecorder
}

// MockZoneEnvironmentDAOMockRecorder is the mock recorder for MockZoneEnvironmentDAO
type MockZoneEnvironmentDAOMockRecorder struct {
	mock *MockZoneEnvironmentDAO
}

// NewMockZoneEnvironmentDAO creates a new mock instance
func NewMockZoneEnvironmentDAO(ctrl *gomock.Controller) *MockZoneEnvironmentDAO {
	mock := &MockZoneEnvironmentDAO{ctrl: ctrl}
	mock.recorder = &MockZoneEnvironmentDAOMockRecorder{mock}
	return mock
}

// EXPECT returns an object that allows the caller to indicate expected use
func (m *MockZoneEnvironmentDAO) EXPECT() *MockZoneEnvironmentDAOMockRecorder {
	return m.recorder
}

// Get mocks base method
func (m *MockZoneEnvironmentDAO) Get(id string) (model.ZoneEnvironment, error) {
	ret := m.ctrl.Call(m, "Get", id)
	ret0, _ := ret[0].(model.ZoneEnvironment)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// Get indicates an expected call of Get
func (mr *MockZoneEnvironmentDAOMockRecorder) Get(id interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Get", reflect.TypeOf((*MockZoneEnvironmentDAO)(nil).Get), id)
}

// GetAll mocks base method
func (m *MockZoneEnvironmentDAO) GetAll(arg0 map[string][]string) ([]model.ZoneEnvironment, error) {
	ret := m.ctrl.Call(m, "GetAll", arg0)
	ret0, _ := ret[0].([]model.ZoneEnvironment)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// GetAll indicates an expected call of GetAll
func (mr *MockZoneEnvironmentDAOMockRecorder) GetAll(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetAll", reflect.TypeOf((*MockZoneEnvironmentDAO)(nil).GetAll), arg0)
}

// Create mocks base method
func (m *MockZoneEnvironmentDAO) Create(resource model.IManagedResource) error {
	ret := m.ctrl.Call(m, "Create", resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// Create indicates an expected call of Create
func (mr *MockZoneEnvironmentDAOMockRecorder) Create(resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Create", reflect.TypeOf((*MockZoneEnvironmentDAO)(nil).Create), resource)
}

// Update mocks base method
func (m *MockZoneEnvironmentDAO) Update(resource model.IManagedResource) error {
	ret := m.ctrl.Call(m, "Update", resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// Update indicates an expected call of Update
func (mr *MockZoneEnvironmentDAOMockRecorder) Update(resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Update", reflect.TypeOf((*MockZoneEnvironmentDAO)(nil).Update), resource)
}

// Delete mocks base method
func (m *MockZoneEnvironmentDAO) Delete(id string) error {
	ret := m.ctrl.Call(m, "Delete", id)
	ret0, _ := ret[0].(error)
	return ret0
}

// Delete indicates an expected call of Delete
func (mr *MockZoneEnvironmentDAOMockRecorder) Delete(id interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Delete", reflect.TypeOf((*MockZoneEnvironmentDAO)(nil).Delete), id)
}
