//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type InfrastructureSystemContextDAO interface {
	Get(id interface{}) (model.InfrastructureSystemContext, error)
	GetAll(map[string][]string) ([]model.InfrastructureSystemContext, error)
	Create(resource *model.InfrastructureSystemContext) error
	Update(resource *model.InfrastructureSystemContext) error
	Delete(id interface{}) error
}

type infrastructureSystemContextDAO struct {
	ManagedResourceDAO
}

func NewInfrastructureSystemContextDAO() InfrastructureSystemContextDAO {
	dao := new(infrastructureSystemContextDAO)
	dao.ManagedResourceDAO = NewManagedResourceDAO(infrastructureSystemContextDB)
	return dao
}

func (dao infrastructureSystemContextDAO) Get(id interface{}) (model.InfrastructureSystemContext, error) {
	var infraContext model.InfrastructureSystemContext
	err := dao.BaseGet(id, &infraContext)
	return infraContext, err
}

func (dao infrastructureSystemContextDAO) GetAll(filters map[string][]string) ([]model.InfrastructureSystemContext, error) {
	var dbList []model.InfrastructureSystemContext
	err := dao.BaseGetAll(&dbList, filters)
	return dbList, err
}

func (dao infrastructureSystemContextDAO) Create(resource *model.InfrastructureSystemContext) error {
	return dao.BaseCreate(resource)
}

func (dao infrastructureSystemContextDAO) Update(resource *model.InfrastructureSystemContext) error {
	return dao.BaseUpdate(resource.Uuid, resource)
}

func (dao infrastructureSystemContextDAO) Delete(id interface{}) error {
	return dao.BaseDelete(id)
}
