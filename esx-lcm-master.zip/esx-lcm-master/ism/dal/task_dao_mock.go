// Co//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	reflect "reflect"

	gomock "github.com/golang/mock/gomock"
	model "github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// MockTaskDAO is a mock of TaskDAO interface
type MockTaskDAO struct {
	ctrl     *gomock.Controller
	recorder *MockTaskDAOMockRecorder
}

// MockTaskDAOMockRecorder is the mock recorder for MockTaskDAO
type MockTaskDAOMockRecorder struct {
	mock *MockTaskDAO
}

// NewMockTaskDAO creates a new mock instance
func NewMockTaskDAO(ctrl *gomock.Controller) *MockTaskDAO {
	mock := &MockTaskDAO{ctrl: ctrl}
	mock.recorder = &MockTaskDAOMockRecorder{mock}
	return mock
}

// EXPECT returns an object that allows the caller to indicate expected use
func (m *MockTaskDAO) EXPECT() *MockTaskDAOMockRecorder {
	return m.recorder
}

// Get mocks base method
func (m *MockTaskDAO) Get(id interface{}) (model.TaskResource, error) {
	ret := m.ctrl.Call(m, "Get", id)
	ret0, _ := ret[0].(model.TaskResource)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// Get indicates an expected call of Get
func (mr *MockTaskDAOMockRecorder) Get(id interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Get", reflect.TypeOf((*MockTaskDAO)(nil).Get), id)
}

// Delete mocks base method
func (m *MockTaskDAO) Delete(id interface{}) error {
	ret := m.ctrl.Call(m, "Delete", id)
	ret0, _ := ret[0].(error)
	return ret0
}

// Delete indicates an expected call of Delete
func (mr *MockTaskDAOMockRecorder) Delete(id interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Delete", reflect.TypeOf((*MockTaskDAO)(nil).Delete), id)
}

// GetAll mocks base method
func (m *MockTaskDAO) GetAll(arg0 map[string][]string) ([]model.TaskResource, error) {
	ret := m.ctrl.Call(m, "GetAll", arg0)
	ret0, _ := ret[0].([]model.TaskResource)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// GetAll indicates an expected call of GetAll
func (mr *MockTaskDAOMockRecorder) GetAll(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetAll", reflect.TypeOf((*MockTaskDAO)(nil).GetAll), arg0)
}

// GetTotal mocks base method
func (m *MockTaskDAO) GetTotal(arg0 map[string][]string) (int, error) {
	ret := m.ctrl.Call(m, "GetTotal", arg0)
	ret0, _ := ret[0].(int)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// GetTotal indicates an expected call of GetTotal
func (mr *MockTaskDAOMockRecorder) GetTotal(arg0 interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetTotal", reflect.TypeOf((*MockTaskDAO)(nil).GetTotal), arg0)
}

// GetStart mocks base method
func (m *MockTaskDAO) GetStart(filters map[string][]string) int {
	ret := m.ctrl.Call(m, "GetStart", filters)
	ret0, _ := ret[0].(int)
	return ret0
}

// GetStart indicates an expected call of GetStart
func (mr *MockTaskDAOMockRecorder) GetStart(filters interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "GetStart", reflect.TypeOf((*MockTaskDAO)(nil).GetStart), filters)
}

// Create mocks base method
func (m *MockTaskDAO) Create(resource *model.TaskResource) error {
	ret := m.ctrl.Call(m, "Create", resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// Create indicates an expected call of Create
func (mr *MockTaskDAOMockRecorder) Create(resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Create", reflect.TypeOf((*MockTaskDAO)(nil).Create), resource)
}

// Update mocks base method
func (m *MockTaskDAO) Update(resource *model.TaskResource) error {
	ret := m.ctrl.Call(m, "Update", resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// Update indicates an expected call of Update
func (mr *MockTaskDAOMockRecorder) Update(resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "Update", reflect.TypeOf((*MockTaskDAO)(nil).Update), resource)
}
