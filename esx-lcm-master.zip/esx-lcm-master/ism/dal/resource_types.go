//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	"errors"
	"fmt"
	"reflect"
	"strings"

	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type resourceAssociation struct {
	Table        string
	ResourceURI  common.IsmURI
	ResourceType model.ResourceType
	Model        reflect.Type
}

//ATTENTION Table name should not include "-" characters.
var (
	taskResourceDB resourceAssociation = resourceAssociation{
		Table:        "tasks",
		ResourceURI:  common.URITaskResource,
		ResourceType: model.TaskResourceType,
		Model:        reflect.TypeOf(model.TaskResource{}),
	}
	infrastructureSystemDB resourceAssociation = resourceAssociation{
		Table:        "infrastructure_systems",
		ResourceURI:  common.URIInfrastructureSystem,
		ResourceType: model.InfrastructureSystemsResourceType,
		Model:        reflect.TypeOf(model.InfrastructureSystem{}),
	}
	infrastructureSystemContextDB resourceAssociation = resourceAssociation{
		Table:        "infrastructure_system_ctx",
		ResourceURI:  "",
		ResourceType: model.InfrastructureSystemContextResourceType,
		Model:        reflect.TypeOf(model.InfrastructureSystemContext{}),
	}

	zoneEnvironmentDB resourceAssociation = resourceAssociation{
		Table:        "zone_environment",
		ResourceURI:  common.URIZoneEnvironment,
		ResourceType: model.ZoneEnvironmentResourceType,
		Model:        reflect.TypeOf(model.ZoneEnvironment{}),
	}

	zoneControllerDB resourceAssociation = resourceAssociation{
		Table:        "zone_controller",
		ResourceURI:  "",
		ResourceType: model.ZoneControllerResourceType,
		Model:        reflect.TypeOf(model.ZoneController{}),
	}
)

var resourceAssociationMap map[model.ResourceType]resourceAssociation = map[model.ResourceType]resourceAssociation{
	model.TaskResourceType:                        taskResourceDB,
	model.InfrastructureSystemsResourceType:       infrastructureSystemDB,
	model.InfrastructureSystemContextResourceType: infrastructureSystemContextDB,
	model.ZoneEnvironmentResourceType:             zoneEnvironmentDB,
	model.ZoneControllerResourceType:              zoneControllerDB,
}

func getResourceAssociationFromUri(uri string) (resourceAssociation, error) {
	ismURI, err := common.GetIsmURIFromURI(uri)
	if err != nil {
		return resourceAssociation{}, err
	}

	for k := range resourceAssociationMap {
		if resourceAssociationMap[k].ResourceURI == ismURI {
			return resourceAssociationMap[k], nil
		}
	}
	return resourceAssociation{}, errors.New(fmt.Sprintf("Resource Uri %s not found!", uri))
}

func getResourceModelFromTable(table string) (reflect.Type, error) {
	for _, v := range resourceAssociationMap {
		if v.Table == table {
			return v.Model, nil
		}
	}

	return nil, errors.New(fmt.Sprintf("Table %s not found!", table))
}

func getUUIDFromUri(uri string) string {
	uriPieces := strings.Split(uri, "/")
	uuid := uriPieces[len(uriPieces)-1]
	return uuid
}
