//(C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
	"testing"
)

// TestInsertTask
func TestInsertTask(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewTaskDAO()
	defer dropTaskSchema(t)

	task := makeTestTask()

	err := dao.Create(&task)
	assert.NoError(err)

	query, err := dao.Get(task.GetUUID())
	assert.NoError(err)

	assertEqualTasks(t, task, query)
}

// TestDeleteTask
func TestDeleteTask(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewTaskDAO()
	defer dropTaskSchema(t)

	task := makeTestTask()

	err := dao.Create(&task)
	assert.NoError(err)

	query, err := dao.Get(task.GetUUID())
	assert.NoError(err)

	assertEqualTasks(t, task, query)

	err = dao.Delete(task.GetUUID())
	assert.NoError(err)
}

// TestUpdateMultipleTasks
func TestUpdateMultipleTasks(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewTaskDAO()
	defer dropTaskSchema(t)

	task1 := makeTestTask()
	task2 := makeTestTask()

	task2.Name = "task-2"

	dao.Create(&task1)
	dao.Create(&task2)

	task1.Name = "UpdatedName1"
	task2.Name = "UpdatedName2"

	err := dao.Update(&task1)
	assert.NoError(err)

	err = dao.Update(&task2)
	assert.NoError(err)

	query1, err := dao.Get(task1.GetUUID())
	assert.NoError(err)

	query2, err := dao.Get(task2.GetUUID())
	assert.NoError(err)

	assertEqualTasks(t, task1, query1)
	assertEqualTasks(t, task2, query2)
}

// TestGetAllTasks
func TestGetAllTasks(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewTaskDAO()
	defer dropTaskSchema(t)

	query, err := dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 0)

	task1 := makeTestTask()
	dao.Create(&task1)
	query, err = dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 1)
	assertEqualTasks(t, task1, query[0])

	task2 := makeTestTask()
	task2.Name = "infra-system-2"
	dao.Create(&task2)
	query, err = dao.GetAll(nil)
	assert.NoError(err)
	assert.Len(query, 2)
	assertEqualTasks(t, task1, query[0])
	assertEqualTasks(t, task2, query[1])
}

// TestGetAllTasks
func TestGetAllTasksWithFilter(t *testing.T) {
	assert := assert.New(t)
	common.StartLogs()

	dao := NewTaskDAO()
	defer dropTaskSchema(t)

	task1 := makeTestTask()
	task2 := makeTestTask()
	task3 := makeTestTask()

	task1.Name = "task-1"
	task1.Status = model.OK

	task2.Name = "task-2"
	task2.Status = model.Critical

	task3.Name = "task-3"
	task3.Status = model.Critical

	dao.Create(&task1)
	dao.Create(&task2)
	dao.Create(&task3)

	filters := make(map[string][]string)
	filters["query"] = []string{"status==" + string(model.Critical)}

	query, err := dao.GetAll(filters)
	assert.NoError(err)

	assert.Len(query, 2)
	assertEqualTasks(t, task2, query[0])
	assertEqualTasks(t, task3, query[1])
}

func assertEqualTasks(t *testing.T, expected model.TaskResource, actual model.TaskResource) {
	assert := assert.New(t)
	assert.Equal(expected.GetUUID(), actual.GetUUID())
	assert.Equal(expected.GetType(), actual.ManagedResource.GetType())
	assert.Equal(expected.GetUri(), actual.ManagedResource.GetUri())
	assert.Equal(expected.Name, actual.Name)
	assert.Equal(expected.Status, actual.Status)
	assert.Equal(expected.State, actual.State)
}

func makeTestTask() model.TaskResource {
	task := model.TaskResource{
		Name:   "task-1",
		Status: model.OK,
		State:  "AnyState",
	}

	return task
}

func dropTaskSchema(t *testing.T) {
	dropSchema(t, "tasks")
}
