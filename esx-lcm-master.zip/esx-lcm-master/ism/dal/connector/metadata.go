//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package connector

import "github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"

// metatable holds metadata from the database.
const Metatable = "metadata"

// metadata has the model for the metadata table.
//
// WARNING - edit this with care. It is imperative to keep this table compatible between different versions of the ISM
// container, otherwise it will break at startup. Limit modifications to adding or removing fields with care, and avoid
// at all costs modifying existing fields.
type metadata struct {
	Version version.Version `json:"version"`
}
