//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package connector

import (
	"encoding/json"
	"fmt"
	"reflect"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx/types"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

type VersionHandler interface {
	// MigrateTable tries to update all the data into the table to a given model. It also performs a 'health check',
	// as if the data can't be loaded into the current model, an error will be thrown.
	MigrateTable(table string, model reflect.Type) error

	// Version returns the database version from the metadata table.
	Version() (version.Version, error)

	// SetVersion updates the database version in the metadata table.
	SetVersion(version.Version) error
}

// NewVersionHandler returns a database handler object for version and metadata manipulation. It also initializes
// a metadata table on the given database, to keep track of resource version.
func NewVersionHandler(connector Connector, version version.Version) (VersionHandler, error) {

	// NOTE this object depends on a pgconnector private methods, that's why it needs a cast. In the future this
	// could be refactored to use only Connector public methods, or dropping the Connector interface and making
	// the pgconnector structure public.
	h := pghandler{
		con: connector.(*pgconnector),
	}

	err := h.initializeMetadata(Metatable, version)
	return h, err
}

// pghandler is MySQL database handler.
type pghandler struct {
	con *pgconnector
}

func (h pghandler) MigrateTable(table string, model reflect.Type) error {
	v := version.API()

	log.Infof("Migrating resources at table %s to version %s", table, v)

	count, err := h.con.SelectCount(table, nil)

	if err != nil {
		log.Errorf("Error counting resource %+v (%v)", count, err)
		return err
	}

	// create a slice of the same type as model to store the object
	slice := reflect.ValueOf(reflect.New(reflect.ArrayOf(count, model)).Interface()).Elem()

	// perform the migration
	return h.migrateAll(table, slice, v)
}

func (h pghandler) Version() (version.Version, error) {
	log.Infof("Getting database version from table %s", Metatable)
	m, err := h.metadata()
	return m.Version, err
}

func (h pghandler) SetVersion(version version.Version) error {
	log.Infof("Setting database version at table %s to %s", Metatable, version)
	m, err := h.metadata()

	if err != nil {
		return err
	}

	if m.Version == version {
		log.Infof("Database version is already %s. Aborting operation.", version)
		return nil
	}

	m.Version = version
	val, err := json.Marshal(m)

	if err != nil {
		log.Errorf("Error marshalling resource %+v (%v)", m, err)
		return err
	}

	err = h.con.transaction(fmt.Sprintf("UPDATE %s SET data = ?", Metatable), val)

	if err != nil {
		log.Errorf("Error updating metadata %s at table %s (%v)", m, Metatable, err)
		return err
	}

	return nil
}

func (h pghandler) metadata() (m metadata, err error) {
	r, err := h.con.get(fmt.Sprintf("SELECT data FROM %s", Metatable))

	if err != nil {
		log.Errorf("Error reading database metadata from table %s (%v)", Metatable, err)
		return m, err
	}

	err = r.Unmarshal(&m)

	if err != nil {
		log.Errorf("Error unmarshalling metadata %+v (%v)", r, err)
		return m, err
	}

	return m, err
}

func (h pghandler) initializeMetadata(table string, v version.Version) error {
	log.Infof("Initializing metadata table on database")

	if err := h.con.Create(table); err != nil {
		log.Errorf("Could not initialize metadata table on database %s (%v)", h.con.name, err)
		return err
	}

	count, err := h.con.count(h.con.makeCountQuery(table, nil))

	if err != nil {
		log.Errorf("Error counting resources from table %s (%v)", table, err)
		return err
	}

	if count > 1 {
		log.Errorf("Database is corrupted: metadata table has more than one row!")
		return err
	}

	if count == 0 {
		// There's no metadata and the database is clean - create new metadata row
		err := h.createMetadataRow(table, v)

		if err != nil {
			log.Errorf("Error initializing metadata row on database %s (%v)", h.con.name, err)
			return err
		}
	}

	log.Infof("Metadata table initialized")
	return nil
}

func (h pghandler) createMetadataRow(table string, v version.Version) error {
	log.Infof("Creating a new row on the metadata table")

	m := metadata{
		Version: v,
	}

	val, err := json.Marshal(m)

	if err != nil {
		return err
	}

	tx := fmt.Sprintf("INSERT INTO %s (data) VALUES (?)", table)
	if err := h.con.transaction(tx, val); err != nil {
		return err
	}

	return nil
}

func (h pghandler) migrateAll(table string, slice reflect.Value, v version.Version) error {
	list, err := h.con.sel(h.con.makeSelectQuery(table, nil))

	if err != nil {
		log.Errorf("Error selecting resources from table %s during migration (%v)", table, err)
		return err
	}

	for i := 0; i < slice.Len(); i++ {
		// create a new pointer to resource (reflection is needed to load contents from list)
		res := reflect.Indirect(slice.Index(i)).Addr().Interface().(model.IManagedResource)

		err = h.migrate(table, res, list[i])

		// failure to migrate causes function to abort
		if err != nil {
			log.Errorf("Failed to migrate resource %s at table %s (%v)", res.GetUUID(), table, err)
			log.Errorf("Resource data: %+v", list[i])
			return err
		}
	}

	return nil
}

func (h pghandler) migrate(table string, r model.IManagedResource, b types.JSONText) error {
	// Unmarshal to fill unchanged fields; if an error happens, the table was not ready to be migrated
	if err := b.Unmarshal(&r); err != nil {
		return err
	}

	// Update resource on the database
	if err := h.con.Update(table, r.GetUUID(), r); err != nil {
		return err
	}

	return nil
}
