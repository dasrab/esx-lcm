//(C) Copyright 2017 Hewlett Packard Enterprise Development LP
package connector

import (
	"encoding/json"
	"reflect"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/version"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

func TestVersion(t *testing.T) {
	a := assert.New(t)
	common.StartLogs()

	con := GetConnector()

	// Cleanup
	defer con.Drop(Metatable)
	con.Drop(Metatable)

	// Start handler (and metadata table) without setting an API Version
	h, err := NewVersionHandler(con, version.API())
	a.NoError(err)

	v, err := h.Version()
	a.NoError(err)
	a.Zero(v)

	con.Drop(Metatable)

	// Set API version
	err = version.LoadAPI([]byte(testVersion1))
	a.NoError(err)

	// Now start handler again (will update metadata table with testVersion1)
	h, err = NewVersionHandler(con, version.API())
	a.NoError(err)

	v, err = h.Version()
	a.NoError(err)
	a.Equal(testVersion1, v)
}

func TestDatabaseTableUpdate(t *testing.T) {
	a := assert.New(t)

	// Set API version
	err := version.LoadAPI([]byte(testVersion1))
	a.NoError(err)

	common.StartLogs()
	con := GetConnector()

	// Cleanup
	defer con.Drop(Metatable)
	con.Drop(Metatable)

	defer con.Drop("people")
	con.Create("people")

	con = GetConnector()

	person := Person{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason Bourne",
		Pet:             Pet{Name: "Rex"},
	}

	// Insert old object on database
	con.Insert("people", &person, "")

	var query Person2
	err = con.Get(&query, "people", "1")

	// Will throw an error, because data was outdated!
	a.Error(err)

	// Set new API version (simulate a container update)
	err = version.LoadAPI([]byte(testVersion2))
	a.NoError(err)

	// Migrate Table to new version
	h, err := NewVersionHandler(con, version.API())
	a.NoError(err)

	err = h.MigrateTable("people", reflect.TypeOf(Person2{}))

	// Will throw an error, because data was outdated!
	a.Error(err)

	// Load data as a map of <string>:<json data> to be able to read old fields
	var data map[string]*json.RawMessage
	err = con.Get(&data, "people", "1")
	a.NoError(err)

	// Manually migrate name from string to a new Name struct
	var fullname string
	err = json.Unmarshal(*data["name"], &fullname)
	a.NoError(err)

	sp := strings.Split(fullname, " ")

	// Manually migrate pet from struct to slice
	var pets map[string]*json.RawMessage
	err = json.Unmarshal(*data["pet"], &pets)
	a.NoError(err)

	newPerson := map[string]interface{}{
		"uuid":     data["uuid"],
		"uri":      data["uri"],
		"type":     data["type"],
		"created":  data["created"],
		"modified": data["modified"],
		"name": map[string]interface{}{
			"first": sp[0],
			"last":  sp[1],
		},
		"pet": []interface{}{
			pets,
		},
	}

	// Marshal into JSON object
	newPersonJSON, err := json.Marshal(newPerson)
	a.NoError(err)

	// Update object on database
	err = con.UpdateJSON("people", person.GetUUID(), newPersonJSON)

	// Update table again
	err = h.MigrateTable("people", reflect.TypeOf(Person2{}))

	// Will NOT throw an error, because data was previously migrated!
	a.NoError(err)

	// Get object from DB gain
	err = con.Get(&query, "people", "1")

	// Will NOT throw an error, because data was previously migrated!
	a.NoError(err)

	a.Equal("Jason", query.Name.First)
	a.Equal("Bourne", query.Name.Last)
	a.Equal("Rex", query.Pet[0].Name)
	a.Equal("/1", query.Uri)
	a.Equal("1", query.Uuid)
}

const (
	testVersion1 version.Version = "10001"
	testVersion2 version.Version = "10002"
)

type Person struct {
	model.ManagedResource
	Name string `json:"name"`
	Pet  Pet    `json:"pet"`
}

type Pet struct {
	Name string `json:"name"`
}

// Person2 is an updated "Person" object. The Name field is now a struct with "First" and "Last" name fields and the Pet
// field is a slice of Pets.
type Person2 struct {
	model.ManagedResource
	Name Name  `json:"name"`
	Pet  []Pet `json:"pet"`
}

type Name struct {
	First string `json:"first"`
	Last  string `json:"last"`
}
