//(C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
package connector

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

func TestInsertSimpleResource(t *testing.T) {
	a := assert.New(t)
	common.StartLogs()

	con := GetConnector()

	con.Create("people")
	defer con.Drop("people")

	type Person struct {
		model.ManagedResource
		Name string `json:"name"`
	}

	person := Person{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason",
	}

	con.Insert("people", &person, "")

	boolean, err := con.Find("people", "1")
	a.True(boolean)
	a.NoError(err)

	boolean, err = con.Find("people", "2")
	a.False(boolean)
	a.NoError(err)

	var query Person

	err = con.Get(&query, "people", "1")
	a.NoError(err)

	a.Equal(person.Name, query.Name)
}

func TestInsertResourceWithUUIDConflict(t *testing.T) {
	a := assert.New(t)
	common.StartLogs()

	con := GetConnector()

	con.Create("people")
	defer con.Drop("people")

	type Person struct {
		model.ManagedResource
		Name string `json:"name"`
	}

	person1 := Person{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason",
	}

	person2 := Person{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason",
	}

	err := con.Insert("people", &person1, "")
	a.NoError(err)

	err = con.Insert("people", &person2, "")
	a.Error(err)
}

func TestInsertComplexResource(t *testing.T) {
	a := assert.New(t)
	common.StartLogs()

	con := GetConnector()

	con.Create("people")
	defer con.Drop("people")

	type Address struct {
		model.ManagedResource
		Street string `json:"street"`
		Number int    `json:"int"`
	}

	type Person struct {
		model.ManagedResource
		Name    string  `json:"name"`
		Age     int     `json:"age"`
		Address Address `json:"address"`
	}

	person := Person{
		ManagedResource: model.ManagedResource{Uuid: "1"},
		Name:            "Jason",
		Age:             15,
		Address: Address{
			ManagedResource: model.ManagedResource{Uuid: "1"},
			Street:          "Elm Street",
			Number:          666,
		},
	}

	conn.Insert("people", &person, "")

	boolean, err := con.Find("people", "1")
	a.True(boolean)
	a.NoError(err)

	boolean, err = con.Find("people", "2")
	a.False(boolean)
	a.NoError(err)

	var query Person

	err = conn.Get(&query, "people", "1")
	a.NoError(err)

	a.Equal(person.GetUUID(), query.GetUUID())
	a.Equal(person.Name, query.Name)
	a.Equal(person.Age, query.Age)
	a.Equal(person.Address.GetUUID(), query.Address.GetUUID())
	a.Equal(person.Address.Street, query.Address.Street)
	a.Equal(person.Address.Number, query.Address.Number)
}

func TestGetTables(t *testing.T) {
	a := assert.New(t)
	common.StartLogs()

	con := GetConnector()

	defer con.Drop("table1")
	defer con.Drop("table2")
	defer con.Drop("table3")

	con.Create("table1")
	con.Create("table2")
	con.Create("table3")

	tables, err := con.Tables()
	a.NoError(err)

	a.Contains(tables, "table1")
	a.Contains(tables, "table2")
	a.Contains(tables, "table3")
}
