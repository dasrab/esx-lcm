//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package connector

import (
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
	"github.com/jmoiron/sqlx/types"
	log "github.hpe.com/kronos/kelog"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/common/properties"
	"github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

var (
	dbTimeout       time.Duration = properties.ISM.Database.Timeout * time.Millisecond
	dbPeriod        time.Duration = 10 * time.Millisecond
	conn            Connector
	once            sync.Once
	countQueryLimit = 100 // can change according vm memory size
)

const (
	startParam      = "start" // API vars
	countParam      = "count" // API vars
	connMaxLifeTime = 14400 * time.Second
)

type Connector interface {

	// Config returns the configuration parameters for the Connector, which are used to connect with the database.
	// These values cannot be injected, instead they should be read from the ism.properties configuration file
	// during startup.
	Config() config

	// Create adds a new table to the database if no table with that name exists; no error is thrown if the table
	// already exists.
	Create(table string) error

	// Delete removes the resource with the given id from the table.
	Delete(table string, id string) error

	// Drop removes a table.
	Drop(table string) error

	// Find returns whether a resource with the given id already exists on the table.
	Find(table string, id string) (bool, error)

	// Get searches for an object with the given id from the table and saves it into the 'dest' interface.
	Get(dest interface{}, table string, id string) error

	// Insert adds a new object to a table.
	Insert(table string, resource model.IManagedResource, uri common.IsmURI) error

	// Select searches for all objects on the table matching the filter, and saves a slice into the 'dest'
	// interface.
	Select(dest interface{}, table string, filters map[string]interface{}) error

	// SelectCount counts the number of obejcts on the table matching the filter.
	SelectCount(table string, filters map[string]interface{}) (int, error)

	// Tables returns a list with all the tables within the database.
	Tables() ([]string, error)

	// Truncate removes all the data within a table.
	Truncate(table string) error

	// Update replaces the resource within the table matching the given id with the new resource
	Update(table string, id string, resource model.IManagedResource) error

	// UpdateJSON replaces the entry within the table matching the given id with a new entry as a JSON. Useful
	// when migrating objects withing the DB wihout required to use the resource models.
	UpdateJSON(table string, id string, resource json.RawMessage) error
}

// pgconnector is a MySQL connector which saves data as JSONB documents.
type pgconnector struct {
	config
	db *sqlx.DB
}

// config is read from the ism.properties configuration file during startup.
type config struct {
	host string
	port string
	name string
	user string
	pass string
	tout time.Duration
}

// GetConnector gets the singleton instance for a Connector, an interface which allows database operations.
//
// The database configuration (host, port, name, user and password) is read from the ism.properties configuration file
// during startup.
//
// TODO inject properties/version into the constructor
func GetConnector() Connector {
	once.Do(func() {
		pg := new(pgconnector)

		pg.host = properties.ISM.Database.Host
		pg.port = properties.ISM.Database.Port

		log.Debugf("Getting mysql credential...")
		pg.user = properties.ISM.Database.User
		pg.pass = properties.ISM.Database.Pass
		pg.name = properties.ISM.Database.Name

		log.Debugf("Connecting to mysql database '%s' as user '%s'", pg.name, pg.user)

		pg.initializeConnection(time.Second*120, 2*time.Second)

		log.Debugf("Connected to database '%s' as user '%s'", pg.name, pg.user)

		conn = pg
	})
	return conn
}

func (con pgconnector) Config() config {
	return con.config
}

func (con pgconnector) Create(table string) error {
	log.Debugf("Creating table %s (if it does not exist)", table)

	stmt, err := con.db.Preparex(fmt.Sprintf("CREATE TABLE IF NOT EXISTS %s (data JSON)", table))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, nil)

	if err != nil {
		log.Errorf("Error creating table %s (%v)", table, err)
	}

	stmt.Close()

	return err
}

func (con pgconnector) Drop(table string) error {
	log.Debugf("Dropping table %s", table)

	stmt, err := con.db.Preparex(fmt.Sprintf("DROP TABLE IF EXISTS %s", table))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, nil)

	if err != nil {
		log.Errorf("Error dropping table %s (%v)", table, err)
	}

	stmt.Close()

	return err
}

func (con pgconnector) Delete(table string, id string) error {
	log.Debugf("Deleting resource %s at table %s", id, table)

	/* #nosec */
	stmt, err := con.db.Preparex(fmt.Sprintf("DELETE FROM %s WHERE json_extract(data, '$.uuid') = '%s'", table, id))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, nil)

	if err != nil {
		log.Errorf("Error deleting resource %s at table %s (%v)", id, table, err)
	}

	stmt.Close()

	return err
}

func (con pgconnector) Find(table string, id string) (bool, error) {
	log.Debugf("Searching for managed resource %s at table %s", id, table)

	/* #nosec */
	exists, err := con.find(fmt.Sprintf("SELECT EXISTS (SELECT 1 FROM %s WHERE json_extract(data, '$.uuid') = '%s')", table, id))

	if err != nil {
		log.Errorf("Error searching for resource %s at table %s (%v)", id, table, err)
	}

	return exists, err
}

func (con pgconnector) Get(dest interface{}, table string, id string) error {
	log.Debugf("Getting resource %s at table %s", id, table)

	/* #nosec */
	r, err := con.get(fmt.Sprintf("SELECT data FROM %s WHERE json_extract(data, '$.uuid') = '%s'", table, id))

	if err != nil {
		log.Errorf("Error getting resource %s at table %s (%v)", id, table, err)
		return err
	}

	err = r.Unmarshal(&dest)

	if err != nil {
		log.Errorf("Error unmarshalling resource %+v (%v)", r, err)
	}

	return err
}

func (con pgconnector) Insert(table string, resource model.IManagedResource, uri common.IsmURI) error {
	err := con.updateUUID(table, resource)

	log.Debugf("Creating managed resource %s at table %s", resource.GetUUID(), table)

	if err != nil {
		log.Errorf("Could not validate managed resource %s UUID (%v)", resource.GetUUID(), err)
		return err
	}

	resource.SetCreatedTime(time.Now().UTC())
	resource.SetModifiedTime(time.Now().UTC())
	resource.SetURI(common.BuildUri(uri, resource.GetUUID()))

	val, err := json.Marshal(resource)

	if err != nil {
		log.Errorf("Error marshalling resource %+v (%v)", resource, err)
		return err
	}

	/* #nosec */
	stmt, err := con.db.Preparex(fmt.Sprintf("INSERT INTO %s (data) VALUES (?)", table))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, val)

	if err != nil {
		log.Errorf("Error inserting resource %+v at table %s (%v)", resource, table, err)
	}

	stmt.Close()

	return err
}

func (con pgconnector) Select(dest interface{}, table string, filters map[string]interface{}) error {
	log.Debugf("Getting resources at table %s with filter %v", table, filters)
	resList, err := con.sel(con.makeSelectQuery(table, filters))

	if err != nil {
		log.Errorf("Error selecting resources from table %s with filters %v (%v)", table, filters, err)
		return err
	}

	list := con.concatenateJSONList(resList)
	err = list.Unmarshal(&dest)

	if err != nil {
		log.Errorf("Error unmarshalling resource %+v (%v)", resList, err)
		return err
	}

	return err
}

func (con pgconnector) SelectCount(table string, filters map[string]interface{}) (int, error) {
	rC, err := con.count(con.makeCountQuery(table, filters))
	if err != nil {
		log.Errorf("Error counting resources from table %s, error -> (%v)", table, err)
		return rC, err
	}

	return rC, err
}

func (con pgconnector) Tables() ([]string, error) {
	log.Debugf("Listing tables on %s.", con.name)

	r, err := con.sel("SHOW TABLES")

	if err != nil {
		log.Errorf("Error listing tables on %s (%v)", con.name, err)
		return nil, err
	}

	log.Debugf("Found tables %v", r)

	var tables []string
	for _, v := range r {
		tables = append(tables, string(v))
	}

	return tables, nil
}

func (con pgconnector) Truncate(table string) error {
	log.Debugf("Truncating table %s", table)

	/* #nosec */
	exists, err := con.find(fmt.Sprintf("SELECT EXISTS (SELECT 1 FROM %s)", table))

	if err != nil {
		log.Errorf("Error searching for table %s (%v)", table, err)
	}

	if !exists {
		log.Debugf("Table %s does not exist and can't be truncated, creating empty table", table)
		return con.Create(table)
	}

	stmt, err := con.db.Preparex(fmt.Sprintf("TRUNCATE TABLE %s", table))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, nil)

	if err != nil {
		log.Errorf("Error truncating table %s (%v)", table, err)
	}

	stmt.Close()

	return err
}

// FIXME it should not be possible to force-update the UUID of a resource, but it is
func (con pgconnector) Update(table string, id string, resource model.IManagedResource) error {
	log.Debugf("Updating resource %s at table %s", id, table)

	resource.SetModifiedTime(time.Now().UTC())

	val, err := json.Marshal(resource)

	if err != nil {
		log.Errorf("Error marshalling resource %+v (%v)", resource, err)
		return err
	}

	if id == "" {
		err := errors.New("id field is empty!")
		log.Errorf("Error marshalling resource %+v (%v)", resource, err)
		return err
	}

	/* #nosec */
	stmt, err := con.db.Preparex(fmt.Sprintf("UPDATE %s SET data = ? WHERE json_extract(data, '$.uuid') = '%s'", table, id))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, val)

	if err != nil {
		log.Errorf("Error updating resource %s at table %s (%v)", id, table, err)
	}

	stmt.Close()

	return err
}

func (con pgconnector) open() error {
	return con.connect(dbTimeout, dbPeriod)
}

func (con *pgconnector) connect(timeout time.Duration, period time.Duration) error {
	err := con.db.Ping()

	if err != nil {
		log.Errorf("Could not connect to database (%v), reinitiliazing connection.", err)
		con.initializeConnection(timeout, period)
	}

	return err
}

func (con *pgconnector) initializeConnection(timeout time.Duration, period time.Duration) {
	// Don't log password
	log.Debugf("Database configuration: host=%v, port=%v, name=%v, pass=*******, tout=%v",
		con.config.host, con.config.port, con.config.name, con.config.tout)

	// host, _ := common.ResolveServiceHostname(con.host)

	log.Debugf("Using hostname %s for mysql service", con.host)

	/*
		todo: Enable ssl for mysql
		sslMode := "require"
		if properties.ISM.Database.SSL == false {
			sslMode = "disable"
		}*/

	dbConnection := fmt.Sprintf(
		"%s:%s@tcp(%s:%s)/%s?parseTime=true",
		con.user,
		con.pass,
		con.host,
		con.port,
		con.name,
	)
	con.db, _ = sqlx.Connect("mysql", dbConnection)

	/*
		When using a database server that closes inactive connections after some
		duration, `SQLConnMaxLifetime` should be set to a value less than that duration.
		Otherwise, the connection will be reused forever, and this could result in a
		dropped connection.

		For example, if MySQL is configured with `wait_timeout = 28800`, so setting
		SQLConnMaxLifetime to 14400s.
	*/
	con.db.SetConnMaxLifetime(connMaxLifeTime)

	// test connection (panic on failure/timeout)
	con.ping(timeout, period)
}

func (con *pgconnector) ping(timeout time.Duration, period time.Duration) {
	var count time.Duration
	err := con.db.Ping()

	for err != nil && count < timeout {
		log.Debugf("Waiting for database to be ready (%v)", err)
		time.Sleep(period)
		err = con.db.Ping()
		count += period
	}

	if err != nil && count >= timeout {
		log.Errorf("Could not connect to database %s (%v)", con.name, err)
		panic(err)
	}
}

func (con pgconnector) find(query string) (r bool, err error) {
	if err = con.open(); err != nil {
		return r, err
	}

	return r, con.db.Get(&r, query)
}

func (con pgconnector) get(query string) (r types.JSONText, err error) {
	if err = con.open(); err != nil {
		return r, err
	}

	return r, con.db.Get(&r, query)
}

func (con pgconnector) count(query string) (res int, err error) {
	if err = con.open(); err != nil {
		return res, err
	}

	return res, con.db.Get(&res, query)
}

func (con pgconnector) sel(query string) (r []types.JSONText, err error) {
	if err = con.open(); err != nil {
		return r, err
	}

	return r, con.db.Select(&r, query)
}

func (con pgconnector) transaction(query string, args []byte) error {
	if err := con.open(); err != nil {
		return err
	}

	tx, err := con.db.Beginx()

	if err != nil {
		return err
	}

	if args == nil {
		tx.Exec(query)
	} else {
		tx.Exec(query, args)
	}

	return tx.Commit()
}

func (con pgconnector) transaction1(stmt *sqlx.Stmt, args []byte) error {
	if err := con.open(); err != nil {
		return err
	}

	tx, err := con.db.Beginx()

	if err != nil {
		return err
	}

	if args == nil {
		tx.Stmtx(stmt).Exec()
	} else {
		tx.Stmtx(stmt).Exec(args)
	}

	return tx.Commit()
}

// makeSelectQuery creates the query for a Select statement.
func (con pgconnector) makeSelectQuery(table string, filters map[string]interface{}) string {
	//var appendQuery string
	appendStmt := false
	/* #nosec */
	query := fmt.Sprint("SELECT * FROM ", table)
	var limitString, offsetString string
	if filters != nil {
		// TODO evolve query to accept multiple filters
		for key, val := range filters {
			log.Debugf("filter key is %s", key)
			switch {
			case key == countParam:
				// Mysql Command equivalence: LIMIT (limitates amount of sent rows
				limit, _ := strconv.Atoi(val.(string))
				if limit <= countQueryLimit {
					// Query return size cannot exceed countQueryLimit; ignore LIMIT if above
					limitString += fmt.Sprintf(" LIMIT %s", val)
					appendStmt = true
				}
			case key == startParam:
				// Mysql Command equivalence: OFFSET (indicates intial rows displacement)
				offsetString += fmt.Sprintf(" OFFSET %s", val)

			default:
				// an actual query
				/* #nosec */
				query += fmt.Sprintf(" WHERE json_extract(data, '$.%s') = '%s'", key, val)
			}
		}
		// All queries must have a limited number of rows returning. Default is countQueryLimit
		if !appendStmt {
			limitString += fmt.Sprintf(" LIMIT %d", countQueryLimit)
		}

		query += limitString + offsetString
	}
	return query
}

// makeCountQuery creates the query for a Select count statement.
func (con pgconnector) makeCountQuery(table string, filters map[string]interface{}) string {
	/* #nosec */
	query := fmt.Sprint("SELECT count(*) as total FROM ", table)
	if filters != nil {
		for key, val := range filters {
			log.Debugf("filter key is %s", key)
			if key != countParam && key != startParam {
				/* #nosec */
				query += fmt.Sprintf(" WHERE json_extract(data, '$.%s') = '%s'", key, val)
			}
		}
	}
	return query
}

func (con pgconnector) concatenateJSONList(j []types.JSONText) types.JSONText {
	var str string

	if len(j) > 0 {
		str = fmt.Sprintf(j[0].String())

		for i := 1; i < len(j); i++ {
			str = str + "," + j[i].String()
		}
	}

	return types.JSONText("[" + str + "]")
}

func (con pgconnector) updateUUID(table string, resource model.IManagedResource) error {
	uuid := resource.GetUUID()
	exists, err := con.Find(table, uuid)

	if err != nil {
		return errors.New(fmt.Sprintf("Error checking database for UUID %s - %v", uuid, err))
	}

	if exists {
		return errors.New(fmt.Sprintf("UUID %s already exists in the database! Can't insert object %+v", uuid, resource))
	}

	if uuid == "" {

		targetUUID, err := con.createUUID(table)

		if err != nil {
			return errors.New(fmt.Sprintf("Error creating UUID - %v", err))
		}

		resource.SetUUID(targetUUID)
	}

	return nil
}

func (con pgconnector) generateUUIDV4() (string, error) {
	var uuid string

	if err := con.open(); err != nil {
		return uuid, err
	}

	return uuid, con.db.Get(&uuid, "select UUID()")
}

// generateUUIDV4 generates a V4 UUID using mysql uuid-ossp package
func (con pgconnector) createUUID(table string) (string, error) {
	exists := true
	count := 0

	for exists == true && count < 5 {
		count++
		targetUUID, err := con.generateUUIDV4()

		if err != nil {
			log.Debugf("Error generating UUID - Trying again (%v)", err)
			continue
		}

		exists, err = con.Find(table, targetUUID)

		if exists == false {
			return targetUUID, nil
		}
	}

	return "", errors.New("Could not create an UUID")
}

func (con pgconnector) UpdateJSON(table string, id string, resource json.RawMessage) error {
	log.Debugf("Updating resource %s at table %s", id, table)

	if id == "" {
		err := errors.New("id field is empty!")
		log.Errorf("Error marshalling resource %+v (%v)", resource, err)
		return err
	}

	/* #nosec */
	stmt, err := con.db.Preparex(fmt.Sprintf("UPDATE %s SET data = ? WHERE json_extract(data, '$.uuid') = '%s'", table, id))

	if err != nil {
		log.Errorf("Error preparing statement for table %s (%v)", table, err)
		return err
	}

	err = con.transaction1(stmt, resource)

	if err != nil {
		log.Errorf("Error updating resource %s at table %s (%v)", id, table, err)
	}

	stmt.Close()

	return err
}
