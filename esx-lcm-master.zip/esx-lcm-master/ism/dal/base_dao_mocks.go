//(C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
package dal

import (
	reflect "reflect"

	gomock "github.com/golang/mock/gomock"
	model "github.hpe.com/ncs-vmware/esx-lcm/ism/model"
)

// MockManagedResourceDAO is a mock of ManagedResourceDAO interface
type MockManagedResourceDAO struct {
	ctrl     *gomock.Controller
	recorder *MockManagedResourceDAOMockRecorder
}

// MockManagedResourceDAOMockRecorder is the mock recorder for MockManagedResourceDAO
type MockManagedResourceDAOMockRecorder struct {
	mock *MockManagedResourceDAO
}

// NewMockManagedResourceDAO creates a new mock instance
func NewMockManagedResourceDAO(ctrl *gomock.Controller) *MockManagedResourceDAO {
	mock := &MockManagedResourceDAO{ctrl: ctrl}
	mock.recorder = &MockManagedResourceDAOMockRecorder{mock}
	return mock
}

// EXPECT returns an object that allows the caller to indicate expected use
func (m *MockManagedResourceDAO) EXPECT() *MockManagedResourceDAOMockRecorder {
	return m.recorder
}

// BaseGet mocks base method
func (m *MockManagedResourceDAO) BaseGet(uuid, result interface{}) error {
	ret := m.ctrl.Call(m, "BaseGet", uuid, result)
	ret0, _ := ret[0].(error)
	return ret0
}

// BaseGet indicates an expected call of BaseGet
func (mr *MockManagedResourceDAOMockRecorder) BaseGet(uuid, result interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseGet", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseGet), uuid, result)
}

// BaseGetAll mocks base method
func (m *MockManagedResourceDAO) BaseGetAll(result interface{}, filters map[string][]string) error {
	ret := m.ctrl.Call(m, "BaseGetAll", result, filters)
	ret0, _ := ret[0].(error)
	return ret0
}

// BaseGetAll indicates an expected call of BaseGetAll
func (mr *MockManagedResourceDAOMockRecorder) BaseGetAll(result, filters interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseGetAll", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseGetAll), result, filters)
}

// BaseGetTotal mocks base method
func (m *MockManagedResourceDAO) BaseGetTotal(result interface{}, filters map[string][]string) (int, error) {
	ret := m.ctrl.Call(m, "BaseGetTotal", result, filters)
	ret0, _ := ret[0].(int)
	ret1, _ := ret[1].(error)
	return ret0, ret1
}

// BaseGetTotal indicates an expected call of BaseGetTotal
func (mr *MockManagedResourceDAOMockRecorder) BaseGetTotal(result, filters interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseGetTotal", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseGetTotal), result, filters)
}

// BaseGetStart mocks base method
func (m *MockManagedResourceDAO) BaseGetStart(filters map[string][]string) int {
	ret := m.ctrl.Call(m, "BaseGetStart", filters)
	ret0, _ := ret[0].(int)
	return ret0
}

// BaseGetStart indicates an expected call of BaseGetStart
func (mr *MockManagedResourceDAOMockRecorder) BaseGetStart(filters interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseGetStart", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseGetStart), filters)
}

// BaseCreate mocks base method
func (m *MockManagedResourceDAO) BaseCreate(resource model.IManagedResource) error {
	ret := m.ctrl.Call(m, "BaseCreate", resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// BaseCreate indicates an expected call of BaseCreate
func (mr *MockManagedResourceDAOMockRecorder) BaseCreate(resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseCreate", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseCreate), resource)
}

// BaseUpdate mocks base method
func (m *MockManagedResourceDAO) BaseUpdate(uuid interface{}, resource model.IManagedResource) error {
	ret := m.ctrl.Call(m, "BaseUpdate", uuid, resource)
	ret0, _ := ret[0].(error)
	return ret0
}

// BaseUpdate indicates an expected call of BaseUpdate
func (mr *MockManagedResourceDAOMockRecorder) BaseUpdate(uuid, resource interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseUpdate", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseUpdate), uuid, resource)
}

// BaseDelete mocks base method
func (m *MockManagedResourceDAO) BaseDelete(uuid interface{}) error {
	ret := m.ctrl.Call(m, "BaseDelete", uuid)
	ret0, _ := ret[0].(error)
	return ret0
}

// BaseDelete indicates an expected call of BaseDelete
func (mr *MockManagedResourceDAOMockRecorder) BaseDelete(uuid interface{}) *gomock.Call {
	return mr.mock.ctrl.RecordCallWithMethodType(mr.mock, "BaseDelete", reflect.TypeOf((*MockManagedResourceDAO)(nil).BaseDelete), uuid)
}
