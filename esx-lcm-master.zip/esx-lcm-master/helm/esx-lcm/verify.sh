#!/bin/sh -xe

# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

SCRIPT_HOME=$(cd $(dirname $0); pwd)

helm lint ${SCRIPT_HOME}
helm install --dry-run --debug --namespace esx-lcm ${SCRIPT_HOME}
