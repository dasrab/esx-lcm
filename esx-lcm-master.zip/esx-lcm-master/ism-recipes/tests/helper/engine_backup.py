#!/usr/bin/env python
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import argparse
from collections import OrderedDict
from functools import partial
import json
import logging
import re
import sys
import traceback
import os
from multiprocessing import TimeoutError
from multiprocessing.pool import ThreadPool
from orch.ism_sdk.activity import Ism_Error
from orch import log
import variable_parser
import yaml

# CONSTANTS FOR ENGINE
WITH_MODE = 'with_mode'
WITH_ITEMS_MODE = 'with_items'
WITH_TOGETHER_MODE = 'with_together'
ASYNC_MODE = 'async'
MAX_THREADS = 'max_threads'


class Engine:
    LOG = ''
    playbook_status = ''
    playbook_details = []

    working_dir = ''
    yaml_file_name = ''
    playbook = {}
    variable_map = {}
    global_vars = {}

    current_tags = set()

    def __init__(self, yaml_file_path, extra_vars, tags):
        self.playbook_status = 'SUCCESS'
        self.playbook_details = []

        file_name_index = yaml_file_path.rfind('/') + 1
        self.working_dir = yaml_file_path[:file_name_index]
        self.yaml_file_name = yaml_file_path[file_name_index:]

        log.setLevel(extra_vars.get('logLevel'))
        log.setPlaybook(self.yaml_file_name)

        self.LOG = log.getLogger(__name__)

        try:
            yaml_file = open(self.working_dir + self.yaml_file_name)
        except IOError as exception:
            self.exit_playbook_fail(exception)

        self.playbook = self.ordered_load(yaml_file)

        # add tag list to current tag set
        self.current_tags.update(tags)
        self.variable_map.update(extra_vars)

    def exit_playbook(self):
        self.LOG.info('Playbook \'' + self.yaml_file_name +
                      '\' final status: ' + self.playbook_status)
        self.LOG.debug('Playbook final details: ' + str(self.playbook_details))

        playbook_return = json.dumps({
            'playbookStatus': self.playbook_status,
            'playbookDetails': self.playbook_details
        })
        sys.exit(playbook_return)

    def exit_playbook_fail(self, exception):
        self.playbook_status = 'FAIL'
        self.playbook_details.append(exception)

        self.LOG.exception(exception)
        if isinstance(exception, Exception):
            self.LOG.debug(traceback.format_exc())
        self.exit_playbook()

    def ordered_load(
            self,
            stream,
            yaml_loader=yaml.SafeLoader,
            object_pairs_hook=OrderedDict):
        class OrderedLoader(yaml_loader):
            pass

        def construct_mapping(loader, node):
            loader.flatten_mapping(node)
            return object_pairs_hook(loader.construct_pairs(node))

        OrderedLoader.add_constructor(
            yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, construct_mapping)

        try:
            return yaml.load(stream, OrderedLoader)
        except TypeError:
            self.exit_playbook_fail(
                "Couldn't load YAML file " +
                stream.name +
                " because it is not correctly formatted. Please check if all brackets are inside" +
                " a string")

    def update_variable_map(self, map_to_update):
        try:
            parsed_map = variable_parser.parse_vars(
                map_to_update, self.variable_map)
        except TypeError as exception:
            self.exit_playbook_fail(exception)

        self.variable_map.update(parsed_map)

    def get_execute_method(self, module_name):
        try:
            module = __import__('lib.' + module_name,
                                fromlist=['base_execute'])

            module_class = getattr(module, module_name.title())
            module_obj = module_class()
            module_method = getattr(module_obj, 'base_execute')

            mocked_response = {}

            # only try getting mocked_response if running in check mode
            if self.check:
                try:
                    # load global json variable RESPONSE as mocked response
                    mocked_response = json.loads(module.RESPONSE)
                except AttributeError:
                    self.LOG.debug(
                        module_name +
                        ' has no attribute RESPONSE for mocked response')
                except ValueError as e:
                    self.LOG.debug(
                        "Error loading attribute RESPONSE. Please double-check if it's a valid JSON.")
                    self.exit_playbook_fail(
                        "Error loading attribute RESPONSE from module " +
                        module_name +
                        ". Please double-check if it's a valid JSON.")

        except Exception as e:
            self.LOG.error('The module ' + module_name +
                           ' is not yet supported by Orca')
            self.exit_playbook_fail(e)

        return module_method, mocked_response

    def get_parsed_params(self, params, variable_map):
        if params is not None:
            try:
                params_to_parse = OrderedDict(
                    list(
                        params.copy().items()) +
                    list(
                        self.global_vars.copy().items()))
                params = variable_parser.parse_vars(
                    params_to_parse, variable_map)
            except KeyError as e:
                self.exit_playbook_fail(e)
        else:
            params = None

        return params

    def execute_python_module(
            self,
            module_name,
            method_params,
            variable_map,
            ignore_errors=False):
        method_to_execute, mocked_response = self.get_execute_method(
            module_name)

        # if engine is running with check flag, then skip running python module
        if self.check:
            return mocked_response

        method_params = self.get_parsed_params(method_params, variable_map)

        try:
            temp_response = method_to_execute(method_params)
        except Exception as e:
            self.exit_playbook_fail(e)

        headers = temp_response['headers']
        body = temp_response['body']

        self.LOG.debug('Task \'' + module_name +
                       '\' return status: ' + headers['module_status'])

        if headers['module_status'] == 'FAIL':
            self.LOG.debug('Failed Payload: ' + str(body))

            if ignore_errors:
                self.playbook_status = 'WARNING'
                self.playbook_details.append(body)
            else:
                self.LOG.debug('Failing playbook.')
                self.exit_playbook_fail(body)

            self.LOG.debug('playbookStatus is ' + self.playbook_status)

        return temp_response

    def get_with_items_params(self, task, with_mode, variable_map):
        # response if a list of items, where item is a dict (with_items) or a
        # list of dicts (with_together)
        list_of_items = []

        # with_items only supports execution with a single list
        if with_mode == WITH_ITEMS_MODE:
            items = variable_parser.parse_var(
                task[with_mode], variable_map, enable_headers=True)

            if items is None:
                self.exit_playbook_fail(
                    Ism_Error(
                        error_code="HCOE_ISM_INVALID_ITERATION_PARAMETER", data=[
                            str(task), str(
                                type(items)), "different than None"]).to_dict())

            # if with_items variable is the return of a module execution, then
            # get list from body
            elif isinstance(items, dict) and 'body' in items:
                items = items['body']

            if not isinstance(items, list):
                self.exit_playbook_fail(
                    Ism_Error(
                        error_code="HCOE_ISM_INVALID_ITERATION_PARAMETER", data=[
                            str(task), str(
                                type(items)), "a list"]).to_dict())

            for item in items:
                item_dict = {'item': item}
                list_of_items.append(item_dict)

        # with_together receives a list of lists, so we must parse them
        # correctly
        elif with_mode == WITH_TOGETHER_MODE:
            # this is a list of every list in with_together playbook params
            lists_to_build = []

            for with_together_list in task[with_mode]:
                items = variable_parser.parse_var(
                    with_together_list, variable_map, enable_headers=True)

                # if with_together variable is the response of a module
                # execution, then get list from body
                if isinstance(items, dict) and 'body' in items:
                    items = items['body']

                if not isinstance(items, list):
                    self.exit_playbook_fail(
                        Ism_Error(
                            error_code="HCOE_ISM_INVALID_ITERATION_PARAMETER", data=[
                                str(task), str(
                                    type(items)), "a list"]).to_dict())

                lists_to_build.append(items)

            accepted_size = None
            for list_to_build in lists_to_build:
                if accepted_size is None:
                    accepted_size = len(list_to_build)
                elif len(list_to_build) != accepted_size:
                    self.exit_playbook_fail(
                        Ism_Error(
                            error_code="HCOE_ISM_INVALID_PARAMETER_LENGTH", data=[
                                str(task), str(
                                    len(list_to_build)), str(accepted_size)]).to_dict())

            for list_index, list_to_build in enumerate(lists_to_build):
                for item_index, item in enumerate(list_to_build):
                    if len(list_of_items) < item_index + 1:
                        list_of_items.append({'item': [item]})
                    elif len(list_of_items[item_index]['item']) < list_index + 1:
                        list_of_items[item_index]['item'].append(item)
                    else:
                        list_of_items[item_index]['item'][list_index] = item

        return list_of_items

    def load_file(self, file_name, ignore_errors=False):
        try:
            # if it starts with /, then it's an absolute path to a file under
            # root folder
            if file_name.startswith('/'):
                yaml_file = open(file_name)
            # if not, it's a relative path to the engine working dir
            else:
                yaml_file = open(self.working_dir + file_name)
            content = self.ordered_load(yaml_file)
            yaml_file.close()
        except IOError:
            if ignore_errors:
                content = {}
                self.LOG.debug(
                    "File " +
                    file_name +
                    " was not found so default var configuration will be used.")
            else:
                raise IOError("File " + file_name + " was not found.")
        return content

    def include_task_file(
            self,
            vars,
            file_name,
            variable_map,
            ignore_errors=False):
        # aggregate vars
        if vars is not None:
            parsed_map = variable_parser.parse_vars(vars, variable_map)
            variable_map.update(parsed_map)

        included_task = self.load_file(file_name, ignore_errors)
        self.execute_tasks(included_task, variable_map)

    def include_vars_from_file(self, file_name, ignore_errors=False):
        included_vars = self.load_file(file_name, ignore_errors)
        self.global_vars.update(included_vars)
        self.update_variable_map(self.global_vars)

    def execute_action(
            self,
            function,
            task,
            module_execution_mode,
            variable_map,
            *args,
            **keyword_args):
        # refresh variable_map with global variable map to ensure it is up to
        # date
        variable_map.update(self.variable_map)

        module_name = function.__name__

        # if action is a python execution, then get the module name to be more
        # specific in the logs
        if module_name == 'execute_python_module':
            module_name = args[0]

        # if with_mode is None, it means action will be executed only once
        if module_execution_mode[WITH_MODE] is None:
            self.LOG.debug('Executing action ' +
                           module_name + ' in single mode')
            # extend args tuple adding variable_map
            extended_args = args + (variable_map,)
            return function(*extended_args, **keyword_args)

        list_of_params_dict = self.get_with_items_params(
            task, module_execution_mode[WITH_MODE], variable_map)
        response_list = []
        async_params = []

        # if running in async mode, build the thread pool with max limit of
        # threads if given by user
        if module_execution_mode[ASYNC_MODE]:
            if module_execution_mode[MAX_THREADS] is not None:
                thread_pool = ThreadPool(
                    processes=module_execution_mode[MAX_THREADS])
            else:
                thread_pool = ThreadPool()

        for param_dict in list_of_params_dict:
            # parse and update map with current item values
            parsed_map = variable_parser.parse_vars(param_dict, variable_map)

            item_variable_map = OrderedDict(list(variable_map.copy().items()) +
                                            list(parsed_map.copy().items()))

            extended_args = args + (item_variable_map,)

            # lazily evaluate if when condition is true
            if 'when' in task and not variable_parser.eval_expression(
                    task['when'], item_variable_map):
                if 'name' in task:
                    skip_msg = "Task " + task['name'] + " will not be executed"
                else:
                    skip_msg = "Task will not be executed"
                self.LOG.debug(
                    skip_msg +
                    " because when condition: " +
                    task['when'] +
                    " was not true")
                continue

            self.LOG.debug("going to execute a with_items action")

            if module_execution_mode[ASYNC_MODE]:
                # adds item map to be executed asynchronously
                async_params.append(item_variable_map)
            else:
                self.LOG.debug("going to execute in sync mode")
                response = function(*extended_args, **keyword_args)
                response_list.append(response)

        if module_execution_mode[ASYNC_MODE]:
            try:
                self.LOG.debug("going to execute in async mode")
                # builds higher order function with constant parameters like args and kwargs and uses
                # timeout_wrapper_function to handle the timeout of each
                # operation
                partial_function = partial(
                    self.timeout_wrapper_function,
                    function,
                    module_name,
                    module_execution_mode[ASYNC_MODE],
                    args,
                    keyword_args)
                # calls asynchronously a list of operations based on the async params list, where chunkzise means that
                # each execution will run in a separate thread
                jobs = thread_pool.map_async(
                    partial_function, async_params, chunksize=1)
                # we don't pass a timeout here because timeout_wrapper_function
                # will handle that
                response_list = jobs.get()

            except TimeoutError:
                if not keyword_args['ignore_errors']:
                    self.exit_playbook_fail(Ism_Error("HCOE_ISM_TIMEOUT", details=str(
                        'Async execution of module \'' + module_name +
                        '\' failed because it exceeded the timeout: ' +
                        str(module_execution_mode[ASYNC_MODE]) +
                        ' seconds')).to_dict())


# close pool so no more operations are submitted
            thread_pool.close()

        return response_list

    @staticmethod
    def timeout_wrapper_function(
            function,
            module_name,
            timeout,
            args,
            keyword_args,
            var_map):
        """
        Wrapper function to handle the timeout for each parallel function that is executed.

        :param function: the function that will execute
        :param module_name: name of the module being executed
        :param timeout: timeout specified per execution
        :param args: args tuple to be passed to function
        :param keyword_args: kwargs dict to be passed to function
        :param var_map: var_map that will be used during function execution
        :return: the function response
        """
        try:
            # Here, we use a new thread pool for each execution separately, so we can handle the timeout of
            # a single operation
            pool = ThreadPool(processes=1)
            return pool.apply_async(function, args +
                                    (var_map,), keyword_args).get(timeout=timeout)
        except TimeoutError as timeout_error:
            pool.terminate()
            pool.close()

            if keyword_args['ignore_errors']:
                return 'Async execution of module \'' + module_name +\
                       '\' failed because it exceeded the timeout: ' + \
                    str(timeout) + ' seconds'

            raise timeout_error

    def write_debug_message(self, debug_message, variable_map):
        list_tokens = re.split('=', debug_message)
        mapped_value = variable_parser.parse_var(list_tokens[1], variable_map)
        self.LOG.debug('[Debug] ' +
                       list_tokens[0] +
                       ' = ' +
                       str(mapped_value) +
                       ' of type: ' +
                       str(type(mapped_value)))

    def execute_playbook(self, playbook='', inherited_tags=set()):
        if not playbook:
            playbook = self.playbook

        for play in playbook:

            if 'name' in play:
                self.LOG.info('Play Name is ' + play['name'])

            if 'tags' in play:
                # parse tags field into each tag
                tags = play['tags'].replace(' ', '')
                list_tags = re.split(',', tags)
                inherited_tags.update(list_tags)

            if 'vars' in play:
                self.global_vars = play['vars']
                self.update_variable_map(self.global_vars)

            if 'include' in play:
                self.execute_playbook(play['include'], inherited_tags)

            if 'tasks' in play:
                tasks = play['tasks']

                for task in tasks:
                    self.execute_task(task, self.variable_map, inherited_tags)

    def execute_tasks(self, tasks, variable_map, inherited_tags=set()):
        for task in tasks:
            self.execute_task(task, variable_map, inherited_tags)

    def execute_task(self, task, variable_map, inherited_tags=set()):
        ignore_errors = False
        list_tags = []

        # set module_execution_mode to default values. This variables indicate how actions like python modules
        # and include_task_file should run, for example once for each item in
        # an array (with_mode) or in async mode
        module_execution_mode = {
            WITH_MODE: None,
            ASYNC_MODE: None,
            MAX_THREADS: None
        }

        task_response = {}
        # create a new local variable for inherited tags so we don't change the
        # original one
        inherited_tags = set(inherited_tags)

        if 'tags' in task:
            # parse tags field into each tag
            tags = task['tags'].replace(' ', '')
            list_tags = re.split(',', tags)
            inherited_tags.update(list_tags)

        # validation if this task should be executed based on its tag
        if len(self.current_tags) > 0 and self.current_tags.isdisjoint(
                inherited_tags) and 'always' not in list_tags:
            if 'name' in task:
                skip_msg = "Task " + task['name'] + \
                    " will not be executed. Current Tags were "
            else:
                skip_msg = "Task will not be executed. Current Tags were "
            self.LOG.debug(skip_msg +
                           json.dumps(list(self.current_tags)) +
                           " while inherited Tags were " +
                           json.dumps(list(inherited_tags)))
            return

        if WITH_ITEMS_MODE in task:
            self.LOG.debug('Task has with_items mode')
            module_execution_mode[WITH_MODE] = WITH_ITEMS_MODE

        if WITH_TOGETHER_MODE in task:
            self.LOG.debug('Task has with_together mode')
            module_execution_mode[WITH_MODE] = WITH_TOGETHER_MODE

        if ASYNC_MODE in task:
            self.LOG.debug('Task has async mode')
            module_execution_mode[ASYNC_MODE] = task[ASYNC_MODE]
            if MAX_THREADS in task:
                module_execution_mode[MAX_THREADS] = task[MAX_THREADS]

        # if when condition is present, evaluate expression to verify if it
        # should execute
        if 'when' in task:
            # if with_items is not present, we can evaluate the expression eagerly. Otherwise, we have to verify
            # for each item
            if module_execution_mode[WITH_MODE] is None and \
                    not variable_parser.eval_expression(task['when'], variable_map):
                if 'name' in task:
                    skip_msg = "Task " + task['name'] + " will not be executed"
                else:
                    skip_msg = "Task will not be executed"
                self.LOG.debug(
                    skip_msg +
                    " because when condition: " +
                    task['when'] +
                    " was not true")
                return

        if 'ignore_errors' in task and task['ignore_errors']:
            self.LOG.debug('Task has ignore_errors: True')
            ignore_errors = True

        for key, value in task.items():

            if key == 'name':
                self.LOG.info('Task name is ' + value)

            elif key == 'ignore_errors':
                pass

            elif key == WITH_ITEMS_MODE or key == WITH_TOGETHER_MODE:
                pass

            elif key == ASYNC_MODE or key == MAX_THREADS:
                pass

            elif key == 'vars' or key == 'tags':
                pass

            elif key == 'when':
                pass

            elif key == 'include':
                self.LOG.debug("Including a new task file")

                self.execute_action(
                    self.include_task_file,
                    task,
                    module_execution_mode,
                    variable_map,
                    task.get("vars"),
                    value,
                    ignore_errors=ignore_errors)

            elif key == 'set_fact':
                self.update_variable_map(value)

            elif key == 'include_vars':
                self.include_vars_from_file(value, ignore_errors)

            # This is a primitive version of 'debug', it needs to be improved.
            elif key == 'debug':
                self.LOG.debug("Writing a debug message")
                self.execute_action(
                    self.write_debug_message,
                    task,
                    module_execution_mode,
                    variable_map,
                    value)
            elif key == 'register':
                self.variable_map[task['register']] = task_response
            else:
                self.LOG.info("Going to execute python module: " + key)

                task_response = self.execute_action(
                    self.execute_python_module,
                    task,
                    module_execution_mode,
                    variable_map,
                    key,
                    value,
                    ignore_errors=ignore_errors
                )

    def execute_post_tasks(self, playbook='', inherited_tags=set()):
        if not playbook:
            playbook = self.playbook
        for play in playbook:
            if 'post_tasks' in play:
                post_tasks = play['post_tasks']
                for task in post_tasks:
                    self.LOG.debug("Executing playbook post tasks")
                    self.execute_task(task, self.variable_map, inherited_tags)


def main():

    log.setup(conf_file="logging.conf")

    parser = argparse.ArgumentParser(
        description='Engine for task orchestration.')
    parser.add_argument('filePath', metavar='f', help='filePath')
    parser.add_argument('-t', '--tags', dest='tags', default='', help='tags')
    parser.add_argument(
        '-e',
        '--extra-vars',
        dest='extra_vars',
        type=json.loads,
        default={},
        help='put a variable in this format: -e \'{"ip":"1111", "username":"dcs", "password":"123"}\'')
    parser.add_argument('-c', '--check', dest='check',
                        action='store_true', help='Checking mode flag')

    args = parser.parse_args()

    tags = []

    if args.tags != '':
        args.tags = args.tags.replace(" ", "")
        tags = [item for item in args.tags.split(',')]

    engine = Engine(args.filePath, args.extra_vars, tags)
    engine.check = args.check

    try:
        engine.execute_playbook()
    except Exception as exception:
        engine.exit_playbook_fail(exception)
    finally:
        engine.execute_post_tasks()
    engine.exit_playbook()


if __name__ == '__main__':
    main()
