# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
import argparse
import json
import time
import os


def main():
    # parse arguments

    parser = argparse.ArgumentParser(
        description='Engine for task orchestration.')
    parser.add_argument('fileName', metavar='f', help='filename')
    parser.add_argument('--tags', dest='tags', default='', help='tags')
    parser.add_argument(
        '-e',
        '--extra-vars',
        dest='extra_vars',
        type=json.loads,
        default={},
        help='put a variable in this format: -e \'{"ip":"1111", "username":"dcs", "password":"123"}\'')

    # This parameter is used for ISM tests only
    parser.add_argument('--returnValue', dest='returnValue',
                        default='', help='returnValue')

    args = parser.parse_args()
    return_value = args.returnValue
    playbook = args.fileName

    print ("Mocked engine executing")
    time.sleep(0.05)  # 50ms delay to concurrency tests.

    playbook_status = 'SUCCESS'

    if return_value is not None and return_value != "":
        ret_json = return_value
    else:
        if os.path.exists('../../orch/engineResults.json'):
            with open('../../orch/engineResults.json') as json_file:
                d = json.load(json_file)
                playbook_status = d[playbook] if playbook in d else 'SUCCESS'

        errs = []
        if str(playbook_status) != "SUCCESS":
            errs = [{"errorCode": "HCOE_ISM_ENGINE_DEBUG"}]

        ret_json = json.dumps({
            'playbookStatus': str(playbook_status),
            'playbookDetails': errs
        })

    exit(ret_json)


if __name__ == '__main__':
    main()
