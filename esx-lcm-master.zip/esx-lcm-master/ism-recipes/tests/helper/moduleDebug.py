#!/usr/bin/env python
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import argparse
import json
import traceback

import os
import sys
import logging
from orch import log

# Usage:
# python moduleDebug.py wrapper_oneview_fts -e '{ "host" : "16.125.106.125", "user" : "Administrator", "password" : "serveradmin" , "enableSupport" : "no" , "ov_ip" : "16.125.106.125" , "subnet" : "255.255.248.0", "gateway" : "16.125.104.1" , "host_name" : "thetemplate" , "domain" : "16.125.106.0" , "nameservers" : ["16.125.25.81"]}'
# python moduleDebug.py wrapper_import_servers -e '{ "host" :
# "16.125.106.125", "username" : "Administrator", "password" :
# "serveradmin" , "servers" : "no" }'


def main():

    # Parse arguments
    parser = argparse.ArgumentParser(description='moduleDebug:')
    parser.add_argument('moduleName', metavar='f',
                        help='moduleName, ex: login ')
    parser.add_argument(
        '-e',
        dest='vars',
        type=json.loads,
        default={},
        help='put a variable in this format: -e \'{"ip":"1111", "username":"dcs", "password":"123"}\'')

    args = parser.parse_args()
    moduleName = args.moduleName
    vars = args.vars

    varMap = {}
    varMap.update(vars)
    varMap['ism_hostname'] = "https://localhost:8083"
    home_path = os.environ['HOME']

    log.setup(log_file='/dev/stdout', log_level=logging.DEBUG)
    LOG = log.getLogger(__name__)

    module_response = {}
    sys.path.append(os.getcwd())

# Import the module and execute it as orch engine would do.
    try:
        module = __import__('lib.' + moduleName, fromlist=['base_execute'])
        moduleClass = getattr(module, moduleName.title())
        moduleObj = moduleClass()
        moduleMethod = getattr(moduleObj, 'base_execute')
        module_response = moduleMethod(varMap)
    except Exception as e:
        LOG.debug('Exception was: ' + str(e))
        LOG.debug(traceback.format_exc())
    else:
        LOG.debug('Module return body: ' + str(module_response['body']))

    sys.path.remove(os.getcwd())
    return str(module_response)


if __name__ == '__main__':
    main()
