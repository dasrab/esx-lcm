# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils


class Get_All_Hostagent_Info(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": None}

    def execute(self, params):
        host_agent_info = {}
        resmgr_info = params['info']
        self.headers['X-Auth-Token'] = resmgr_info['token']
        try:
            _url = urlparse.urlsplit(resmgr_info['resmgr_url'])
            path = '/'.join([_url.path, 'v1/hosts'])
            # Do a REST call to get the host information from HPE gateway
            with utils.do_request("GET", _url.netloc,
                                  path, self.headers, {}) as response:
                host_agents = json.loads(response.read())
            all_host_agents_info = list()
            for host_agent in host_agents:
                host_agent_info = dict()
                host_agent_info['id'] = host_agent['id']
                # Get the All the cluster info
                host_agent_info['clusters'] = self._get_cluster_info(
                    host_agent)
                # Appliance IP and Hostname
                host_agent_info['ip_address'] = utils.get_val(
                    host_agent, 'extensions', 'interfaces',
                    'data', 'iface_ip', 'br-int')
                host_agent_info['hostname'] = host_agent['info']['hostname']
                # Get the Roles appplied on host
                host_agent_info['roles'] = host_agent['roles']
                # Record the initial status of host
                if host_agent['roles']:
                    host_agent_info['status'] = host_agent['role_status']
                else:
                    # Status will be None if None of the roles are present
                    host_agent_info['status'] = None
                all_host_agents_info.append(host_agent_info)
            return self.exit_success(all_host_agents_info)
        except Exception as e:
            self.LOG.exception('Get HostAgent Info failed!')
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))

    def _get_cluster_info(self, host_agent_info):
        clusters = host_agent_info['extensions'][
            'hypervisor_details']['data']['clusters']
        clusters_details = [dict(name=cluster['name'],
                                 datastores=cluster['datastores'])
                            for cluster in clusters]
        return clusters_details
