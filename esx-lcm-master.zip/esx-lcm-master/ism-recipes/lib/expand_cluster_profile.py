# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP


import traceback
import hpOneViewClrm as hpovclrm

from common.oneview_connector import OneviewConnector

from hpOneView.resources import task_monitor as tm
from hpOneView.exceptions import HPOneViewException

from orch import log
from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from orch.ism_sdk.activity import Ism_Error

'''
module: expand_cluster_profile
description: Expand cluster profile by adding new server to an existing cluster.
arguments:
    ov_host:
        description:
            - Oneview server IP.
    auth:
        description:
            - OneView session_id
    association:
        description:
            - Server cluster association.
            - association['server_uris'] has array of server hardware uri to added to the cluster.
            - association['cluster_profile_uri'] cluster profile uri

returns:
    hypervisor_cluster_profile:
        description:
            - hypervisor cluster profile with details of newly added servers
'''


class Expand_Cluster_Profile(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    @with_task('HCOE_ISM_EXPAND_CLUSTER_PROFILE')
    def execute(self, params):

        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        association = params.get('_association')
        err_msg = ""

        server_hardware_uri = []
        for server in association['server_uris']:
            sh_uri = {"serverHardwareUri": server}
            server_hardware_uri.append(sh_uri)

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)

            hypervisor_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
                association['cluster_profile_uri'])
            host_profile_uris_before_expansion = hypervisor_cluster_profile[
                'hypervisorHostProfileUris']

            self.LOG.debug(
                "hypervisorHostProfileUris before expansion : " +
                str(host_profile_uris_before_expansion))
            cluster_name = hypervisor_cluster_profile['name']
            msg = "Cluster Profile (%s) Expansion " % cluster_name
            err_msg = msg + "Failed"
            self.LOG.debug(msg + "Started")

            task = cluster_profiles.expand_cluster_profile(
                association['cluster_profile_uri'],
                server_hardware_uri,
                blocking=False,
            )

            self.update_task(20, msg + "Started")
            self.LOG.info("Checking OneView task: %s" % task['uri'])

            task_monitor = tm.TaskMonitor(connection)
            cluster_profile_resp = task_monitor.wait_for_task(
                task, timeout=95 * 60)

            self.update_task(90, msg + "Completed")
            self.update_parent_task(70, msg + "Completed")

            host_profile_uris_after_expansion = cluster_profile_resp[
                'hypervisorHostProfileUris']

            self.LOG.debug(
                "hypervisorHostProfileUris after expansion : " +
                str(host_profile_uris_after_expansion))

            # Filter out only new hypervisorHostProfileUris
            for host_profile_uri_before_expansion in host_profile_uris_before_expansion:
                host_profile_uris_after_expansion.remove(
                    host_profile_uri_before_expansion)

            self.LOG.debug(
                "hypervisorHostProfileUris after filter : " +
                str(host_profile_uris_after_expansion))
            return self.exit_success(hypervisor_cluster_profile)

        except HPOneViewException as exe:
            self.update_task(90, err_msg)
            self.update_parent_task(70, err_msg)
            self.LOG.error(err_msg)
            self.LOG.error(traceback.format_exc())
            raise Ism_Error('HCOE_ISM_CLUSTER_EXPAND_FAILED',
                            details=err_msg + ' got (' + str(exe) + ')')
        except Exception as e:
            self.update_task(90, err_msg)
            self.update_parent_task(70, err_msg)
            self.LOG.error(err_msg)
            return self.exit_fail(str(e))
