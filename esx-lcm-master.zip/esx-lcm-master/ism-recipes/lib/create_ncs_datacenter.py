# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import time

import hpOneViewClrm as hpovclrm
from orch import log
from orch.moduleBase import ModuleBase

from pyVmomi import vim

from common.oneview_connector import OneviewConnector
from common.vcenter_utils import VcenterUtils

TASK_WAIT_DELAY = 5
HYP_MGR_RETRY_COUNT = 11


class Create_Ncs_Datacenter(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def _refresh_hypervisor_manager(self, hypervisor_managers, vc_host):
        # Make a put call with no change in payload
        hypervisor = hypervisor_managers.get_hypervisor_manager(vc_host)
        _retries = 3
        for i in range(_retries):
            try:
                self.LOG.debug("Making a PUT call with no change in payload to"
                               " hypervisor-managers to sync the inventory.")
                hypervisor_managers.update_hypervisor_manager(hypervisor)
                self.LOG.info("Successfully refreshed hypervisor-manager")
                return
            except Exception:
                if i < _retries - 1:
                    time.sleep(5)
                    continue

    def _wait_for_dc_hypervisor_manager_pairing(
            self, hypervisor_managers, vc_host, dc_name):

        retry_count = 0
        while True:
            retry_count += 1
            hypervisor = hypervisor_managers.get_hypervisor_manager(vc_host)
            self.LOG.debug("Hypervisor manager obtained %s" % str(hypervisor))
            for resource_path in hypervisor.get('resourcePaths'):
                if resource_path.get('userPath') == dc_name:
                    self.LOG.info(
                        "Datacenter '{}' is successfully registered with "
                        "hypervisor-managers".format(dc_name))
                    return
            if retry_count < HYP_MGR_RETRY_COUNT:
                self.LOG.info("Datacenter '{}' is not registered yet with "
                              "hypervisor-managers. Retrying again in '{}'s"
                              .format(dc_name, TASK_WAIT_DELAY * retry_count))
                time.sleep(TASK_WAIT_DELAY * retry_count)
            else:
                raise Exception("Timed out while waiting for Datacenter '{}' "
                                "to be registered with hypervisor-managers !"
                                .format(dc_name))

    def execute(self, params):
        try:
            si = self._vc_utils.get_service_instance(
                params['vc_host'], params['vc_user'],
                params['vc_password'], params['vc_port'])
            dc = self._vc_utils.get_obj(
                si.content, [vim.Datacenter], params['datacenter_name'])

            if dc:
                msg = ("A Datacenter by name '{}' already exist ! "
                       "Re-Using it.". format(params['datacenter_name']))
                self.update_parent_task(30, msg)
                self.LOG.warn(msg)
                return self.exit_success(True)

            self._vc_utils.create_datacenter(
                si.content, params['datacenter_name'])

            self.LOG.info("Successfully created datacenter '{}'"
                          .format(params['datacenter_name']))

            connection = OneviewConnector(
                params['ov_host'], params['ov_port'],
                params['auth']).connect()
            hypervisor_managers = hpovclrm.hypervisor_managers(connection)

            self._refresh_hypervisor_manager(
                hypervisor_managers, params['vc_remote_host'])

            self._wait_for_dc_hypervisor_manager_pairing(
                hypervisor_managers, params['vc_remote_host'],
                params['datacenter_name'])

            msg = ("Created '{}' Datacenter in vCenter"
                   .format(params['datacenter_name']))
            self.update_parent_task(30, msg)

            return self.exit_success(True)

        except Exception as e:
            err_msg = ("Failed to create Datacenter in vCenter'{}'"
                       .format(params['datacenter_name']))
            self.update_parent_task(30, err_msg)
            self.LOG.exception(err_msg)
            return self.exit_fail(e)
