# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase


class Store_Spt_Blueprint_Uri(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):

        try:
            zone_uuid = params['zone_uuid']
            spt_bp_uri = [params['spt_bp_uri']]
            self.update_zone_environment(zone_uuid, spt_bp_uri)
            return self.exit_success(spt_bp_uri)
        except Exception as e:
            self.LOG.exception("Set SPT Uri failed.!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
