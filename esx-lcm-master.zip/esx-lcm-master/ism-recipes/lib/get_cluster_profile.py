# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error
from common.oneview_connector import OneviewConnector
import hpOneViewClrm as hpovclrm


class Get_Cluster_Profile(ModuleBase):

    def execute(self, params):

        try:
            ov_host = params.get("_ov_hostname")
            ov_port = params.get("_ov_port")
            auth = params.get("_ov_auth")
            cluster_profile_uri = params.get("_cluster_profile_uri")
            self.validate_parameters(ov_host, ov_port, auth, cluster_profile_uri)

            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            return self.exit_success(hypervisor_cluster_profile)

        except Exception as e:
            self.LOG.exception(
                "Error in getting the cluster profile from OneView:" + str(e))
            raise Ism_Error(
                "HCOE_ISM_GET_CLUSTER_PROFILE_FAILED",
                details=str(e))

    @staticmethod
    def validate_parameters(ov_host, ov_port, auth, cluster_profile_uri):
        if ov_host is None or ov_host == '':
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Cluster_Profile module failed because ov_host was None or an em"
                "pty string")
        if ov_port is None:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Cluster_Profile module failed because ov_port was None")
        if auth is None or auth == '':
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Cluster_Profile module failed because auth was None or an empty string")

        if cluster_profile_uri is None or cluster_profile_uri == '':
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Cluster_Profile module failed because auth was None or an empty string")
