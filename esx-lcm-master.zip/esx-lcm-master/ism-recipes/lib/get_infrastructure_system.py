# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import json
from orch.moduleBase import ModuleBase
from orch.ism_sdk.infrastructure_systems import InfrastructureSystems

DOCUMENTATION = '''
---
module: Get Infrastructure Systems
short_description: Return Infrastructure Systems
'''

EXAMPLES = '''
  - name: Get Infrastructure Systems
    get_infrastructure_systems: {}
    register: infra_settings
How to test with ModuleDebug:
moduleDebug.py get_infrastructure_systems -e '{
 "ism_hostname": "http://localhost:8084"
 }'
'''


class Get_Infrastructure_System(ModuleBase):
    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        try:
            ism_client = InfrastructureSystems(self.private_request)

            infra_systems = ism_client.get_all_infrastructure_systems()
            if infra_systems:
                system = ism_client.get_all_infrastructure_systems()[0]
            else:
                system = None
        except Exception as e:
            self.LOG.exception('Exception in execute: ' + str(e))
            return self.exit_fail(e)

        return self.exit_success(system)
