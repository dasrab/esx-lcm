# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from common.vcenter_utils import VcenterUtils
import hpOneViewClrm as hpovclrm
from orch import log
from orch.moduleBase import ModuleBase
from pyVmomi import vim

from common.oneview_connector import OneviewConnector


class Update_Host_State(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def execute(self, params):
        try:
            self.connection = OneviewConnector(params['_ov_host'], params['_ov_port'], params['_auth']).connect()

            hyp_host_ips = list()
            hv_cluster_profile_client = hpovclrm.cluster_profile(self.connection)
            hv_profile_client = hpovclrm.hypervisor_profiles(self.connection)

            hypervisor_cluster_profile = hv_cluster_profile_client.get_cluster_profile_by_uri(
                str(params['_cluster_profile_uri']))

            host_profile_uris = hypervisor_cluster_profile[
                'hypervisorHostProfileUris']
            for host_profile_uri in host_profile_uris:
                hv_host_profile = hv_profile_client.get_hypervisor_profile_by_uri(
                    host_profile_uri)
                hv_host_uri = hv_host_profile['hypervisorHostUri']
                hv_host = hv_profile_client.get_hypervisor_host_by_uri(hv_host_uri)
                hyp_host_ips.append(hv_host['name'])

            si = self._vc_utils.get_service_instance(
                params['_vc_host'], params['_vc_user'],
                params['_vc_password'], params['_vc_port'])
            for hyp_host in hyp_host_ips:
                host = self._vc_utils.get_obj(
                    si.content, [vim.HostSystem], hyp_host)
                if not host:
                    self.LOG.warn("Host with name %s not found. Continuing..",
                        hyp_host)
                    continue
                self._vc_utils.enter_maintenance_mode(si, host)
                self.LOG.info("Successfully put host into maintenance mode. '{}'"
                          .format(host.name))
            return self.exit_success(True)
        except Exception as e:
            err_msg = ("Failed to update all hosts in Maintenance mode in Cluster '{}'"
                       .format(params['_cluster_profile_uri']))
            self.LOG.exception(err_msg)
            return self.exit_fail(e)
