# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from common.vcenter_utils import VcenterUtils

from orch.moduleBase import ModuleBase

DOCUMENTATION = '''
module: validate_deletion
short_description: Validate the rules for deletion
description:
    Rules for deletion validation:
    - The selected cluster shouldn't have any VMS
'''


class Validate_Deletion(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self._vc_utils = VcenterUtils()

    def check_if_vms_are_present(self, params):
        self.vc_ip = params.get("_vc_ip")
        self.vc_port = params.get("_vc_port")
        self.vc_username = params.get("_username")
        self.vc_password = params.get("_password")
        self.datacenter_name = params.get("_datacenterPath")
        self.cluster_name = params.get("_cluster_prefix")

        try:
            # TODO Need to get port and cert(default to None) from params
            si = self._vc_utils.get_service_instance(
                self.vc_ip, self.vc_username, self.vc_password, self.vc_port)
        except Exception as err:
            self.LOG.debug(
                "Error connecting to vCenter {0}.{1}".format(
                    self.vc_ip, str(err)))
            raise err
        try:
            cluster = self._vc_utils.get_cluster_by_datacenter(
                si, self.datacenter_name, self.cluster_name)
        except Exception as e:
            self.LOG.exception("Failed to get cluster details" + str(e))
            raise e
        if cluster.host:
            for host_id in cluster.host:
                if len(host_id.vm) > 0:
                    error_msg = ("Virtual machine instances are "
                                 "running on the compute node")
                    raise Exception(error_msg)

    def execute(self, params):
        self.LOG.debug("Validating Cluster for deletion")
        try:
            self.check_if_vms_are_present(params)

        except Exception as exception:
            self.LOG.debug(
                "Cluster Deletion cannot be executed: " +
                str(exception))
            return self.exit_fail(exception)

        return self.exit_success(
            "Deletion validation completed successfully.")
