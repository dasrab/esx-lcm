# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import time
import traceback

from pyVmomi import vim
from orch import log
from orch.moduleBase import ModuleBase

from common.vcenter_utils import VcenterUtils


class Delete_Ncs_Datacenter(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def execute(self, params):
        try:
            si = self._vc_utils.get_service_instance(
                params['vc_host'], params['vc_user'],
                params['vc_password'], params['vc_port'])
            dc = self._vc_utils.get_obj(
                si.content, [vim.Datacenter], params['datacenter_name'])
            if not dc:
                return self.exit_success("Datacenter with given name not found..")

            self._vc_utils.delete_datacenter(si, dc)
            self.LOG.info("Successfully deleted datacenter '{}'"
                          .format(params['datacenter_name']))
            return self.exit_success(True)
        except Exception as e:
            err_msg = ("Failed to delete Datacenter in vCenter '{}'"
                       .format(params['datacenter_name']))
            self.LOG.exception(err_msg)
            return self.exit_fail(e)
