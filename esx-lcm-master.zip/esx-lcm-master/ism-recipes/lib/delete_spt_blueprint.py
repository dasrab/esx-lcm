# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase


class Delete_Spt_Blueprint(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            self.delete_zone_environment(params['zone_uri'])
            return self.exit_success("Successfully deleted SPT bluepint for zone " + str(params['zone_uri']))
        except Exception as e:
            self.LOG.exception("Delete Server Blueprint failed.!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
