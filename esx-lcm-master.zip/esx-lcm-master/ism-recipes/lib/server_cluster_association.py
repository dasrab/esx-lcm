# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase


class Server_Cluster_Association(ModuleBase):

    def execute(self, params):
        self.LOG.debug('Executing Define_Server_Cluster_Association')

        server_hardware_uris = params.get('_server_hardware_uris')
        cluster_profile_uri = params.get('_cluster_profile_uri')

        association = {"server_uris": server_hardware_uris,
                       "cluster_profile_uri": cluster_profile_uri}

        bodyDict = {"association": association}
        self.LOG.info('Association Data : ' + str(bodyDict))

        return self.exit_success(bodyDict)
