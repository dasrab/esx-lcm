# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import getpass
import json
import os
import sys
import urlparse

from orch import log
from orch.moduleBase import ModuleBase

from hpeGateway import utils as hpe_gateway_util
from hpeGateway.model import Proxy_Server


class Hpe_Gateway_Ova_Download(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def _download_report(self, bytes_so_far, total_size, installer_name):
        """
        Print the status of downloading on the console.
        """
        percent = float(bytes_so_far) / total_size
        percent = round(percent * 100, 2)
        sys.stdout.write("{0}: Downloaded {1} of {2} bytes {3:.2f}%\r".format(
            installer_name, bytes_so_far, total_size, percent))

        if bytes_so_far >= total_size:
            sys.stdout.write('\n')

    def _raise_exception_with_message(self, status, reason):
        self.LOG.warning("Failed: %s %s", status, reason)
        raise Exception("Reason: %s %s" % (status, reason))

    def _download_installer(self, url, token, cookie, installer_name):
        """
        Download ova installer from the given details.
        """
        headers = {"X-Auth-Token": token, "cookie": cookie}
        body = ""

        _, net_location, path, _, _ = urlparse.urlsplit(url)
        with hpe_gateway_util.do_request("GET", net_location,
                                 path, headers, body) as response:
            total_size = int(response.getheader('Content-Length').strip())
            bytes_read = 0
            # writes the file in the current working directory
            with open(installer_name, 'w') as fp:

                while True:
                    body = response.read(512 * 1024)
                    bytes_read += len(body)
                    # if response is empty, return
                    if not body:
                        break
                    fp.write(body)
                    self._download_report(
                        bytes_read, total_size, installer_name)

    def _get_package_info_from_token(self, keystone_url, token, region):
        """
        Get VMware package details from the token
        """
        headers = {
            "Content-Type": "application/json",
            "X-Auth-Token": token
        }
        _, host, path, _, _ = urlparse.urlsplit(keystone_url)
        with hpe_gateway_util.do_request("GET", host,
                                 "/keystone_admin/v3/services?type=regionInfo",
                                 headers, {}) as response:
            response_body = json.loads(response.read())
            service_id = response_body['services'][0]['id']

        url = "/keystone_admin/v3/endpoints?service_id={0}".format(service_id)
        public_url = ""
        with hpe_gateway_util.do_request("GET", host, url,
                                 headers, {}) as response:
            response_body = json.loads(response.read())
            for ep in response_body['endpoints']:
                if ep['region'] == region:
                    if ep['interface'] == 'internal':
                        internal_url = ep['url']
                    elif ep['interface'] == 'public':
                        public_url = ep['url']
        if not public_url:
            # We hit this if invalid region is provided.
            return {}

        _, net_location, path, _, _ = urlparse.urlsplit(public_url)
        with hpe_gateway_util.do_request("GET", net_location,
                                 path, headers, {}) as response:
            response_body = json.loads(response.read())
            cookie_url = response_body['links']['token2cookie']

        _, net_location, path, _, _ = urlparse.urlsplit(cookie_url)
        with hpe_gateway_util.do_request("GET", net_location,
                                 path, headers, {}) as response:
            cookie = response.getheader('set-cookie')

        headers['cookie'] = cookie
        _, net_location, path, _, _ = urlparse.urlsplit(internal_url)
        with hpe_gateway_util.do_request("GET", net_location,
                                 path, headers, {}) as response:
            response_body = json.loads(response.read())
            vmware_appliance = response_body['links']['vmware_appliance']

        return {
            'cookie': cookie,
            'internal_url': internal_url,
            'public_url': public_url,
            'vmware_appliance': vmware_appliance
        }

    def execute(self, params):
        Proxy_Server.set_proxy_details(
            params["proxy_server"], params["proxy_port"])
        token = hpe_gateway_util.get_token_v3(params["keystone_url"], params["user"],
                                      params["password"], params["tenant"])
        info = self._get_package_info_from_token(params["keystone_url"],
                                                 token, params["region"])
        if not info:
            return self.exit_fail(
                "Compute OVA download failed. Couldn't connect to region '{}'" .format(
                    params["region"]))

        package_url = info['vmware_appliance']
        installer_name = package_url.rsplit('/', 1)[1]
        ova_file_path = os.path.join(os.getcwd(), installer_name)
        if os.path.exists(ova_file_path):
            self.LOG.debug(
                "HPE gateway ova already present %s. Returning", str(ova_file_path))
            return self.exit_success(
                {"Result": "Already Present", "ova_path": ova_file_path})
        self._download_installer(
            package_url, token, info['cookie'], installer_name)
        self.LOG.debug("HPE gateway ova download successful..")
        return self.exit_success(
            {"Result": "Downloaded", "ova_path": ova_file_path})
