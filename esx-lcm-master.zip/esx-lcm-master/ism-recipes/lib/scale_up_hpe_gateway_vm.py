# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase

from pyVmomi import vim

from common.vcenter_utils import VcenterUtils


class Scale_Up_Hpe_Gateway_Vm(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def _get_cpu_and_memory(self, cluster, vm, vcpus, memory):
        # Add the increment counter with the current resource.
        incremented_cpu = vm.summary.config.numCpu + vcpus
        incremented_memory = vm.summary.config.memorySizeMB + long(memory)
        # Return if the incremented resource can be allocated by the cluster
        if (cluster.summary.effectiveCpu > incremented_cpu and
                cluster.summary.effectiveMemory > incremented_memory):
            return incremented_cpu, incremented_memory

    def execute(self, params):
        si = self._vc_utils.get_service_instance(
            params['vcenter_ip'], params['vcenter_username'],
            params['vcenter_password'], params['vcenter_port'],
            params.get('cert_path'))
        dc = self._vc_utils.get_obj(
            si.content, [vim.Datacenter], params['datacenter'])
        if not dc:
            return self.exit_fail("Couldn't find the Datacenter '{}'"
                                  .format(params['datacenter']))
        cluster = self._vc_utils.get_obj(
            si.content, [vim.ClusterComputeResource],
            params['cluster'], dc.hostFolder)
        if not cluster:
            return self.exit_fail("Couldn't find the Cluster '{}'"
                                  .format(params['cluster']))
        hpe_gateway_vm = self._vc_utils.get_obj(
            si.content, [vim.VirtualMachine],
            params['appliance_name'], dc.vmFolder)
        if not hpe_gateway_vm:
            return self.exit_fail("Couldn't find the HPE gateway VM '{}'"
                                  .format(params['appliance_name']))

        cpu, memory = self._get_cpu_and_memory(
            cluster, hpe_gateway_vm, params['vcpus'], params['memory'])
        if not all([cpu, memory]):
            return self.exit_fail(
                "Cluster '{}' don't have enough resource to scale up the HPE gateway "
                "VM '{}'".format(params['cluster'],
                                 params['appliance_name']))
        vm_conf = vim.vm.ConfigSpec(numCPUs=cpu, memoryMB=memory)
        self._vc_utils.reconfigure_vm(si, hpe_gateway_vm, vm_conf)
        self.LOG.info("Successfully scaled up the HPE gateway VM '{}'"
                      .format(params['appliance_name']))
        return self.exit_success({"Status": "SUCCESS"})
