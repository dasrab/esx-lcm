# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest
import mock

from lib.common import utils
from lib.common import models
from lib.allocate_servers import Allocate_Servers


class TestAllocateServers(unittest.TestCase):

    def setUp(self):
        super(TestAllocateServers, self).setUp()
        self.allocate_servers_obj = Allocate_Servers()

    def test_execute_success(self):
        fake_params = {'serverBlueprintUri': '/rest/serverblueprints/abcd',
                       'server_count': 2,
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        mock_result = {'name': 'server1',
                       'uri': '/rest/server/serveruri',
                       'serverProfileTemplateUri': '/rest/spt/spturi',
                       'serverHardwareUri': '/rest/serverhardware/uri',
                       'serverBlueprintUri': '/rest/spb/uri',
                       'state': 'Allocated'}
        with contextlib.nested(
                mock.patch.object(utils.ApplianceManagerProxy,
                                  'allocate_server', return_value=mock_result),
                mock.patch.object(models.Server, 'serialize')) as (
                mock_allocate_servers, mock_serialize_server):
            self.allocate_servers_obj.execute(fake_params)
            self.assertTrue(mock_allocate_servers.called)
            mock_serialize_server.assert_called_with()

    def test_execute_failure_for_keyerror(self):
        fake_params = {'serverBlueprintUri': '/rest/serverblueprints/abcd',
                       'server_count': 2,
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        mock_result = {'name': 'server1',
                       'uri': '/rest/server/serveruri',
                       'serverBlueprintUri': '/rest/spb/uri',
                       'state': 'Allocated'}
        with contextlib.nested(
                mock.patch.object(utils.ApplianceManagerProxy,
                                  'allocate_server', return_value=mock_result),
                mock.patch.object(models.Server,
                                  'serialize', side_effect=KeyError)) as (
                mock_allocate_servers, mock_serialize_server):
            self.allocate_servers_obj.execute(fake_params)
            self.assertTrue(mock_allocate_servers.called)
            self.assertFalse(mock_serialize_server.called)

    def test_execute_failure_when_unavailable_servers(self):
        fake_params = {'serverBlueprintUri': '/rest/serverblueprints/abcd',
                       'server_count': 2,
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'allocate_server', side_effect=Exception) as (
                mock_allocate_servers):
            self.allocate_servers_obj.execute(fake_params)
            self.assertTrue(mock_allocate_servers.called)

    def test_execute_exception(self):
        fake_params = {'serverBlueprintUri': '/rest/serverblueprints/abcd',
                       'server_count': 2,
                       'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'allocate_server') as (mock_allocate_servers):
            self.allocate_servers_obj.execute(fake_params)
            self.assertFalse(mock_allocate_servers.called)


if __name__ == '__main__':
    unittest.main()
