#!/usr/bin/env python
# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
'''
Created on June 21, 2016

'''
import unittest
import mock
from lib.create_cluster_profile import Create_Cluster_Profile
import hpOneViewClrm as hpovclrm
from mock import patch


class create_cluster_profile_unittest (unittest.TestCase):

    def setUp(self):
        self.params = {
            "_ovhost": "10.0.0.0",
            "_auth": "LTMwNjQ5MjEyMTE3oLtyrisVhSlXiIvySti3su61qzSMrmXr",
            "_name": "fake_cluster",
            "_hypervisor_type": "esx",
            "_deployment_plan_uri": "fake_plan_uri",
            "_server_profile_template_uri": [
                {"server_profile_template_uri": "/rest/server-profile-templates/ec7c1add-b8bf-4fb0-8ffd-4578bd0c28ca",
                 "state": "Completed"}],
            "_network_uris": [{"uri": "/rest/management-network/1"}],
            "_servers": [{"username": "_hcoe_user",
                          "federationGroup": "Hellfire",
                          "serverHardwareTypeUri": "/rest/server-hardware-types/12D0895D-E3A7-4BE9-8631-8DDBA3749B82",
                          "uuid": "4C4C4548-4946-4753-4836-313258353256", "created": "2016-08-24T01:00:34.90194912Z",
                          "serialNumber": "SGH612X52V",
                          "modified": "2016-08-24T01:00:34.90194943Z",
                          "uri": "/rest/unmanaged-servers/4C4C4548-4946-4753-4836-313258353256",
                          "iloIpAddress": "fe80::1602:ecff:fe3b:adf8",
                          "serverHardwareUri": "/rest/server-hardware/4C4C4548-4946-4753-4836-313258353256",
                          "unmanagedServerUri": "/rest/unmanaged-services/",
                          "password": "_hcoe_user", "type": "unmanaged-server", "seedNode": False}],
            "_host_credentials": {"password": "mock_pass"},
            "_datacenterPath": "fake_dc_path",
            "_hostPassword": "fake__hostPassword",
            "_hypervisor_manager_uri": "/rest/hypervisor-manager/1"

        }
        self.create_clu_obj = Create_Cluster_Profile()
        self.success_result = {'module_status': 'SUCCESS'}
        self.failure_result = {'module_status': 'FAIL'}

    @patch('lib.create_cluster_profile.OneviewConnector')
    @patch.object(hpovclrm, 'cluster_profile')
    def test_execute_try(self, hpovclrm_clu_pro, conn):
        with mock.patch.object(self.create_clu_obj,
                               'update_resource_uri') as mock_update:
            res = self.create_clu_obj.execute(self.params)
            self.assertEqual(res['headers'], self.success_result)

    @patch('lib.create_cluster_profile.OneviewConnector')
    def test_execute_try_excp(self, conn):
        res = self.create_clu_obj.execute(self.params)
        self.assertEqual(res['headers'], self.failure_result)

    @patch.object(hpovclrm, 'cluster_profile')
    def test_execute_tm_excp(self, hpovclrm_clu_pro):
        res = self.create_clu_obj.execute(self.params)
        self.assertEqual(res['headers'], self.failure_result)
