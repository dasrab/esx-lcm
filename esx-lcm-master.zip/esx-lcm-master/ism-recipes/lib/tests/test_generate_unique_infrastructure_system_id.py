# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

from lib import generate_unique_infrastructure_system_id as infra_id
from lib.common.vcenter_utils import VcenterUtils

args = {
    'vc_host': '1.1.1.1',
    'vc_user': 'root',
    'vc_password': '***',
    'vc_port': 443,
    'datacenter_name': 'Datacenter1',
    'cluster_name': 'Cluster1'
}


class si:

    class content:

        class about:
            instanceUuid = 'fake-vcenter-uuid'


class cluster:
    _moId = 'domain-c0'
    hostFolder = None


class TestGenerate_Unique_Infrastructure_System_Id(unittest.TestCase):

    def setUp(self):
        super(TestGenerate_Unique_Infrastructure_System_Id, self).setUp()
        self._get_unique_infra_id = (
            infra_id.Generate_Unique_Infrastructure_System_Id())

    def test_execute(self):
        with contextlib.nested(
            patch.object(VcenterUtils, 'get_service_instance',
                         return_value=si),
            patch.object(VcenterUtils, 'get_obj', return_value=cluster)) as (
                get_service_instance, get_obj):

            ret_val = self._get_unique_infra_id.execute(args)

            self.assertIsNotNone(ret_val)
            cluster_id = ret_val.get('body')
            self.assertEqual(
                cluster_id.split('_')[0], si.content.about.instanceUuid)
            self.assertEqual(cluster_id.split('_')[1], cluster._moId)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_service_instance.called)
            self.assertTrue(get_obj.called)
