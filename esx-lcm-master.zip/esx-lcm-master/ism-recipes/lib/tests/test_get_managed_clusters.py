# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
from orch.moduleBase import ModuleBase
import unittest

from lib.get_managed_clusters import Get_Managed_Clusters
from lib.hpeGateway import utils


mock_host_agent_info = [{'id': 'abcd12345678',
                         'ip_address': '10.10.20.21',
                         'hostname': 'fake_agent1',
                         'clusters': ['managed_cluster', 'unmanaged_cluster']},
                        {'id': 'dcba87654321',
                         'ip_address': '10.10.20.22',
                         'hostname': 'fake_agent2',
                         'clusters': ['managed_cluster', 'unmanaged_cluster']}]

fake_resmgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                    'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

fake_params = {'all_host_agent_info': mock_host_agent_info,
               'resmgr_info': fake_resmgr_info}

fake_return_value = {'body': [{'host_id': 'abcd12345678',
                               'ip_address': '10.10.20.21',
                               'name': 'fake_agent1',
                               'clusters': ['managed_cluster']},
                              {'host_id': 'dcba87654321',
                               'ip_address': '10.10.20.22',
                               'name': 'fake_agent2',
                               'clusters': ['managed_cluster']}],
                     'headers': {'module_status': 'SUCCESS'}}


class TestGet_Managed_Clusters(unittest.TestCase):

    def setUp(self):
        super(TestGet_Managed_Clusters, self).setUp()
        self.managed_clusters_obj = Get_Managed_Clusters()

    def test_execute_return_clusters(self):
        fake_managed_clusters = ['managed_cluster']
        for each_entry in fake_return_value['body']:
            each_entry['clusters'] = fake_managed_clusters
        with mock.patch.object(utils, 'get_all_managed_clusters_from_hpe_gateway',
                               return_value=fake_managed_clusters) as (
                mock_get_managed_clusters):
            managed_clusters = self.managed_clusters_obj.execute(fake_params)
            self.assertTrue(mock_get_managed_clusters.called)
            self.assertEqual(mock_get_managed_clusters.call_count, 2)
            self.assertEqual(managed_clusters, fake_return_value)

    def test_execute_return_empty_clusters(self):
        for each_entry in fake_return_value['body']:
            each_entry['clusters'] = []
        with mock.patch.object(utils, 'get_all_managed_clusters_from_hpe_gateway',
                               return_value=[]) as (
                mock_get_managed_clusters):
            managed_clusters = self.managed_clusters_obj.execute(fake_params)
            self.assertTrue(mock_get_managed_clusters.called)
            self.assertEqual(mock_get_managed_clusters.call_count, 2)
            self.assertEqual(managed_clusters, fake_return_value)


if __name__ == '__main__':
    unittest.main()
