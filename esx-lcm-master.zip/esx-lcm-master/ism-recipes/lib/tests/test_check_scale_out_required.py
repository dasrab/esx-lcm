# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase
import unittest

from lib.check_scale_out_required import Check_Scale_Out_Required


class TestScaleOutRequired(unittest.TestCase):

    def setUp(self):
        super(TestScaleOutRequired, self).setUp()
        self.check_scale_out_obj = Check_Scale_Out_Required()

    def test_execute_true(self):
        fake_params = dict()
        fake_params['managed_clusters'] = [
            {
                "id": "fake_agent1", "clusters": [
                    "fake_cluster1", "fake_cluster2"]}, {
                "id": "fake_agent2", "clusters": [
                    "fake_cluster3", "fake_cluster4"]}]
        fake_result = {'body': {'new_ova_required': 'True'},
                       'headers': {'module_status': 'SUCCESS'}}
        fake_params['cluster_scale_count'] = 2
        fake_params['new_cluster_list'] = ["new_cluster1", "new_cluster2"]
        result = self.check_scale_out_obj.execute(fake_params)
        self.assertEqual(result, fake_result)

    def test_execute_false(self):
        fake_params = dict()
        fake_params['managed_clusters'] = [{"id": "fake_agent1",
                                            "clusters": ["fake_cluster1", "fake_cluster2"]},
                                           {"id": "fake_agent2",
                                            "clusters": ["fake_cluster3"]}]
        fake_result = {'body': {'new_ova_required': 'False'},
                       'headers': {'module_status': 'SUCCESS'}}
        fake_params['cluster_scale_count'] = 3
        fake_params['new_cluster_list'] = ["new_cluster1", "new_cluster2"]
        result = self.check_scale_out_obj.execute(fake_params)
        self.assertEqual(result, fake_result)


if __name__ == '__main__':
    unittest.main()
