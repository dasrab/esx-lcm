# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP


import unittest
import mock
from lib.infrastructure_cluster_profile_association import *
from orch.ism_sdk.infrastructure_systems import InfrastructureSystems

class private_request (object):
    def __init__(self):
        self.hostname = "mock_host"


class TestInfrastructureClusterProfileAssociation(unittest.TestCase):
    def setUp(self):
        self.infra_cluster_pro_obj = Infrastructure_Cluster_Profile_Association()
        self.infra_cluster_pro_obj.private_request = private_request()
        self.params = {
            "_hypervisor_cluster_name":"cluster2",
            "_infra_system_uri": "fake_infra_system_uri",

            "_hypervisor_clusters": [
                {"name": "cluster2",
                 "uri": "fake_uri",
                 "hypervisorClusterUri": "fake_uri",
                 }
            ]

        }

    def test_execute_success(self):

        fake_infra_systems = [
            {

                "uri": "fake_infra_system_uri",

                "hypervisorSettings":
                    {

                        "hypervisorCluster": {"name": "cluster2",
                                              "clusterPrefix": "test"},

                    }

            }

        ]

        expected = {'body': {'association':
                            {'cluster_profile_uri': 'fake_uri',
                             'cluster_uri': 'fake_uri'}
                              },
                    'headers': {'module_status': 'SUCCESS'}}


        with mock.patch.object(InfrastructureSystems, 'get_all_infrastructure_systems',
                               return_value=fake_infra_systems) as (mock_get_all_infrastructure_systems):

            res = self.infra_cluster_pro_obj.execute(self.params)
            self.assertEqual(res, expected)

    def test_execute_failure(self):
        self.fake_params = {}
        res = self.infra_cluster_pro_obj.execute(self.fake_params)



