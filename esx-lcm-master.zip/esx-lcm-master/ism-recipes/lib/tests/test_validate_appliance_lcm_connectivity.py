# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import mock
import unittest

from lib.common import utils
from lib import validate_appliance_lcm_connectivity


class TestValidate_Appliance_Lcm_Connectivity(unittest.TestCase):

    def setUp(self):
        super(TestValidate_Appliance_Lcm_Connectivity, self).setUp()
        self.validate_appliance_lcm_connectivity_obj = (
            validate_appliance_lcm_connectivity.
            Validate_Appliance_Lcm_Connectivity())

    def test_execute_success(self):
        fake_params = {}
        fake_params['appliance_manager_ip'] = "10.0.0.1"
        fake_params['appliance_manager_port'] = 5000
        fake_appliance_lcm_info = {}
        fake_appliance_lcm_info['appliance_ip'] = "10.0.0.1"
        fake_appliance_lcm_info['appliance_port'] = 5000
        fake_AppManProxy = utils.ApplianceManagerProxy(fake_appliance_lcm_info)
        with contextlib.nested(
            mock.patch.object(utils, 'ApplianceManagerProxy'),
            mock.patch.object(fake_AppManProxy, "get_servers",
                              return_value=[])) as (
                mock_appliance_proxy, mock_get_servers):
            mock_appliance_proxy.return_value.__enter__.return_value = (
                fake_AppManProxy)
            result = self.validate_appliance_lcm_connectivity_obj.execute(
                fake_params)
            self.assertTrue(mock_appliance_proxy.called)
            self.assertEqual(result['body']['is_valid'], True)

    def test_execute_failure(self):
        fake_params = {}
        fake_params['appliance_manager_ip'] = "10.0.0.1"
        fake_params['appliance_manager_port'] = 5000
        fake_appliance_lcm_info = {}
        fake_appliance_lcm_info['appliance_ip'] = "10.0.0.1"
        fake_appliance_lcm_info['appliance_port'] = 5000
        fake_AppManProxy = utils.ApplianceManagerProxy(fake_appliance_lcm_info)
        with contextlib.nested(
            mock.patch.object(utils, 'ApplianceManagerProxy'),
            mock.patch.object(fake_AppManProxy, "get_servers",
                              return_value=[])) as (
                mock_appliance_proxy, mock_get_servers):
            mock_appliance_proxy.side_effect = Exception()
            result = self.validate_appliance_lcm_connectivity_obj.execute(
                fake_params)
            self.assertTrue(mock_appliance_proxy.called)
            self.assertEqual(result['body']['is_valid'], False)


if __name__ == '__main__':
    unittest.main()
