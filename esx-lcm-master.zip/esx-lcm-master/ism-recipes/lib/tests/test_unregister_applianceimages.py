# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
import mock

from lib.common import utils
from lib.unregister_applianceimages import Unregister_Applianceimages


class TestUnregisterApplianceimages(unittest.TestCase):

    def setUp(self):
        super(TestUnregisterApplianceimages, self).setUp()
        self.unregister_appimage_obj = Unregister_Applianceimages()

    def test_execute_success(self):
        fake_params = {'app_image_uri': '/rest/applianceimage/uri',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'unregister_applianceimage') as (mock_unregister):
            self.unregister_appimage_obj.execute(fake_params)
            self.assertTrue(mock_unregister.called)

    def test_execute_failure(self):
        fake_params = {'app_image_uri': '/rest/applianceimage/uri',
                       'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'unregister_applianceimage') as (mock_unregister):
            self.unregister_appimage_obj.execute(fake_params)
            self.assertFalse(mock_unregister.called)


if __name__ == '__main__':
    unittest.main()
