# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

import hpOneView
import hpOneViewClrm as hpovclrm

from pyVmomi import vim

from lib import create_ncs_datacenter
from lib.common.vcenter_utils import VcenterUtils

args = {
    'ov_host': '2.2.2.2',
    'ov_port': 443,
    'auth': 'fake-auth',
    'vc_host': '1.1.1.1',
    'vc_user': 'root',
    'vc_password': '***',
    'vc_port': 443,
    'vc_remote_host': '1.1.1.1',
    'datacenter_name': 'Datacenter1'
}


class si:

    class content:

        class rootFolder:

            @staticmethod
            def CreateDatacenter(dc_name):
                raise Exception()


class hypervisor_manager:

    @staticmethod
    def get_hypervisor_manager(vc_host):
        return {
            'resourcePaths': [
                {'userPath': args['datacenter_name']}
                ]
            }

    @staticmethod
    def update_hypervisor_manager(hypervisor):
        return


class TestCreate_Ncs_Datacenter(unittest.TestCase):

    def setUp(self):
        super(TestCreate_Ncs_Datacenter, self).setUp()
        self.create_dc = create_ncs_datacenter.Create_Ncs_Datacenter()

    def test_execute(self):
        with contextlib.nested(
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(self.create_dc,
                         '_wait_for_dc_hypervisor_manager_pairing'),
            patch.object(self.create_dc, '_refresh_hypervisor_manager')) as (
                get_service_instance, mock_wait, refresh_hyp_mgr):
            ret_val = self.create_dc.execute(args)
            self.assertIsNotNone(ret_val)
            self.assertTrue(ret_val.get('body'))
            self.assertTrue(get_service_instance.called)
            self.assertTrue(mock_wait.called)
            self.assertTrue(refresh_hyp_mgr.called)

    def test_execute_duplicate_err_success(self):
        with contextlib.nested(
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(VcenterUtils, 'get_obj', return_value='fake-dc')) as (
                get_service_instance, get_obj):
            ret_val = self.create_dc.execute(args)
            self.assertIsNotNone(ret_val)
            self.assertTrue(ret_val.get('body'))
            self.assertTrue(get_service_instance.called)
            self.assertTrue(get_obj.called)

    def test_execute_generic_err_failure(self):
        with patch.object(VcenterUtils, 'get_service_instance',
                          return_value=si) as (get_service_instance):
            ret_val = self.create_dc.execute(args)
            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('body').get('errorCode'),
                'HCOE_ISM_MODULE_FAILED')
            self.assertTrue(get_service_instance.called)

    def test_wait_for_dc_hypervisor_manager_pairing(self):
        # On success this method simply returns.
        # And python default return value is None.
        self.assertIsNone(
            self.create_dc._wait_for_dc_hypervisor_manager_pairing(
                hypervisor_manager, args['vc_host'], args['datacenter_name']))

    def test_wait_for_dc_hypervisor_manager_pairing_exception(self):
        dc_name = args['datacenter_name']
        args['datacenter_name'] = 'fake-dc'
        create_ncs_datacenter.HYP_MGR_RETRY_COUNT = 1
        exp_msg = ("Timed out while waiting for Datacenter '{}' to be "
                   "registered with hypervisor-managers !".format(dc_name))

        with self.assertRaises(Exception) as ctx:
            self.create_dc._wait_for_dc_hypervisor_manager_pairing(
                hypervisor_manager, args['vc_host'], dc_name)

        self.assertTrue(exp_msg in ctx.exception)

    def test_refresh_hypervisor_manager(self):
        # On success/failure this method simply returns.
        # And python default return value is None.
        self.assertIsNone(
           self.create_dc._refresh_hypervisor_manager(
               hypervisor_manager, args['vc_host']))
