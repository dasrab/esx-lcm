# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import mock
import unittest
import hpOneView
from lib.validate_oneview_connectivity import Validate_Oneview_Connectivity

ONEVIEW_VERSION = 500
fake_host = '11.22.33.44'
fake_port = 443
fake_creds = {'ov_username': 'fake_user',
              'ov_password': 'fake_password'}

fake_params = {'ov_host': fake_host,
               'ov_port': fake_port}
fake_params.update(fake_creds)

fake_ov_creds = {'userName': fake_creds['ov_username'],
             'password': fake_creds['ov_password']}

class Test_Validate_Oneview_Connectivity(unittest.TestCase):

    def setUp(self):
        super(Test_Validate_Oneview_Connectivity, self).setUp()
        self.ov_connection_obj = Validate_Oneview_Connectivity()

    def test_execute_connect_success(self):
        with mock.patch('hpOneView.connection.login') as mock_conn:
            self.ov_connection_obj.execute(fake_params)
            host = fake_host + ":" + str(fake_port)
            mock_conn.assert_called_with({'userName': 'fake_user', 'password': 'fake_password'})
            self.assertEqual(mock_conn.call_count, 1)

    def test_execute_login_success(self):
        with mock.patch.object(hpOneView.connection, "login") as (mock_login):
            self.ov_connection_obj.execute(fake_params)
            mock_login.assert_called_with(fake_ov_creds)
            self.assertEqual(mock_login.call_count, 1)
