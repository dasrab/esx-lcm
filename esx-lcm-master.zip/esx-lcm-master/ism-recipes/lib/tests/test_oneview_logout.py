# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
'''
Created on Jan 18, 2017

@author: sathishkumar.sivagurunathan@hpe.com
'''

import unittest
import mock
from lib.oneview_logout import Oneview_Logout
from orch.ism_sdk.activity import Ism_Error


class OneviewLogoutTest(unittest.TestCase):

    def setUp(self):
        self.params = {
            "_ov_host": "1.1.1.1",
                        "_auth": "agsasgkahakdhkah374672shh"
        }

        self.oneview_logout = Oneview_Logout()
        unittest.TestCase.setUp(self)

    def tearDown(self):
        self.params = None
        self.oneview_logout = None
        unittest.TestCase.tearDown(self)

    @mock.patch(
        'lib.oneview_logout.OneviewConnector',
        side_effect=Exception)
    def test_execute_connection_exception(self, mock_connection):
        self.assertRaises(Ism_Error, self.oneview_logout.execute, self.params)
