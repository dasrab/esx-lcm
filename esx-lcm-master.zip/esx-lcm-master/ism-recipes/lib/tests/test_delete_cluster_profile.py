# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import unittest
from mock import patch
from lib import delete_cluster_profile


expectedValue = {'module_status': 'SUCCESS'}


class Test_Delete_Cluster_Profile(unittest.TestCase):

    @patch('delete_cluster_profile.OneviewConnector')
    def test_execute_delete_cluster_profile_exception(self, mocked_ov_con):
        class_obj = delete_cluster_profile.Delete_Cluster_Profile()
        params = {
            "_ov_hostname": "10.0.0.0",
            "_ov_port": 443,
            "_cluster_profile_uri": ""}
        returnValue = class_obj.execute(params)
        error_msg = returnValue.get("body")["nestedErrors"][0]["details"]

        expected_error_msg = ("Cluster profile uri not found in " +
                              "infrastructure systems")
        self.assertEqual(error_msg, expected_error_msg)

    @patch('delete_cluster_profile.tm.TaskMonitor.get_completed_task')
    @patch('hpOneViewClrm.cluster_profile')
    @patch('delete_cluster_profile.OneviewConnector')
    def test_execute_delete_cluster_profile(
            self, mocked_ov_con, mocked_cluster_profile, mocked_tm):
        class_obj = delete_cluster_profile.Delete_Cluster_Profile()
        params = {
            "_ov_hostname": "10.0.0.0",
            "_ov_port": 443,
            "_cluster_profile_uri": "/rest/cluster_profile_uri/dummyuri"}
        returnValue = class_obj.execute(params)
        module_status = returnValue.get("headers")["module_status"]
        expected_status = "SUCCESS"
        self.assertEqual(module_status, expected_status)
