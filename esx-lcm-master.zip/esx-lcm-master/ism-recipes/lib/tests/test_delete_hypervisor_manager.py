# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
import contextlib
import mock
import unittest

import hpOneViewClrm as hpovclrm
from lib.delete_hypervisor_manager import Delete_Hypervisor_Manager


fake_params = {'_ov_host': 'fake_host',
               '_ov_port': 443,
               '_auth': 'fake_auth',
               '_hypervisor_manager_uri': 'fake_uri'}

moduleStatus_succ = {'module_status': 'SUCCESS'}

class Test_Delete_Hypervisor_Manager(unittest.TestCase):

    def setUp(self):
        super(Test_Delete_Hypervisor_Manager, self).setUp()
        self.del_hyp_manager = Delete_Hypervisor_Manager()

    def test_execute_success(self):
        with contextlib.nested(
            mock.patch.object(self.del_hyp_manager.LOG,
                              'debug'),
            mock.patch.object(hpovclrm.hypervisor_managers,
                              'delete_hypervisor_manager')) as (
                mock_log_debug, mock_delete_hyp):
            result = self.del_hyp_manager.execute(fake_params)
            self.assertEqual(result['headers'], moduleStatus_succ)
            self.assertTrue(mock_log_debug.called)
            self.assertEqual(mock_log_debug.call_count, 3)
            self.assertTrue(mock_delete_hyp.called)
            self.assertEqual(result['body'],
                fake_params['_hypervisor_manager_uri'])

    def test_execute_raise_exception(self):
        with contextlib.nested(
            mock.patch.object(self.del_hyp_manager.LOG,
                              'error'),
            mock.patch.object(hpovclrm.hypervisor_managers,
                              'delete_hypervisor_manager',
                              side_effect=Exception())) as (
                mock_log_error, mock_delete_hyp):
            result = self.del_hyp_manager.execute(fake_params)
            self.assertEqual(result['headers'], moduleStatus_succ)
            self.assertFalse(mock_log_error.called)
            self.assertTrue(mock_delete_hyp.called)
