# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest

import mock
from mock import patch

from lib.common import utils
from lib.get_serverblueprint_by_uri import Get_Serverblueprint_By_Uri


class TestGetServerblueprintByUri(unittest.TestCase):

    def setUp(self):
        super(TestGetServerblueprintByUri, self).setUp()
        self.get_serverblueprint_obj = Get_Serverblueprint_By_Uri()

    def test_execute(self):
        fake_params = {'serverblueprint_uri': 'fake_spt_1',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_serverblueprint_by_uri') as (
                mock_get_sbp_by_uri):
            self.get_serverblueprint_obj.execute(fake_params)
            self.assertTrue(mock_get_sbp_by_uri.called)

    def test_execute_exception(self):
        fake_params = {'serverblueprint_uri': 'fake_spt_1',
                       'appliance_ip': '127.0.0.1'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_serverblueprint_by_uri') as (
                mock_get_sbp_by_uri):
            self.get_serverblueprint_obj.execute(fake_params)
            self.assertFalse(mock_get_sbp_by_uri.called)
