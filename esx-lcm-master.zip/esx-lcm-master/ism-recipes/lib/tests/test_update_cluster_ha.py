# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import unittest
import mock
from mock import patch
from lib.update_cluster_ha import Update_Cluster_Ha
from hpOneViewClrm import *



class Test_Update_Cluster_Ha(unittest.TestCase):
    def setUp(self):
        self.param = {'_ov_host': "Fake_host",
                      '_auth': "Fake_auth",
                      '_ha_enable': True,
                      '_cluster': 'Fake_cluster'
                      }
        self.update_clu_obj = Update_Cluster_Ha()
        self.success = {'module_status': 'SUCCESS'}
        self.failed = {'module_status': 'FAIL'}

    def test_get_cluster_profile(self):
        mock_cluster_list = [{'name': 'Fake_cluster',
                              'hypervisorClusterSettings': {'haEnabled': True}},
                             {'name': 'Fake_cluster_2',
                              'hypervisorClusterSettings': {'haEnabled': False}}]

        self.update_clu_obj.get_cluster_profile(mock_cluster_list, 'Fake_cluster')

    # checking exit fail when update_cluster_profile is None
    @patch('lib.update_cluster_ha.OneviewConnector')
    def test_execute_none(self, mock_conn):
        res = self.update_clu_obj.execute(self.param)
        self.assertEqual(res['headers'], self.failed)

    @patch('lib.update_cluster_ha.OneviewConnector')
    def test_execute_if_true(self, mock_conn):
        fake_update_cluster_profile = {'hypervisorClusterSettings': {'haEnabled': True},
                                       }
        with mock.patch.object(Update_Cluster_Ha, 'get_cluster_profile', return_value=fake_update_cluster_profile):
            res = self.update_clu_obj.execute(self.param)
            self.assertEqual(res['headers'], self.success)

    @patch('lib.update_cluster_ha.OneviewConnector')
    def test_execute_if_false(self, mock_conn):
        fake_update_cluster_profile = {'hypervisorClusterSettings': {'haEnabled': False},
                                       }
        with mock.patch.object(Update_Cluster_Ha, 'get_cluster_profile', return_value=fake_update_cluster_profile):
            res = self.update_clu_obj.execute(self.param)
            self.assertEqual(res['headers'], self.failed)

    @patch('lib.update_cluster_ha.OneviewConnector',
           side_effect=HPOneViewException("No route to host"))
    def test_execute_exc_connection(self, mock_ov):
        result = self.update_clu_obj.execute(self.param)
        expected_result = self.param['_ov_host'] + ": " + \
                          "No route to host"
        self.assertEqual(result['headers'], self.failed)
        self.assertEqual(result['body']['nestedErrors'][0]['details'],
                         expected_result)

