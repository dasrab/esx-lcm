# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest

import mock
from mock import patch

from lib.common import utils
from lib.get_servers import Get_Servers


class TestGetServers(unittest.TestCase):

    def setUp(self):
        super(TestGetServers, self).setUp()
        self.get_server_obj = Get_Servers()

    def test_execute_server_present(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_servers') as (
                mock_get_servers):
            self.get_server_obj.execute(fake_params)
            self.assertTrue(mock_get_servers.called)

    def test_execute_no_server_present(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_servers', return_value=[]) as (
                mock_get_servers):
            self.get_server_obj.execute(fake_params)
            self.assertTrue(mock_get_servers.called)

    def test_execute_exception(self):
        fake_params = {'appliance_ip': '127.0.0.1'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_servers') as (
                mock_get_servers):
            self.get_server_obj.execute(fake_params)
            self.assertFalse(mock_get_servers.called)
