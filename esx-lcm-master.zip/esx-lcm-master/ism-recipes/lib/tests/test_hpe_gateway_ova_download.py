# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
import os
import unittest
import urlparse

from lib.hpe_gateway_ova_download import Hpe_Gateway_Ova_Download
from lib.hpeGateway import utils as hpe_gateway_util
from lib.hpeGateway.utils import Proxy_Server


mock_package_json = json.dumps({
    "services": [{"id": "1234-3456-5678-78910"}],
    "endpoints": [{
        "region": "vmware",
        "url": "https://test-ova-dev-11.platform9.net/public/links/",
        "interface": "public"},
        {"region": "vmware",
         "url": "https://test-ova-dev-11.platform9.net/internal/links/",
         "interface": "internal"}],
    "links": {
        "token2cookie": "https://test-ova-dev-11.platform9.net/token2cookie/",
        "vmware_appliance": "https://test-ova-dev-11.platform9.net/private/platform9-vmware-appliance-vmware.ova"}})


mock_info = {
    "vmware_appliance": "https://test-ova-dev-11.platform9.net/private/platform9-vmware-appliance-vmware.ova",
    "public_url": "https://test-ova-dev-11.platform9.net/links/",
    "cookie": "X-Auth-Token=gAAAAABZeY-oV1zl;Domain=test-ova-dev-11.platform9.net;Path=/;Max-Age=86400",
    "internal_url": "https://test-ova-dev-11.platform9.net/private/links.json"}


class TestOVADownloader(unittest.TestCase):

    def setUp(self):
        super(TestOVADownloader, self).setUp()
        self.hpe_gateway_obj = Hpe_Gateway_Ova_Download()
        self.hpe_gateway_util = hpe_gateway_util
        self.mock_token = "gAAAAABZeY-oV1zl"
        self.params = {
            "keystone_url": "https://test-ova-dev-11.platform9.net/keystone/v3",
            "region": "vmware",
            "user": "testuser@dummy.com",
            "password": "&&GATNNDDD",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"}

    def tearDown(self):
        try:
            ova_path = mock_info['vmware_appliance'][mock_info['vmware_appliance'].rfind('/') + 1:]
            os.remove(ova_path)
        except OSError:
            pass

    def _create_dummy_http_response_object(self, status, reason):
        class DummySocket():

            def makefile(self, *args, **kw):
                return self

        response = httplib.HTTPResponse(DummySocket())
        response.status = status
        response.reason = reason
        return response

    @unittest.skip("")
    def test_download_installer_success(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")

        with contextlib.nested(
            mock.patch('lib.hpeGateway.utils.do_request'),
            mock.patch.object(http_resp, "getheader", return_value="250"),
            mock.patch.object(http_resp, "read", return_value="")) as (
                mock_request, mock_header_length, mock_response_reader):
            package_url = mock_info["vmware_appliance"]
            installer_name = package_url.rsplit('/', 1)[1]
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_obj._download_installer(package_url,
                                             self.mock_token,
                                             mock_info["cookie"],
                                             installer_name)
            _, net_location, path, _, _ = urlparse.urlsplit(
                mock_info["vmware_appliance"])
            headers = {
                "X-Auth-Token": self.mock_token,
                "cookie": mock_info["cookie"]}
            body = ""
            mock_request.assert_called_with(
                "GET",
                net_location,
                path,
                headers,
                body)
            self.assertTrue(mock_header_length.called)
            # Check Exception not raised.
            mock_response_reader.assert_called_with(512 * 1024)
            installer_name = mock_info["vmware_appliance"].rsplit('/', 1)[1]
            ova_file_path = os.path.join(os.getcwd(), installer_name)
            # Check the downloaded file exists
            self.assertTrue(os.path.exists(ova_file_path))

    @unittest.skip("")
    def test_download_installer_raise_exception(self):
        http_resp = self._create_dummy_http_response_object(404, "Not Found")

        with contextlib.nested(
                mock.patch('lib.hpeGateway.utils.do_request'),
                mock.patch.object(http_resp, "getheader", return_value="250"),
                mock.patch.object(http_resp, "read", return_value="")) as (
                mock_request, mock_header_length, mock_response_reader):
            package_url = mock_info["vmware_appliance"]
            installer_name = package_url.rsplit('/', 1)[1]
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_obj._download_installer(package_url,
                                             self.mock_token,
                                             mock_info["cookie"],
                                             installer_name)
            _, net_location, path, _, _ = urlparse.urlsplit(
                mock_info["vmware_appliance"])
            headers = {
                "X-Auth-Token": self.mock_token,
                "cookie": mock_info["cookie"]}
            body = ""
            mock_request.assert_called_with(
                "GET",
                net_location,
                path,
                headers,
                body)
            self.assertTrue(mock_header_length.called)
            self.assertTrue(mock_response_reader.called)

    @unittest.skip("")
    def test_get_package_info_from_token_success(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")

        with contextlib.nested(
                mock.patch('lib.hpeGateway.utils.do_request'),
                mock.patch.object(http_resp, "getheader",
                                  return_value="Mock-Cookie"),
                mock.patch.object(http_resp, "read",
                                  return_value=mock_package_json)) as (
                mock_request, mock_header_length, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            resultant_info = self.hpe_gateway_obj._get_package_info_from_token(
                self.params["keystone_url"],
                self.mock_token,
                self.params["region"])
            mock_internal_url = "https://test-ova-dev-11.platform9.net/internal/links/"
            mock_public_url = "https://test-ova-dev-11.platform9.net/public/links/"
            self.assertEqual(mock_request.call_count, 5)
            self.assertEqual(mock_response_reader.call_count, 4)
            self.assertEqual(mock_header_length.call_count, 1)
            self.assertEqual(resultant_info["cookie"], "Mock-Cookie")
            self.assertEqual(resultant_info["internal_url"], mock_internal_url)
            self.assertEqual(resultant_info["public_url"], mock_public_url)
            self.assertEqual(
                resultant_info["vmware_appliance"],
                mock_info["vmware_appliance"])

    @unittest.skip("")
    def test_get_package_info_from_token_success_invalid_region(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        with contextlib.nested(
                mock.patch('lib.hpeGateway.utils.do_request'),
                mock.patch.object(http_resp, "getheader",
                                  return_value="Mock-Cookie"),
                mock.patch.object(http_resp, "read",
                                  return_value=mock_package_json)) as (
                mock_request, mock_header_length, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            resultant_info = self.hpe_gateway_obj._get_package_info_from_token(
                self.params["keystone_url"],
                self.mock_token,
                "invalid_region")
            self.assertEqual(mock_request.call_count, 2)
            self.assertEqual(mock_response_reader.call_count, 2)
            self.assertEqual(resultant_info, {})

    @unittest.skip("")
    def test_get_package_info_from_token_exception(self):
        http_resp = self._create_dummy_http_response_object(404, "Accepted")

        with contextlib.nested(
                mock.patch('lib.hpeGateway.utils.do_request', side_effect=Exception),
                mock.patch.object(http_resp, "getheader",
                                  return_value="Mock-Cookie"),
                mock.patch.object(http_resp, "read",
                                  return_value=mock_package_json)) as (
                mock_request, mock_header_length, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.assertRaises(Exception,
                              self.hpe_gateway_obj._get_package_info_from_token,
                              self.params["keystone_url"],
                              self.mock_token,
                              self.params["region"])
            self.assertTrue(mock_request.called)
            self.assertFalse(mock_header_length.called)
            self.assertFalse(mock_response_reader.called)

    @unittest.skip("")
    def test_execute_ova_download(self):
        with contextlib.nested(
            mock.patch('lib.hpeGateway.utils.get_token_v3',
                       return_value=self.mock_token),
            mock.patch.object(self.hpe_gateway_obj, "_get_package_info_from_token",
                              return_value=mock_info),
            mock.patch("os.path.exists", return_value=False),
            mock.patch.object(self.hpe_gateway_obj, "_download_installer")) as (
                mock_get_token, mock_get_package, mock_path, mock_downloader):
            self.hpe_gateway_obj.execute(self.params)
            mock_get_token.assert_called_with(self.params["keystone_url"],
                                              self.params["user"],
                                              self.params["password"],
                                              self.params["tenant"])
            mock_get_package.assert_called_with(self.params["keystone_url"],
                                                self.mock_token,
                                                self.params["region"])
            self.assertTrue(mock_path.called)
            package_url = mock_info["vmware_appliance"]
            installer_name = package_url.rsplit('/', 1)[1]
            mock_server, mock_port = Proxy_Server.get_proxy_details()
            self.assertEqual(mock_server, self.params["proxy_server"])
            self.assertEqual(mock_port, self.params["proxy_port"])
            mock_downloader.assert_called_with(package_url,
                                               self.mock_token,
                                               mock_info["cookie"],
                                               installer_name)

    @unittest.skip("")
    def test_execute_ova_download_invalid_region(self):
        with contextlib.nested(
            mock.patch('lib.hpeGateway.utils.get_token_v3',
                       return_value=self.mock_token),
            mock.patch.object(self.hpe_gateway_obj, "_get_package_info_from_token",
                              return_value={}),
            mock.patch("os.path.exists", return_value=False),
            mock.patch.object(self.hpe_gateway_obj, "exit_fail")) as (
                mock_get_token, mock_get_package, mock_path, mock_exit_fail):
            self.hpe_gateway_obj.execute(self.params)
            mock_get_token.assert_called_with(self.params["keystone_url"],
                                              self.params["user"],
                                              self.params["password"],
                                              self.params["tenant"])
            mock_get_package.assert_called_with(self.params["keystone_url"],
                                                self.mock_token,
                                                self.params["region"])
            self.assertTrue(mock_exit_fail.called)

    @unittest.skip("")
    def test_execute_ova_present_already(self):
        with contextlib.nested(
            mock.patch('lib.hpeGateway.utils.get_token_v3',
                       return_value=self.mock_token),
            mock.patch.object(self.hpe_gateway_obj, "_get_package_info_from_token",
                              return_value=mock_info),
            mock.patch("os.path.exists", return_value=True),
            mock.patch.object(self.hpe_gateway_obj.LOG, "debug"),
            mock.patch.object(self.hpe_gateway_obj, "_download_installer")) as (
            mock_get_token, mock_get_package, mock_path, mock_log,
                mock_downloader):
            self.hpe_gateway_obj.execute(self.params)
            mock_server, mock_port = Proxy_Server.get_proxy_details()
            self.assertEqual(mock_server, self.params["proxy_server"])
            self.assertEqual(mock_port, self.params["proxy_port"])
            mock_get_token.assert_called_with(self.params["keystone_url"],
                                              self.params["user"],
                                              self.params["password"],
                                              self.params["tenant"])
            mock_get_package.assert_called_with(self.params["keystone_url"],
                                                self.mock_token,
                                                self.params["region"])
            self.assertTrue(mock_path.called)
            self.assertTrue(mock_log.called)
            self.assertFalse(mock_downloader.called)
