# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import unittest
import mock
from lib.login import Login
from orch.ism_sdk.activity import Ism_Error
from hpOneView.exceptions import HPOneViewException


class Login_test(unittest.TestCase):
    def setUp(self):
        self.login_obj = Login()
        self.mock_params = {'_ov_host': "10.0.0.10",
                            '_ov_port': 443,
                            '_username': "mock_username",
                            '_password': "mock_password"}
        self.oneview_version = 500
        self.fake_host = '10.0.0.10:443'

    @mock.patch('hpOneView.connection.get_eula_status')
    @mock.patch('hpOneView.connection.login')
    def test_execute(self, mock_conn, mock_getstatus):
        mock_getstatus.return_value = False
        with mock.patch.object(self.login_obj.LOG, "debug") as (mock_log):
            self.login_obj.execute(self.mock_params)

    # SYN_ISM_LOGIN_ONEVIEW_FAILED
    @mock.patch('hpOneView.connection.login')
    def test_execute_cred_fail(self, mock_conn):
        self.param = {'_ov_host': "10.0.0.1",
                      '_ov_port': 443}
        mock_conn.side_effect = [HPOneViewException]
        self.assertRaises(Ism_Error, self.login_obj.execute, self.param)

    # Connection timed out
    @mock.patch('hpOneView.connection.login')
    def test_execute_excp(self, mock_conn):
        mock_conn.side_effect = [Exception]
        self.param = {}
        with mock.patch.object(self.login_obj.LOG, "debug") as (mock_log):
            self.assertRaises(
                Ism_Error, self.login_obj.execute, self.mock_params)

    # SYN_ISM_UNABLE_TO_EULA_ONEVIEW
    @mock.patch('hpOneView.connection.get_eula_status')
    @mock.patch('hpOneView.connection.login')
    def test_execute_oV_excp(self, mock_conn, mock_getstatus):
        mock_getstatus.side_effect = [Exception]
        self.param = {}
        with mock.patch.object(self.login_obj.LOG, "debug") as (mock_log):
            self.assertRaises(
                Ism_Error, self.login_obj.execute, self.mock_params)

    @mock.patch('hpOneView.connection.get_eula_status')
    @mock.patch('hpOneView.connection.login')
    def test_execute_login_success(self, m_conn, mock_getstatus):
            self.login_obj.execute(self.mock_params)
            m_conn.assert_called_with({'userName': 'mock_username', 'password': 'mock_password'})
            self.assertEqual(m_conn.call_count, 1)
