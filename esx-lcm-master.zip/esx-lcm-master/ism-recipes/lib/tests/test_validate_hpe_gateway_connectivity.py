# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import mock
import unittest

from lib.hpeGateway import utils
from lib import validate_hpe_gateway_connectivity


class TestValidate_Hpe_Gateway_Connectivity(unittest.TestCase):

    def setUp(self):
        super(TestValidate_Hpe_Gateway_Connectivity, self).setUp()
        self.validate_hpe_gateway_connectivity_obj = (
            validate_hpe_gateway_connectivity.Validate_Hpe_Gateway_Connectivity())

    def test_execute_success(self):
        fake_params = {
            "keystone_url": "https://test-ova-dev.platform9.net/keystone/v3",
            "username": "xyz@qbc.com",
            "password": "123456abcdefgh",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"}
        with mock.patch.object(utils,
                               'get_token_v3') as (mock_get_token_v3):
            result = self.validate_hpe_gateway_connectivity_obj.execute(fake_params)
            self.assertTrue(mock_get_token_v3.called)
            self.assertEqual(result['body']['is_valid'], True)

    def test_execute_failure(self):
        fake_params = {
            "keystone_url": "https://test-ova-dev.platform9.net/keystone/v3",
            "username": "xyz@qbc.com",
            "password": "123456abcdefgh",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"}
        with mock.patch.object(utils,
                               'get_token_v3') as (mock_get_token_v3):
            mock_get_token_v3.side_effect = Exception()
            result = self.validate_hpe_gateway_connectivity_obj.execute(fake_params)
            self.assertTrue(mock_get_token_v3.called)
            self.assertEqual(result['body']['is_valid'], False)


if __name__ == '__main__':
    unittest.main()
