#!/usr/bin/env python
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
'''
Created on June 21, 2016

@author: Harish.arora@hpe.com
'''
import unittest
from lib.update_cluster_profile import Update_Cluster_Profile
from mock import Mock
from mock import patch

update_cluster_profile = Update_Cluster_Profile()


params = {
    "_ovhost": "10.0.0.0",
    "_auth": "LTMwNjQ5MjEyMTE3oLtyrisVhSlXiIvySti3su61qzSMrmXr",
    "_hypervisor_settings":
        {
            "hypervisorCluster": {"clusterPrefix": "test", "name": "cluster2"},
            "hypervisorManager": {"datacenterPath": "Sushil-DC", "type": "vSphere",
                                  "username": "administrator@vsphere.local", "password": "Hellfire!234",
                                  "ipAddress": "10.10.0.25"},
            "hypervisorHost": {"username": "root", "password": "vmware6"},
            "hypervisor_manager_uri": "/rest/hypervisor-manager/1"
        },
    "_server_profile_template_uri": [
        {"server_profile_template_uri": "/rest/server-profile-templates/ec7c1add-b8bf-4fb0-8ffd-4578bd0c28ca",
         "state": "Completed"}],
    "_network_uris": [{"uri": "/rest/management-network/1"}],
    "_servers": [{"username": "_hcoe_user",
                  "federationGroup": "Hellfire",
                  "serverHardwareTypeUri": "/rest/server-hardware-types/12D0895D-E3A7-4BE9-8631-8DDBA3749B82",
                  "uuid": "4C4C4548-4946-4753-4836-313258353256", "created": "2016-08-24T01:00:34.90194912Z",
                  "serialNumber": "SGH612X52V",
                  "modified": "2016-08-24T01:00:34.90194943Z",
                  "uri": "/rest/unmanaged-servers/4C4C4548-4946-4753-4836-313258353256",
                  "iloIpAddress": "fe80::1602:ecff:fe3b:adf8",
                  "serverHardwareUri": "/rest/server-hardware/4C4C4548-4946-4753-4836-313258353256",
                  "unmanagedServerUri": "/rest/unmanaged-services/",
                  "password": "_hcoe_user", "type": "unmanaged-server", "seedNode": False}],
    "_host_credentials": {"password": "mock_pass"}
}

expectedValue = {'module_status': 'SUCCESS'}


class update_cluster_profile_unittest (unittest.TestCase):
    '''
    def testExecute_withoutMock(self):
        self.assertFalse(create_cluster_profile().execute(hypervisorHostProfileUris) ==  expectedValue)
    '''

    def testExecute_update_cluster_profile(self):
        create_cluster_profile = Mock()
        outputs = {
            'method.return_value': expectedValue,
            'keyError.side_effect': KeyError}
        create_cluster_profile.configure_mock(**outputs)
        self.assertEqual(create_cluster_profile.method(), expectedValue)

    @patch('lib.create_cluster_profile.OneviewConnector')
    def testExecute_exception_check(self, hpOv):
        obj = Update_Cluster_Profile()
        self.assertRaises(Exception, obj.execute)

    @patch('lib.update_cluster_profile.OneviewConnector')
    def testExecute_execute(self, hpOv):
        ov_instance = hpOv.return_value
        ov_instance.connection.return_value = True
        update_cluster_profile.return_value = True
        update_cluster_profile.parent_id = True
        update_cluster_profile.private_request.hostname = "localhost:8082"
        update_cluster_profile.infrastructure_system_uri = None
        update_cluster_profile.parent_id = None
        hpOv.add_task(hpOv, hpOv)
        update_cluster_profile.update_cluster_profile = update_cluster_profile.update_cluster_profile(
            hpOv, hpOv)
        cluster_profile = hpOv
        cluster_profile.get_cluster_profile_by_uri.return_value = expectedValue
        result = update_cluster_profile.execute(params)
        self.assertEqual(result['headers'], expectedValue)

    @patch('lib.update_cluster_profile.OneviewConnector')
    def testExecute_update_cluster_profile(self, hpOv):

        cluster_profile = hpOv
        cluster_profile.get_cluster_profile_by_uri.return_value = expectedValue
        result = update_cluster_profile.update_cluster_profile(
            cluster_profile,
            params['_hypervisor_settings']['hypervisorCluster']['clusterPrefix'],
            params['_hypervisor_settings']['hypervisorManager']['type'],
            params['_server_profile_template_uri'],
            '/rest/deployment-plan-uri',
            params['_host_credentials']['password'],
            '/rest/server-hardware-uri',
            '/rest/hypervisor-manager/1',
            params['_network_uris'],
            'abc-path',
            True).return_value = expectedValue

        self.assertEqual(result, expectedValue)

    @patch('lib.update_cluster_profile.OneviewConnector')
    def testExecute_delete_server_exception_check(self, hpOv):
        self.assertRaises(Exception, update_cluster_profile.execute)


if __name__ == '__main__':
    unittest.main()
