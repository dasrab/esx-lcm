# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import mock
import unittest
import requests

from mock import mock_open

from lib.common import utils
from lib.common import constants

fake_params = {'appliance_ip': '127.0.0.1',
               'appliance_port': '9000'}

fake_network_map = {
    "ncsManagementNetwork": "dcm_net",
    "storageNetwork": "vsan_net",
    "vMotionNetwork": "vmotion_net",
    "esxManagementNetwork": "ft_net",
    "productionNetworks": [
        "tenant_net1",
        "tenant_net2",
    ]
}

fake_net_map_list = {
    "ncsManagementNetwork": ["dcm_net"],
    "storageNetwork": ["vsan_net"],
    "vMotionNetwork": ["vmotion_net"],
    "esxManagementNetwork": ["ft_net"],
    "productionNetworks": [
        "tenant_net1",
    ]
}

fake_platform_profile_template = {
    "name": "SY480-Gen9-Low-Density",
    "description": "provides cloud with hybrid vsan datastore and optimal storage to compute density",
    "server_type": "SY480_gen9",
    "host_disks": {
        "capacity_drive_type": "bigbird:SAS",
        "capacity_drive_count": 1,
        "capacity_driv_size_tb": 2,
        "cache_drive_type": "local:HDD",
        "cache_drive_count": 1,
        "cache_drive_size_gb": 800}}

fake_l2_networks = [{"ethernetNetworkType": "Tagged", "name": "tenant_net1", "purpose": "General",
    "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/7918f982-ed02-428c-a8cb-f9f06a41916f",
    "vlanId": 350},
  {"ethernetNetworkType": "Tagged", "name": "dcm_net", "purpose": "Management",
   "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/93929d64-c9aa-4bbf-84b2-85c16b1f6a92",
    "vlanId": 332},
  {"ethernetNetworkType": "Tagged", "name": "ft_net", "purpose": "Management",
   "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/83929d64-c9aa-4bbf-84b2-85c16b1f6a83",
    "vlanId": 333},
  {"ethernetNetworkType": "Tagged", "name": "Deployment", "purpose": "ISCSI",
    "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/9ba96004-f450-43fe-86d7-ac5b65caede7",
    "vlanId": 2},
  {"ethernetNetworkType": "Tagged", "name": "vmotion_net", "purpose": "VMMigration",
    "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/afaa726c-7923-4215-8c99-c7166154e60d",
    "vlanId": 330},
  {"ethernetNetworkType": "Tagged", "name": "vsan_net", "purpose": "ISCSI",
    "uri": "/rest/appliances/9287544d-73e6-4f72-883c-4f51bcdeefe0/ethernet-networks/f90957c6-e303-477d-82af-cadad2c954f6",
    "vlanId": 329}]

fake_sbp = {
    "networkMap": [
      {
        "name": "SBP.ESX.MGMT",
        "netUris": [
          "DCM"
        ]
      },
      {
        "name": "SBP.ESX.vMOTION",
        "netUris": [
          "Vmotion"
        ]
      },
      {
        "name": "SBP.NCS.MGMT",
        "netUris": [
          "DCM"
        ]
      },
      {
        "name": "SBP.ESX.vSAN",
        "netUris": [
          "VSAN"
        ]
      },
      {
        "name": "SBP.ESX.GUEST.Tenant",
        "netUris": [
          "Production"
        ]
      },
      {
        "deployNetwork": "true",
        "name": "SBP.ESX.Deployment"
      }
    ],
    "networkSetBlueprints": [
      {
        "name": "ESX.Management",
        "nsUri": [
          "/rest/network-sets/92ee878a-9734-40d0-9991-f06dda3b2269"
        ]
      },
      {
        "name": "ESX.Storage",
        "nsUri": [
          "/rest/network-sets/e1005b3e-1621-4c30-9fd3-545c4463bb99"
        ]
      },
      {
        "name": "ESX.Data",
        "nsUri": [
          "/rest/network-sets/c861a211-d8c2-495e-830f-2c26bc7f58fd"
        ]
      }
    ],
    "serverProfileTemplateBlueprint": {
      "OSDeploymentPlanName": "esx-65-deployment-plan",
      "blueprint": {
        "boot": {
          "order": [
            "HardDisk"
          ]
        },
        "bootMode": {
          "mode": "UEFIOptimized",
          "pxeBootPolicy": "Auto"
        },
        "connectionSettings": {
          "connections": [
            {
              "name": "Deployment Network A",
              "networkUri": {
                "$ref": "#/refs/networks/SBP.ESX.Deployment/uri"
              },
              "portId": "Mezz 3:1-a"
            },
            {
              "name": "Deployment Network B",
              "networkUri": {
                "$ref": "#/refs/networks/SBP.ESX.Deployment/uri"
              },
              "portId": "Mezz 3:2-a"
            },
            {
              "name": "Management Network A",
              "networkUri": {
                "$ref": "#/refs/networksets/ESX.Management/uri"
              },
              "portId": "Mezz 3:1-b"
            },
            {
              "name": "Management Network B",
              "networkUri": {
                "$ref": "#/refs/networksets/ESX.Management/uri"
              },
              "portId": "Mezz 3:2-b"
            },
            {
              "name": "Storage Network",
              "networkUri": {
                "$ref": "#/refs/networksets/ESX.Storage/uri"
              },
              "portId": "Mezz 3:1-d"
            },
            {
              "name": "Data Network A",
              "networkUri": {
                "$ref": "#/refs/networksets/ESX.Data/uri"
              },
              "portId": "Mezz 3:1-c"
            },
            {
              "name": "Data Network B",
              "networkUri": {
                "$ref": "#/refs/networksets/ESX.Data/uri"
              },
              "portId": "Mezz 3:2-c"
            }
          ],
        },
      },
    },
  }


class FakeResponse(object):

    status_code = 200

    def json(self):
        return "Success"

    def raise_for_status(self):
        return Exception("Failure")


class TestCommonUtils(unittest.TestCase):

    def setUp(self):
        super(TestCommonUtils, self).setUp()
        self.appman_proxy_obj = utils.ApplianceManagerProxy(fake_params)
        self.diskmodel_obj = utils.DiskModelRenderer(
            fake_platform_profile_template)
        self.networkmodel_obj = utils.NetworkModelRenderer(fake_network_map)
        self.switchLayout_obj = utils.SwitchLayoutRenderer(fake_l2_networks, fake_sbp,
                                                           fake_net_map_list)

    def test_create_sbp_request_success(self):
        fake_data = {'name': 'sbp'}
        FakeResponse.status_code = 201
        with mock.patch('requests.post',
                        return_value=FakeResponse()) as mock_post:
            self.appman_proxy_obj.create_serverblueprint(fake_data)
            self.assertTrue(mock_post.called)

    def test_create_sbp_request_failure(self):
        fake_data = {'name': 'sbp'}
        FakeResponse.status_code = 409
        with mock.patch('requests.post',
                        return_value=FakeResponse()) as mock_post:
            self.assertRaises(
                Exception,
                lambda: self.appman_proxy_obj.create_serverblueprint(fake_data))
            self.assertTrue(mock_post.called)

    def test_get_serverblueprints_request_success(self):
        FakeResponse.status_code = 200
        with mock.patch('requests.get',
                        return_value=FakeResponse()) as mock_get:
            self.appman_proxy_obj.get_serverblueprints()
            self.assertTrue(mock_get.called)

    def test_get_serverblueprints_request_failure(self):
        FakeResponse.status_code = 404
        with mock.patch('requests.get',
                        return_value=FakeResponse()) as mock_get:
            self.assertRaises(
                Exception,
                lambda: self.appman_proxy_obj.get_serverblueprints())
            self.assertTrue(mock_get.called)

    def test_get_serverblueprint_by_uri(self):
        FakeResponse.status_code = 200
        with mock.patch.object(requests, 'get',
                               return_value=FakeResponse()) as mock_get:
            result = self.appman_proxy_obj.get_serverblueprint_by_uri(
                '/rest/serverblueprints/ABC1234')
            self.assertEqual(result, 'Success')
            self.assertTrue(mock_get.called)

    def test_get_serverblueprint_by_uri_raise_error(self):
        FakeResponse.status_code = 404
        with mock.patch.object(requests, 'get',
                               return_value=FakeResponse()) as mock_get:
            self.assertRaises(Exception,
                              lambda: self.appman_proxy_obj.get_serverblueprint_by_uri(
                                  '/rest/serverblueprints/ABC1234'))
            self.assertTrue(mock_get.called)

    def test_delete_serverblueprint_by_uri(self):
        FakeResponse.status_code = 204
        with mock.patch.object(requests, 'delete',
                               return_value=FakeResponse()) as mock_delete:
            result = self.appman_proxy_obj.delete_serverblueprint_by_uri(
                '/rest/serverblueprints/ABC1234')
            self.assertEqual(result, 'Success')
            self.assertTrue(mock_delete.called)

    def test_delete_serverblueprint_by_uri_raise_error(self):
        FakeResponse.status_code = 404
        with mock.patch.object(requests, 'delete',
                               return_value=FakeResponse()) as mock_delete:
            self.assertRaises(Exception,
                              lambda: self.appman_proxy_obj.delete_serverblueprint_by_uri(
                                  '/rest/serverblueprints/ABC1234'))
            self.assertTrue(mock_delete.called)

    def test_allocate_server_request_success(self):
        fake_data = {'name': 'server1'}
        FakeResponse.status_code = 201
        with mock.patch('requests.post',
                        return_value=FakeResponse()) as mock_post:
            self.appman_proxy_obj.allocate_server(fake_data)
            self.assertTrue(mock_post.called)

    def test_allocate_server_request_failure(self):
        fake_data = {'name': 'server1'}
        FakeResponse.status_code = 409
        with mock.patch('requests.post',
                        return_value=FakeResponse()) as mock_post:
            self.assertRaises(
                Exception,
                lambda: self.appman_proxy_obj.allocate_server(fake_data))
            self.assertTrue(mock_post.called)

    def test_deallocate_server_request_success(self):
        fake_uri = "/rest/servers/server1"
        FakeResponse.status_code = 204
        with mock.patch('requests.delete',
                        return_value=FakeResponse()) as mock_delete:
            self.appman_proxy_obj.deallocate_server(fake_uri)
            self.assertTrue(mock_delete.called)

    def test_deallocate_server_request_failure(self):
        fake_uri = "/rest/servers/server1"
        FakeResponse.status_code = 404
        with mock.patch('requests.delete',
                        return_value=FakeResponse()) as mock_delete:
            self.assertRaises(
                Exception,
                lambda: self.appman_proxy_obj.deallocate_server(fake_uri))
            self.assertTrue(mock_delete.called)

    def test_validate_and_fetch_disk_type_exception(self):
        result = self.assertRaises(
            Exception,
            lambda: self.diskmodel_obj._validate_and_fetch_disk_type("bigbird:Sas"))
        self.assertFalse(result)

    def test_validate_and_fetch_disk_size_exception(self):
        result = self.assertRaises(
            Exception,
            lambda: self.diskmodel_obj._validate_and_fetch_disk_size(
                str(2)))
        self.assertFalse(result)

    def test_read_json(self):
        filename = "fake_doc.txt"
        with mock.patch("__builtin__.open",
                        mock_open(read_data="data")) as mock_file:
            self.assertRaises(Exception,
                              lambda: utils.read_json(filename))
            self.assertTrue(mock_file.called)

    def test_get_ethernet_network(self):
        result = self.switchLayout_obj._get_ethernet_network()
        self.assertEqual(result['esxManagementNetwork']['ethernet_name'],
                         fake_net_map_list['esxManagementNetwork'][0] )
        self.assertEqual(result['productionNetworks']['ethernet_name'],
                         fake_net_map_list['productionNetworks'][0] )
        self.assertEqual(result['vMotionNetwork']['ethernet_name'],
                         fake_net_map_list['vMotionNetwork'][0] )
        self.assertEqual(result['ncsManagementNetwork']['ethernet_name'],
                         fake_net_map_list['ncsManagementNetwork'][0] )
        self.assertEqual(result['storageNetwork']['ethernet_name'],
                         fake_net_map_list['storageNetwork'][0] )
        self.assertEqual(result['esxManagementNetwork']['vlanId'],
                        fake_l2_networks[2]['vlanId'])
        self.assertEqual(result['vMotionNetwork']['vlanId'],
                        fake_l2_networks[4]['vlanId'])

    def test_create_ethernetwork_and_networkset_map(self):
        fake_eth_net_dict = {
            'esxManagementNetwork': {
                'ethernet_name': 'ft_net',
                'uri': '/rest/ethernet-networks/83929d64-c9aa-4bbf-84b2-85c16b1f6a83',
                'vlanId': 333, 'purpose': 'Management'},
            'productionNetworks': {
                'ethernet_name': 'tenant_net1',
                'uri': '/rest/ethernet-networks/7918f982-ed02-428c-a8cb-f9f06a41916f',
                'vlanId': 350, 'purpose': 'General'},
            'vMotionNetwork': {
                'ethernet_name': 'vmotion_net',
                'uri': '/rest/ethernet-networks/afaa726c-7923-4215-8c99-c7166154e60d',
                'vlanId': 330, 'purpose': 'VMMigration'},
            'ncsManagementNetwork': {
                'ethernet_name': 'dcm_net',
                'uri': '/rest/ethernet-networks/93929d64-c9aa-4bbf-84b2-85c16b1f6a92',
                'vlanId': 332, 'purpose': 'Management'},
            'storageNetwork': {
                'ethernet_name': 'vsan_net',
                'uri': '/rest/ethernet-networks/f90957c6-e303-477d-82af-cadad2c954f6',
                'vlanId': 329, 'purpose': 'ISCSI'}}
        with mock.patch.object(utils.SwitchLayoutRenderer,
                               "_get_ethernet_network",
                        return_value=fake_eth_net_dict) as (
                        mock_get_ethernet_network):
            self.switchLayout_obj._create_ethernetwork_and_networkset_map()
            self.assertTrue(mock_get_ethernet_network.called)
