# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import unittest
import mock
from mock import patch

from lib.common.vcenter_utils import VcenterUtils
from lib import validate_deletion
from lib.validate_deletion import Validate_Deletion

expectedValue = {'module_status': 'SUCCESS'}


class FakeVM(object):

    def __init__(self):
        pass


class FakeHostId(object):

    def __init__(self):
        self.vm = [FakeVM()]


class FakeHostIdWithoutVM(object):

    def __init__(self):
        self.vm = []


class FakeCluster(object):

    def __init__(self):
        self.host = [FakeHostId()]


class Test_Validate_Deletion(unittest.TestCase):

    def setUp(self):
        self.params = {
            "_vc_ip": "10.0.0.0",
            "_vc_port": 443,
            "_username": "Administrator@vsphere.local",
            "_password": "Pass",
            "_datacenterPath": "DC",
            "_cluster_prefix": "Cluster1",
        }

    @patch.object(VcenterUtils, 'get_cluster_by_datacenter')
    @patch.object(VcenterUtils, 'get_service_instance')
    def test_execute_vm_running(
            self,
            mocked_vc_connect,
            mocked_get_cluster_by_dc):
        class_obj = Validate_Deletion()

        mocked_get_cluster_by_dc.return_value = FakeCluster()
        returnValue = class_obj.execute(self.params)
        module_status = returnValue.get("headers")["module_status"]
        actual_message = returnValue.get("body")["nestedErrors"][0]["details"]
        expected_status = "FAIL"
        expected_message = "Virtual machine instances are running on the compute node"
        self.assertEqual(module_status, expected_status)
        self.assertEqual(actual_message, expected_message)
        mocked_vc_connect.assert_called_once_with(
            '10.0.0.0', 'Administrator@vsphere.local', 'Pass', 443)

    @patch.object(VcenterUtils, 'get_cluster_by_datacenter')
    @patch.object(VcenterUtils, 'get_service_instance')
    def test_execute_success(
            self,
            mocked_vc_connect,
            mocked_get_cluster_by_dc):
        class_obj = validate_deletion.Validate_Deletion()
        fc = FakeCluster()
        fc.host = [FakeHostIdWithoutVM()]
        mocked_get_cluster_by_dc.return_value = fc
        returnValue = class_obj.execute(self.params)
        module_status = returnValue.get("headers")["module_status"]
        expected_status = "SUCCESS"
        self.assertEqual(module_status, expected_status)
        mocked_vc_connect.assert_called_once_with(
            '10.0.0.0', 'Administrator@vsphere.local', 'Pass', 443)
