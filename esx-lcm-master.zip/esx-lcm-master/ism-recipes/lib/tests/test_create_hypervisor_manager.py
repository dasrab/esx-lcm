# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import unittest
import mock
from mock import patch
from lib.create_hypervisor_manager import Create_Hypervisor_Manager
import hpOneView as ov

params = {
    "_auth": "LTQ4MjcyMjUxMTA3pQuO4S_1A1Ujk-O9vnhE5AwId6DhoFkj",
    "_ov_host": "10.10.10.1",
    '_ov_port': 443,
    "_hypervisor_type": "vSphere",
    "_hypervisor_manager_credentials": {
        "ipAddress": "10.10.10.2",
        "username": "username",
        "password": "password",
        }

}

moduleStatus_succ = {'module_status': 'SUCCESS'}
moduleStatus_fail = {'module_status': 'FAIL'}


class Create_Hypervisor_Manager_unittest(unittest.TestCase):

    def test_execute_success(self):
        fake_hypervisor_obj = {'uri': "fake_uri"}

        with mock.patch.object(
                Create_Hypervisor_Manager, 'create_hypervisor_manager',
                return_value=fake_hypervisor_obj):
            obj = Create_Hypervisor_Manager()
            result = obj.execute(params)

            self.assertEqual(result['headers'], moduleStatus_succ)

    @patch('lib.create_hypervisor_manager.sleep')
    def test_execute_exception(self, _mock_sleep):
        _mock_sleep.return_value = 0
        fake_hypervisor_obj = {'uri'}

        with mock.patch.object(
                Create_Hypervisor_Manager, 'create_hypervisor_manager',
                return_value=fake_hypervisor_obj):
            obj = Create_Hypervisor_Manager()
            result = obj.execute(params)

            self.assertTrue(_mock_sleep.called)
            self.assertEqual(result['headers'], moduleStatus_fail)

