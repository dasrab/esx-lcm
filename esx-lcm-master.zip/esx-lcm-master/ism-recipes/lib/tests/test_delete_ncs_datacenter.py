# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
import contextlib
import mock
import unittest

from common.vcenter_utils import VcenterUtils
from lib.delete_ncs_datacenter import Delete_Ncs_Datacenter


fake_params = {'vc_host': 'fake_host',
               'vc_user': 'fake_user',
               'vc_password': 'fake_password',
               'vc_port': '443',
               'datacenter_name': 'fake_datacenter'}

fake_vc_instance = mock.Mock()
fake_dc_object = {'name': 'fake-dc',
                  'id': 'fake-id'}

class Test_Delete_Ncs_Datacenter(unittest.TestCase):

    def setUp(self):
        super(Test_Delete_Ncs_Datacenter, self).setUp()
        self.del_ncs_dc = Delete_Ncs_Datacenter()

    def test_execute_success_dc_exists(self):
        success_msg = "Successfully deleted datacenter 'fake_datacenter'"
        with contextlib.nested(
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_service_instance',
                              return_value=fake_vc_instance),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_obj',
                              return_value=fake_dc_object),
            mock.patch.object(self.del_ncs_dc.LOG,
                              'info'),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                'delete_datacenter')) as (mock_get_svc,
                                        mock_get_dc,
                                        mock_log_info,
                                        mock_del_dc):
            return_value = self.del_ncs_dc.execute(fake_params)
            self.assertEqual(mock_get_dc.call_count, 1)
            self.assertEqual(mock_get_svc.call_count, 1)
            self.assertEqual(mock_log_info.call_count, 1)
            self.assertEqual(mock_del_dc.call_count, 1)
            self.assertEqual(return_value['body'], True)
            mock_log_info.assert_called_with(success_msg)

    def test_execute_success_dc_not_exists(self):
        return_msg = "Datacenter with given name not found.."
        with contextlib.nested(
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_service_instance',
                              return_value=fake_vc_instance),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_obj',
                              return_value=None),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                'delete_datacenter')) as (mock_get_svc,
                                        mock_get_dc,
                                        mock_del_dc):
            return_value = self.del_ncs_dc.execute(fake_params)
            self.assertEqual(mock_get_dc.call_count, 1)
            self.assertEqual(mock_get_svc.call_count, 1)
            self.assertEqual(mock_del_dc.call_count, 0)
            self.assertEqual(return_value['body'], return_msg)

    def test_execute_failure_exception(self):
        err_msg = "Failed to delete Datacenter in vCenter 'fake_datacenter'"
        with contextlib.nested(
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_service_instance',
                              return_value=fake_vc_instance),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                              'get_obj',
                              side_effect=Exception()),
            mock.patch.object(self.del_ncs_dc.LOG,
                              'exception'),
            mock.patch.object(self.del_ncs_dc._vc_utils,
                'delete_datacenter')) as (mock_get_svc,
                                        mock_get_dc,
                                        mock_log_exception,
                                        mock_del_dc):
            return_value = self.del_ncs_dc.execute(fake_params)
            self.assertEqual(mock_get_dc.call_count, 1)
            self.assertEqual(mock_get_svc.call_count, 1)
            self.assertEqual(mock_log_exception.call_count, 1)
            self.assertEqual(mock_del_dc.call_count, 0)
            mock_log_exception.assert_called_with(err_msg)
