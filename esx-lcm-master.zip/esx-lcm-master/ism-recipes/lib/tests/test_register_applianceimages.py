# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest
import mock

from lib.common import utils
from lib.common import models
from lib.register_applianceimages import Register_Applianceimages


class TestRegisterApplianceimages(unittest.TestCase):

    def setUp(self):
        super(TestRegisterApplianceimages, self).setUp()
        self.register_appimage_obj = Register_Applianceimages()

    def test_execute_success(self):
        fake_params = {'appliance_image_name': 'APPLIANCE_IMAGE1',
                       'image_artifact_url': '/rest/image_artifact',
                       'target_appliance_uri': '/rest/target/appliance',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        mock_result = {'name': 'APPLIANCE_IMAGE1_001',
                       'imageUrl': '/rest/image/url',
                       'applianceUri': '/rest/appliance/uri',
                       'uri': '/rest/applianceimage/uri',
                       'state': 'Created'}
        with contextlib.nested(
                mock.patch.object(utils.ApplianceManagerProxy,
                                  'register_applianceimage', return_value=mock_result),
                mock.patch.object(models.ApplianceImage, '_get_uri')) as (
                mock_register, mock_get_uri):
            self.register_appimage_obj.execute(fake_params)
            self.assertTrue(mock_register.called)
            mock_get_uri.assert_called_with()

    def test_execute_failure_for_keyerror(self):
        fake_params = {'appliance_image_name': 'APPLIANCE_IMAGE1',
                       'image_artifact_url': '/rest/image_artifact',
                       'target_appliance_uri': '/rest/target/appliance',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        mock_result = {'name': 'APPLIANCE_IMAGE1_001',
                       'state': 'Created'}
        with contextlib.nested(
                mock.patch.object(utils.ApplianceManagerProxy,
                                  'register_applianceimage', return_value=mock_result),
                mock.patch.object(models.ApplianceImage, '_get_uri')) as (
                mock_register, mock_get_uri):
            self.register_appimage_obj.execute(fake_params)
            self.assertTrue(mock_register.called)
            self.assertFalse(mock_get_uri.called)

    def test_execute_exception(self):
        fake_params = {'appliance_image_name': 'APPLIANCE_IMAGE1',
                       'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'register_applianceimage') as mock_register:
            self.register_appimage_obj.execute(fake_params)
            self.assertFalse(mock_register.called)


if __name__ == '__main__':
    unittest.main()
