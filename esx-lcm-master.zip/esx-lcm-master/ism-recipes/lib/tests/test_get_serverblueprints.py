# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
import mock

from lib.common import utils
from lib.get_serverblueprints import Get_Serverblueprints


class TestGetServerblueprints(unittest.TestCase):

    def setUp(self):
        super(TestGetServerblueprints, self).setUp()
        self.get_sbp_obj = Get_Serverblueprints()

    def test_execute_success(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_serverblueprints') as (mock_get_serverblueprints):
            self.get_sbp_obj.execute(fake_params)
            self.assertTrue(mock_get_serverblueprints.called)

    def test_execute_with_result_None(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_serverblueprints', return_value={}) as (
                mock_get_serverblueprints):
            self.get_sbp_obj.execute(fake_params)
            self.assertTrue(mock_get_serverblueprints.called)

    def test_execute_failure(self):
        fake_params = {'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_serverblueprints') as (mock_get_serverblueprints):
            self.get_sbp_obj.execute(fake_params)
            self.assertFalse(mock_get_serverblueprints.called)


if __name__ == '__main__':
    unittest.main()
