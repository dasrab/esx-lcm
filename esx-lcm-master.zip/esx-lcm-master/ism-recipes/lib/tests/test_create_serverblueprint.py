# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest
import mock
import os

from lib.common import utils
from lib.common import models
from lib.create_serverblueprint import Create_Serverblueprint

fake_network_map = {
    "managementNetwork": "dcm_net",
    "storageNetwork": "vsan_net",
    "movementNetwork": "vmotion_net",
    "deployNetwork": "deploy",
    "faultToleranceNetwork": "ft_net",
    "productionNetwork": [
        "tenant_net1",
        "tenant_net2",
    ]
}

platform_profile_template = {
    "name": "SY480-Gen9-Low-Density",
    "description": "provides cloud with hybrid vsan datastore and optimal storage to compute density",
    "server_type": "SY 480 Gen9 1",
    "host_disks": {
        "capacity_drive_type": "bigbird:SAS",
        "capacity_drive_count": 1,
        "capacity_driv_size_tb": 2,
        "cache_drive_type": "local:HDD",
        "cache_drive_count": 1,
        "cache_drive_size_gb": 800}}


class TestCreateServerblueprint(unittest.TestCase):

    def setUp(self):
        super(TestCreateServerblueprint, self).setUp()
        self.create_sbp_obj = Create_Serverblueprint()
        self.fake_params = {'serverblueprint_name': 'SBP001',
                       'network_map': fake_network_map,
                       'platform_profile_template': platform_profile_template,
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000',
                       'appliance_uri': 'fake_uri'}
        self.fake_server_hardware = {"blueprint":{'localStorage': 123}}

    def test_execute_success(self):
        mock_result = {'name': 'SBP',
                       'uri': '/rest/serverblueprints/sbpuri',
                       'state': 'Created'}
        fake_disk_model = {'localStorage': 'local:ssd'}
        with contextlib.nested(
            mock.patch.object(os, 'listdir', return_value=['SY480_gen9',
                                                           'network_sets']),
            mock.patch.object(utils, 'read_json'),
            mock.patch.object(utils.NetworkModelRenderer,
                              'render_networkmodel_template'),
            mock.patch.object(utils.DiskModelRenderer,
                              'render_diskmodel_template', return_value=fake_disk_model),
            mock.patch.object(utils.SPTModelRenderer,
                              'render_sptmodel_template', return_value=self.fake_server_hardware),
            mock.patch.object(utils.ApplianceManagerProxy,
                              'create_serverblueprint', return_value=mock_result),
            mock.patch.object(models.ServerBlueprint,
                              '_get_serverblueprint_uri')) as (
                mock_os_listdir, mock_read_json,
                mock_network_model, mock_diskmodel, mock_hardware_type,
                mock_serverblueprint, mock_get_sbp_uri):
            self.create_sbp_obj.execute(self.fake_params)
            self.assertTrue(mock_network_model.called)
            self.assertTrue(mock_diskmodel.called)
            self.assertTrue(mock_hardware_type.called)
            self.assertTrue(mock_serverblueprint.called)
            mock_get_sbp_uri.assert_called_with()

    def test_execute_failure_for_keyerror(self):
        mock_result = {'name': 'SBP',
                       'state': 'Created'}
        with contextlib.nested(
            mock.patch.object(os, 'listdir', return_value=['SY480_gen9',
                                                           'network_sets']),
            mock.patch.object(utils, 'read_json'),
            mock.patch.object(utils.NetworkModelRenderer,
                              'render_networkmodel_template'),
            mock.patch.object(utils.DiskModelRenderer,
                              'render_diskmodel_template'),
            mock.patch.object(utils.SPTModelRenderer,
                              'render_sptmodel_template', return_value=self.fake_server_hardware),
            mock.patch.object(utils.ApplianceManagerProxy,
                              'create_serverblueprint', return_value=mock_result),
            mock.patch.object(models.ServerBlueprint,
                              '_get_serverblueprint_uri')) as (
                mock_os_listdir, mock_read_json,
                mock_network_model, mock_diskmodel, mock_hardware_type,
                mock_serverblueprint, mock_get_sbp_uri):
            self.create_sbp_obj.execute(self.fake_params)
            self.assertTrue(mock_network_model.called)
            self.assertTrue(mock_diskmodel.called)
            self.assertTrue(mock_hardware_type.called)
            self.assertTrue(mock_serverblueprint.called)
            self.assertFalse(mock_get_sbp_uri.called)

    def test_execute_exception(self):
        fake_params = {'serverblueprint_name': 'SBP001',
                       'platform_profile_template': platform_profile_template,
                       'appliance_ip': '127.0.0.1',
                       'appliance_uri': 'fake_uri'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'create_serverblueprint') as (mock_serverblueprint):
            self.create_sbp_obj.execute(fake_params)
            self.assertFalse(mock_serverblueprint.called)
