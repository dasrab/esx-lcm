# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import mock
import unittest

from lib import hpe_gateway_pre_scale_check
from lib.hpe_gateway_pre_scale_check import Hpe_Gateway_Pre_Scale_Check
from lib.hpeGateway import utils

fake_host_agent_info = {
    'status': 'ok', 'id': 'abc123',
    'roles': [hpe_gateway_pre_scale_check.HPEGateway_NOVA_PROXY_ROLE]
}

fake_res_mgr_info = {
    'resmgr_url': 'https://xyz.net/resmgr',
    'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'
}

args = {
    'hostagent_info': fake_host_agent_info,
    'res_mgr_info': fake_res_mgr_info
}


class TestHpe_Gateway_Pre_Scale_Check(unittest.TestCase):

    def setUp(self):
        super(TestHpe_Gateway_Pre_Scale_Check, self).setUp()
        self.scale_check = Hpe_Gateway_Pre_Scale_Check()

    def test_execute_success(self):

        with mock.patch.object(
                utils, 'get_all_managed_clusters_from_hpe_gateway') as (
                    get_all_managed_clusters):

            args['cluster_scale_count'] = 12

            # No exception but will return scale_up = False
            existing_nodes = 6
            clusters = [''.join(['cluster', str(i)])
                        for i in xrange(existing_nodes)]
            get_all_managed_clusters.return_value = clusters
            do_scale = self.scale_check.execute(args)
            self.assertFalse(do_scale.get('body'))
            self.assertEqual(do_scale['headers']['module_status'], 'SUCCESS')

            # Should raise Exception !
            existing_nodes = 12
            clusters = [''.join(['cluster', str(i)])
                        for i in xrange(existing_nodes)]
            get_all_managed_clusters.return_value = clusters
            do_scale = self.scale_check.execute(args)
            self.assertEqual(do_scale['headers']['module_status'], 'FAIL')

            args['cluster_scale_count'] = 6

            existing_nodes = 6
            clusters = [''.join(['cluster', str(i)])
                        for i in xrange(existing_nodes)]
            get_all_managed_clusters.return_value = clusters
            do_scale = self.scale_check.execute(args)
            self.assertEqual(do_scale['headers']['module_status'], 'FAIL')
