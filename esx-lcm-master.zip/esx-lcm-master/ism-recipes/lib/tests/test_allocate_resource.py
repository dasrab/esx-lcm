# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import mock
import unittest

from lib.allocate_resource import Allocate_Resource
from lib.hpeGateway import utils


class TestAllocateResource(unittest.TestCase):

    def setUp(self):
        super(TestAllocateResource, self).setUp()
        self.allocate_resource_obj = Allocate_Resource()

    def test_execute_success(self):
        fake_params = {}
        fake_host_agent_info = {'status': 'ok',
                                'clusters': [{
                                    'datastores': [{'name': 'datastore1'},
                                                   {'name': 'nfs', }],
                                    'name': 'Cluster3'},
                                    {'datastores': [{'name': 'datastore1'}],
                                     'name': 'Cluster2'}],
                                'id': 'abcdefgh-99192fe776b'}
        fake_cluster_list = ['Cluster2', 'Cluster1']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['res_mgr_info'] = fake_res_mgr_info
        with mock.patch.object(utils,
                               'manage_cluster') as (mock_manage_cluster):
            self.allocate_resource_obj.execute(fake_params)
            self.assertTrue(mock_manage_cluster.called)

    def test_execute_failure(self):
        fake_params = {}
        fake_host_agent_info = {'status': 'converging',
                                'clusters': [{
                                    'datastores': [{'name': 'datastore1'},
                                                   {'name': 'nfs', }],
                                    'name': 'Cluster3'},
                                    {'datastores': [{'name': 'datastore1'}],
                                     'name': 'Cluster2'}],
                                'id': 'abcdefgh-99192fe776b'}
        fake_cluster_list = ['Cluster2', 'Cluster1']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['res_mgr_info'] = fake_res_mgr_info
        with mock.patch.object(utils,
                               'manage_cluster') as (mock_manage_cluster):
            self.allocate_resource_obj.execute(fake_params)
            self.assertFalse(mock_manage_cluster.called)


if __name__ == '__main__':
    unittest.main()
