# (C) Copyright 2018 Hewlett Packard Enterprise Development LP


import unittest
from orch.ism_sdk.activity import Ism_Error
from lib.check_for_max_hosts_allocated_per_cluster import Check_For_Max_Hosts_Allocated_Per_Cluster
from hpOneViewClrm import *
import mock


class Test_Check_For_Max_Hosts_Allocated_Per_Cluster(unittest.TestCase):

    def setUp(self):

        self.max_host_obj = Check_For_Max_Hosts_Allocated_Per_Cluster()
        self.success = {'module_status': 'SUCCESS'}

    @mock.patch('hpOneView.connection')
    def test_execute(self, mock_conn):
        self.param = {

            '_max_hosts_alloc_per_cluster': 6,
            '_nodes_to_expand_count': 2,
            '_ov_host': "fake_host",
            '_ov_port': 443,
            '_auth': "ZwcjosGjkow347jdQfc",
            '_hypervisor_cluster_uri': "/rest/cluster/213u21jsa1232130qwwq"

        }
        fake_hypervisor_cluster_profile = {
            'hypervisorHostProfileUris': [
                "uri_1", "uri_2"]}

        with mock.patch.object(cluster_profile, 'get_cluster_profile_by_uri',
                               return_value=fake_hypervisor_cluster_profile):
            exp = {
                'body': u'Check_For_Max_Host_Allocated_Per_Cluster is PASSED',
                'headers': {
                    'module_status': 'SUCCESS'}}
            res = self.max_host_obj.execute(self.param)
            self.assertEqual(res['headers'], self.success)

    @mock.patch('hpOneView.connection')
    def test_execute_exception(self, mock_conn):
        self.param = {

            '_max_hosts_alloc_per_cluster': 3,
            '_nodes_to_expand_count': 2,
            '_ov_host': "fake_host",
            '_ov_port': 443,
            '_auth': "ZwcjosGjkow347jdQfc",
            '_hypervisor_cluster_uri': "/rest/cluster/213u21jsa1232130qwwq"

        }
        fake_hypervisor_cluster_profile = {
            'hypervisorHostProfileUris': [
                "uri_1", "uri_2"]}

        with mock.patch.object(cluster_profile, 'get_cluster_profile_by_uri',
                               return_value=fake_hypervisor_cluster_profile):

            self.assertRaises(Ism_Error, self.max_host_obj.execute, self.param)
