# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

import hpOneView
import hpOneViewClrm as hpovclrm

from lib import update_vcenter_creds

args = {
    'ov_host': '2.2.2.2',
    'ov_port': 443,
    'auth': 'fake-auth',
    'vc_host': '1.1.1.1',
    'vc_username': 'root',
    'vc_password': '***',
    'vc_remote_host': '3.3.4.4'
}


class hypervisor_manager:

    @staticmethod
    def get_hypervisor_manager(vc_host):
        return {
            'username': args['vc_username'],
            'password': args['vc_password']
        }

    @staticmethod
    def update_hypervisor_manager(hypervisor):
        return


class TestUpdate_Vcenter_Creds(unittest.TestCase):

    def setUp(self):
        super(TestUpdate_Vcenter_Creds, self).setUp()
        self.update_creds = update_vcenter_creds.Update_Vcenter_Creds()

    def test_execute_same_creds(self):
        with contextlib.nested(
            patch.object(hpovclrm, 'hypervisor_managers',
                         return_value=hypervisor_manager)) as mock_hyp_mgr:
            ret_val = self.update_creds.execute(args)
            self.assertIsNotNone(ret_val)
            self.assertEqual(ret_val['headers']['module_status'], 'FAIL')
            self.assertTrue(mock_hyp_mgr[0].called)

    def test_execute_different_creds(self):
        args2 = args.copy()
        args2['vc_password'] = 'different_password'
        with contextlib.nested(
            patch.object(hpovclrm, 'hypervisor_managers',
                         return_value=hypervisor_manager)) as (
                            mock_hyp_mgr):
            ret_val = self.update_creds.execute(args2)
            self.assertIsNotNone(ret_val)
            self.assertEqual(ret_val['headers']['module_status'], 'SUCCESS')
            self.assertTrue(mock_hyp_mgr[0].called)
