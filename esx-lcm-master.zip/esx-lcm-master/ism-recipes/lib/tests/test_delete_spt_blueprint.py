# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
import mock
import unittest

from lib.delete_spt_blueprint import Delete_Spt_Blueprint


fake_zone_id = "1111-2222-3333-4444"

class Test_Delete_Spt_Blueprint(unittest.TestCase):

    def setUp(self):
        super(Test_Delete_Spt_Blueprint, self).setUp()
        self.spt_bp_obj = Delete_Spt_Blueprint()

    def test_execute_success(self):
        with mock.patch.object(self.spt_bp_obj,
                'delete_zone_environment') as mock_del:
            self.spt_bp_obj.execute({"zone_uri": fake_zone_id})
            mock_del.assert_called_with(fake_zone_id)
            self.assertEqual(mock_del.call_count, 1)
