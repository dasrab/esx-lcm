# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import unittest
from mock import patch
import hpOneViewClrm
from lib.get_hypervisor_manager import Get_Hypervisor_Manager


params = {
    "_ov_host": "10.10.11.1",
    "_ov_port": 443,
    "_auth": "12121212",
    "_hypervisor_manager_hostname": "10.10.12.10"
}


get_hypervisor_manager_mock_value = {
    "uri": "hypervisor_manager_uri", "name": "10.10.12.10"}


class Get_Hypervisor_Manager_Test(unittest.TestCase):

    @patch('hpOneViewClrm.hypervisor_managers')
    def testExecute_Get_Hypervisor_Manager_if(
            self, hypervisor_manager_client_mock):

        hypervisor_manager = hypervisor_manager_client_mock.return_value
        hypervisor_manager.get_hypervisor_manager.return_value = get_hypervisor_manager_mock_value
        result = Get_Hypervisor_Manager().execute(params)
        self.assertTrue(result['headers']['module_status'] == 'SUCCESS')
        self.assertTrue(result['body'] == 'hypervisor_manager_uri')

    @patch('hpOneViewClrm.hypervisor_managers')
    def testExecute_Get_Hypervisor_Manager_else(
            self, hypervisor_manager_client_mock):
        fake_hyp_mgr = {}
        hypervisor_manager = hypervisor_manager_client_mock.return_value
        hypervisor_manager.get_hypervisor_manager.return_value = fake_hyp_mgr
        result = Get_Hypervisor_Manager().execute(params)
        self.assertTrue(result['headers']['module_status'] == 'SUCCESS')
        self.assertTrue(result['body'] == False)

    @patch('hpOneView.connection', side_effect=Exception)
    def testExecute_Get_Hypervisor_Manager_excp(self, ovclrm_con):
        result = Get_Hypervisor_Manager().execute(params)
        self.assertTrue(result['headers']['module_status'] == 'FAIL')
