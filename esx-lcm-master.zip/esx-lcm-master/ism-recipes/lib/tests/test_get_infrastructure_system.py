# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import unittest
import mock
from lib import get_infrastructure_system
from orch.ism_sdk.infrastructure_systems import InfrastructureSystems


class private_request (object):
    def __init__(self):
        self.hostname = "mock_host"


class Get_Infrastructure_System_test(unittest.TestCase):

    def setUp(self):
        self.get_infra_sys_obj = get_infrastructure_system.Get_Infrastructure_System()
        self.get_infra_sys_obj.private_request = private_request()
        self.param = "mock_param"

    def test_execute(self):
        infra_system_list = ["mock_system"]
        with mock.patch.object(InfrastructureSystems, "get_all_infrastructure_systems",
                               return_value=infra_system_list) as (mock_sys_infra):
            with mock.patch.object(self.get_infra_sys_obj, 'exit_success') as (exit_status):
                self.get_infra_sys_obj.execute(self.param)
                mock_return_value = mock_sys_infra.assert_called_with()
                self.assertTrue(exit_status.called)
                exit_status.assert_called_with("mock_system")

    def test_execute_exception(self):
        with mock.patch.object(InfrastructureSystems, "get_all_infrastructure_systems",
                               side_effect=Exception) as (mock_sys_infra):
            with mock.patch.object(self.get_infra_sys_obj.LOG, 'exception') as (log):
                self.get_infra_sys_obj.execute(self.param)
                self.assertTrue(log.called)

    def test_execute_empty_list(self):
        infra_system_list = []
        with mock.patch.object(InfrastructureSystems, "get_all_infrastructure_systems",
                               return_value=infra_system_list) as (mock_sys_infra):
            with mock.patch.object(self.get_infra_sys_obj, 'exit_success') as (exit_status):
                self.get_infra_sys_obj.execute(self.param)
                mock_return_value = mock_sys_infra.assert_called_with()
                self.assertTrue(exit_status.called)
                exit_status.assert_called_with(None)

    def tearDown(self):
        pass
