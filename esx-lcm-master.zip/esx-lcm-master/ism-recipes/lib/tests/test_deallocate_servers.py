# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
import mock

from lib.common import utils
from lib.deallocate_servers import Deallocate_Servers


class TestDeallocateServers(unittest.TestCase):

    def setUp(self):
        super(TestDeallocateServers, self).setUp()
        self.deallocate_servers_obj = Deallocate_Servers()

    def test_execute_success(self):
        fake_params = {'server_uris': ['/rest/servers/abcd',
                                       '/rest/servers/efgh'],
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '7000'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'deallocate_server') as (mock_deallocate_servers):
            self.deallocate_servers_obj.execute(fake_params)
            self.assertTrue(mock_deallocate_servers.called)

    def test_execute_failure(self):
        fake_params = {'server_uris': ['/rest/servers/abcd'],
                       'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'deallocate_server') as (mock_deallocate_servers):
            self.deallocate_servers_obj.execute(fake_params)
            self.assertFalse(mock_deallocate_servers.called)


if __name__ == '__main__':
    unittest.main()
