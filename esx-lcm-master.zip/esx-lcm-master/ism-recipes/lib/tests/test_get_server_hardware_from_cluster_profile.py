# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
import contextlib
import mock
from orch.moduleBase import ModuleBase
import unittest

import hpOneView as ov
import hpOneViewClrm as hpovclrm
from lib.get_server_hardware_uris_from_cluster_profile import \
    Get_Server_Hardware_Uris_From_Cluster_Profile
from hpOneView.resources.servers import server_profiles as ov_server_profiles

class TestGetServerHardwareFromClusterProfile(unittest.TestCase):

    def setUp(self):
        super(TestGetServerHardwareFromClusterProfile, self).setUp()
        self.get_svr_obj = Get_Server_Hardware_Uris_From_Cluster_Profile()

    def test_execute_success(self):
        fake_params = {'_ov_host': 'dummy_ov',
                       '_ov_port': 443,
                       '_auth': '123456abcdefgh78910',
                       '_cluster_profile_uri': 'fake-cluster-uri'}

        fake_cluster_profile = {'id': 'fake-cluster-id',
                                'uri': 'fake-cluster-uri',
                                'hypervisorHostProfileUris':
                                    ['fake-hypervisor-uri']}

        fake_hypervisor_profile = {'id': 'fake-hypervisor-id',
                                   'uri': 'fake-hypervisor-uri',
                                   'serverProfileUri': 'fake-svr-profile-uri'}

        fake_server_profile = {'id': 'fake-svr-profile-id',
                               'uri': 'fake-svr-profile-uri',
                               'serverHardwareUri': 'fake-svr-hardware-uri'}

        with contextlib.nested(
            mock.patch.object(hpovclrm.cluster_profile, 'get_cluster_by_uri',
                              return_value=fake_cluster_profile),
            mock.patch.object(hpovclrm.hypervisor_profiles,
                              'get_hypervisor_profile_by_uri',
                              return_value=fake_hypervisor_profile),
            mock.patch.object(ov_server_profiles.ServerProfiles, 'get',
                              return_value=fake_server_profile),
            mock.patch.object(ModuleBase, 'exit_success')) as (
                mock_get_cluster, mock_get_hypervisor_profile,
                    mock_get_server_profile, mock_success):
            self.get_svr_obj.execute(fake_params)
            self.assertTrue(mock_get_cluster.called)
            self.assertTrue(mock_get_hypervisor_profile.called)
            self.assertTrue(mock_get_server_profile.called)
            self.assertTrue(mock_success.called)
