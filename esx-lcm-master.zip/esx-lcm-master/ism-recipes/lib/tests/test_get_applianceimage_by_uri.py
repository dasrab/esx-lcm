# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
import mock

from lib.common import utils
from lib.get_applianceimage_by_uri import Get_Applianceimage_By_Uri


class TestGetApplianceimageByUri(unittest.TestCase):

    def setUp(self):
        super(TestGetApplianceimageByUri, self).setUp()
        self.get_appimage_obj = Get_Applianceimage_By_Uri()

    def test_execute_success(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234',
                       'applianceimage_uri': '/rest/aapimage/image1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_applianceimage_by_uri') as (mock_get_applianceimage):
            self.get_appimage_obj.execute(fake_params)
            self.assertTrue(mock_get_applianceimage.called)

    def test_execute_failure(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'applianceimage_uri': '/rest/aapimage/image1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_applianceimage_by_uri') as (mock_get_applianceimage):
            self.get_appimage_obj.execute(fake_params)
            self.assertFalse(mock_get_applianceimage.called)


if __name__ == '__main__':
    unittest.main()
