# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import copy
import contextlib
from mock import patch
from mock.mock import MagicMock
import unittest
import urlparse

from pyVmomi import vim

from lib import hpe_gateway_ova_upload
from lib.common.vcenter_utils import VcenterUtils
from lib.hpe_gateway_ova_upload import Hpe_Gateway_Ova_Upload
from lib.hpe_gateway_ova_upload import OvfHandler
from lib.hpeGateway import utils


MAGIC_MOCK = MagicMock()
args = {
    'vcenter_ip': '1.1.1.1',
    'vcenter_username': 'root',
    'vcenter_password': '***',
    'vcenter_port': 443,
    'datacenter': 'Datacenter1',
    'cluster': 'Cluster1',
    'network_name': 'VM Network',
    'ova_path': '/path/to/platform9-vmware-appliance-vmware.ova',
    'proxy_server': 'some-proxy.company.org',
    'proxy_port': '8080',
    'appliance_name': 'hpe-gateway-001',
    'appliance_ip': '10.10.10.10',
    'appliance_netmask': '255.255.255.0',
    'appliance_gateway': '10.10.10.1',
    'appliance_dns': '10.10.10.2',
    'keystone_url': "https://myhost.platform9.net/keystone/v3",
    'region': "vmware",
    'username': "abc@abc.com",
    'password': "ABCDEfGH6oBoKNq",
    'tenant': "service",
    'proxy_server': "proxy.company.com",
    'proxy_port': "8080"
}

host_agents = [{
    "extensions": {
        "interfaces": {
            "status": "ok",
            "data": {
                "iface_ip": {
                    "br-int": args['appliance_ip']
                },
                "ovs_bridges": [
                    "br-int"
                ]
            }
        },
        "hypervisor_details": {
            "data": {
                "pair_status": "paired"
            }
        }
    }
}]


class Net:
    ipAddress = ['10.10.10.10']


class VM:
    name = args['appliance_name']

    class guest:
        toolsStatus = 'toolsNotRunning'
        net = [Net]


class fileItem:
    deviceId = '123'
    path = '/path/to/vmdk'


class DeviceUrl:
    importKey = '123'


class lease:

    class info:
        deviceUrl = [DeviceUrl]
        entity = VM

    @staticmethod
    def Complete():
        pass

    @staticmethod
    def Abort(msg):
        pass


class LOG:

    @staticmethod
    def info(msg):
        pass


class TestOVADeployer(unittest.TestCase):

    def setUp(self):
        super(TestOVADeployer, self).setUp()
        self.hpe_gateway_ova_upload = Hpe_Gateway_Ova_Upload()
        self.hpe_gateway_ova_upload._args = args
        with patch.object(OvfHandler, '__init__', return_value=None):
            self.ovf_handler = OvfHandler(args['ova_path'], 'fakeVC')
            self.ovf_handler.LOG = LOG

    @unittest.skip("")
    def test_execute(self):
        with contextlib.nested(
            patch.object(utils, 'get_resource_manager_endpoint'),
            patch.object(self.hpe_gateway_ova_upload, '_get_appliance_ip'),
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(VcenterUtils, 'get_obj'),
            patch.object(Hpe_Gateway_Ova_Upload, '_get_datastore'),
            patch.object(OvfHandler, '__init__', return_value=None),
            patch.object(Hpe_Gateway_Ova_Upload, '_get_ovf_import_spec_result'),
            patch.object(OvfHandler, 'upload_ova'),
            patch.object(Hpe_Gateway_Ova_Upload, '_power_on_vm'),
            patch.object(Hpe_Gateway_Ova_Upload, '_validate_deployment',
                         return_value=True)) as (
                mock_res_endpoint, mock_get_appliance_ip,
                _get_service_instance, _get_obj, _get_datastore,
                OvfHandler__init__, _get_ovf_import_spec_result,
                upload_ova, _power_on_vm, _validate_deployment):
            output = self.hpe_gateway_ova_upload.execute(args)
            self.assertIsNotNone(output)
            module_status = output.get('headers').get('module_status')
            self.assertEqual(module_status, 'SUCCESS')
            self.assertFalse(mock_res_endpoint.called)
            self.assertFalse(mock_get_appliance_ip.called)
            self.assertTrue(_get_service_instance.called)
            self.assertTrue(_get_obj.called)
            self.assertTrue(_get_datastore.called)
            self.assertTrue(OvfHandler__init__.called)
            self.assertTrue(_get_ovf_import_spec_result.called)
            self.assertTrue(upload_ova.called)
            self.assertTrue(_power_on_vm.called)
            self.assertTrue(_validate_deployment.called)

    @unittest.skip("")
    def test_execute_with_scale_out(self):
        fake_args = copy.deepcopy(args)
        fake_args['appliance_prefix'] = 'fake_prefix'
        fake_args['appliance_ip'] = ""
        with contextlib.nested(
            patch.object(utils, 'get_resource_manager_endpoint'),
            patch.object(self.hpe_gateway_ova_upload, '_get_appliance_ip'),
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(VcenterUtils, 'get_obj'),
            patch.object(Hpe_Gateway_Ova_Upload, '_get_datastore'),
            patch.object(OvfHandler, '__init__', return_value=None),
            patch.object(Hpe_Gateway_Ova_Upload, '_get_ovf_import_spec_result'),
            patch.object(OvfHandler, 'upload_ova'),
            patch.object(Hpe_Gateway_Ova_Upload, '_power_on_vm'),
            patch.object(Hpe_Gateway_Ova_Upload, '_validate_deployment',
                         return_value=True)) as (
                mock_res_endpoint, mock_get_appliance_ip,
                _get_service_instance, _get_obj, _get_datastore,
                OvfHandler__init__, _get_ovf_import_spec_result,
                upload_ova, _power_on_vm, _validate_deployment):
            output = self.hpe_gateway_ova_upload.execute(fake_args)
            self.assertIsNotNone(output)
            module_status = output.get('headers').get('module_status')
            self.assertEqual(module_status, 'SUCCESS')
            self.assertTrue(mock_res_endpoint.called)
            self.assertTrue(mock_get_appliance_ip.called)
            self.assertTrue(_get_service_instance.called)
            self.assertTrue(_get_obj.called)
            self.assertTrue(_get_datastore.called)
            self.assertTrue(OvfHandler__init__.called)
            self.assertTrue(_get_ovf_import_spec_result.called)
            self.assertTrue(upload_ova.called)
            self.assertTrue(_power_on_vm.called)
            self.assertTrue(_validate_deployment.called)

    @unittest.skip("")
    def test_get_appliance_ip(self):
        fake_args = copy.deepcopy(args)
        fake_args['appliance_start_ipaddress'] = "10.10.10.10"
        fake_args['appliance_end_ipaddress'] = "10.10.10.20"
        self.hpe_gateway_ova_upload._args = fake_args
        fake_reserved_ips = ["10.10.10.10"]
        fake_res_mgr_info = {'token': 'abcd123', 'resmgr_url':
                             '/'.join([fake_args['keystone_url'], 'resmgr'])}
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": fake_res_mgr_info['token']
                        }
        fake_url = urlparse.urlsplit(fake_res_mgr_info['resmgr_url'])
        fake_path = '/'.join([fake_url.path, 'v1/hosts'])
        with contextlib.nested(
            patch.object(utils, 'get_host_agents', return_value=host_agents),
            patch.object(utils, 'generate_new_ip')) as (
                mock_get_host_agents, mock_generate_new_ip):
            output = self.hpe_gateway_ova_upload._get_appliance_ip(fake_res_mgr_info)
            self.assertTrue(mock_get_host_agents.called)
            self.assertTrue(mock_generate_new_ip.called)
            mock_get_host_agents.assert_called_with(fake_url.netloc,
                                                    fake_path, fake_headers)
            mock_generate_new_ip.assert_called_with(
                fake_args['appliance_start_ipaddress'],
                fake_args['appliance_end_ipaddress'],
                fake_reserved_ips)

    @unittest.skip("")
    def test_execute_ova_not_found(self):
        self.assertRaises(Exception, self.hpe_gateway_ova_upload.execute, args)

    @unittest.skip("")
    def test_get_ovf_properties(self):
        output = self.hpe_gateway_ova_upload._get_ovf_properties()
        self.assertIsNotNone(output)
        self.assertEqual(args['vcenter_ip'], output['host_ip'])
        self.assertEqual(args['vcenter_username'], output['host_username'])
        self.assertEqual(args['vcenter_password'], output['host_password'])
        self.assertEqual(args['appliance_ip'], output['static_ip'])
        self.assertEqual(args['appliance_netmask'], output['static_netmask'])
        self.assertEqual(args['appliance_gateway'], output['static_gateway'])
        self.assertEqual(args['proxy_server'], output['proxy_ip'])

    @unittest.skip("")
    def test_get_ovf_import_spec_result(self):
        with contextlib.nested(
                patch.object(VcenterUtils, 'get_obj',
                             return_value=vim.Network('fakeNetwork')),
                patch.object(OvfHandler, 'get_descriptor')) as (
                    _get_obj, get_descriptor):
            output = self.hpe_gateway_ova_upload._get_ovf_import_spec_result(
                MAGIC_MOCK, MAGIC_MOCK, 'fake_ds', 'fake_rp', OvfHandler)
            self.assertIsNotNone(output)
            self.assertTrue(_get_obj.called)
            self.assertTrue(get_descriptor.called)
            config_spec = output.importSpec.configSpec
            self.assertTrue(config_spec.cpuHotAddEnabled)
            self.assertTrue(config_spec.memoryHotAddEnabled)

    @unittest.skip("")
    def test_get_max_capacity_datastore(self):
        class Datastore1:

            class summary:
                freeSpace = 50 * 1024 * 1024 * 1024

        class Datastore2:

            class summary:
                freeSpace = 30 * 1024 * 1024 * 1024
        output = self.hpe_gateway_ova_upload._get_max_capacity_datastore(
            [Datastore1, Datastore2])
        self.assertIsNotNone(output)
        self.assertEqual(output, Datastore1)

    @unittest.skip("")
    def test_get_device_url(self):

        output = self.ovf_handler._get_device_url(fileItem, lease)
        self.assertIsNotNone(output)
        self.assertEqual(output.importKey, DeviceUrl.importKey)

    @unittest.skip("")
    def test_upload_ova(self):
        class FakeSpec:
            fileItem = ['fakeFileItems']
        self.ovf_handler.set_spec(FakeSpec)
        with patch.object(OvfHandler, '_upload_disk') as (_upload_disk):
            output = self.ovf_handler.upload_ova(lease)
            self.assertIsNotNone(output)
            self.assertEqual(output.name, args['appliance_name'])
            self.assertTrue(_upload_disk.called)

    @unittest.skip("")
    def test_fail_wait_for_vmware_tools(self):
        hpe_gateway_ova_upload.VM_TOOLS_RETRY_COUNT = 1
        hpe_gateway_ova_upload.TASK_WAIT_DELAY = 1
        # Class VM has toolsNotRunning so it will raise Exception
        self.assertRaises(
            Exception, self.hpe_gateway_ova_upload._wait_for_vmware_tools, VM)

    @unittest.skip("")
    def test_wait_for_vmware_tools(self):
        class VM1:

            class guest:
                toolsStatus = 'toolsOk'
        # Class VM1 has toolsOk so it will successfully return
        hpe_gateway_ova_upload.VM_TOOLS_RETRY_COUNT = 1
        hpe_gateway_ova_upload.TASK_WAIT_DELAY = 1
        # None means wait for vmware tools is successful
        self.assertIsNone(self.hpe_gateway_ova_upload._wait_for_vmware_tools(VM1))

    @unittest.skip("")
    def test_wait_for_ip_config(self):
        # None means IP populated and matches the IP in args and the IP in VM
        self.assertIsNone(self.hpe_gateway_ova_upload._wait_for_ip_config(VM))

    @unittest.skip("")
    def test_fail_wait_for_ip_config(self):
        hpe_gateway_ova_upload.NET_INFO_COUNT = 1
        hpe_gateway_ova_upload.TASK_WAIT_DELAY = 1
        self.hpe_gateway_ova_upload._args['appliance_ip'] = 'fakeIP'
        self.assertRaises(
            Exception, self.hpe_gateway_ova_upload._wait_for_ip_config, VM)
        # Change the IP back again so that other tests don't fail.
        self.hpe_gateway_ova_upload._args['appliance_ip'] = '10.10.10.10'

    @unittest.skip("")
    def test_wait_for_being_paired(self):
        res_mgr_info = {'token': 'abcd123', 'resmgr_url':
                        '/'.join([args['keystone_url'], 'resmgr'])}
        with contextlib.nested(
                patch.object(utils, 'get_resource_manager_endpoint',
                             return_value=res_mgr_info),
                patch.object(utils, 'get_host_agents',
                             return_value=host_agents)) as (
                get_res_mgr_enpt, get_host_agents):
            is_paired = self.hpe_gateway_ova_upload._wait_for_being_paired()
            self.assertTrue(is_paired)
            self.assertTrue(get_res_mgr_enpt.called)
            self.assertTrue(get_host_agents.called)


if __name__ == '__main__':
    unittest.main()
