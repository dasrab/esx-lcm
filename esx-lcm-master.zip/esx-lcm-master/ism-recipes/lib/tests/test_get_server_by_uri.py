# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest

import mock
from mock import patch

from lib.common import utils
from lib.get_server_by_uri import Get_Server_By_Uri


class TestGetServerByUri(unittest.TestCase):

    def setUp(self):
        super(TestGetServerByUri, self).setUp()
        self.get_server_obj = Get_Server_By_Uri()

    def test_execute(self):
        fake_params = {'server_uri': 'fake_server_1',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_server_by_uri') as (
                mock_get_server_by_uri):
            self.get_server_obj.execute(fake_params)
            self.assertTrue(mock_get_server_by_uri.called)

    def test_execute_exception(self):
        fake_params = {'server_uri': 'fake_server_1',
                       'appliance_ip': '127.0.0.1'}
        with patch.object(utils.ApplianceManagerProxy,
                          'get_server_by_uri') as (
                mock_get_server_by_uri):
            self.get_server_obj.execute(fake_params)
            self.assertFalse(mock_get_server_by_uri.called)
