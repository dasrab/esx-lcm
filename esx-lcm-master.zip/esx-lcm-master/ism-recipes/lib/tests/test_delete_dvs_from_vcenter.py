# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

from lib.delete_dvs_from_vcenter import Delete_Dvs_From_Vcenter
from lib.common.vcenter_utils import VcenterUtils

args = {
    'vc_host': '1.1.1.1',
    'vc_username': 'root',
    'vc_password': '***',
    'vc_port': 443,
    'datacenter_name': 'Datacenter1',
    'blueprint': {
        'uri': '/path/to/fake-uri',
        'networkSetBlueprints': [
            {'uname': 'MGMT-Set'},
            {'uname': 'DATA-Set'}
        ]
    }
}


class TestDelete_Dvs_From_Vcenter(unittest.TestCase):

    def setUp(self):
        super(TestDelete_Dvs_From_Vcenter, self).setUp()
        self._delete_dvs = Delete_Dvs_From_Vcenter()

    def test_execute_success(self):
        with contextlib.nested(
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(VcenterUtils, 'get_obj')) as (
                get_service_instance, get_obj):
            ret_val = self._delete_dvs.execute(args)
            self.assertIsNotNone(ret_val)
            self.assertEqual(ret_val['headers']['module_status'], 'SUCCESS')
            self.assertTrue(ret_val['body'])
            self.assertTrue(get_service_instance.called)
            self.assertTrue(get_obj.called)

    def test_execute_success_no_dvs(self):
        args['blueprint']['networkSetBlueprints'] = []

        ret_val = self._delete_dvs.execute(args)
        self.assertIsNotNone(ret_val)
        self.assertEqual(ret_val.get('body'), 'There is no DVS to delete !')
        self.assertEqual(ret_val['headers']['module_status'], 'SUCCESS')
