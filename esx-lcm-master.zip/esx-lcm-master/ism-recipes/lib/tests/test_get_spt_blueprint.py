# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
import unittest
import mock
from lib.get_spt_blueprint import Get_Spt_Blueprint
from orch.moduleBase import ModuleBase

fake_spt_bps = ["fake_blueprint1", "fake_blueprint2"]
fake_zone_env = {"id": "fake_zone_uri",
                 "sptBlueprintURIs": fake_spt_bps}
failure_status={'module_status': 'FAIL'}


class Test_Get_Spt_Blueprint(unittest.TestCase):

    def setUp(self):
        super(Test_Get_Spt_Blueprint, self).setUp()
        self.spt_bp_obj = Get_Spt_Blueprint()


    def test_execute_success(self):
        with mock.patch.object(ModuleBase,'get_zone_environment',
                        return_value=fake_zone_env) as mock_get_zone_env:
            res_blueprints = self.spt_bp_obj.execute(
                {"zone_uri": fake_zone_env['id']})
            mock_get_zone_env.assert_called_with(fake_zone_env['id'])

            self.assertEqual(mock_get_zone_env.call_count, 1)
            self.assertEqual(res_blueprints['body'], fake_spt_bps)

    def test_execute_fail(self):
        self.params={}
        with mock.patch.object(ModuleBase, 'get_zone_environment',
                               return_value=fake_zone_env) as mock_get_zone_env:
            res_blueprints = self.spt_bp_obj.execute(self.params)
            self.assertEqual(res_blueprints['headers'],failure_status)
