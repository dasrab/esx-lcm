# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

import hpOneView
import hpOneViewClrm as hpovclrm

from orch.ism_sdk import InfrastructureSystems
from orch.ism_sdk.activity import Ism_Error

from lib.update_infra_system_node_count import Update_Infra_System_Node_Count

args = {
    '_ov_host': '2.2.2.2',
    '_ov_port': 443,
    '_auth': 'fake-auth',
    'cluster_profile_uri': 'fake-cluster_profile_uri',
    'infra_system_uri': 'fake-infra_system_uri'
}


class cluster_profiles:

    @staticmethod
    def get_cluster_profile_by_uri(uri):
        if uri == args['cluster_profile_uri']:
            return {
                'hypervisorHostProfileUris': [
                    'fake-host-uri-1',
                    'fake-host-uri-2'
                ]
            }
        raise Exception('URI not found')


class TestUpdate_Infra_System_Node_Count(unittest.TestCase):

    def setUp(self):
        super(TestUpdate_Infra_System_Node_Count, self).setUp()
        self.update_node_count = Update_Infra_System_Node_Count()

    def test_execute_susccess(self):
        with contextlib.nested(
            patch.object(hpovclrm, 'cluster_profile',
                         return_value=cluster_profiles),
            patch.object(InfrastructureSystems,
                         'update_infrastructure_system')) as (
                             cluster_profile, update_infra):

            ret_val = self.update_node_count.execute(args)

            self.assertIsNotNone(ret_val)
            self.assertEqual(ret_val['headers']['module_status'], 'SUCCESS')
            fake_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
                args['cluster_profile_uri'])
            fake_host_uris = fake_cluster_profile.get(
                'hypervisorHostProfileUris')
            self.assertEqual(ret_val['body']['nodeCount'], len(fake_host_uris))
            self.assertTrue(cluster_profile.called)
            self.assertTrue(update_infra.called)

    def test_execute_failure(self):
        args2 = args.copy()
        args2['cluster_profile_uri'] = 'some-other-uri'
        with contextlib.nested(
                patch.object(hpovclrm, 'cluster_profile',
                             return_value=cluster_profiles)) as (cluster_profile):

            with self.assertRaises(Ism_Error) as ctx:
                self.update_node_count.execute(args2)

            self.assertEqual(ctx.exception.message,
                             'HCOE_ISM_UPDATE_INFRA_NODE_COUNT_FAILED')

            self.assertTrue(cluster_profile[0].called)
