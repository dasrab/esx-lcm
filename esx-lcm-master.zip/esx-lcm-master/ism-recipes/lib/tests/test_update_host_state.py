# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from common.vcenter_utils import VcenterUtils
import contextlib
import hpOneViewClrm as hpovclrm
import mock
import unittest

from lib.update_host_state import Update_Host_State


fake_cluster_profile = {'id': '1111-1111-1111-1111',
                        'uri': '/rest/cluster-profiles/1111-1111-1111-1111',
                        'hypervisorHostProfileUris':
                            ['/rest/hypervisor-host-profiles/1111-2222']}
fake_hypervisor_profile = {'id': '1111-2222',
                           'uri': '/rest/hypervisor-host-profiles/1111-2222',
                           'hypervisorHostUri': '/rest/hypervisor-hosts/5555'}
fake_host_profile = {'id': '5555',
                     'name': '10.20.30.40',
                     'uri': '/rest/hypervisor-hosts/5555'}

moduleStatus_succ = {'module_status': 'SUCCESS'}
moduleStatus_fail = {'module_status': 'FAIL'}

class TestUpdateHostState(unittest.TestCase):

    def setUp(self):
        super(TestUpdateHostState, self).setUp()
        self.hypervisor_obj = Update_Host_State()

    def test_execute_success(self):
        fake_params = {'_auth': '55555-wwwwww-abcdef',
                       '_ov_host': '11.22.33.44',
                       '_ov_port': 443,
                       '_vc_host': 'fake-host',
                       '_vc_user': 'fake-user',
                       '_vc_password': 'fake-password',
                       '_vc_port': 443,
                       '_cluster_profile_uri': fake_cluster_profile['uri']}

        with contextlib.nested(
            mock.patch.object(hpovclrm.cluster_profile,
                              'get_cluster_profile_by_uri',
                              return_value=fake_cluster_profile),
            mock.patch.object(hpovclrm.hypervisor_profiles,
                              'get_hypervisor_profile_by_uri',
                              return_value=fake_hypervisor_profile),
            mock.patch.object(hpovclrm.hypervisor_profiles,
                              'get_hypervisor_host_by_uri',
                              return_value=fake_host_profile),
            mock.patch.object(self.hypervisor_obj._vc_utils,
                              'get_obj', return_value='fake-host'),
            mock.patch.object(self.hypervisor_obj._vc_utils,
                              'enter_maintenance_mode')) as (
                mock_get_cluster, mock_get_hypervisor_profile,
                mock_get_host_profile, mock_get_obj, mock_put_state):
            result = self.hypervisor_obj.execute(fake_params)
            mock_get_cluster.assert_called_with(fake_cluster_profile['uri'])
            mock_get_hypervisor_profile.assert_called_with(
                fake_hypervisor_profile['uri'])
            mock_get_host_profile.assert_called_with(fake_host_profile['uri'])
            self.assertEqual(mock_get_cluster.call_count, 1)
            self.assertEqual(mock_get_hypervisor_profile.call_count, 1)
            self.assertEqual(mock_get_host_profile.call_count, 1)

    def test_execute_exception(self):
        fake_params = {'_auth': '55555-wwwwww-abcdef',
                       '_ov_host': '11.22.33.44',
                       '_ov_port': 443,
                       '_vc_host': 'fake-host',
                       '_vc_user': 'fake-user',
                       '_vc_password': 'fake-password',
                       '_vc_port': 443,
                       '_cluster_profile_uri': fake_cluster_profile['uri']}

        with contextlib.nested(
            mock.patch.object(hpovclrm.cluster_profile,
                              'get_cluster_profile_by_uri',
                              return_value=fake_cluster_profile),
            mock.patch.object(hpovclrm.hypervisor_profiles,
                              'get_hypervisor_profile_by_uri',
                              return_value=fake_hypervisor_profile),
            mock.patch.object(hpovclrm.hypervisor_profiles,
                              'get_hypervisor_host_by_uri',
                              return_value=fake_host_profile),
            mock.patch.object(self.hypervisor_obj._vc_utils,
                              'get_obj', side_effect=Exception()),
            mock.patch.object(self.hypervisor_obj._vc_utils,
                              'enter_maintenance_mode')) as (
                mock_get_cluster, mock_get_hypervisor_profile,
                mock_get_host_profile, mock_get_obj, mock_put_state):
            result = self.hypervisor_obj.execute(fake_params)
            mock_get_cluster.assert_called_with(fake_cluster_profile['uri'])
            mock_get_hypervisor_profile.assert_called_with(
                fake_hypervisor_profile['uri'])
            mock_get_host_profile.assert_called_with(fake_host_profile['uri'])
            self.assertEqual(mock_get_cluster.call_count, 1)
            self.assertEqual(mock_get_hypervisor_profile.call_count, 1)
            self.assertEqual(mock_get_host_profile.call_count, 1)
            self.assertEqual(mock_put_state.call_count, 0)
            self.assertEqual(result['headers'], moduleStatus_fail)
