# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
import mock
import unittest

from lib import get_virtual_switch_layout
from lib.common import utils

fake_sbp = {
    "networkMap": [
      {
        "name": "SBP.ESX.MGMT",
        "netUris": [
          "DCM"
        ]
      },
      {
        "name": "SBP.ESX.vMOTION",
        "netUris": [
          "Vmotion"
        ]
      },
      {
        "name": "SBP.NCS.MGMT",
        "netUris": [
          "DCM"
        ]
      },
      {
        "name": "SBP.ESX.vSAN",
        "netUris": [
          "VSAN"
        ]
      },
      {
        "name": "SBP.ESX.GUEST.Tenant",
        "netUris": [
          "Production"
        ]
      },
      {
        "deployNetwork": "true",
        "name": "SBP.ESX.Deployment"
      }
    ]
    }

fake_net_map_list = {
    "ncsManagementNetwork": ["DCM"],
    "storageNetwork": ["VSAN"],
    "vMotionNetwork": ["Vmotion"],
    "esxManagementNetwork": ["DCM"],
    "productionNetworks": [
        "Production",
    ]
}

params = {'appliance_manager_ip': '127.0.0.1', 'appliance_manager_port': 5000,
          'serverProfileBlueprintUri': '/rest/serverprofileblueprint/12345abcd',
          'appliance_uri': '/rest/appliance/6789abcd'}
class Test_Get_VirtualSwitchLayout(unittest.TestCase):

    def setUp(self):
        super(Test_Get_VirtualSwitchLayout, self).setUp()
        self.virtualSwitchLayout_obj = get_virtual_switch_layout.Get_VirtualSwitchLayout()

    def test_get_network_map_from_sbp(self):
        result = self.virtualSwitchLayout_obj.get_network_map_from_sbp(fake_sbp)
        self.assertEqual(result, fake_net_map_list)

    def test_execute(self):
        with contextlib.nested(mock.patch.object(utils.ApplianceManagerProxy,
                                                 'get_serverblueprint_by_uri'),
                               mock.patch.object(get_virtual_switch_layout.Get_VirtualSwitchLayout,
                                                 'get_network_map_from_sbp'),
                               mock.patch.object(utils.ApplianceManagerProxy,
                                                 'get_l2networks'),
                               mock.patch.object(utils.SwitchLayoutRenderer,
                                                 'render_switchLayout_template')) as (
                                                     mock_get_serverblueprint_by_uri,
                                                     mock_get_network_map_from_sbp,
                                                     mock_get_l2networks,
                                                     mock_render_switchLayout_template):
            self.virtualSwitchLayout_obj.execute(params)
            self.assertTrue(mock_get_serverblueprint_by_uri.called)
            self.assertTrue(mock_get_network_map_from_sbp.called)
            self.assertTrue(mock_get_l2networks.called)
            self.assertTrue(mock_render_switchLayout_template.called)

    def test_execute_exception(self):
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_serverblueprint_by_uri') as(
                                   mock_get_serverblueprint_by_uri):
            self.assertRaises(Exception,
                              lambda: virtualSwitchLayout_obj.execute(params))
            self.assertFalse(mock_get_serverblueprint_by_uri.called)
