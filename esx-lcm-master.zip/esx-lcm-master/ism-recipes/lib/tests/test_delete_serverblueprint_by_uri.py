# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import unittest

import mock
from mock import patch

from lib.common import utils
from lib.delete_serverblueprint_by_uri import Delete_Serverblueprint_By_Uri


class TestDeleteServerblueprintByUri(unittest.TestCase):

    def setUp(self):
        super(TestDeleteServerblueprintByUri, self).setUp()
        self.delete_serverblueprint_obj = Delete_Serverblueprint_By_Uri()

    def test_execute(self):
        fake_params = {'serverblueprint_uri': 'fake_spt_1',
                       'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with patch.object(utils.ApplianceManagerProxy,
                          'delete_serverblueprint_by_uri') as (
                mock_delete_sbp_by_uri):
            self.delete_serverblueprint_obj.execute(fake_params)
            self.assertTrue(mock_delete_sbp_by_uri.called)

    def test_execute_exception(self):
        fake_params = {'serverblueprint_uri': 'fake_spt_1',
                       'appliance_ip': '127.0.0.1'}
        with patch.object(utils.ApplianceManagerProxy,
                          'delete_serverblueprint_by_uri') as (
                mock_delete_sbp_by_uri):
            self.delete_serverblueprint_obj.execute(fake_params)
            self.assertFalse(mock_delete_sbp_by_uri.called)
