# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import mock
import unittest

from lib.hpeGateway.physnetutil import PhysnetUtil
from lib.hpeGateway import utils


class TestPhysnetUtil(unittest.TestCase):

    def setUp(self):
        super(TestPhysnetUtil, self).setUp()
        self.agent = {
            "info": {
                "responding": "true",
                "hostname": "ubuntu.ubuntu"
            },
            "extensions": {
                "interfaces": {
                    "status": "ok",
                    "data": {
                        "ovs_bridges": ["external"]
                    }
                }
            },
            "id": "f09d3669-9088-40f8-b7c0-9fd36a480360"
        }
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": 'token'}
        self.physnetutil = PhysnetUtil('dummuy-du-hpecorp.net',
                                       '/v1/hosts', headers,
                                       self.agent)

    def test_validate_success(self):
        expected_list = ["physnet1", "physnet2"]
        ovb = ["br-abcd", "br-physnet1", "br-physnet2"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        with mock.patch.object(utils, 'get_physnets',
                               return_value="external") as mock_get_physnets:
            self.assertEqual(self.physnetutil.validate(), expected_list)
            self.assertTrue(mock_get_physnets.called)

    def test_validate_no_bridges(self):
        self.assertRaises(Exception,
                          lambda: self.physnetutil.validate())

    def test_validate_host_with_lesser_no_bridges(self):
        ovb = ["br-abcd", "br-physnet1"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        with mock.patch.object(utils, 'get_physnets',
                               return_value="physnet1,physnet2") as (
                mock_get_physnets):
            self.assertRaises(Exception,
                              lambda: self.physnetutil.validate())
            self.assertTrue(mock_get_physnets.called)

    def test_validate_host_skip_more_no_bridges(self):
        ovb = ["br-abcd", "br-physnet1", "br-physnet2"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        with mock.patch.object(utils, 'get_physnets',
                               return_value="physnet1") as mock_get_physnets:
            self.physnetutil.validate()
            self.assertTrue(mock_get_physnets.called)

    def test_validate_bridges_not_matching_physnets(self):
        ovb = ["br-abcd", "br-physnetabcd", "br-physnetdef"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        with mock.patch.object(utils, 'get_physnets',
                               return_value="physnet1,physnet2") as (
                mock_get_physnets):
            self.assertRaises(Exception,
                              lambda: self.physnetutil.validate())
            self.assertTrue(mock_get_physnets.called)

    def test_validate_skip_physnet_creation(self):
        ovb = ["br-abcd", "br-physnet1"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        with mock.patch.object(utils, 'get_physnets',
                               return_value="physnet1") as mock_get_physnets:
            with mock.patch.object(self.physnetutil,
                                   '_create_physnets'
                                   ) as mock_create_physnets:
                self.physnetutil.validate()
                self.assertFalse(mock_create_physnets.called)

    def test_validate_and_create_physnets_True(self):
        with mock.patch.object(self.physnetutil, 'validate',
                               return_value="physnet1") as mock_validate:
            with mock.patch.object(self.physnetutil,
                                   '_create_physnets') as mock_create_physnets:
                self.physnetutil.validate_and_create_physnets()
                self.assertTrue(mock_create_physnets.called)

    def test_validate_and_create_physnets_False(self):
        with mock.patch.object(self.physnetutil, 'validate',
                               return_value=None) as mock_validate:
            with mock.patch.object(self.physnetutil,
                                   '_create_physnets') as mock_create_physnets:
                self.physnetutil.validate_and_create_physnets()
                self.assertFalse(mock_create_physnets.called)

    def test_create_physnets(self):
        with mock.patch.object(utils, 'do_request') as mock_do_request:
            self.physnetutil._create_physnets(
                ["physnet1", "physnet2"], "create_physnets")
            self.assertTrue(mock_do_request.called)

    def test_clean_physnet(self):
        with mock.patch.object(self.physnetutil,
                               '_create_physnets') as mock_create_physnets:
            self.physnetutil.clean_physnet()
            self.assertTrue(mock_create_physnets.called)

    def test_fetch_bridges(self):
        ovb = ["br-abcd", "br-physnet1", "br-physnet2"]
        self.agent['extensions']['interfaces']['data']['ovs_bridges'] = ovb
        expected_bridge_list = ["br-physnet1", "br-physnet2"]
        self.assertEqual(self.physnetutil._fetch_bridges(),
                         expected_bridge_list)

    def test_fetch_physnets(self):
        expected_physnet_list = ["physnet1", "physnet2"]
        with mock.patch.object(utils, 'get_physnets',
                               return_value="external,physnet1,physnet2,PHYsnet3"
                               ) as mock_get_physnets:
            self.assertEqual(self.physnetutil._fetch_physnets(),
                             expected_physnet_list)

if __name__ == '__main__':
    unittest.main()
