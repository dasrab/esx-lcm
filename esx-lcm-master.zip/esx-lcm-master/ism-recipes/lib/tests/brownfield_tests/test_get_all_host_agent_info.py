# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
from orch.moduleBase import ModuleBase
import unittest

from lib.get_all_hostagent_info import Get_All_Hostagent_Info
from lib.hpeGateway import utils


mock_host_agent_info = json.dumps(
    [{'id': 'abcd12345678',
      'roles': ['pf9-ostackhost-vmw', 'pf9-glance-role-vmw'],
      'role_status': 'ok',
      'info': {'hostname': 'fake_agent1'},
      'extensions': {
          'interfaces': {'data': {'iface_ip': {'br-int': '10.0.0.1'}}},
          'hypervisor_details': {'data': {'clusters': [
              {'name': 'Cluster1', 'datastores': 'Datastore1'}]}}}},
     {'id': 'dcba87654321',
      'roles': ['pf9-ostackhost-vmw', 'pf9-glance-role-vmw'],
      'role_status': 'ok',
      'info': {'hostname': 'fake_agent2'},
      'extensions': {
          'interfaces': {'data': {'iface_ip': {'br-int': '10.0.0.2'}}},
          'hypervisor_details': {'data': {'clusters': [
              {'name': 'Cluster2', 'datastores': 'Datastore2'}]}}}}])


class TestGetAllHostAgentInfo(unittest.TestCase):

    def setUp(self):
        super(TestGetAllHostAgentInfo, self).setUp()
        self.host_agent_obj = Get_All_Hostagent_Info()

    def _create_dummy_http_response_object(self, status, reason):
        class DummySocket():

            def makefile(self, *args, **kw):
                return self

        response = httplib.HTTPResponse(DummySocket())
        response.status = status
        response.reason = reason
        return response

    def test_execute_success(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info

        http_resp = self._create_dummy_http_response_object(200, "Accepted")

        with contextlib.nested(
            mock.patch.object(utils, 'do_request'),
            mock.patch.object(ModuleBase, 'exit_fail'),
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_host_agent_info)) as (
                mock_request, mock_fail, mock_success, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.host_agent_obj.execute(fake_params)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertFalse(mock_fail.called)
            self.assertTrue(mock_success.called)

    def test_execute_failure(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info

        http_resp = self._create_dummy_http_response_object(404, "Not Found")

        with contextlib.nested(
            mock.patch.object(utils, 'do_request'),
            mock.patch.object(ModuleBase, 'exit_fail'),
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(http_resp, "read",
                              return_value="")) as (
                mock_request, mock_fail, mock_success, mock_response_reader):
            mock_request.return_value.__enter__.return_value = ""
            self.host_agent_obj.execute(fake_params)
            self.assertTrue(mock_request.called)
            self.assertFalse(mock_response_reader.called)
            self.assertFalse(mock_success.called)
            self.assertTrue(mock_fail.called)


if __name__ == '__main__':
    unittest.main()
