# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
import mock
import unittest
from orch.moduleBase import ModuleBase

from lib.configure_neutron_server import Configure_Neutron_Server
from lib.hpeGateway.vmware_neutron_utils import VMwareNeutronConf
from lib.hpeGateway import utils


class TestConfigureNeutronServer(unittest.TestCase):

    def setUp(self):
        super(TestConfigureNeutronServer, self).setUp()
        self.configure_neutron_server_obj = Configure_Neutron_Server()

    def test_execute_success_with_neutron_enabled(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'vcenter_ip': '127.0.0.1'}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': True}
        fake_params['vmware_neutron'] = True
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['dvs_name'] = "dvSwitch1"
        with contextlib.nested(
            mock.patch.object(utils, 'is_neutron_enabled', return_value=True),
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(ModuleBase, 'exit_fail'),
            mock.patch.object(VMwareNeutronConf,
                              'update_neutron_server_conf')) as (
                                  mock_neutron_enabled,
                                  mock_success,
                                  mock_failure,
                                  mock_update_neutron_server_conf):
            self.configure_neutron_server_obj.execute(fake_params)
            self.assertTrue(mock_neutron_enabled.called)
            self.assertTrue(mock_update_neutron_server_conf.called)
            self.assertFalse(mock_failure.called)
            self.assertTrue(mock_success.called)

    def test_execute_success_with_neutron_disabled(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        fake_params['vmware_neutron'] = False
        fake_params['res_mgr_info'] = fake_res_mgr_info
        with contextlib.nested(
            mock.patch.object(utils, 'is_neutron_enabled', return_value=False),
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(ModuleBase, 'exit_fail'),
            mock.patch.object(VMwareNeutronConf,
                              'update_neutron_server_conf')) as (
                                  mock_neutron_enabled,
                                  mock_success,
                                  mock_failure,
                                  mock_update_neutron_server_conf):
            self.configure_neutron_server_obj.execute(fake_params)
            self.assertTrue(mock_neutron_enabled.called)
            self.assertFalse(mock_update_neutron_server_conf.called)
            self.assertFalse(mock_failure.called)
            self.assertTrue(mock_success.called)

    def test_execute_failure(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}
        fake_params['vmware_neutron'] = False
        fake_params['res_mgr_info'] = fake_res_mgr_info
        with contextlib.nested(
            mock.patch.object(utils, 'is_neutron_enabled', return_value=True),
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(ModuleBase, 'exit_fail'),
            mock.patch.object(VMwareNeutronConf,
                              'update_neutron_server_conf')) as (
                                  mock_neutron_enabled,
                                  mock_success,
                                  mock_failure,
                                  mock_update_neutron_server_conf):
            self.configure_neutron_server_obj.execute(fake_params)
            self.assertFalse(mock_neutron_enabled.called)
            self.assertFalse(mock_update_neutron_server_conf.called)
            self.assertFalse(mock_success.called)
            self.assertTrue(mock_failure.called)


if __name__ == '__main__':
    unittest.main()
