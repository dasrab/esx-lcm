# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from mock import patch
import unittest
import uuid
from lib.common import constants
from lib.synchronize_unmanaged_kvm_servers import (
    Synchronize_Unmanaged_Kvm_Servers
)

params = {
    'unmanaged_kvm_servers': [
        {
            'id': 'kvm-host-1',
            'name': 'kvm-host-1',
            'state': '',
            'serverUri': 'fake-server-uri',
            'volumes': [
                {
                    'name': 'fake-ds-name',
                    'size': 40.45
                }
            ]
        }
    ],
    'zone_uri': 'fake-zone-uri',
    'is_zone_managed': ''
}

INFRA_SYS_DB = list()


class FakeInfraSys(object):

    def __init__(self, private_request):
        pass

    def create_infrastructure_system(self, resource_name, extraPayloadArgs):
        extraPayloadArgs['infraState'] = constants.RUNNING
        extraPayloadArgs['uri'] = uuid.uuid4()
        INFRA_SYS_DB.append(extraPayloadArgs)

    def update_infrastructure_system(self, uri, extra_payload_args):
        for item in INFRA_SYS_DB:
            for payload in extra_payload_args:
                if payload['path'] == '/state':
                    item['state'] = payload['value']

    def delete_infrastructure_system(self, uri):
        for item in INFRA_SYS_DB:
            if item['uri'] == uri:
                INFRA_SYS_DB.remove(item)
                break


class Test_Synchronize_Unmanaged_Kvm_servers(unittest.TestCase):

    def setUp(self):
        super(Test_Synchronize_Unmanaged_Kvm_servers, self).setUp()
        self.sync_kvm_servers = Synchronize_Unmanaged_Kvm_Servers()

    @patch('lib.synchronize_unmanaged_kvm_servers.InfrastructureSystems',
           FakeInfraSys)
    def test_1_execute_create_resource(self, ):
        params['unmanaged_kvm_servers'][0]['state'] = constants.DISABLED
        with patch.object(self.sync_kvm_servers, '_get_all_infra_sys_for_zone',
                          return_value=INFRA_SYS_DB) as (
                _get_all_infra_sys_for_zone):

            self.sync_kvm_servers.execute(params)

            server_id = params['unmanaged_kvm_servers'][0]['id']
            self.assertEqual(server_id, INFRA_SYS_DB[0]['id'])
            self.assertTrue(_get_all_infra_sys_for_zone.called)

    @patch('lib.synchronize_unmanaged_kvm_servers.InfrastructureSystems',
           FakeInfraSys)
    def test_2_execute_update_resource(self):
        params['unmanaged_kvm_servers'][0]['state'] = constants.ENABLED
        with patch.object(self.sync_kvm_servers, '_get_all_infra_sys_for_zone',
                          return_value=INFRA_SYS_DB) as (
                              _get_all_infra_sys_for_zone):
            self.sync_kvm_servers.execute(params)
            server_state = params['unmanaged_kvm_servers'][0]['state']
            self.assertEqual(server_state, INFRA_SYS_DB[0]['state'])
            self.assertTrue(_get_all_infra_sys_for_zone.called)

    @patch('lib.synchronize_unmanaged_kvm_servers.InfrastructureSystems',
           FakeInfraSys)
    def test_3_execute_create_and_update_resource(self):
        params['unmanaged_kvm_servers'][0]['state'] = constants.DISABLED
        server2 = {
            'id': 'kvm-host-2',
            'name': 'kvm-host-2',
            'state': constants.ENABLED,
            'serverUri': 'fake-server-uri',
            'volumes': [
                {
                    'name': 'fake-ds-name',
                    'size': 40.45
                }
            ]
        }
        params['unmanaged_kvm_servers'].append(server2)
        with patch.object(self.sync_kvm_servers, '_get_all_infra_sys_for_zone',
                          return_value=INFRA_SYS_DB) as (
                              _get_all_infra_sys_for_zone):
            self.sync_kvm_servers.execute(params)
            server1_state = params['unmanaged_kvm_servers'][0]['state']
            self.assertEqual(server1_state, INFRA_SYS_DB[0]['state'])
            self.assertEqual(len(INFRA_SYS_DB), 2)
            self.assertEqual(server2['state'], INFRA_SYS_DB[1]['state'])
            self.assertTrue(_get_all_infra_sys_for_zone.called)

    @patch('lib.synchronize_unmanaged_kvm_servers.InfrastructureSystems',
           FakeInfraSys)
    def test_4_execute_delete_resource(self):
        params['unmanaged_kvm_servers'].pop(0)
        with patch.object(self.sync_kvm_servers, '_get_all_infra_sys_for_zone',
                          return_value=INFRA_SYS_DB) as (
                              _get_all_infra_sys_for_zone):
            self.sync_kvm_servers.execute(params)
            server = params['unmanaged_kvm_servers'][0]
            self.assertEqual(server['id'], INFRA_SYS_DB[0]['id'])
            self.assertEqual(server['state'], INFRA_SYS_DB[0]['state'])
            self.assertEqual(len(INFRA_SYS_DB), 1)
            self.assertTrue(_get_all_infra_sys_for_zone.called)
