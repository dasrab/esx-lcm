# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import contextlib
import copy
from mock import patch
import unittest

from lib.hpeGateway import utils
from lib.synchronize_kvm_server_roles import Synchronize_Kvm_Server_Roles
from lib.common import constants

HOST_ID = 'a828850e-5e62-4dad-8b08-4a98289ca9c6'
HOST_NAME = 'ubuntu-kvm'
params = {
    'resource_mgr_info': {
        'token': 'fake-token',
        'resmgr_url': '/resmgr'
    },
    'host_id': HOST_ID
}

host_agent = {
        "info": {
            "hostname": HOST_NAME
        },
        "hypervisor_info": {
            "hypervisor_type": "kvm"
        },
        "id": HOST_ID,
        "message": ""
}


class Test_Synchronize_Kvm_Server_Roles(unittest.TestCase):

    def setUp(self):
        super(Test_Synchronize_Kvm_Server_Roles, self).setUp()
        self.kvm_recovery = Synchronize_Kvm_Server_Roles()

    def test_1_execute_success(self):
        host_agent1 = copy.deepcopy(host_agent)
        host_agent1['role_status'] = (
            constants.HOST_AGENT_ROLE_STATUS_CONVERGING)
        host_agent2 = copy.deepcopy(host_agent)
        host_agent2['role_status'] = constants.HOST_AGENT_ROLE_STATUS_OK
        constants.SLEEP_TIME_TO_GET_OK_STATE = (
            constants.SLEEP_TIME_TO_GET_CONVERGING_STATE)
        with contextlib.nested(
            patch.object(utils, 'get_host_agents', return_value=[host_agent]),
            patch.object(utils, 'get_kvm_host_agent',
                         side_effect=[host_agent1, host_agent2])) as (
                get_host_agents, get_kvm_host_agent):

            ret_val = self.kvm_recovery.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_kvm_host_agent.called)

    def test_2_execute_failure(self):
        host_agent1 = copy.deepcopy(host_agent)
        host_agent1['role_status'] = (
            constants.HOST_AGENT_ROLE_STATUS_CONVERGING)
        host_agent2 = copy.deepcopy(host_agent)
        host_agent2['role_status'] = constants.HOST_AGENT_ROLE_STATUS_FAILED
        with contextlib.nested(
            patch.object(utils, 'get_host_agents', return_value=[host_agent]),
            patch.object(utils, 'get_kvm_host_agent',
                         side_effect=[host_agent1, host_agent2])) as (
                get_host_agents, get_kvm_host_agent):

            ret_val = self.kvm_recovery.execute(params)

            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'FAIL')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_kvm_host_agent.called)
