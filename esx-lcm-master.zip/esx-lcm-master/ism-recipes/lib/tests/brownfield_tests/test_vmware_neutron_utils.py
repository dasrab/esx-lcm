# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
import unittest

from lib.hpeGateway import vmware_neutron_utils
from lib.hpeGateway import utils as hpe_gateway_util


class TestVMWareNeutronUtils(unittest.TestCase):

    def setUp(self):
        super(TestVMWareNeutronUtils, self).setUp()
        params = {'hostagent_info': {},
                  'res_mgr_info': {},
                  'dvs_name': "data_dvs"}
        params['res_mgr_info']['token'] = "fakeToken"
        params['hostagent_info']['id'] = "fakeId"
        params['hostagent_info']['vcenter_ip'] = "10.10.10.10"
        params['res_mgr_info']['resmgr_url'] = "https://fakeurl.com/resmgr"
        self.vmware_neutron = vmware_neutron_utils.VMwareNeutronConf(params)

    def _create_dummy_http_response_object(self, status, reason):
        class DummySocket():

            def makefile(self, *args, **kw):
                return self

        response = httplib.HTTPResponse(DummySocket())
        response.status = status
        response.reason = reason
        return response

    def test_get_neutron_server_info(self):
        result = self.vmware_neutron._get_neutron_server_dvs_conf()
        http_resp = self._create_dummy_http_response_object(200, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            response = self.vmware_neutron.get_neutron_server_info()
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(response, result)

    def _sec_tunnel_response(self):
        response = []
        tunnel = dict(destination_host="10.10.10.10",
                      destination_port=443,
                      node_uuid="87b2d93c-b51b-4074-a31f",
                      proxy_host="example.com",
                      proxy_port=8030)
        response.append(tunnel)
        return response

    def test_get_sec_tunnel_info(self):
        result = self._sec_tunnel_response()
        http_resp = self._create_dummy_http_response_object(200, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            response = self.vmware_neutron.get_sec_tunnel_info()
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(response, result)

    def test_create_sec_tunnel(self):
        result = []
        http_resp = self._create_dummy_http_response_object(201, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_sec_tunnel_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  get_sec_tunnel_info,
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.create_sec_tunnel()
            self.assertTrue(get_sec_tunnel_info.called)
            self.assertEqual(get_sec_tunnel_info.return_value, result)
            self.assertTrue(mock_request.called)

    def test_create_sec_tunnel_tunnel_exist(self):
        result = self._sec_tunnel_response()
        http_resp = self._create_dummy_http_response_object(201, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_sec_tunnel_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  get_sec_tunnel_info,
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.create_sec_tunnel()
            self.assertTrue(get_sec_tunnel_info.called)
            self.assertFalse(mock_request.called)

    def test_delete_sec_tunnel(self):
        result = self._sec_tunnel_response()
        http_resp = self._create_dummy_http_response_object(204, "OK")
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_sec_tunnel_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request')) as (
                get_sec_tunnel_info, mock_request):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.delete_sec_tunnel()
            self.assertTrue(get_sec_tunnel_info.called)
            self.assertTrue(mock_request.called)

    def test_update_neutron_server_conf(self):
        result = self.vmware_neutron._get_neutron_server_default_conf()
        http_resp = self._create_dummy_http_response_object(201, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_neutron_server_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  get_neutron_server_info,
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.update_neutron_server_conf()
            self.assertTrue(get_neutron_server_info.called)
            self.assertTrue(mock_request.called)

    def test_update_neutron_server_conf_default(self):
        result = self.vmware_neutron._get_neutron_server_dvs_conf()
        http_resp = self._create_dummy_http_response_object(201, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_neutron_server_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  get_neutron_server_info,
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.update_neutron_server_conf(default=True)
            self.assertFalse(get_neutron_server_info.called)
            self.assertTrue(mock_request.called)

    def test_update_neutron_server_conf_dvs_exists(self):
        result = self.vmware_neutron._get_neutron_server_dvs_conf()
        http_resp = self._create_dummy_http_response_object(201, "OK")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(self.vmware_neutron, 'get_neutron_server_info',
                              return_value=result),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  get_neutron_server_info,
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.vmware_neutron.update_neutron_server_conf()
            self.assertTrue(get_neutron_server_info.called)
            self.assertFalse(mock_request.called)


if __name__ == '__main__':
    unittest.main()
