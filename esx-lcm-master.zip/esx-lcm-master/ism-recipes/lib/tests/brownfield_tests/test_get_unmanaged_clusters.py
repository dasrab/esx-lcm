# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from mock import patch
import copy
import unittest
import urlparse
from lib.get_unmanaged_resource import Get_Unmanaged_Resource


fake_host_agents = [{u'info': {u'responding': True,
                               u'hostname': u'platform9-vmware-gateway',
                               u'os_family': u'Linux',
                               u'last_response_time': None,
                               u'arch': u'x86_64',
                               u'os_info': u'centos 7.1.1503 Core'},
                     u'hypervisor_info': {u'hypervisor_type': u'VMWareCluster'},
                     u'roles': [u'pf9-glance-role-vmw',
                                u'pf9-ostackhost-vmw',
                                u'pf9-cindervolume-base',
                                u'pf9-cindervolume-other'],
                     u'role_status': u'ok',
                     u'extensions': {u'volumes_present': {u'status': u'ok',
                                                          u'data': [{u'name': u'centos',
                                                                     u'free': u'44.00m',
                                                                     u'size': u'39.51g'}]},
                                     u'interfaces': {u'status': u'ok',
                                                     u'data': {u'iface_ip': {u'br-int': u'172.22.24.15',
                                                                             u'virbr0': u'192.168.122.1'},
                                                               u'ovs_bridges': [u'br-int']}},
                                     u'hypervisor_details': {u'status': u'ok',
                                                             u'data': {u'total_time': u'0:00:01.741976',
                                                                       u'vcenter_ip': u'172.22.24.14',
                                                                       u'hypervisor_type': u'VMWareCluster',
                                                                       u'credentials': u'valid',
                                                                       u'clusters': [{u'datastores': [{u'storage_usage_gb': 353.6181640625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore12',
                                                                                                       u'moid': u'datastore-120',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 356.6083984375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore10',
                                                                                                       u'moid': u'datastore-100',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 374.90625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore13',
                                                                                                       u'moid': u'datastore-130',
                                                                                                       u'shared': False,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 360.615234375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore11',
                                                                                                       u'moid': u'datastore-110',
                                                                                                       u'shared': False,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75}],
                                                                                      u'name': u'FTC1',
                                                                                      u'cluster_usable': True,
                                                                                      u'cluster_moid': u'domain-c7',
                                                                                      u'cpu_capacity_mhz': 172512,
                                                                                      u'memory_usage_gb': 80.40625,
                                                                                      u'cpu_usage_mhz': 3179,
                                                                                      u'reason': u'',
                                                                                      u'memory_capacity_gb': 1023.5088195800781},
                                                                                     {u'datastores': [{u'storage_usage_gb': 353.6181640625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore12',
                                                                                                       u'moid': u'datastore-120',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 356.6083984375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore10',
                                                                                                       u'moid': u'datastore-100',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 374.90625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore13',
                                                                                                       u'moid': u'datastore-130',
                                                                                                       u'shared': False,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 360.615234375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore11',
                                                                                                       u'moid': u'datastore-110',
                                                                                                       u'shared': False,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75}],
                                                                                      u'name': u'FTC2',
                                                                                      u'cluster_usable': True,
                                                                                      u'cluster_moid': u'domain-c8',
                                                                                      u'cpu_capacity_mhz': 172512,
                                                                                      u'memory_usage_gb': 80.40625,
                                                                                      u'cpu_usage_mhz': 3179,
                                                                                      u'reason': u'',
                                                                                      u'memory_capacity_gb': 1023.5088195800781},
                                                                                     {u'datastores': [{u'storage_usage_gb': 353.6181640625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore12',
                                                                                                       u'moid': u'datastore-120',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 356.6083984375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore10',
                                                                                                       u'moid': u'datastore-100',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 374.90625,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore13',
                                                                                                       u'moid': u'datastore-130',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75},
                                                                                                      {u'storage_usage_gb': 360.615234375,
                                                                                                       u'datacenter_name': u'FTCLR1',
                                                                                                       u'name': u'datastore11',
                                                                                                       u'moid': u'datastore-110',
                                                                                                       u'shared': True,
                                                                                                       u'type': u'VMFS',
                                                                                                       u'storage_capacity_gb': 830.75}],
                                                                                      u'name': u'FTC3',
                                                                                      u'cluster_usable': False,
                                                                                      u'cluster_moid': u'domain-c9',
                                                                                      u'cpu_capacity_mhz': 172512,
                                                                                      u'memory_usage_gb': 80.40625,
                                                                                      u'cpu_usage_mhz': 3179,
                                                                                      u'reason': u'No Datastores Found',
                                                                                      u'memory_capacity_gb': 1023.5088195800781},
                                                                                     {u'name': u'FTC4',
                                                                                      u'cluster_usable': False,
                                                                                      u'cluster_moid': u'domain-c10',
                                                                                      u'cpu_capacity_mhz': 172512,
                                                                                      u'memory_usage_gb': 80.40625,
                                                                                      u'cpu_usage_mhz': 3179,
                                                                                      u'reason': u'Cluster has more than 1 host but DRS is not enabled',
                                                                                      u'memory_capacity_gb': 1023.5088195800781}],
                                                                       u'vcenter_id': u'7DACD400-0055-4C7E-B460-AE4062546439',
                                                                       u'pair_status': u'Insufficient permissions',
                                                                       u'permissions': u'invalid',
                                                                       u'login_time': u'0:00:00.172668'}},
                                     u'resource_usage': {u'status': u'ok',
                                                         u'data': {u'disk': {u'total': 38195646464,
                                                                             u'percent': 8.7,
                                                                             u'used': 3319902208},
                                                                   u'cpu': {u'total': 1797917000,
                                                                            u'percent': 3.0,
                                                                            u'used': 53937510.0},
                                                                   u'memory': {u'available': 5602074624,
                                                                               u'total': 8204062720,
                                                                               u'percent': 31.7}}},
                                     u'ip_address': {u'status': u'ok',
                                                     u'data': [u'192.168.122.1',
                                                               u'172.22.24.15']},
                                     u'cpu_stats': {u'status': u'ok',
                                                    u'data': {u'load_average': u'0.15 0.14 0.14'}}},
                     u'message': u'',
                     u'id': u'706a5c21-1dae-48f2-868c-d957ba530fa6'},
                    {u'info': {u'os_family': u'Linux',
                               u'hostname': u'0a85f482e8a6',
                               u'arch': u'x86_64',
                               u'os_info': u'Ubuntu 14.04 trusty'},
                     u'hypervisor_info': {u'hypervisor_type': u'kvm'},
                     u'roles': [],
                     u'extensions': {u'resource_usage': {u'status': u'ok',
                                                         u'data': {u'disk': {u'total': 906086395904,
                                                                             u'percent': 8.0,
                                                                             u'used': 72478760960},
                                                                   u'cpu': {u'total': 3500000000,
                                                                            u'percent': 1.4,
                                                                            u'used': 49000000.0},
                                                                   u'memory': {u'available': 91395551232,
                                                                               u'total': 101306703872,
                                                                               u'percent': 9.8}}},
                                     u'ip_address': {u'status': u'ok',
                                                     u'data': [u'172.50.0.8']},
                                     u'interfaces': {u'status': u'ok',
                                                     u'data': {u'iface_ip': {u'eth0': u'172.50.0.8'},
                                                               u'ovs_bridges': []}},
                                     u'volumes_present': {u'status': u'ok',
                                                          u'data': [u'Error: No vgs command found.']},
                                     u'cpu_stats': {u'status': u'ok',
                                                    u'data': {u'load_average': u'0.73 0.68 0.58'}}},
                     u'message': {u'warn': []},
                     u'id': u'79b3af00-33f7-4206-b324-b31f95c42b9f'}]


class TestGet_unanaged_Clusters(unittest.TestCase):

    def setUp(self):
        super(TestGet_unanaged_Clusters, self).setUp()
        self.unmanaged_clusters_obj = Get_Unmanaged_Resource()

    @patch('lib.hpeGateway.utils.get_all_managed_clusters_from_hpe_gateway')
    @patch('lib.hpeGateway.utils.get_host_agents')
    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test__get_unmanaged_clusters(
            self,
            mocked_rsc_mgr,
            mocked_host_agents,
            mocked_allocated_clusters):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mock_ds = [{u'storage_usage_gb': 353.6181640625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore12',
                    u'moid': u'datastore-120',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-120',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 356.6083984375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore10',
                    u'moid': u'datastore-100',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-100',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 374.90625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore13',
                    u'moid': u'datastore-130',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-130',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 360.615234375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore11',
                    u'moid': u'datastore-110',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-110',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75}]
        mocked_rsc_mgr.return_value = {
            'token': "dummyauthtoken",
            "resmgr_url": "https://dummy-du/resmgr",
            "neutron_ep_present": False}
        mocked_allocated_clusters.return_value = [u'FTC1']
        mocked_host_agents.return_value = fake_host_agents
        expected_output = {'body': [
            {'cluster_name': u'FTC1',
             'status': 'OK',
             'state': 'Enabled',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c7",
             'datastores': mock_ds},
            {'cluster_name': u'FTC2',
             'status': 'OK',
             'state': 'Disabled',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c8",
             'datastores': mock_ds},
        ], 'headers': {'module_status': 'SUCCESS'}}
        actual_output = self.unmanaged_clusters_obj.execute(params=params)
        self.assertEqual(expected_output, actual_output)

        mocked_rsc_mgr.assert_called_once_with(
            params['keystone_url'],
            params['username'],
            params['password'],
            params['tenant'],
            params['region'],
            params['vmware_neutron'])

        _url = urlparse.urlsplit("https://dummy-du/resmgr")
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": "dummyauthtoken"
                   }
        path = '/'.join([_url.path, 'v1/hosts'])
        mocked_host_agents.assert_called_once_with(_url.netloc, path, headers)

    @patch('lib.hpeGateway.utils.get_all_managed_clusters_from_hpe_gateway')
    @patch('lib.hpeGateway.utils.get_host_agents')
    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test__get_unmanaged_clusters_with_neutron_enabled(
            self,
            mocked_rsc_mgr,
            mocked_host_agents,
            mocked_allocated_clusters):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mock_ds = [{u'storage_usage_gb': 353.6181640625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore12',
                    u'moid': u'datastore-120',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-120',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 356.6083984375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore10',
                    u'moid': u'datastore-100',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-100',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 374.90625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore13',
                    u'moid': u'datastore-130',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-130',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 360.615234375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore11',
                    u'moid': u'datastore-110',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-110',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75}]
        mocked_rsc_mgr.return_value = {
            'token': "dummyauthtoken",
            "resmgr_url": "https://dummy-du/resmgr",
            "neutron_ep_present": True}
        mocked_allocated_clusters.return_value = [u'FTC1']
        fake_host_agents[0]['roles'] = []
        fake_host_agents[0]['roles'] = [u'pf9-glance-role-vmw',
                                        u'pf9-ostackhost-neutron-vmw',
                                        u'pf9-cindervolume-base',
                                        u'pf9-cindervolume-other']
        mocked_host_agents.return_value = fake_host_agents
        expected_output = {'body': [
            {'cluster_name': u'FTC1',
             'status': 'OK',
             'state': 'Enabled',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c7",
             'datastores': mock_ds},
            {'cluster_name': u'FTC2',
             'status': 'OK',
             'state': 'Disabled',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c8",
             'datastores': mock_ds},
        ], 'headers': {'module_status': 'SUCCESS'}}
        actual_output = self.unmanaged_clusters_obj.execute(params=params)
        self.assertEqual(expected_output, actual_output)

        mocked_rsc_mgr.assert_called_once_with(
            params['keystone_url'],
            params['username'],
            params['password'],
            params['tenant'],
            params['region'],
            params['vmware_neutron'])

        _url = urlparse.urlsplit("https://dummy-du/resmgr")
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": "dummyauthtoken"
                   }
        path = '/'.join([_url.path, 'v1/hosts'])
        mocked_host_agents.assert_called_once_with(_url.netloc, path, headers)

    @patch('lib.hpeGateway.utils.get_all_managed_clusters_from_hpe_gateway')
    @patch('lib.hpeGateway.utils.get_host_agents')
    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test__get_unmanaged_clusters_no_roles(
            self,
            mocked_rsc_mgr,
            mocked_host_agents,
            mocked_allocated_clusters):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mock_ds = [{u'storage_usage_gb': 353.6181640625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore12',
                    u'moid': u'datastore-120',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-120',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 356.6083984375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore10',
                    u'moid': u'datastore-100',
                    u'id': '7dacd400-0055-4c7e-b460-ae4062546439_datastore-100',
                    u'shared': True,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 374.90625,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore13',
                    u'moid': u'datastore-130',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-130',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75},
                   {u'storage_usage_gb': 360.615234375,
                    u'datacenter_name': u'FTCLR1',
                    u'name': u'datastore11',
                    u'moid': u'datastore-110',
                    u'id': u'7dacd400-0055-4c7e-b460-ae4062546439_datastore-110',
                    u'shared': False,
                    u'type': u'VMFS',
                    u'storage_capacity_gb': 830.75}]
        mocked_rsc_mgr.return_value = {
            'token': "dummyauthtoken", "resmgr_url": "https://dummy-du/resmgr",
            "neutron_ep_present": False}
        mocked_allocated_clusters.return_value = [u'FTC1']
        fake_host_agents_without_hpe_gateway_osstack_role = copy.deepcopy(
            fake_host_agents)
        fake_host_agents_without_hpe_gateway_osstack_role[0]["roles"] = []
        mocked_host_agents.return_value = fake_host_agents_without_hpe_gateway_osstack_role
        expected_output = {'body': [
            {'cluster_name': u'FTC1',

             'state': 'Disabled',
             'status': 'OK',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c7",
             'datastores': mock_ds},
            {'cluster_name': u'FTC2',

             'state': 'Disabled',
             'status': 'OK',
             'id': "7dacd400-0055-4c7e-b460-ae4062546439_domain-c8",
             'datastores': mock_ds},
        ], 'headers': {'module_status': 'SUCCESS'}}

        actual_output = self.unmanaged_clusters_obj.execute(params=params)
        self.assertEqual(expected_output, actual_output)

        mocked_rsc_mgr.assert_called_once_with(
            params['keystone_url'],
            params['username'],
            params['password'],
            params['tenant'],
            params['region'],
            params['vmware_neutron'])

        _url = urlparse.urlsplit("https://dummy-du/resmgr")
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": "dummyauthtoken"
                   }
        path = '/'.join([_url.path, 'v1/hosts'])
        mocked_host_agents.assert_called_once_with(_url.netloc, path, headers)

    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test__get_unmanaged_clusters_invalid_region(self, mocked_rsc_mgr):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mocked_rsc_mgr.return_value = {}
        expected_output = {'body': [], 'headers': {'module_status': 'SUCCESS'}}
        actual_output = self.unmanaged_clusters_obj.execute(params=params)
        self.assertEqual(expected_output, actual_output)
        mocked_rsc_mgr.assert_called_once_with(
            params['keystone_url'],
            params['username'],
            params['password'],
            params['tenant'],
            params['region'],
            params['vmware_neutron'])

    @patch('lib.hpeGateway.utils.get_host_agents')
    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test__get_unmanaged_clusters_no_hpe_gateway_hosts(
            self,
            mocked_rsc_mgr,
            mocked_host_agents):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mocked_rsc_mgr.return_value = {
            'token': "dummyauthtoken", "resmgr_url": "https://dummy-du/resmgr",
            "neutron_ep_present": False}
        mocked_host_agents.return_value = []
        expected_output = {'body': [], 'headers': {'module_status': 'SUCCESS'}}
        actual_output = self.unmanaged_clusters_obj.execute(params=params)
        self.assertEqual(expected_output, actual_output)

        mocked_rsc_mgr.assert_called_once_with(
            params['keystone_url'],
            params['username'],
            params['password'],
            params['tenant'],
            params['region'],
            params['vmware_neutron'])

        _url = urlparse.urlsplit("https://dummy-du/resmgr")
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": "dummyauthtoken"
                   }
        path = '/'.join([_url.path, 'v1/hosts'])
        mocked_host_agents.assert_called_once_with(_url.netloc, path, headers)

    @patch('lib.hpeGateway.utils.get_all_managed_clusters_from_hpe_gateway')
    @patch('lib.hpeGateway.utils.get_host_agents')
    @patch('lib.hpeGateway.utils.get_resource_manager_endpoint')
    def test_get_unmanaged_clusters_with_hosts(
            self,
            mocked_rsc_mgr,
            mocked_host_agents,
            mocked_allocated_clusters):
        params = {
            'proxy_server': 'indproxy',
            'proxy_port': '8080',
            'keystone_url': 'https://dummy-du/keystone',
            'username': 'duuser',
            'password': 'dupass',
            'tenant': 'service',
            'region': 'dummyregion',
            'vmware_neutron': True,
        }
        mocked_rsc_mgr.return_value = {
            'token': "dummyauthtoken",
            "resmgr_url": "https://dummy-du/resmgr",
            "neutron_ep_present": False
        }
        mocked_allocated_clusters.return_value = [u'FTC1']
        host_agents = copy.deepcopy(fake_host_agents)
        host_agent = host_agents[0]
        hosts = [
            {
                'name': u'FTC1',
                'hosts': {
                    'id': 'host-21',
                    'name': '10.10.10.10',
                    'totalMemoryGb': 4.0,
                    'freeMemoryGb': 2.1,
                    'totalCpuGhz': 32.09,
                    'freeCpuGhz': 16.03,
                    'datastores': [
                        'local-ds-1',
                        'shared-ds-1',
                        'shared-ds-2'
                    ]
                }
            }
        ]
        cluster_inventory = {
            'data': hosts
        }
        host_agent['extensions']['cluster_inventory'] = cluster_inventory
        mocked_host_agents.return_value = [host_agent]

        output = self.unmanaged_clusters_obj.execute(params=params)
        output = output.get('body')
        for resource in output:
            if resource.get('cluster_name') == u'FTC1':
                self.assertEqual(resource.get('hosts'), hosts[0].get('hosts'))


