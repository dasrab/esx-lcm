# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
import unittest
import urlparse

from lib.hpeGateway import utils as hpe_gateway_util
from lib.hpeGateway.utils import Proxy_Server


mock_info = {
    "vmware_appliance":
    "https://test-ova.platform9.net/private/platform9-vmware-appliancei.ova",
    "cookie":
    "X-Auth-Token=gAAAABl;Domain=test-ova.platform9.net;Path=/;Max-Age=86400",
}


class TestHPEGatewayUtil(unittest.TestCase):

    def setUp(self):
        super(TestHPEGatewayUtil, self).setUp()
        self.proxy_model = Proxy_Server
        self.hpe_gateway_util = hpe_gateway_util
        self.mock_token = "gAAAAABZeY-oV1zl"
        self.params = {
            "keystone_url": "https://test-ova.platform9.net/keystone/v3",
            "user": "abc@hpe.com",
            "password": "qabcd1234wxyz",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"}

    def _create_dummy_http_response_object(self, status, reason):
        class DummySocket():

            def makefile(self, *args, **kw):
                return self

        response = httplib.HTTPResponse(DummySocket())
        response.status = status
        response.reason = reason
        return response

    def test_do_request_with_proxy(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        Proxy_Server.set_proxy_details(
            self.params["proxy_server"],
            self.params["proxy_port"])
        with contextlib.nested(
                mock.patch('httplib.HTTPSConnection.request'),
                mock.patch('httplib.HTTPSConnection.set_tunnel'),
                mock.patch('httplib.HTTPSConnection.getresponse',
                           return_value=http_resp)) as (
                               mock_request, mock_set_tunnel,
                               mock_get_response):
            _, net_location, path, _, _ = urlparse.urlsplit(
                mock_info["vmware_appliance"])
            headers = {
                "X-Auth-Token": self.mock_token,
                "cookie": mock_info["cookie"]}
            with self.hpe_gateway_util.do_request(
                    "GET", net_location, path,
                    headers, "mock_body") as response:
                mock_request.assert_called_with(
                    "GET",
                    path,
                    '"mock_body"',
                    headers)
                self.assertIsNotNone(response)
                self.assertTrue(mock_set_tunnel.called)
                self.assertTrue(mock_get_response.called)

    def test_do_request_without_proxy(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        Proxy_Server.set_proxy_details("", "")
        with contextlib.nested(
                mock.patch('httplib.HTTPSConnection.request'),
                mock.patch('httplib.HTTPSConnection.set_tunnel'),
                mock.patch('httplib.HTTPSConnection.getresponse',
                           return_value=http_resp)) as (
                mock_request, mock_set_tunnel, mock_get_response):
            _, net_location, path, _, _ = urlparse.urlsplit(
                mock_info["vmware_appliance"])
            headers = {
                "X-Auth-Token": self.mock_token,
                "cookie": mock_info["cookie"]}
            with self.hpe_gateway_util.do_request(
                    "POST",
                    net_location,
                    path,
                    headers,
                    "mock_body") as response:
                mock_request.assert_called_with(
                    "POST",
                    path,
                    '"mock_body"',
                    headers)
                self.assertFalse(mock_set_tunnel.called)
                self.assertTrue(mock_get_response.called)
                self.assertIsNotNone(response)

    def test_get_token_v3_success(self):
        http_resp = self._create_dummy_http_response_object(200, "Accepted")

        with contextlib.nested(
                mock.patch('lib.hpeGateway.utils.do_request'),
                mock.patch.object(http_resp, "getheader",
                                  return_value=self.mock_token),
                mock.patch.object(hpe_gateway_util,
                                  '_get_token_request_body')) as (
                mock_request, mock_header_length, mock_token):
            mock_request.return_value.__enter__.return_value = http_resp
            resultant_token = self.hpe_gateway_util.get_token_v3(
                self.params["keystone_url"],
                self.params["user"],
                self.params["password"],
                self.params["tenant"])
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_header_length.called)
            mock_header_length.assert_called_with("X-Subject-Token")
            self.assertTrue(mock_token.caled)
            self.assertEqual(resultant_token, self.mock_token)

    def test_get_token_request_body(self):
        mock_request_body = {
            "auth": {
                "identity": {
                    "methods": ["password"], "password": {
                        "user": {
                            "name": self.params["user"],
                            "domain": {"id": "default"},
                            "password": self.params["password"]}}},
                "scope": {"project": {"name": self.params["tenant"],
                                      "domain": {"id": "default"}}}}}
        resultant_body = self.hpe_gateway_util._get_token_request_body(
            self.params["user"],
            self.params["password"],
            self.params["tenant"])
        self.assertEqual(resultant_body, mock_request_body)

    def test_get_all_host_agent_roles(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        result = [{"name": "pf9-monasca-agent"},
                  {"name": "pf9-cindervolume-other"},
                  {"name": "pf9-cindervolume-base"},
                  {"name": "pf9-glance-role-vmw"},
                  {"name": "pf9-ostackhost-vmw"}]
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            result = self.hpe_gateway_util.get_all_host_agent_roles(
                fake_net_location, fake_path, fake_headers)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_get_all_managed_clusters_from_hpe_gateway(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        result = {"cluster_name": "Cluster2,Cluster1",
                  "datastore_regex": "datastore2,datastore1"}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            result = self.hpe_gateway_util.get_all_managed_clusters_from_hpe_gateway(
                fake_net_location, fake_path, fake_headers)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(len(result), 2)

    def test_apply_compute_role(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_cluster_names = "Cluster2,Cluster1"
        fake_datastore_regex = "datastore2,datastore1"
        fake_neutron = {'enabled': False, 'ep_present': False}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps("")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_util._apply_compute_role(
                fake_net_location, fake_path, fake_headers,
                fake_cluster_names, fake_datastore_regex, fake_neutron)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_apply_glance_role(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_datacenter_name = "datacenter1"
        fake_datastore_name = ['datastore2']
        fake_host_agent_info = {'ip_address': '10.10.0.1'}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps("")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_util._apply_glance_role(
                fake_net_location, fake_path, fake_headers,
                fake_host_agent_info, fake_datacenter_name,
                fake_datastore_name)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_apply_cinder_volume_role(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_base = True
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps("")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_util._apply_cinder_role(
                fake_net_location, fake_path, fake_headers,
                fake_base)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_apply_monasca_role(self):
        fake_params = {}
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"

        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps("")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_util._apply_monasca_role(
                fake_net_location, fake_path, fake_headers,
                fake_params)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_wait_for_host_agent_success(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = [json.dumps({'role_status': 'converging'}),
                       json.dumps({'role_status': 'ok'})]
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch('time.sleep', return_value=None),
            mock.patch.object(http_resp, "read",
                              side_effect=mock_result)) as (
                                  mock_request, mock_sleep,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            return_value = self.hpe_gateway_util._wait_for_host_agent(
                fake_net_location, fake_path, fake_headers)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_sleep.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(return_value['role_status'], 'ok')

    def test_wait_for_host_agent_last_cluster(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps({'roles': []})
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            return_value = self.hpe_gateway_util._wait_for_host_agent(
                fake_net_location, fake_path, fake_headers, True)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(return_value, True)

    def test_wait_for_host_agent_failure(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps({'role_status': 'converging'})
        hpe_gateway_util.MAX_WAIT_TIME = 60
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch('time.sleep', return_value=None),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_sleep,
                                  mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            return_value = self.hpe_gateway_util._wait_for_host_agent(
                fake_net_location, fake_path, fake_headers)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_sleep.called)
            self.assertTrue(mock_response_reader.called)
            self.assertEqual(return_value, None)

    def test_get_resource_manager_endpoint(self):
        fake_host = 'abc.com'
        fake_useranme = 'user1'
        fake_password = 'password'
        fake_tenant = 'service'
        fake_region = 'vmware'
        fake_neutron = False
        fake_response = json.dumps({'token':
                                    {'catalog':
                                     [{'type': 'resmgr',
                                       'endpoints': [
                                           {'region': 'vmware',
                                            'interface': 'public',
                                            'url': 'www.xyz.com'}]}]}})
        fake_body = {}
        fake_token = 'dummytoken123456abcd'
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              '_get_token_request_body',
                              return_value=fake_body),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=fake_response),
            mock.patch.object(http_resp, "getheader",
                              return_value=fake_token)) as (
                                  mock_token_request,
                                  mock_request,
                                  mock_response_reader,
                                  mock_getheader):
            mock_request.return_value.__enter__.return_value = http_resp
            info = self.hpe_gateway_util.get_resource_manager_endpoint(
                fake_host, fake_useranme, fake_password,
                fake_tenant, fake_region, fake_neutron)
            self.assertTrue(mock_token_request.called)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertTrue(mock_getheader.called)
            self.assertEqual(info['resmgr_url'], "www.xyz.com")

    def test_get_resource_manager_endpoint_invalid_region(self):
        fake_host = 'abc.com'
        fake_useranme = 'user1'
        fake_password = 'password'
        fake_tenant = 'service'
        fake_region = 'invalid'
        fake_neutron = False
        fake_response = json.dumps({'token':
                                    {'catalog':
                                     [{'type': 'resmgr',
                                       'endpoints': [
                                           {'region': 'vmware',
                                            'interface': 'public',
                                            'url': 'www.xyz.com'}]}]}})
        fake_body = {}
        fake_token = 'dummytoken123456abcd'
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              '_get_token_request_body',
                              return_value=fake_body),
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=fake_response),
            mock.patch.object(http_resp, "getheader",
                              return_value=fake_token)) as (
                                  mock_token_request,
                                  mock_request,
                                  mock_response_reader,
                                  mock_getheader):
            mock_request.return_value.__enter__.return_value = http_resp
            info = self.hpe_gateway_util.get_resource_manager_endpoint(
                fake_host, fake_useranme, fake_password,
                fake_tenant, fake_region, fake_neutron)
            self.assertTrue(mock_token_request.called)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertTrue(mock_getheader.called)
            self.assertEqual(info, {})

    def test_deauthorize_host(self):
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        result = ""
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        mock_result = json.dumps(result)
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, 'do_request'),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                                  mock_request, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            self.hpe_gateway_util._deauthorize_host(
                fake_net_location, fake_path, fake_headers)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)

    def test_hpe_gateway_roles_for_allocate_first_cluster(self):
        fake_monasca_details = {}
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_hpe_gateway_roles = ['pf9-ostackhost-vmw']
        fake_ip_address = '10.0.0.1'
        fake_clusters = [{'name': 'cluster1',
                          'datastores': [{'datacenter_name': 'datacenter1',
                                          'moid': 'datastore-100',
                                          'shared': True,
                                          'type': 'VMFS',
                                          'name': 'datastore1'}]}]
        fake_cluster_names = ['cluster1']
        fake_monasca_details['region_id'] = "region1234abcd"
        fake_monasca_details['provider_id'] = "provider1234abcd"
        fake_monasca_details['zone_id'] = "zone1234abcd"
        fake_monasca_details['monasca_url'] = "http://dummy-monasca.com"
        fake_monasca_details['monasca_password'] = "dummypassword123"
        fake_monasca_details['monasca_tenant'] = "dummymonasca"
        fake_neutron = {'enabled': False, 'ep_present': False}
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, '_apply_compute_role'),
            mock.patch.object(hpe_gateway_util, '_apply_glance_role'),
            mock.patch.object(hpe_gateway_util, '_apply_cinder_role'),
            mock.patch.object(hpe_gateway_util, '_apply_monasca_role',
                              return_value=True)) as (
                                  mock_compute_role,
                                  mock_glance_role,
                                  mock_cinder_role,
                                  mock_monasca_role):
            self.hpe_gateway_util._apply_hpe_gateway_roles(
                fake_clusters, fake_cluster_names, fake_hpe_gateway_roles,
                fake_ip_address, fake_path, fake_headers,
                fake_net_location, fake_monasca_details, fake_neutron)
            self.assertTrue(mock_compute_role.called)
            self.assertTrue(mock_glance_role.called)
            self.assertTrue(mock_cinder_role.called)
            self.assertTrue(mock_monasca_role.called)

    def test_hpe_gateway_roles_with_compute_role_only(self):
        fake_monasca_details = {}
        fake_net_location = "xyz.com"
        fake_path = "/resmgr"
        fake_headers = {"Content-Type": "application/json",
                        "X-Auth-Token": "dummytoken123456abcd"}
        fake_hpe_gateway_roles = ['pf9-ostackhost-vmw']
        fake_ip_address = '10.0.0.1'
        fake_clusters = [{'name': 'cluster1',
                          'datastores': [{'datacenter_name': 'datacenter1',
                                          'moid': 'datastore-100',
                                          'shared': True,
                                          'type': 'VMFS',
                                          'name': 'datastore1'},
                                         {'datacenter_name': 'datacenter2',
                                          'moid': 'datastore-200',
                                          'shared': False,
                                          'type': 'VMFS',
                                          'name': 'datastore2'}]}]
        fake_cluster_names = ['cluster1']
        fake_monasca_details['region_id'] = "region1234abcd"
        fake_monasca_details['provider_id'] = "provider1234abcd"
        fake_monasca_details['zone_id'] = "zone1234abcd"
        fake_monasca_details['monasca_url'] = "http://dummy-monasca.com"
        fake_monasca_details['monasca_password'] = "dummypassword123"
        fake_monasca_details['monasca_tenant'] = "dummymonasca"
        fake_neutron = {'enabled': False, 'ep_present': False}

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util, '_apply_compute_role'),
            mock.patch.object(hpe_gateway_util, '_apply_glance_role'),
            mock.patch.object(hpe_gateway_util, '_apply_cinder_role'),
            mock.patch.object(hpe_gateway_util, '_apply_monasca_role',
                              return_value=True)) as (
                                  mock_compute_role,
                                  mock_glance_role,
                                  mock_cinder_role,
                                  mock_monasca_role):
            self.hpe_gateway_util._apply_hpe_gateway_roles(
                fake_clusters, fake_cluster_names, fake_hpe_gateway_roles,
                fake_ip_address, fake_path, fake_headers,
                fake_net_location, fake_monasca_details, fake_neutron)
            mock_compute_role.assert_called_once_with(
                fake_net_location, fake_path, fake_headers,
                'cluster1', 'datastore2,datastore1', fake_neutron)
            self.assertTrue(mock_compute_role.called)
            self.assertTrue(mock_glance_role.called)
            self.assertTrue(mock_cinder_role.called)
            self.assertTrue(mock_monasca_role.called)

    def test_manage_cluster(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}
        fake_cluster_list = ['cluster1']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        allocate = True
        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[[], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_wait_for_host):
            return_value = self.hpe_gateway_util.manage_cluster(
                fake_params, allocate)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertTrue(return_value)
            self.assertEqual(
                hpe_gateway_util.
                get_all_managed_clusters_from_hpe_gateway.call_count, 2)

    def test_manage_cluster_with_minimum_one_cluster_allocated(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw',
                                          'pf9-glance-role-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]},
                                    {'name': 'cluster2',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter2',
                                         'moid': 'datastore-120',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore2'}]}],
                                'ip_address': '10.0.0.1'}
        fake_cluster_list = ['cluster2']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        allocate = True
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster1'], ['cluster1', 'cluster2']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_wait_for_host):
            return_value = self.hpe_gateway_util.manage_cluster(
                fake_params, allocate)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertTrue(return_value)

    def test_manage_cluster_for_deallocate(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw',
                                          'pf9-glance-role-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}
        fake_cluster_list = ['cluster2']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        allocate = False
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster1', 'cluster2'], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_wait_for_host):
            return_value = self.hpe_gateway_util.manage_cluster(
                fake_params, allocate)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertTrue(return_value)

    def test_manage_cluster_for_deauthorize(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw',
                                          'pf9-glance-role-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}
        fake_cluster_list = ['cluster1']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        allocate = False
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster1'], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_deauthorize_host'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_deauthorize,
                                  mock_wait_for_host):
            return_value = self.hpe_gateway_util.manage_cluster(
                fake_params, allocate)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertFalse(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_deauthorize.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertTrue(return_value)

    def test_manage_cluster_failure_time_out(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}
        fake_cluster_list = ['cluster1']
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        allocate = True
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['cluster_names'] = fake_cluster_list
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster1'], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=None)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_wait_for_host):
            self.assertRaises(Exception, self.hpe_gateway_util.manage_cluster,
                              fake_params, allocate)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertRaises(Exception, self.hpe_gateway_util.manage_cluster,
                              fake_params, allocate)
            self.assertEqual(hpe_gateway_util.
                             get_all_managed_clusters_from_hpe_gateway.call_count, 2)

    def test_enable_disable_resource(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}

        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['clusters_to_allocate'] = ['cluster1']
        fake_params['clusters_to_deallocate'] = ['cluster2']
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster1'], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_deauthorize_host'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_deauthorize_host,
                                  mock_wait_for_host):
            return_value = self.hpe_gateway_util.enable_disable_resource(
                fake_params)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertFalse(mock_deauthorize_host.called)
            self.assertTrue(mock_wait_for_host.called)
            self.assertTrue(return_value)
            self.assertEqual(hpe_gateway_util.
                             get_all_managed_clusters_from_hpe_gateway.call_count, 2)

    def test_enable_disable_resource_with_deauthorize(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}

        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['clusters_to_allocate'] = []
        fake_params['clusters_to_deallocate'] = ['cluster2']
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster2'], []]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_deauthorize_host'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=True)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_deauthorize_host,
                                  mock_wait_for_host):
            self.hpe_gateway_util.enable_disable_resource(fake_params)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertFalse(mock_apply_hpe_gateway_roles.called)
            self.assertTrue(mock_deauthorize_host.called)
            self.assertTrue(mock_wait_for_host.called)

    def test_enable_disable_resource_with_failure_timeout(self):
        fake_params = {}
        fake_host_agent_info = {'id': 'abcd12345678',
                                'roles': ['pf9-ostackhost-vmw'],
                                'role_status': 'ok',
                                'clusters': [
                                    {'name': 'cluster1',
                                     'datastores': [{
                                         'datacenter_name': 'datacenter1',
                                         'moid': 'datastore-100',
                                         'shared': True,
                                         'type': 'VMFS',
                                         'name': 'datastore1'}]}],
                                'ip_address': '10.0.0.1'}

        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU',
                             'neutron_ep_present': False}
        fake_params['hostagent_info'] = fake_host_agent_info
        fake_params['res_mgr_info'] = fake_res_mgr_info
        fake_params['clusters_to_allocate'] = ['cluster1']
        fake_params['clusters_to_deallocate'] = ['cluster2']
        fake_params['region_id'] = "region1234abcd"
        fake_params['provider_id'] = "provider1234abcd"
        fake_params['zone_id'] = "zone1234abcd"
        fake_params['monasca_url'] = "http://dummy-monasca.com"
        fake_params['monasca_password'] = "dummypassword123"
        fake_params['monasca_tenant'] = "dummymonasca"
        fake_params['vmware_neutron'] = False

        with contextlib.nested(
            mock.patch.object(hpe_gateway_util,
                              'get_all_managed_clusters_from_hpe_gateway',
                              side_effect=[
                                  ['cluster2'], ['cluster1']]),
            mock.patch.object(hpe_gateway_util, '_apply_hpe_gateway_roles'),
            mock.patch.object(hpe_gateway_util, '_deauthorize_host'),
            mock.patch.object(hpe_gateway_util, '_wait_for_host_agent',
                              return_value=None)) as (
                                  mock_get_all_clusters,
                                  mock_apply_hpe_gateway_roles,
                                  mock_deauthorize_host,
                                  mock_wait_for_host):
            self.assertRaises(
                Exception, self.hpe_gateway_util.enable_disable_resource,
                fake_params)
            self.assertTrue(mock_get_all_clusters.called)
            self.assertTrue(mock_apply_hpe_gateway_roles.called)
            self.assertFalse(mock_deauthorize_host.called)
            self.assertTrue(mock_wait_for_host.called)

    def test_generate_new_ip(self):
        fake_ip_start_range = "10.10.10.120"
        fake_ip_end_range = "10.10.10.130"
        fake_reserved_ips = ["10.10.10.120",
                             "10.10.10.121",
                             "10.10.10.122",
                             "10.10.10.125"]
        fake_return_value = "10.10.10.123"
        new_ip_address = self.hpe_gateway_util.generate_new_ip(
            fake_ip_start_range, fake_ip_end_range, fake_reserved_ips)
        self.assertEqual(new_ip_address, fake_return_value)

    def test_generate_new_ip_return_none(self):
        fake_ip_start_range = "10.10.10.120"
        fake_ip_end_range = "10.10.10.123"
        fake_reserved_ips = ["10.10.10.120",
                             "10.10.10.121",
                             "10.10.10.122",
                             "10.10.10.123"]
        new_ip_address = self.hpe_gateway_util.generate_new_ip(
            fake_ip_start_range, fake_ip_end_range, fake_reserved_ips)
        self.assertEqual(new_ip_address, None)


if __name__ == '__main__':
    unittest.main()
