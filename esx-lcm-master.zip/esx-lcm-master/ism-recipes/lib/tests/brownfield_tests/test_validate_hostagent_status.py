# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import json
import mock
from orch.moduleBase import ModuleBase
import unittest

from lib.hpeGateway import utils
from lib import validate_hostagent_status

mock_host_agent_info = [{'id': 'abcd12345678',
                         'roles': ['pf9-ostackhost-vmw',
                                   'pf9-glance-role-vmw'],
                         'role_status': 'ok',
                         'extensions': {
                             'interfaces': {'data':
                                            {'iface_ip':
                                             {'br-int': '10.0.0.1'}}},
                             'hypervisor_details':
                             {'data': {'clusters': [
                                 {'name': 'Cluster1',
                                  'datastores': 'Datastore1'}]}}}}]


class TestValidate_Hostagent_Status(unittest.TestCase):

    def setUp(self):
        super(TestValidate_Hostagent_Status, self).setUp()
        self.validate_hostagent_status_obj = (
            validate_hostagent_status.Validate_Hostagent_Status())

    def _create_dummy_http_response_object(self, status, reason):
        class DummySocket():

            def makefile(self, *args, **kw):
                return self

        response = httplib.HTTPResponse(DummySocket())
        response.status = status
        response.reason = reason
        return response

    def test_execute_success(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        fake_result = result = {'is_valid': True,
                                'details': '', 'error_code': ''}
        mock_result = json.dumps(mock_host_agent_info)
        with contextlib.nested(
            mock.patch.object(utils, 'do_request'),
            mock.patch.object(ModuleBase, 'exit_success',
                              return_value=fake_result),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                mock_request, mock_success, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            result = self.validate_hostagent_status_obj.execute(fake_params)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertTrue(mock_success.called)
            self.assertEqual(result['is_valid'], True)

    def test_execute_failure(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info
        http_resp = self._create_dummy_http_response_object(200, "Accepted")
        fake_result = result = {'is_valid': False,
                                'details': '', 'error_code': ''}
        mock_host_agent_info[0]['role_status'] = 'converging'
        mock_result = json.dumps(mock_host_agent_info)
        with contextlib.nested(
            mock.patch.object(utils, 'do_request'),
            mock.patch.object(ModuleBase, 'exit_success',
                              return_value=fake_result),
            mock.patch.object(http_resp, "read",
                              return_value=mock_result)) as (
                mock_request, mock_success, mock_response_reader):
            mock_request.return_value.__enter__.return_value = http_resp
            result = self.validate_hostagent_status_obj.execute(fake_params)
            self.assertTrue(mock_request.called)
            self.assertTrue(mock_response_reader.called)
            self.assertTrue(mock_success.called)
            self.assertEqual(result['is_valid'], False)


if __name__ == '__main__':
    unittest.main()
