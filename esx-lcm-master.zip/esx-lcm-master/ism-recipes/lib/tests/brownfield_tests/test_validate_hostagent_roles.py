# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import mock
import unittest

from lib.hpeGateway import utils
from lib import validate_hostagent_roles


class TestValidate_Hostagent_Roles(unittest.TestCase):

    def setUp(self):
        super(TestValidate_Hostagent_Roles, self).setUp()
        self.validate_hostagent_roles_obj = (
            validate_hostagent_roles.Validate_Hostagent_Roles())

    def test_execute_success(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info
        mock_result = ["pf9-monasca-agent", "pf9-cindervolume-other",
                       "pf9-cindervolume-base", "pf9-glance-role-vmw",
                       "pf9-ostackhost-vmw"]
        with mock.patch.object(utils,
                               'get_all_host_agent_roles',
                               return_value=mock_result) as (
                                   mock_get_all_host_agent_roles):
            result = self.validate_hostagent_roles_obj.execute(fake_params)
            self.assertTrue(mock_get_all_host_agent_roles.called)
            self.assertEqual(result['body']['is_valid'], True)

    def test_execute_failure(self):
        fake_params = {}
        fake_res_mgr_info = {'resmgr_url': 'https://xyz.net/resmgr',
                             'token': 'gAAAAABZet95FlYNH-iVTn7YrydfU'}

        fake_params['info'] = fake_res_mgr_info
        mock_result = ["pf9-cindervolume-other",
                       "pf9-cindervolume-base", "pf9-glance-role-vmw",
                       "pf9-ostackhost-vmw"]
        with mock.patch.object(utils,
                               'get_all_host_agent_roles',
                               return_value=mock_result) as (
                                   mock_get_all_host_agent_roles):
            result = self.validate_hostagent_roles_obj.execute(fake_params)
            self.assertTrue(mock_get_all_host_agent_roles.called)
            self.assertEqual(result['body']['is_valid'], False)


if __name__ == '__main__':
    unittest.main()
