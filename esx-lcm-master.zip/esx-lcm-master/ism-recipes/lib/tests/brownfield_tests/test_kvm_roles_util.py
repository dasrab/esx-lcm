# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from mock import patch
import unittest

from lib.common import constants as const
from lib.hpeGateway.kvm_roles_util import KVMRolesUtil
from lib.hpeGateway import utils

params = {
    'net_loc': 'fake-netloc',
    'host_agent': {
        'id': 'fake-host-agent-id',
        'roles': [],
        'extensions': {
            'interfaces': {
                'data': {
                    'ovs_bridges': [
                        'br-physnet1',
                        'br-physnet2',
                    ]
                }
            }
        },
    },
    'res_mgr_path': '/resmgr',
    'headers': 'fake-headers',
    'kvm_ip': 'fake-ip',
    'is_enable': True
}

role_defs = [dict(name=role) for role in const.PRIMARY_KVM_ROLES]
role_defs += [
    dict(name=const.GLANCE_ROLE),
    dict(name=const.CINDER_VOLUME_CEPH_ROLE)
]


class Test_KVMRolesUtil(unittest.TestCase):

    def setUp(self):
        super(Test_KVMRolesUtil, self).setUp()
        with patch.object(KVMRolesUtil, '_get_kvm_role_definitions',
                          return_value=role_defs):
            self.kvm_roles_util = KVMRolesUtil(**params)

    def test_apply_role(self):
        with patch.object(utils, 'do_request') as do_request:
            self.kvm_roles_util.apply_role('fake-role')
            self.assertTrue(do_request.called)

    def test_create_physnet_to_bridge_mappings(self):
        expected_bridge_mappings = "physnet2:br-physnet2,physnet1:br-physnet1"
        with patch.object(utils, 'get_physnets',
                          return_value="physnet1,physnet2") as (
                get_physnets):
            created_bridge_mappings = (
                self.kvm_roles_util._create_physnet_to_bridge_mappings())
            self.assertEqual(
                expected_bridge_mappings, created_bridge_mappings)
            self.assertTrue(get_physnets.called)

    def test_delete_all_roles(self):
        with patch.object(utils, 'do_request') as (do_request):
            self.kvm_roles_util.delete_all_roles()
            self.assertTrue(do_request.called)

    def test_get_pf9_cindervolume_ceph_body(self):
        body = self.kvm_roles_util._get_pf9_cindervolume_ceph_body()
        self.assertEqual(body.get('volume_backend_name'),
                         const.STORAGE_VOLUME_NAME)
        self.assertEqual(body.get('rbd_pool'),
                         const.STORAGE_POOL_NAME)

    def test_get_pf9_cindervolume_lvm_body(self):
        body = self.kvm_roles_util._get_pf9_cindervolume_lvm_body()
        self.assertEqual(body.get('iscsi_ip_address'), params['kvm_ip'])
        self.assertEqual(body.get('volume_backend_name'),
                         const.STORAGE_VOLUME_NAME)
