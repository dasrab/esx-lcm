# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest

from lib.get_cluster_names_from_resource_list import Get_Cluster_Names_From_Resource_List


class Test_Get_Cluster_Names_From_Resource_List(unittest.TestCase):

    def setUp(self):
        super(Test_Get_Cluster_Names_From_Resource_List, self).setUp()
        self.cluster_names_from_res_obj = Get_Cluster_Names_From_Resource_List()

    def test_execute_enabling_success(self):
        fake_params = {

            'resource_list': [{"state": "Enabling",
                               "name": "TestCluster1"
                               }]
        }

        cluster_names = self.cluster_names_from_res_obj.execute(fake_params)
        self.assertEquals(cluster_names['body']
                          ['enable_clusters'], ['TestCluster1'])

    def test_execute_disabling_success(self):
        fake_params = {

            'resource_list': [{"state": "Disabling",
                               "name": "TestCluster1"
                               }]
        }

        cluster_names = self.cluster_names_from_res_obj.execute(fake_params)
        self.assertEquals(cluster_names['body']
                          ['disable_clusters'], ['TestCluster1'])

    def test_execute_failure(self):
        self.fake_params = {

            'resource_list': [{
            }]
        }
        self.fail_status = {'module_status': 'FAIL'}

        cluster_names = self.cluster_names_from_res_obj.execute(
            self.fake_params)
        self.assertEquals(cluster_names['headers'], self.fail_status)
