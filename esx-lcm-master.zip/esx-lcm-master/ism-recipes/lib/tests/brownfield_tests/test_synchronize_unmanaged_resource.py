# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import contextlib
import copy
import mock
from orch.moduleBase import ModuleBase
from orch.private_request import PrivateRequest
import unittest
from lib.synchronize_unmanaged_resource import Synchronize_Unmanaged_Resource
from orch.ism_sdk.infrastructure_systems import InfrastructureSystems
from requests.exceptions import HTTPError
from lib.common import constants as const


hosts = [
    {
        'id': 'host-21',
        'name': '10.10.10.10',
        'totalMemoryGb': 4.0,
        'freeMemoryGb': 2.1,
        'totalCpuGhz': 32.09,
        'freeCpuGhz': 16.03,
        'datastores': [
            'local-ds-1',
            'shared-ds-1',
            'shared-ds-2'
        ]
    }
]


class Test_Synchronize_Unmanaged_Resource(unittest.TestCase):

    def setUp(self):
        super(Test_Synchronize_Unmanaged_Resource, self).setUp()
        self.synchronize_unmanaged_resource_obj = (
            Synchronize_Unmanaged_Resource())

    def test_execute_success(self):
        fake_unmanaged_resource = [{
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }
            ], "state": "Enabled"}]
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_is_zone_managed = False
        fake_params = {"unmanaged_resources": fake_unmanaged_resource,
                       "zone_uri": fake_zone_uri,
                       "is_zone_managed": fake_is_zone_managed}

        with contextlib.nested(
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'sync_unmanaged_resource_for_esx_lcm')) as (
                                  mock_exit_success,
                                  mock_sync_unmanaged_resource):
            self.synchronize_unmanaged_resource_obj.execute(fake_params)
            mock_sync_unmanaged_resource.assert_called_with(
                fake_unmanaged_resource, fake_zone_uri, None)
            self.assertTrue(mock_sync_unmanaged_resource.called)
            self.assertTrue(mock_exit_success.called)

    def test_execute_failure(self):
        fake_unmanaged_resource = {
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }
            ], "state": "Enabled"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_is_zone_managed = False
        fake_params = {"unmanaged_resources": fake_unmanaged_resource,
                       "zone_uri": fake_zone_uri,
                       "is_zone_managed": fake_is_zone_managed}

        with contextlib.nested(
            mock.patch.object(ModuleBase, 'exit_success'),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'sync_unmanaged_resource_for_esx_lcm')) as (
                                  mock_exit_success,
                                  mock_sync_unmanaged_resource):
            self.synchronize_unmanaged_resource_obj.execute(fake_params)
            self.assertFalse(mock_sync_unmanaged_resource.called)
            self.assertTrue(mock_exit_success.called)

    def test_categorize_datastores(self):
        fake_datastores_from_gateway = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore24",
             "sizeGiB": 1000, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-12",
             "name": "datastore42",
             "sizeGiB": 950, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-14",
             "name": "datastore41",
             "sizeGiB": 900, "type": "VSAN"}]
        fake_datastores_from_db = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore24",
             "sizeGiB": 1000, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-12",
             "name": "datastore42",
             "sizeGiB": 950, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-15",
             "name": "datastore5",
             "sizeGiB": 900, "type": "VSAN"}]
        expected_result = {
            "existing_datastores": [
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                 "name": "datastore24",
                 "sizeGiB": 1000, "type": "VMFS"},
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-12",
                 "name": "datastore42",
                 "sizeGiB": 950, "type": "VMFS"}],
            "new_datastores": [
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-14",
                 "name": "datastore41",
                 "sizeGiB": 900, "type": "VSAN"}],
            "datastores_to_be_deleted": [
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-15",
                 "name": "datastore5",
                 "sizeGiB": 900, "type": "VSAN"}]}
        result = (
            self.synchronize_unmanaged_resource_obj._categorize_datastores(
                fake_datastores_from_gateway,
                fake_datastores_from_db))
        self.assertEqual(result, expected_result)

    def test_get_datastores_dict_from_clusters(self):
        fake_clutser_info = [{
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }
            ], "state": "Enabled"}]
        fake_resource = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
                         "cluster_name": "Cluster1"}
        expected_result = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore1",
             "sizeGiB": 924.0,
             "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
             "name": "datastore2",
             "sizeGiB": 924.0,
             "type": "VMFS"}]

        result = (
            self.synchronize_unmanaged_resource_obj._get_datastores_dict_from_clusters(
                fake_resource,
                fake_clutser_info))
        self.assertEqual(result, expected_result)

    def test_get_datastores_dict_from_clusters_for_unmatched_resource(self):
        fake_cluster_info = [{
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }
            ], "state": "Enabled"}]
        fake_resource = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
                         "cluster_name": "Cluster2"}
        expected_result = []

        result = (
            self.synchronize_unmanaged_resource_obj._get_datastores_dict_from_clusters(
                fake_resource,
                fake_cluster_info))
        self.assertEqual(result, expected_result)

    def test_categorize_resource_with_no_clusters_from_db(self):
        fake_private_req = PrivateRequest()
        fake_ism_client = InfrastructureSystems(fake_private_req)
        gateway_cluster1 = {
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        gateway_cluster2 = {
            "cluster_name": "Cluster2",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore3",
                    "moid": "datastore-30",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore4",
                    "moid": "datastore-40",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        gateway_cluster4 = {
            "cluster_name": "Cluster4",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c9",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore5",
                    "moid": "datastore-50",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-50",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore6",
                    "moid": "datastore-60",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-60",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_cluster_info = [gateway_cluster1,
                             gateway_cluster2,
                             gateway_cluster4]
        mock_clusters_from_db = []
        expected_result = {
            "existing_unmanaged_resources": [],
            "new_unmanaged_resources": [gateway_cluster1,
                                        gateway_cluster2,
                                        gateway_cluster4],
            "unmanaged_resource_to_be_deleted": []}

        with mock.patch.object(fake_ism_client,
                               'get_all_infrastructure_systems',
                               return_value=mock_clusters_from_db) as (
                                   mock_get_all_clusters_from_db):
            self.synchronize_unmanaged_resource_obj.is_zone_managed = False
            return_value = (
                self.synchronize_unmanaged_resource_obj.categorize_resource(
                    fake_ism_client, fake_cluster_info, fake_zone_uri))
            self.assertTrue(mock_get_all_clusters_from_db.called)
            self.assertEqual(expected_result, return_value)

    def test_categorize_resource(self):
        fake_private_req = PrivateRequest()
        fake_ism_client = InfrastructureSystems(fake_private_req)
        gateway_cluster1 = {
            "cluster_name": "Cluster1",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        gateway_cluster2 = {
            "cluster_name": "Cluster2",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore3",
                    "moid": "datastore-30",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore4",
                    "moid": "datastore-40",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        gateway_cluster4 = {
            "cluster_name": "Cluster4",
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c9",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore5",
                    "moid": "datastore-50",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-50",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore6",
                    "moid": "datastore-60",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-60",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "state": "Enabled"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        db_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "uri": "/rest/infrastructuresystems/2132131233",
            "infraState": "Running",
            "associatedZoneURI": fake_zone_uri}
        db_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "name": "Cluster2",
            "uri": "/rest/infrastructuresystems/2132131233",
            "infraState": "Running",
            "associatedZoneURI": fake_zone_uri}
        db_cluster5 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c11",
            "name": "Cluster5",
            "uri": "/rest/infrastructuresystems/2132131233",
            "infraState": "Running",
            "associatedZoneURI": fake_zone_uri}
        fake_cluster_info = [gateway_cluster1,
                             gateway_cluster2,
                             gateway_cluster4]
        mock_clusters_from_db = [db_cluster1, db_cluster2, db_cluster5]
        expected_result = {
            "existing_unmanaged_resources": [db_cluster1, db_cluster2],
            "new_unmanaged_resources": [gateway_cluster4],
            "unmanaged_resource_to_be_deleted": [db_cluster5]}

        with mock.patch.object(fake_ism_client,
                               'get_all_infrastructure_systems',
                               return_value=mock_clusters_from_db) as (
                                   mock_get_all_clusters_from_db):
            self.synchronize_unmanaged_resource_obj.is_zone_managed = False
            return_value = (
                self.synchronize_unmanaged_resource_obj.categorize_resource(
                    fake_ism_client, fake_cluster_info, fake_zone_uri))
            self.assertTrue(mock_get_all_clusters_from_db.called)
            self.assertEqual(expected_result, return_value)

    def test_is_update_required_for_cluster_name_change(self):
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster2",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [
                {"id": "datastore1", "name": "datastore1",
                 "sizeGiB": 924.0, "type": "VMFS"},
                {"id": "datastore2", "name": "datastore2",
                 "sizeGiB": 924.0, "type": "VMFS"}],
            "hosts": hosts}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "hosts": hosts}]
        fake_datastores_from_gateway = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore1",
             "sizeGiB": 1000, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
             "name": "datastore2",
             "sizeGiB": 950, "type": "VMFS"}]
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value={}) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     fake_datastores_from_gateway))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                fake_datastores_from_gateway,
                fake_resource['datastores'])

    def test_is_update_required_for_cluster_state_change(self):
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                 "name": "datastore1",
                 "sizeGiB": 924.0, "type": "VMFS"},
                {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                 "name": "datastore2",
                 "sizeGiB": 924.0, "type": "VMFS"}],
            "hosts": hosts}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }],
            "hosts": hosts}]
        fake_datastores_from_gateway = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore1",
             "sizeGiB": 1000, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
             "name": "datastore2",
             "sizeGiB": 950, "type": "VMFS"}]
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value={}) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     fake_datastores_from_gateway))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                fake_datastores_from_gateway,
                fake_resource['datastores'])

    def test_is_update_required_host_free_cpu_changed(self):
        fake_resource = {
            "id": "fake-id",
            "name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [],
            "hosts": hosts}

        cluster_hosts = copy.deepcopy(hosts)
        cluster_hosts[0]['freeCpuGhz'] = 10.03
        fake_cluster_info = [{
            "id": "fake-id",
            "cluster_name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "datastores": [],
            "hosts": cluster_hosts}]
        with mock.patch.object(
                Synchronize_Unmanaged_Resource, '_categorize_datastores',
                return_value={}) as (mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     []))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)

    def test_is_update_required_host_free_memory_changed(self):
        fake_resource = {
            "id": "fake-id",
            "name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [],
            "hosts": hosts}

        cluster_hosts = copy.deepcopy(hosts)
        cluster_hosts[0]['freeMemoryGb'] = 1.1
        fake_cluster_info = [{
            "id": "fake-id",
            "cluster_name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "datastores": [],
            "hosts": cluster_hosts}]
        with mock.patch.object(
                Synchronize_Unmanaged_Resource, '_categorize_datastores',
                return_value={}) as (mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     []))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)

    def test_is_update_required_host_datastore_removed(self):
        fake_resource = {
            "id": "fake-id",
            "name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [],
            "hosts": hosts}

        cluster_hosts = copy.deepcopy(hosts)
        cluster_hosts[0]['datastores'].pop(0)
        fake_cluster_info = [{
            "id": "fake-id",
            "cluster_name": "Cluster1",
            "state": "Disabled",
            "status": "OK",
            "datastores": [],
            "hosts": cluster_hosts}]
        with mock.patch.object(
                Synchronize_Unmanaged_Resource, '_categorize_datastores',
                return_value={}) as (mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     []))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)

    def test_is_update_required_for_new_datastore_added(self):
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "hosts": hosts,
            "datastores": []}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [
                {
                    "datacenter_name": "DC1",
                    "name": "datastore1",
                    "moid": "datastore-10",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 198.830078125},
                {
                    "datacenter_name": "DC2",
                    "name": "datastore2",
                    "moid": "datastore-20",
                    "id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "shared": True,
                    "type": "VMFS",
                    "storage_capacity_gb": 924.0,
                    "storage_usage_gb": 286.67578125
                }]}]
        fake_datastores_from_gateway = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore1",
             "sizeGiB": 924, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
             "name": "datastore2",
             "sizeGiB": 924, "type": "VMFS"}]
        fake_categorize_datastore = {
            "existing_datastores": [],
            "new_datastores": fake_datastores_from_gateway,
            "datastores_to_be_deleted": []}
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value=fake_categorize_datastore) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     fake_datastores_from_gateway))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                fake_datastores_from_gateway,
                fake_resource['datastores'])

    def test_is_update_required_for_existing_datastore_added(self):
        fake_datastores = [
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
             "name": "datastore1",
             "sizeGiB": 924, "type": "VMFS"},
            {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
             "name": "datastore2",
             "sizeGiB": 924, "type": "VMFS"}]
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "hosts": hosts,
            "datastores": fake_datastores}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": []}]
        fake_categorize_datastore = {
            "existing_datastores": [],
            "new_datastores": [],
            "datastores_to_be_deleted": fake_datastores}
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value=fake_categorize_datastore) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     []))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                [], fake_resource['datastores'])

    def test_is_update_required_for_datastore_name_change(self):
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                     "name": "datastore3",
                     "sizeGiB": 924, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                     "name": "datastore4",
                     "sizeGiB": 924, "type": "VMFS"}
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "datastores": [fake_ds11, fake_ds22],
            "hosts": hosts}]
        fake_categorize_datastore = {
            "existing_datastores": [fake_ds1, fake_ds2],
            "new_datastores": [],
            "datastores_to_be_deleted": []}
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value=fake_categorize_datastore) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     [fake_ds11, fake_ds22]))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                [fake_ds11, fake_ds22], fake_resource['datastores'])

    def test_is_update_required_for_datastore_size_change(self):
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                     "name": "datastore1",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                     "name": "datastore2",
                     "sizeGiB": 1500, "type": "VMFS"}
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds11, fake_ds22]}]
        fake_categorize_datastore = {
            "existing_datastores": [fake_ds1, fake_ds2],
            "new_datastores": [],
            "datastores_to_be_deleted": []}
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value=fake_categorize_datastore) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     [fake_ds11, fake_ds22]))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, True)
            mock_categorize_datastores.assert_called_with(
                [fake_ds11, fake_ds22], fake_resource['datastores'])

    def test_is_update_not_required_(self):
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                     "name": "datastore1",
                     "sizeGiB": 924, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                     "name": "datastore2",
                     "sizeGiB": 924, "type": "VMFS"}
        fake_resource = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts}
        fake_cluster_info = [{
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "datastores": [fake_ds11, fake_ds22],
            "hosts": hosts}]
        fake_categorize_datastore = {
            "existing_datastores": [fake_ds1, fake_ds2],
            "new_datastores": [],
            "datastores_to_be_deleted": []}
        with mock.patch.object(Synchronize_Unmanaged_Resource,
                               '_categorize_datastores',
                               return_value=fake_categorize_datastore) as (
                                   mock_categorize_datastores):
            return_value = (
                 self.synchronize_unmanaged_resource_obj._is_update_required(
                     fake_resource, fake_cluster_info,
                     [fake_ds11, fake_ds22]))
            self.assertTrue(mock_categorize_datastores.called)
            self.assertEqual(return_value, False)
            mock_categorize_datastores.assert_called_with(
                [fake_ds11, fake_ds22], fake_resource['datastores'])

    def test_sync_unmanaged_resource_for_esx_lcm(self):
        fake_private_req = PrivateRequest()
        self.synchronize_unmanaged_resource_obj.private_request = (
            fake_private_req)
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-110",
                     "name": "datastore11",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-220",
                     "name": "datastore22",
                     "sizeGiB": 1500, "type": "VMFS"}
        fake_ds3 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "name": "datastore3",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds4 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "name": "datastore4",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds33 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-330",
                     "name": "datastore33",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds44 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-440",
                     "name": "datastore44",
                     "sizeGiB": 1500, "type": "VMFS"}
        db_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster11",
            "state": "Enabled",
            "status": "OK",

            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131233",
            "hosts": hosts,
            "datastores": [fake_ds1, fake_ds2],
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "name": "Cluster22",
            "state": "Enabled",
            "infraState": "Running",
            "status": "OK",
            "status": const.CRITICAL,
            "uri": "/rest/infrastructuresystems/2132131234",
            "hosts": hosts,
            "datastores": [fake_ds11, fake_ds22],
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster5 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c9",
            "name": "Cluster55",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131235",
            "datastores": [fake_ds3, fake_ds4],
            "hosts": hosts,
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts}
        fake_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "cluster_name": "Cluster2",
            "state": "Enabled",
            "status": "OK",
            "datastores": [fake_ds11, fake_ds22],
            "hosts": hosts}
        fake_cluster4 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c10",
            "cluster_name": "Cluster4",
            "state": "Enabled",
            "datastores": [fake_ds33, fake_ds44],
            "hosts": hosts}
        fake_cluster_info = [fake_cluster1, fake_cluster2, fake_cluster4]
        fake_categorize_resource = {
            "existing_unmanaged_resources": [db_cluster1, db_cluster2],
            "new_unmanaged_resources": [fake_cluster4],
            "unmanaged_resource_to_be_deleted": [db_cluster5]}

        with contextlib.nested(
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'categorize_resource',
                              return_value=fake_categorize_resource),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_form_datastores_dict',
                              return_value=[fake_ds33, fake_ds44]),
            mock.patch.object(InfrastructureSystems,
                              'create_infrastructure_system'),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_get_datastores_dict_from_clusters',
                              side_effect=[[fake_ds1, fake_ds2],
                                           [fake_ds11, fake_ds22]]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_is_update_required',
                              side_effect=[True, False]),
            mock.patch.object(InfrastructureSystems,
                              'update_infrastructure_system'),
            mock.patch.object(InfrastructureSystems,
                              'delete_infrastructure_system')) as (
                                  mock_categorize_resource,
                                  mock_form_datastore_dict,
                                  mock_create_infra_system,
                                  mock_get_datastores,
                                  mock_is_update_required,
                                  mock_update_infra_system,
                                  mock_delete_infra_system):
            self.synchronize_unmanaged_resource_obj.sync_unmanaged_resource_for_esx_lcm(
                fake_cluster_info, fake_zone_uri)
            mock_form_datastore_dict.assert_called_with([fake_ds33, fake_ds44])
            self.assertTrue(mock_categorize_resource.called)
            self.assertTrue(mock_form_datastore_dict.called)
            self.assertTrue(mock_create_infra_system.called)
            self.assertTrue(mock_get_datastores.called)
            self.assertTrue(mock_is_update_required.called)
            self.assertTrue(mock_update_infra_system.called)
            self.assertTrue(mock_delete_infra_system.called)
            self.assertEqual(
                InfrastructureSystems.create_infrastructure_system.call_count,
                1)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._get_datastores_dict_from_clusters.call_count, 2)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._is_update_required.call_count, 2)
            self.assertEqual(
                InfrastructureSystems.update_infrastructure_system.call_count,
                1)
            self.assertEqual(
                InfrastructureSystems.delete_infrastructure_system.call_count,
                1)

    def test_sync_unmanaged_resource_for_esx_lcm_with_configuring_state(self):
        fake_private_req = PrivateRequest()
        self.synchronize_unmanaged_resource_obj.private_request = (
            fake_private_req)
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-110",
                     "name": "datastore11",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-220",
                     "name": "datastore22",
                     "sizeGiB": 1500, "type": "VMFS"}
        fake_ds3 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "name": "datastore3",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds4 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "name": "datastore4",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds33 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-330",
                     "name": "datastore33",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds44 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-440",
                     "name": "datastore44",
                     "sizeGiB": 1500, "type": "VMFS"}
        db_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster11",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Configuring",
            "uri": "/rest/infrastructuresystems/2132131233",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts,
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "name": "Cluster22",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Configuring",
            "uri": "/rest/infrastructuresystems/2132131234",
            "hosts": hosts,
            "datastores": [fake_ds11, fake_ds22],
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster5 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c9",
            "name": "Cluster55",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131235",
            "hosts": hosts,
            "datastores": [fake_ds3, fake_ds4],
            "associatedZoneURI": fake_zone_uri,
            "managed": "True"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds1, fake_ds2]}
        fake_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "cluster_name": "Cluster2",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds11, fake_ds22]}
        fake_cluster4 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c10",
            "cluster_name": "Cluster4",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds33, fake_ds44]}
        fake_cluster_info = [fake_cluster1, fake_cluster2, fake_cluster4]
        fake_categorize_resource = {
            "existing_unmanaged_resources": [db_cluster1, db_cluster2],
            "new_unmanaged_resources": [fake_cluster4],
            "unmanaged_resource_to_be_deleted": [db_cluster5]}

        with contextlib.nested(
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'categorize_resource',
                              return_value=fake_categorize_resource),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_form_datastores_dict',
                              return_value=[fake_ds33, fake_ds44]),
            mock.patch.object(InfrastructureSystems,
                              'create_infrastructure_system'),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_get_datastores_dict_from_clusters',
                              side_effect=[[fake_ds1, fake_ds2],
                                           [fake_ds11, fake_ds22]]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_is_update_required',
                              side_effect=[True, True]),
            mock.patch.object(InfrastructureSystems,
                              'update_infrastructure_system'),
            mock.patch.object(InfrastructureSystems,
                              'delete_infrastructure_system')) as (
                                  mock_categorize_resource,
                                  mock_form_datastore_dict,
                                  mock_create_infra_system,
                                  mock_get_datastores,
                                  mock_is_update_required,
                                  mock_update_infra_system,
                                  mock_delete_infra_system):
            self.synchronize_unmanaged_resource_obj.sync_unmanaged_resource_for_esx_lcm(
                fake_cluster_info, fake_zone_uri)
            mock_form_datastore_dict.assert_called_with([fake_ds33, fake_ds44])
            self.assertTrue(mock_categorize_resource.called)
            self.assertTrue(mock_form_datastore_dict.called)
            self.assertTrue(mock_create_infra_system.called)
            self.assertFalse(mock_get_datastores.called)
            self.assertFalse(mock_is_update_required.called)
            self.assertFalse(mock_update_infra_system.called)
            self.assertFalse(mock_delete_infra_system.called)
            self.assertEqual(
                InfrastructureSystems.create_infrastructure_system.call_count,
                1)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._get_datastores_dict_from_clusters.call_count, 0)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._is_update_required.call_count, 0)
            self.assertEqual(
                InfrastructureSystems.update_infrastructure_system.call_count,
                0)
            self.assertEqual(
                InfrastructureSystems.delete_infrastructure_system.call_count,
                0)

    def test_sync_unmanaged_resource_for_esx_lcm_with_exception_handing(self):
        fake_private_req = PrivateRequest()
        self.synchronize_unmanaged_resource_obj.private_request = (
            fake_private_req)
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-110",
                     "name": "datastore11",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-220",
                     "name": "datastore22",
                     "sizeGiB": 1500, "type": "VMFS"}
        fake_ds3 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "name": "datastore3",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds4 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "name": "datastore4",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds33 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-330",
                     "name": "datastore33",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds44 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-440",
                     "name": "datastore44",
                     "sizeGiB": 1500, "type": "VMFS"}
        db_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster11",
            "state": "Enabled",
            "status": "OK",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131233",
            "datastores": [fake_ds1, fake_ds2],
            "hosts": hosts,
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster5 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c11",
            "name": "Cluster55",
            "state": "Disabled",
            "status": "OK",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131235",
            "datastores": [fake_ds3, fake_ds4],
            "hosts": hosts,
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds1, fake_ds2]}
        fake_cluster2 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c8",
            "cluster_name": "Cluster2",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds11, fake_ds22]}
        fake_cluster4 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c10",
            "cluster_name": "Cluster4",
            "state": "Enabled",
            "status": "OK",
            "hosts": hosts,
            "datastores": [fake_ds33, fake_ds44]}
        fake_cluster_info = [fake_cluster1, fake_cluster2, fake_cluster4]
        fake_categorize_resource = {
            "existing_unmanaged_resources": [db_cluster1],
            "new_unmanaged_resources": [fake_cluster4, fake_cluster2],
            "unmanaged_resource_to_be_deleted": [db_cluster5]}

        with contextlib.nested(
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'categorize_resource',
                              return_value=fake_categorize_resource),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_form_datastores_dict',
                              return_value=[[fake_ds33, fake_ds44],
                                            [fake_ds11, fake_ds22]]),
            mock.patch.object(InfrastructureSystems,
                              'create_infrastructure_system',
                              side_effect=[HTTPError("409 Client Error"), {}]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_get_datastores_dict_from_clusters',
                              side_effect=[[fake_ds1, fake_ds2]]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_is_update_required',
                              side_effect=[True, True]),
            mock.patch.object(InfrastructureSystems,
                              'update_infrastructure_system'),
            mock.patch.object(InfrastructureSystems,
                              'delete_infrastructure_system')) as (
                                  mock_categorize_resource,
                                  mock_form_datastore_dict,
                                  mock_create_infra_system,
                                  mock_get_datastores,
                                  mock_is_update_required,
                                  mock_update_infra_system,
                                  mock_delete_infra_system):
            self.synchronize_unmanaged_resource_obj.sync_unmanaged_resource_for_esx_lcm(
                fake_cluster_info, fake_zone_uri)
            self.assertTrue(mock_categorize_resource.called)
            self.assertTrue(mock_form_datastore_dict.called)
            self.assertTrue(mock_create_infra_system.called)
            self.assertTrue(mock_get_datastores.called)
            self.assertTrue(mock_is_update_required.called)
            self.assertTrue(mock_update_infra_system.called)
            self.assertTrue(mock_delete_infra_system.called)
            self.assertEqual(
                InfrastructureSystems.create_infrastructure_system.call_count,
                2)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._get_datastores_dict_from_clusters.call_count, 1)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._is_update_required.call_count, 1)
            self.assertEqual(
                InfrastructureSystems.update_infrastructure_system.call_count,
                1)
            self.assertEqual(
                InfrastructureSystems.delete_infrastructure_system.call_count,
                1)

    def test_sync_unmanaged_resource_for_esx_lcm_with_unhandled_exception(self):
        fake_private_req = PrivateRequest()
        self.synchronize_unmanaged_resource_obj.private_request = (
            fake_private_req)
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_ds1 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-10",
                    "name": "datastore1",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds2 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-20",
                    "name": "datastore2",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds11 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-110",
                     "name": "datastore11",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds22 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-220",
                     "name": "datastore22",
                     "sizeGiB": 1500, "type": "VMFS"}
        fake_ds3 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-30",
                    "name": "datastore3",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds4 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-40",
                    "name": "datastore4",
                    "sizeGiB": 924, "type": "VMFS"}
        fake_ds33 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-330",
                     "name": "datastore33",
                     "sizeGiB": 1000, "type": "VMFS"}
        fake_ds44 = {"id": "7DACD400-0055-4C7E-B460-AE4062546439_datastore-440",
                     "name": "datastore44",
                     "sizeGiB": 1500, "type": "VMFS"}
        db_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "name": "Cluster11",
            "state": "Enabled",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131233",
            "hosts": hosts,
            "datastores": [fake_ds1, fake_ds2],
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        db_cluster5 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c9",
            "name": "Cluster55",
            "state": "Disabled",
            "infraState": "Running",
            "uri": "/rest/infrastructuresystems/2132131235",
            "hosts": hosts,
            "datastores": [fake_ds3, fake_ds4],
            "associatedZoneURI": fake_zone_uri,
            "managed": "False"}
        fake_zone_uri = "/rest/zones/ca48a819-06d0-4463-8fdb-d300865cb04f"
        fake_cluster1 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c7",
            "cluster_name": "Cluster1",
            "state": "Enabled",
            "hosts": hosts,
            "datastores": [fake_ds1, fake_ds2]}
        fake_cluster4 = {
            "id": "7DACD400-0055-4C7E-B460-AE4062546439_domain-c10",
            "cluster_name": "Cluster4",
            "state": "Enabled",
            "hosts": hosts,
            "datastores": [fake_ds33, fake_ds44]}
        fake_cluster_info = [fake_cluster1, fake_cluster4]
        fake_categorize_resource = {
            "existing_unmanaged_resources": [db_cluster1],
            "new_unmanaged_resources": [fake_cluster4],
            "unmanaged_resource_to_be_deleted": [db_cluster5]}

        with contextlib.nested(
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              'categorize_resource',
                              return_value=fake_categorize_resource),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_form_datastores_dict',
                              return_value=[[fake_ds33, fake_ds44]]),
            mock.patch.object(InfrastructureSystems,
                              'create_infrastructure_system',
                              side_effect=[HTTPError("404 Client Error")]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_get_datastores_dict_from_clusters',
                              side_effect=[[fake_ds1, fake_ds2]]),
            mock.patch.object(Synchronize_Unmanaged_Resource,
                              '_is_update_required',
                              side_effect=[True, True]),
            mock.patch.object(InfrastructureSystems,
                              'update_infrastructure_system'),
            mock.patch.object(InfrastructureSystems,
                              'delete_infrastructure_system')) as (
                                  mock_categorize_resource,
                                  mock_form_datastore_dict,
                                  mock_create_infra_system,
                                  mock_get_datastores,
                                  mock_is_update_required,
                                  mock_update_infra_system,
                                  mock_delete_infra_system):
            self.assertRaises(HTTPError,
                              self.synchronize_unmanaged_resource_obj.sync_unmanaged_resource_for_esx_lcm,
                              fake_cluster_info, fake_zone_uri)
            self.assertTrue(mock_categorize_resource.called)
            self.assertTrue(mock_form_datastore_dict.called)
            self.assertTrue(mock_create_infra_system.called)
            self.assertFalse(mock_get_datastores.called)
            self.assertFalse(mock_is_update_required.called)
            self.assertFalse(mock_update_infra_system.called)
            self.assertFalse(mock_delete_infra_system.called)
            self.assertEqual(
                InfrastructureSystems.create_infrastructure_system.call_count,
                1)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._get_datastores_dict_from_clusters.call_count, 0)
            self.assertEqual(
                Synchronize_Unmanaged_Resource._is_update_required.call_count, 0)
            self.assertEqual(
                InfrastructureSystems.update_infrastructure_system.call_count,
                0)
            self.assertEqual(
                InfrastructureSystems.delete_infrastructure_system.call_count,
                0)
