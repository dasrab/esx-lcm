# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import copy
import contextlib
from mock import patch
import unittest

from orch.zone_controller import ZoneController

from lib.common import constants
from lib.enable_kvm_server import Enable_Kvm_Server
from lib.hpeGateway import utils
from lib.hpeGateway.kvm_roles_util import KVMRolesUtil
from lib.hpeGateway.physnetutil import PhysnetUtil

HOST_ID = 'a828850e-5e62-4dad-8b08-4a98289ca9c6'
HOST_NAME = 'ubuntu-kvm'
params = {
    'zone_id': 'fake-zone-id',
    'resource_mgr_info': {
        'token': 'fake-token',
        'resmgr_url': '/resmgr'
    },
    'intransit_kvm_servers': [
        {
            'serverUri': '/'.join([constants.SERVERS_URL, HOST_ID]),
            'roles': []
        }
    ]
}

host_agent = {
    'info': {
        'hostname': HOST_NAME
    },
    'hypervisor_info': {
        'hypervisor_type': 'kvm'
    },
    'role_status': constants.HOST_AGENT_ROLE_STATUS_OK,
    'roles': [],
    'extensions': {
        'interfaces': {
            'data': {
                'ovs_bridges': [
                    'br-ext',
                    'br-int',
                    'br-vlan'
                ]
            }
        }
    },
    'id': HOST_ID
}

zone_controller = {
    'uuid': HOST_ID,
    'location': {
        'ipAddress': '10.10.10.10'
    }
}


class FakeKVMRolesUtil(object):

    def __init__(self, **kwargs):
        pass

    def delete_all_roles(self):
        host_agent.update({'roles': []})

    def apply_role(self, role_name):
        host_agent['roles'].append(role_name)


class Test_Enable_Kvm_Server(unittest.TestCase):

    def setUp(self):
        super(Test_Enable_Kvm_Server, self).setUp()
        self.enable_kvm = Enable_Kvm_Server()

    def test_1_execute_success(self):
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller),
            patch.object(PhysnetUtil, 'validate_and_create_physnets'),
            patch.object(KVMRolesUtil, '_create_physnet_to_bridge_mappings'),
            patch.object(KVMRolesUtil, '_get_kvm_role_definitions'),
            patch.object(utils, 'do_request'),
            patch.object(utils, '_wait_for_kvm_host_agent'),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2)) as (
                    get_host_agents, get_zone_ctrl,
                    validate_and_create_physnets,
                    _create_physnet_to_bridge_mappings,
                    _get_kvm_role_definitions,
                    do_request, wait_for_host_agent,
                    get_number_of_enabled_kvm_servers):

            ret_val = self.enable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(validate_and_create_physnets.called)
            self.assertTrue(_create_physnet_to_bridge_mappings.called)
            self.assertTrue(_get_kvm_role_definitions.called)
            self.assertTrue(do_request.called)
            self.assertTrue(wait_for_host_agent.called)
            self.assertTrue(get_number_of_enabled_kvm_servers.called)

    def test_execute_host_id_not_in_zone_ctrl(self):
        zone_controller2 = copy.deepcopy(zone_controller)
        zone_controller2['uuid'] = 'fake-id'
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller2),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2),
            patch.object(KVMRolesUtil, 'delete_all_roles')) as (
                    get_host_agents, get_zone_ctrl,
                    get_number_of_enabled_kvm_servers,
                    delete_all_roles):

            ret_val = self.enable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'FAIL')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(get_number_of_enabled_kvm_servers.called)
            self.assertTrue(delete_all_roles.called)

    def test_execute_role_status_is_converging(self):
        host_agent2 = copy.deepcopy(host_agent)
        host_agent2['role_status'] = (
            constants.HOST_AGENT_ROLE_STATUS_CONVERGING)
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2),
            patch.object(KVMRolesUtil, 'delete_all_roles')) as (
                    get_host_agents, get_zone_ctrl,
                    get_number_of_enabled_kvm_servers,
                    delete_all_roles):

            ret_val = self.enable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'FAIL')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(get_number_of_enabled_kvm_servers.called)
            self.assertTrue(delete_all_roles.called)

    @patch('lib.enable_kvm_server.KVMRolesUtil', FakeKVMRolesUtil)
    def test_2_execute_fail_clear_roles(self):
        host_agent['role_status'] = constants.HOST_AGENT_ROLE_STATUS_FAILED
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller),
            patch.object(PhysnetUtil, 'validate_and_create_physnets'),
            patch.object(utils, '_wait_for_kvm_host_agent',
                         side_effect=[False, True]),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2)) as (
                    get_host_agents, get_zone_ctrl,
                    validate_and_create_physnets,
                    wait_for_host_agent,
                    get_number_of_enabled_kvm_servers):

            ret_val = self.enable_kvm.execute(params)

            self.assertEqual(len(host_agent['roles']), 0)
            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'FAIL')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(validate_and_create_physnets.called)
            self.assertTrue(wait_for_host_agent.called)
            self.assertTrue(get_number_of_enabled_kvm_servers.called)

    @patch('lib.enable_kvm_server.KVMRolesUtil', FakeKVMRolesUtil)
    def test_3_clear_roles_if_enable_fails(self):
        class _url:
            netloc = 'fake-netloc'
            path = 'fake_path'
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent', return_value=host_agent),
            patch.object(utils, '_wait_for_kvm_host_agent',
                         return_value=True),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2)
        ) as (get_agent, wait_for_agent, get_number_of_enabled_kvm_servers):

            host_agent['roles'] = ['role1', 'role2']
            self.enable_kvm._clear_roles_if_enable_fails(
                _url, 'fake-headers', 'fake-path')
            self.assertEqual(len(host_agent['roles']), 0)
            self.assertTrue(get_agent.called)
            self.assertTrue(wait_for_agent.called)
            self.assertTrue(get_number_of_enabled_kvm_servers.called)
