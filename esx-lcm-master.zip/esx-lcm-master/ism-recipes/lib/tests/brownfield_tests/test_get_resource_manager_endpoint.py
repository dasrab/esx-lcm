# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
import mock
from orch.moduleBase import ModuleBase
import unittest

from lib.get_resource_manager_endpoint import Get_Resource_Manager_Endpoint
from lib.hpeGateway import utils


class TestGetResourceManagerEndpoint(unittest.TestCase):

    def setUp(self):
        super(TestGetResourceManagerEndpoint, self).setUp()
        self.res_mgr_obj = Get_Resource_Manager_Endpoint()

    def test_execute_success(self):
        fake_params = {
            "host": "xyz.net",
            "region": "vmware",
            "user": "abc@xyz.com",
            "password": "abcdefgh1234",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"
        }
        with contextlib.nested(
                mock.patch.object(utils, 'get_resource_manager_endpoint'),
                mock.patch.object(ModuleBase, 'exit_fail'),
                mock.patch.object(ModuleBase, 'exit_success')) as (
                mock_res_mgr_endpoint, mock_fail, mock_success):
            self.res_mgr_obj.execute(fake_params)
            self.assertTrue(mock_res_mgr_endpoint.called)
            self.assertTrue(mock_success.called)
            self.assertFalse(mock_fail.called)

    def test_execute_failure(self):
        fake_params = {
            "host": "xyz.net",
            "region": "vmware",
            "user": "abc@xyz.com",
            "password": "abcdefgh1234",
            "tenant": "service",
            "proxy_server": "11.22.33.44",
            "proxy_port": "8080"
        }
        with contextlib.nested(
                mock.patch.object(utils,
                                  'get_resource_manager_endpoint',
                                  side_effect=Exception),
                mock.patch.object(ModuleBase, 'exit_fail'),
                mock.patch.object(ModuleBase, 'exit_success')) as (
                mock_res_mgr_endpoint, mock_fail, mock_success):
            self.res_mgr_obj.execute(fake_params)
            self.assertTrue(mock_res_mgr_endpoint.called)
            self.assertFalse(mock_success.called)
            self.assertTrue(mock_fail.called)


if __name__ == '__main__':
    unittest.main()
