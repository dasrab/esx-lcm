# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import copy
import contextlib
from mock import patch
import unittest

from orch.zone_controller import ZoneController

from lib.common import constants
from lib.disable_kvm_server import Disable_Kvm_Server
from lib.hpeGateway import utils
from lib.hpeGateway.kvm_roles_util import KVMRolesUtil
from lib.hpeGateway.physnetutil import PhysnetUtil


HOST_ID = 'a828850e-5e62-4dad-8b08-4a98289ca9c6'
HOST_NAME = 'ubuntu-kvm'
params = {
    'resource_mgr_info': {
        'token': 'fake-token',
        'resmgr_url': '/resmgr'
    },
    'zone_id': 'fake-zone-id',
    'intransit_kvm_servers': [
        {
            'serverUri': '/'.join([constants.SERVERS_URL, HOST_ID]),
            'roles': []
        }
    ]
}

host_agent = {
    'info': {
        'hostname': HOST_NAME
    },
    'hypervisor_info': {
        'hypervisor_type': 'kvm'
    },
    'role_status': 'ok',
    'roles': ['fake_role'],
    'id': HOST_ID
}

zone_controller = {
    'uuid': HOST_ID,
    'location': {
        'ipAddress': '10.10.10.10'
    }
}


class Test_Disable_Kvm_Server(unittest.TestCase):

    def setUp(self):
        super(Test_Disable_Kvm_Server, self).setUp()
        self.disable_kvm = Disable_Kvm_Server()

    def test_execute_success(self):
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=2),
            patch.object(KVMRolesUtil, 'delete_all_roles'),
            patch.object(utils, '_wait_for_kvm_host_agent')) as (
                get_host_agents, get_zone_ctrl, get_number_of_enabled_servers,
                delete_all_roles, wait_for_kvm_host_agent):

            ret_val = self.disable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(get_number_of_enabled_servers.called)
            self.assertTrue(delete_all_roles.called)
            self.assertTrue(wait_for_kvm_host_agent.called)

    def test_execute_success_no_roles_to_delete(self):
        host_agent2 = copy.deepcopy(host_agent)
        host_agent2['roles'].pop()
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent2),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller)) as (
                get_host_agents, get_zone_ctrl):

            ret_val = self.disable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)

    def test_execute_success_physnet_should_be_deleted(self):
        with contextlib.nested(
            patch.object(utils, 'get_kvm_host_agent',
                         return_value=host_agent),
            patch.object(ZoneController, 'get',
                         return_value=zone_controller),
            patch.object(utils, 'get_number_of_enabled_kvm_servers',
                         return_value=1),
            patch.object(KVMRolesUtil, 'delete_all_roles'),
            patch.object(PhysnetUtil, 'clean_physnet'),
            patch.object(utils, '_wait_for_kvm_host_agent')) as (
                get_host_agents, get_zone_ctrl, get_number_of_enabled_servers,
                delete_all_roles, clean_physnet, wait_for_kvm_host_agent):

            ret_val = self.disable_kvm.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(get_host_agents.called)
            self.assertTrue(get_zone_ctrl.called)
            self.assertTrue(get_number_of_enabled_servers.called)
            self.assertTrue(delete_all_roles.called)
            self.assertTrue(clean_physnet.called)
            self.assertTrue(wait_for_kvm_host_agent.called)
