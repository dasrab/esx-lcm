# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import copy
from mock import patch
import unittest

from lib.hpeGateway import utils
from lib.check_kvm_host_agent_connection_status import (
    Check_Kvm_Host_Agent_Connection_Status
)

HOST_ID = 'a828850e-5e62-4dad-8b08-4a98289ca9c6'
HOST_NAME = 'ubuntu-kvm'
params = {
    'info': {
        'token': 'fake-token',
        'resmgr_url': '/resmgr'
    },
    'host_id': HOST_ID
}

host_agent = {
        "info": {
            "hostname": HOST_NAME
        },
        "hypervisor_info": {
            "hypervisor_type": "kvm"
        },
        "id": HOST_ID,
        "message": ""
}


class Test_Check_Kvm_Host_Agent_Connection(unittest.TestCase):

    def setUp(self):
        super(Test_Check_Kvm_Host_Agent_Connection, self).setUp()
        self.kvm_conn = Check_Kvm_Host_Agent_Connection_Status()

    def test_execute_success(self):
        with patch.object(
                utils, 'get_kvm_host_agent', return_value=host_agent) as (
                    get_host_agents):

            ret_val = self.kvm_conn.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')
            self.assertTrue(ret_val.get('body').get('paired'))
            self.assertEqual(ret_val.get('body').get('id'), HOST_ID)
            self.assertEqual(ret_val.get('body').get('name'), HOST_NAME)
            self.assertTrue(get_host_agents.called)

    def test_execute_failure(self):
        host_agent2 = copy.deepcopy(host_agent)
        host_agent2['message'] = {
            "warn": ["NTP Problem"]
        }
        with patch.object(
                utils, 'get_kvm_host_agent', return_value=host_agent2) as (
                    get_host_agents):

            ret_val = self.kvm_conn.execute(params)

            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'FAIL')
            self.assertTrue(get_host_agents.called)
