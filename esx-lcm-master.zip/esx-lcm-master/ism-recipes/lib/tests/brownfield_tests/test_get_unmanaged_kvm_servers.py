# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import copy
from mock import patch
import unittest

from lib.common import constants
from lib.hpeGateway import utils
from lib.get_unmanaged_kvm_servers import Get_Unmanaged_Kvm_Servers

HOST_ID = 'a828850e-5e62-4dad-8b08-4a98289ca9c6'
HOST_NAME = 'ubuntu-kvm'
params = {
    'resource_mgr_info': {
        'token': 'fake-token',
        'resmgr_url': '/resmgr'
    },
    'zone_id': 'fake-zone-id'
}

host_agents = [
    {
        "info": {
            "hostname": HOST_NAME
        },
        "hypervisor_info": {
            "hypervisor_type": "kvm"
        },
        "role_status": "ok",
        "id": HOST_ID,
        "message": "",
        "extensions": {
            "volumes_present": {
                "data": [
                    {
                        "size": "15.34g"
                    }
                ]
            }
        }
    }
]


class FakeZoneController:
    def __init__(self, pr):
        pass

    def get_by_uuid(self, zone_id, zone_ctrl_uuid):
        return {
            'id': 'zone-connection-id-1',
            'uuid': HOST_ID,
            'location': {
                'ipAddress': '10.10.10.10'
            }
        }


def _get_state(host_agent):
    if host_agent.get('role_status') == 'ok':
        return constants.ENABLED
    else:
        return constants.DISABLED


class Test_Get_All_Kvm_Servers(unittest.TestCase):

    def setUp(self):
        super(Test_Get_All_Kvm_Servers, self).setUp()
        self.get_kvm_servers = Get_Unmanaged_Kvm_Servers()

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_enabled_servers(self):
        host_agents1 = copy.deepcopy(host_agents)
        with patch.object(utils, 'get_host_agents',
                          return_value=host_agents1) as (
                get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            host_agent = host_agents[0]

            self.assertEqual(kvm_server['name'], HOST_NAME)
            self.assertEqual(kvm_server['id'], HOST_NAME)
            self.assertEqual(kvm_server['state'], _get_state(host_agent))
            self.assertEqual(len(kvm_server.get('volumes')), 1)
            self.assertTrue(get_host_agents.called)

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_enabling_servers(self):
        host_agents2 = copy.deepcopy(host_agents)
        with patch.object(
                utils, 'get_host_agents', return_value=host_agents2) as (
                    get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            host_agent = host_agents2[0]
            self.assertEqual(kvm_server['state'], _get_state(host_agent))
            self.assertEqual(len(kvm_server.get('volumes')), 1)
            self.assertTrue(get_host_agents.called)

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_fresh_servers(self):
        host_agents3 = copy.deepcopy(host_agents)
        with patch.object(
                utils, 'get_host_agents', return_value=host_agents3) as (
                    get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            host_agent = host_agents3[0]
            self.assertEqual(kvm_server['state'], _get_state(host_agent))
            self.assertEqual(len(kvm_server.get('volumes')), 1)
            self.assertTrue(get_host_agents.called)

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_invalid_volume_1(self):
        host_agents4 = copy.deepcopy(host_agents)
        host_agents4[0]['extensions']['volumes_present']['data'] = [
            "Error: No vgs command found."
        ]
        with patch.object(
                utils, 'get_host_agents', return_value=host_agents4) as (
                    get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            self.assertEqual(len(kvm_server.get('volumes')), 0)
            self.assertTrue(get_host_agents.called)

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_invalid_volume_2(self):
        host_agents5 = copy.deepcopy(host_agents)
        host_agents5[0]['extensions']['volumes_present']['data'] = [
            {'name': 'no', 'free': 'groups', 'size': 'volume'}
        ]
        with patch.object(
                utils, 'get_host_agents', return_value=host_agents5) as (
                    get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            self.assertEqual(len(kvm_server.get('volumes')), 0)
            self.assertTrue(get_host_agents.called)

    @patch('lib.get_unmanaged_kvm_servers.ZoneController', FakeZoneController)
    def test_execute_host_agent_not_responding(self):
        host_agents6 = copy.deepcopy(host_agents)
        host_agents6[0]['info']['responding'] = False
        with patch.object(
                utils, 'get_host_agents', return_value=host_agents6) as (
                    get_host_agents):

            ret_val = self.get_kvm_servers.execute(params)

            self.assertIsNotNone(ret_val)
            self.assertEqual(
                ret_val.get('headers').get('module_status'), 'SUCCESS')

            kvm_server = ret_val.get('body')[0]
            self.assertTrue('status' in kvm_server)
            self.assertEqual(kvm_server['status'], constants.CRITICAL)
            self.assertTrue(get_host_agents.called)
