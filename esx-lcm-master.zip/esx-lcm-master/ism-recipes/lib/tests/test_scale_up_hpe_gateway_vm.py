# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import contextlib
from mock import patch
import unittest

from lib import scale_up_hpe_gateway_vm
from lib.common.vcenter_utils import VcenterUtils

args = {
    'vcenter_ip': '1.1.1.1',
    'vcenter_username': 'root',
    'vcenter_password': '***',
    'vcenter_port': 443,
    'datacenter': 'Datacenter1',
    'cluster': 'Cluster',
    'appliance_name': 'hpe_gateway-vm-002',
    'vcpus': 4,
    'memory': 4096
}


class cluster:
    class summary:
        effectiveCpu = 8
        effectiveMemory = long(8192)


class vm:
    class summary:
        class config:
            numCpu = 2
            memorySizeMB = long(2048)


class TestScale_Up_Hpe_Gateway_Vm(unittest.TestCase):

    def setUp(self):
        super(TestScale_Up_Hpe_Gateway_Vm, self).setUp()
        self.scale_hpe_gateway = scale_up_hpe_gateway_vm.Scale_Up_Hpe_Gateway_Vm()

    def test_execute(self):
        with contextlib.nested(
            patch.object(VcenterUtils, 'get_service_instance'),
            patch.object(VcenterUtils, 'get_obj'),
            patch.object(self.scale_hpe_gateway, '_get_cpu_and_memory',
                         return_value=(2, 1024)),
            patch.object(VcenterUtils, 'reconfigure_vm')) as (
                get_service_instance, get_obj,
                _get_cpu_and_memory, reconfigure_vm):
            self.scale_hpe_gateway.execute(args)
            self.assertTrue(get_service_instance.called)
            self.assertTrue(get_obj.called)
            self.assertTrue(_get_cpu_and_memory.called)
            self.assertTrue(reconfigure_vm.called)

    def test_get_cpu_and_memory(self):
        cpu, memory = self.scale_hpe_gateway._get_cpu_and_memory(
            cluster, vm, args['vcpus'], args['memory'])
        self.assertIsNotNone(cpu)
        self.assertIsNotNone(memory)
        self.assertIsInstance(cpu, int)
        self.assertIsInstance(memory, long)
        self.assertEqual(
            cpu, (vm.summary.config.numCpu + args['vcpus']))
        self.assertEqual(
            memory, (vm.summary.config.memorySizeMB + args['memory']))


if __name__ == '__main__':
    unittest.main()
