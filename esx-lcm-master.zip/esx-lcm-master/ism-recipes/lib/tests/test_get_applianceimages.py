# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
import mock

from lib.common import utils
from lib.get_applianceimages import Get_Applianceimages


class TestGetApplianceimages(unittest.TestCase):

    def setUp(self):
        super(TestGetApplianceimages, self).setUp()
        self.get_appimage_obj = Get_Applianceimages()

    def test_execute_success(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_applianceimages') as (mock_get_applianceimages):
            self.get_appimage_obj.execute(fake_params)
            self.assertTrue(mock_get_applianceimages.called)

    def test_execute_with_result_None(self):
        fake_params = {'appliance_ip': '127.0.0.1',
                       'appliance_port': '1234'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_applianceimages', return_value={}) as (
                mock_get_applianceimages):
            self.get_appimage_obj.execute(fake_params)
            self.assertTrue(mock_get_applianceimages.called)

    def test_execute_failure(self):
        fake_params = {'appliance_ip': '127.0.0.1'}
        with mock.patch.object(utils.ApplianceManagerProxy,
                               'get_applianceimages') as (mock_get_applianceimages):
            self.get_appimage_obj.execute(fake_params)
            self.assertFalse(mock_get_applianceimages.called)


if __name__ == '__main__':
    unittest.main()
