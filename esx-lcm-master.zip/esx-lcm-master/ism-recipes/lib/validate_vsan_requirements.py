#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager

DOCUMENTATION = '''
---
module: Validate VSAN requirements
description: Validates user VSAN requirements.
options:
    encryption:
       description:
            - Enable or disable encryption on the VSAN cluster.
    fault_domain:
        description:
            - Enables configuring fault domains for the VSAN cluster.
    performance:
        description:
            - Enable or disable performance service for the VSAN cluster.
    vsan_disk_info:
        description:
            - Host disk information from platform profile template
'''

EXAMPLES = '''
- name: Validate VSAN requirements
    validate_vsan_requirements:
      encryption: false
      fault_domain: ''
      performance: false
      vsan_disk_info: {
            "cache_drive_count": 1,
            "cache_drive_size_gb": 1200,
            "cache_drive_type": "local:SAS:HDD",
            "capacity_drive_count": 2,
            "capacity_drive_size_gb": 2000,
            "capacity_drive_type": "bigbird:SATA:HDD" }
    register: validate_vsan_result'''


class Validate_Vsan_Requirements(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.error_code = "HCOE_ISM_BUILD_SYSTEM_VALIDATION_FAILED"

    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        self.LOG.info("Validating VSAN pre-requisites before attempting "
                      "VSAN setup.")
        try:
            (status, error_msg) = \
                vsan_cm.perform_pre_host_creation_validations(params)
        except Exception as exc:
            self.LOG.exception('Exception in execute of '
                               'Validate_Vsan_Requirements :: %s' % str(exc))
            result = {'is_valid': False, 'details': str(exc),
                      'error_code': self.error_code}
            return self.exit_success(result)
        else:
            if status:
                self.LOG.info("VSAN pre-requisites validation succeeded.")
                result = {'is_valid': True, 'details': '', 'error_code': ''}
            else:
                self.LOG.error(error_msg)
                result = {'is_valid': False, 'details': error_msg,
                          'error_code': self.error_code}
            return self.exit_success(result)
