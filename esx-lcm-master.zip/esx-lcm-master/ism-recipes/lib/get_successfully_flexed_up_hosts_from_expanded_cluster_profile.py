# (C) Copyright 2017 Hewlett Packard Enterprise Development LP


from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Get_Successfully_Flexed_Up_Hosts_From_Expanded_Cluster_Profile(
        ModuleBase):
    def execute(self, params):
        try:
            hypervisor_cluster_profile_after_flexup = params.get(
                "_hypervisor_cluster_profile_after_flexup")
            hypervisor_cluster_profile_before_flexup = params.get(
                "_hypervisor_cluster_profile_before_flexup")
            hypervisor_host_profile_uris_before_flesup = hypervisor_cluster_profile_before_flexup[
                'hypervisorHostProfileUris']
            hypervisor_host_profile_uris_after_flexup = hypervisor_cluster_profile_after_flexup[
                'hypervisorHostProfileUris']
            for host_profile_uri in list(
                    hypervisor_host_profile_uris_after_flexup):
                if host_profile_uri in hypervisor_host_profile_uris_before_flesup:
                    hypervisor_host_profile_uris_after_flexup.remove(
                        host_profile_uri)

            hypervisor_cluster_profile_after_flexup[
                'hypervisorHostProfileUris'] = hypervisor_host_profile_uris_after_flexup
            return self.exit_success(hypervisor_cluster_profile_after_flexup)

        except Exception as e:
            self.LOG.exception(
                "Error during filtering of the failed hypervisor cluster profile for valid hosts")
            raise Ism_Error(
                "HCOE_ISM_FILTER_EXPAND_HYPERVISOR_PROFILE_DETAILS_FAILED",
                details=str(e))
