# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import json
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils


class Get_Hostagent_Info(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": None}

    def execute(self, params):
        host_agent_info = {}
        resmgr_info = params['info']
        self.headers['X-Auth-Token'] = resmgr_info['token']
        vmware_neutron = params.get('vmware_neutron')
        try:
            _, net_location, path, _, _ = urlparse.urlsplit(
                resmgr_info['resmgr_url'])
            path = path + "/v1/hosts"
            # Do a REST call to get the host information from HPE gateway
            self.LOG.debug("Get the Host info from HPE Gateway")
            with utils.do_request("GET", net_location,
                                  path, self.headers, {}) as response:
                host_agent = json.loads(response.read())
            # TODO(Manju) Need to enhance it for multiple host
            # For now assuming there is only one host
            host_agent_info['id'] = host_agent[0]['id']
            # Get the All the cluster info
            host_agent_info['clusters'] = self._get_cluster_info(host_agent)
            # Appliance IP
            if vmware_neutron:
                host_agent_info['vcenter_ip'] = utils.get_val(
                    host_agent[0], 'extensions', 'hypervisor_details',
                    'data', 'vcenter_ip')
            # There is some changes in output of resmgr/v1/hosts between
            # 3.5 release and <3.5 release with respect IP address
            # fetch. Following code is work for both conditions.
            host_agent_info['ip_address'] = utils.get_val(
                    host_agent[0], 'extensions', 'interfaces',
                    'data', 'iface_ip', 'br-int')
            if (not host_agent_info['ip_address']):
                host_agent_info['ip_address'] = utils.get_val(
                    host_agent[0], 'extensions', 'interfaces',
                    'data', 'iface_ip', 'eth0')

            # Get the Roles appplied on host
            host_agent_info['roles'] = host_agent[0]['roles']
            # Record the initial status of host
            if host_agent[0]['roles']:
                host_agent_info['status'] = host_agent[0]['role_status']
            else:
                # Status will be None if None of the roles are present
                host_agent_info['status'] = None
            return self.exit_success(host_agent_info)
        except Exception as e:
            self.LOG.exception('Get HostAgent Info failed!')
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))

    def _get_cluster_info(self, host_agent_info):
        clusters = host_agent_info[0]['extensions'][
            'hypervisor_details']['data']['clusters']
        clusters_details = []
        for cluster in clusters:
            cluster_info = {}
            cluster_info['name'] = cluster['name']
            cluster_info['datastores'] = cluster['datastores']
            clusters_details.append(cluster_info)
        return clusters_details
