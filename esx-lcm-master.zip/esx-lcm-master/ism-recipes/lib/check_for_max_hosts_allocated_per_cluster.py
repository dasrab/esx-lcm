#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from future import standard_library

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error
from common.oneview_connector import OneviewConnector

import hpOneViewClrm as hpovclrm

standard_library.install_aliases()

DOCUMENTATION = '''
---
module: check_for_max_hosts_allocated_per_cluster
short_description:
    Checks if during flex up operation the limit for maximum
hosts that can be allocated in a cluater is maintiained
    This check is done only when max_hosts_alloc_per_cluster
flag in properties/cluster_configuration_parameters.yml is
set to > 0

description:
    - Accepts following parameters
1.infrastructure environment
2.hypervisor_clusters inventory
3.Count of nodes in current flex up operation
4.Max hosts that can be allocated per cluster

'''

EXAMPLES = '''
  - name: Check for max hosts that can be allocated in a cluster
    check_for_max_hosts_allocated_per_cluster:
      _infra_environment: "{{infra_environment}}"
      _hypervisor_clusters: "{{ hypervisor_clusters }}"
      _nodes_to_expand_count: "{{  (serverSettings.content|from_json)['targetUnmanagedServers']|length }}"
      _max_host_alloc_per_cluster: "{{max_host_alloc_per_cluster}}"
    register: check_message
    when: max_host_alloc_per_cluster > 0
'''


class Check_For_Max_Hosts_Allocated_Per_Cluster(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        self.LOG.debug(
            "Checking for max number of hosts limit in cluster before flexup")
        max_host_alloc = params.get("_max_hosts_alloc_per_cluster")
        nodes_to_expand_count = params.get("_nodes_to_expand_count")
        ov_host = params.get("_ov_host")
        ov_port = params.get("_ov_port")
        auth = params.get("_auth")
        cluster_profile_uri = params.get("_hypervisor_cluster_uri")

        connection = OneviewConnector(ov_host, ov_port, auth).connect()
        cluster_profiles = hpovclrm.cluster_profile(connection)
        hypervisor_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
            cluster_profile_uri)
        hypervisorHostProfileUri = hypervisor_cluster_profile.get(
            "hypervisorHostProfileUris", [])
        if len(hypervisorHostProfileUri) + \
                int(nodes_to_expand_count) > int(max_host_alloc):
            self.LOG.debug(
                "Max host allocasation limit per cluster exceeded-flex up failed")
            raise Ism_Error(
                "SYN_ISM_MAX_HOST_ALLOCATION",
                details="Flex up operation failed because max limit of host per clusters exceeded")

        return self.exit_success(
            "Check_For_Max_Host_Allocated_Per_Cluster is PASSED")
