# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from orch.ism_sdk import InfrastructureSystems
from orch.ism_sdk.activity import Ism_Error


class Report_Failures(ModuleBase):

    def execute(self, params):
        operation = params.get('operation', None)
        infra_uri = params.get('infra_uri', None)

        error_code = params.get('_error_code',
                                "HCOE_ISM_BUILD_SYSTEM_VALIDATION_FAILED")

        validations = []
        errors = list()
        validations += [params.get('_vmotion_net_validation_result')]
        validations += [params.get('_iscsi_net_validation_result')]
        validations += [params.get('_mgmt_net_validation_result')]
        validations += [params.get('_ft_net_validation_result')]
        validations += [params.get('_quorum_validation_result')]
        validations += [params.get('_vsa_validation_result')]
        validations += [params.get('_hyp_mgr_validation_result')]
        validations += [params.get('_hyp_mgr_connectivity_result')]
        validations += [params.get('_ntp_validation_result')]
        validations += [params.get('_nodes_validation_result')]
        validations += [params.get('_hyp_host_validation_result')]
        validations += [params.get('_vlanid_validation_result')]
        validations += [params.get('_dhcp_validation_result')]
        validations += [params.get('_hyp_host_count_validation_result')]
        validations += [params.get('_vsan_validation_result')]
        validations += [params.get('_hpe_gateway_connectivity_result')]
        validations += [params.get('_hpe_gateway_roles_validation_result')]
        validations += [params.get('_hpe_gateway_status_validation_result')]
        validations += [params.get('_appliance_lcm_connectivity_result')]
        validations += [params.get('_oneview_validation_result')]

        for validation in validations:
            if isinstance(validation, dict) and not validation['is_valid']:
                errors.append(Ism_Error(error_code=validation['error_code'],
                                        details=validation['details']))

        if len(errors) > 0:
            if operation == "build":
                self.delete_infrasystems_failed_to_deploy(infra_uri)
            raise self.set_main_error(errors, error_code)

        return self.exit_success({})

    def set_main_error(self, errors, error_code):
        main_error = Ism_Error(error_code=error_code)
        main_error.nested_errors = list(errors)
        self.LOG.debug(
            'Check_Failure_On_Validations failed:' +
            str(main_error))
        return main_error

    def delete_infrasystems_failed_to_deploy(self, infra_uri):
        ism_client = InfrastructureSystems(self.private_request)
        self.LOG.info("Deleting resource %s" % infra_uri)
        ism_client.delete_infrastructure_system(infra_uri)
        self.LOG.info("Resource %s delete" % infra_uri)
