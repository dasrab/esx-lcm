# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import urlparse

from orch.moduleBase import ModuleBase
from orch.ism_sdk import InfrastructureSystems


class Clean_Up_Failed_Infrasystem(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def delete_infrasystems_failed_to_deploy(self, infra_uri):
        ism_client = InfrastructureSystems(self.private_request)
        self.LOG.info("Deleting resource %s" % infra_uri)
        ism_client.delete_infrastructure_system(infra_uri)
        self.LOG.info("Resource %s delete" % infra_uri)

    def execute(self, params):
        infra_uri = params.get("infra_system_uri")
        self.delete_infrasystems_failed_to_deploy(infra_uri)
        return self.exit_success(
            "Deletion of failed infra completed successfully")
