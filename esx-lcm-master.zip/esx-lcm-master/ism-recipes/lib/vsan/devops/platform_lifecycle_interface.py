# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
from abc import abstractmethod


class PlatformLifecycleInterface(object):

    def __init__(self, handlers):
        self.handler = handlers

    @abstractmethod
    def run(self):
        pass
