# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

"""
The file contains code to run vsan deployment iteratively in given mode.
It relies on deploy.py to run each job. Its primary function is to do
following:

1) Put a delay between two run
2) Generate a unique log file for each run
3) Generate a summary report of batch operations


"""

import time
from lib.vsan.devops.common.log import Logger
from lib.vsan.devops.utils import conf
from lib.vsan.handlers.platform_lifecycle.lcm.deploy import LcmDeployHandler
from lib.vsan.handlers.platform_lifecycle.lcm.delete import LcmDeleteHandler
from lib.vsan.handlers.platform_lifecycle.lcm.scaleout import LcmScaleoutHandler
from platform_lifecycle_manager import PlatformLifecycleManager


class PlatformBatchManager():

    def __init__(self):
        self.mode = conf.get_conf(section="devops", option="mode")
        self.handlers = self._initialize_handlers()
        self.plm = PlatformLifecycleManager(self.handlers)

    def run(self, n):
        delay_interval = conf.get_conf(
            section="devops", option="delay_interval")
        run_status = []
        for iteration in range(n):
            LOG = self._initialize_logger(iteration)
            LOG.info("Starting Iteration : %s" % iteration)
            status = self.plm.run()
            run_status.append("Iteration-" + str(iteration) + " : " + status)
            LOG.info("Completed Iteration : %s" % iteration)
            if (iteration < n - 1):
                LOG.info("Sleep %s seconds, until next run is triggered." %
                         delay_interval)
                time.sleep(int(delay_interval))

        LOG = self._initialize_logger("final")
        LOG.info(" Overall Summary of Test Runs")
        LOG.info("=" * 80)
        # This is just a placeholder for final report, we should add more
        # information into this final log so that we can check respective log
        # file for detail analysis.
        for run in run_status:
            LOG.info(run)

    def _initialize_handlers(self):
        handlers = {}
        if self.mode == "esx-lcm":
            handlers['deploy'] = LcmDeployHandler()
            handlers['scaleout'] = LcmScaleoutHandler()
            handlers['delete'] = LcmDeleteHandler()
        return handlers

    def _initialize_logger(self, iteration):
        log_dir = conf.get_conf(section="devops", option="log_dir")
        log_file = log_dir + "devops-run-" + str(iteration) + ".log"
        Logger.setup_logging(filename=log_file)
        LOG = Logger.getLogger(__name__)
        LOG.info("Initialized logger for current iteration at %s" % log_file)
        return LOG
