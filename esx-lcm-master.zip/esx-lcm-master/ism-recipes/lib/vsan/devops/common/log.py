#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#
import os.path
import logging
import logging.config

log_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        },
    },

    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "DEBUG",
            "formatter": "simple",
                         "stream": "ext://sys.stdout"
        },
        "file_handler": {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "DEBUG",
            "formatter": "simple",
            "filename": "/home/aiswarya/devops.log",
            "maxBytes": 104857600,
            "backupCount": 20,
            "encoding": "utf8"
        },
    },

    "root": {
        "level": "DEBUG",
        "handlers": ["console", "file_handler"]
    }
}


class Logger(object):

    """
    Custom Logger Manager to wrap DevopsFilter
    """
    _loggers = {}

    @staticmethod
    def setup_logging(filename=""):
        directory = os.path.dirname(filename)
        if not os.path.exists(directory):
            os.makedirs(directory)
        global log_config
        log_config["handlers"]["file_handler"]["filename"] = filename
        logging.config.dictConfig(log_config)

    @staticmethod
    def getLogger(name):
        logger = logging.getLogger(name)
        Logger._loggers[name] = logger
        return logger
