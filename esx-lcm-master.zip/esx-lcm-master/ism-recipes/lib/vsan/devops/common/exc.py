#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#



# ----------------------------------------------------------------------------
# It is very important to create class hierarchy of exception to reflect
# the correct message. This section captures exceptions related to end-to-end
# vmware platform deployment activities. In future, exception related to any
# platform operation will derive the exception from the below mentioned base
# class.
# ----------------------------------------------------------------------------
class DevopsException(Exception):
    """Base DevopsConfigException class.

    To correctly use this class, inherit from it and define
    a 'message' property. That message will get printf'd
    with the keyword arguments provided to the constructor.
    """
    message = "An unknown exception occurred."
    details = None

    def __init__(self, message=None, details=None, **kwargs):
        if not message:
            message = self.message
        try:
            message = message % kwargs
            if details:
                self.details = details % kwargs
        except Exception as exc:
            raise exc

        # at least get the core message out if something happened
        self.message = message
        super(DevopsException, self).__init__(message)


class DevopsInvalidOperation(DevopsException):
    message = "%(msg)s"
