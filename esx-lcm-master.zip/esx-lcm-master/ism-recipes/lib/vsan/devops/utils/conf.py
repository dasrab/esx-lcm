#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

import os
from ConfigParser import SafeConfigParser
from lib.vsan.devops.common import exc


CONF = None
CONF_FILE_NAME = "../conf/devops.conf"


def read_config():
    parser = SafeConfigParser()
    parser.read(os.path.join(os.path.dirname(__file__), CONF_FILE_NAME))
    return parser


def get_conf(section=None, option=None):
    global CONF
    if CONF == None:
        CONF = read_config()
    option = CONF.get(section, option)
    if option == None:
        raise exc.DevopsException("Unsupported option : %s", option)
    return option
