#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

"""
The file contains functionality to clean-up the host if it is not in
usable state for deployment or scale-out operations. Primarily, it
login to host and cleans following things:

    1) delete partition(s), if there are any
    2) delete diskgroup

The above operation might to force delete as well if it does not work
in normal way. So, invoker should be aware of it. The primary consumer
of this operations are:

    1) Rollie to clean the host before using it for vsan deployment.
       He needs to do only if he is consuming the host which is not in
       clean state. This will be a documented procedure.
    2) Automated rollback during vsan operations like day-zero deployment,
       scale-out and scale-in (if supported). The playboook can be
       hooked to overall lifecycle operation so that host is cleaned
       up correctly if there are some traces left after errors.
"""


import argparse
from orch import log
from pyVim.connect import Disconnect
from pyVmomi import vim, vmodl
from abc import abstractmethod
# this call is to extend pyVmomi with vSAN entities.
from lib.vsan import vsanmgmtObjects
from lib.vsan.utils import vcenter
from lib.vsan.common.exc import exceptions as exc


class HostCleaner(object):

    def __init__(self):
        pass

    @abstractmethod
    def clean(self, cluster=None, host_list=[]):
        pass


class HostVCenterCleaner(HostCleaner):

    def __init__(self, args):
        self.LOG = log.getLogger(__name__)
        attrs = ['ipaddress', 'username', 'password', 'vc_port']
        for attr in attrs:
            setattr(self, attr, args.get(attr))
        self.vc_utils = vcenter.vCenterUtils()
        self.si = None

    def _get_dirty_hosts_mobs(self, cluster, host_list, hosts):
        """
        Check if the hosts passed are the subset of the hosts
        present in the cluster.

        Prepare the list of host MOBs that has to be cleaned up.
        """
        cluster_hosts_ips = [host.name for host in hosts]
        if not set(host_list).issubset(cluster_hosts_ips):
            message = "Could not perform the host disk cleanup " \
                "as some of the hosts are not part of the" \
                " cluster : %s" % cluster
            raise exc.VsanHostDiskCleanUpException(message)

        unclean_hosts = []
        for ip in host_list:
            for host in hosts:
                if host.name == ip:
                    unclean_hosts.append(host)
                    break

        return unclean_hosts

    def clean(self, cluster=None, host_list=[]):
        """
        This method is used to clean the disks of VCenter Cluster's host.
        @param  cluster: Name of the cluster whose hosts has to be cleaned.
        @param host_list: If only some of the hosts in the cluster needs to be 
        cleaned. Expecting to pass the list of ipaddress.
        """
        try:
            # 1. Connect to VCenter
            self.LOG.debug("Connecting to the VCenter : %s " % self.ipaddress)
            self.si, context = \
                self.vc_utils.connect(self.ipaddress,
                                      self.username,
                                      self.password,
                                      self.vc_port)

            # 2. Get the management Objects
            vc_mos = \
                self.vc_utils.get_vsan_managed_objects(self.si._stub,
                                                       context=context)
            dms = vc_mos['vsan-disk-management-system']

            # 3. Get the host objects from the cluster
            vc_cluster = \
                self.vc_utils.get_cluster_instance(self.si, cluster)
            host_props = \
                self.vc_utils.collect_host_properties(self.si.content,
                                                      vc_cluster.host)
            hosts = host_props.keys()

            if host_list:
                hosts = self._get_dirty_hosts_mobs(cluster, host_list, hosts)

            failed_hosts = []
            for host in hosts:
                try:
                    # 4. Erase the disk partitions
                    self._erase_disk_partition(host, host_props)
                    # 5. Remove the diskgroups from the hosts
                    self._delete_diskgroup(dms, host, host_props)
                except Exception as e:
                    err_msg = "Error wiping disk(s) on host : %s. Reason : %s" % (
                        host.name, str(e))
                    self.LOG.error(err_msg)
                    failed_hosts.append(err_msg)

            if len(failed_hosts) > 0:
                raise exc.VsanHostDiskCleanUpException(msg=str(failed_hosts))
        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                Exception) as ex:
            self.LOG.error("CleanUp ESX Host Disks failed : %s" % ex)
            raise exc.VsanHostDiskCleanUpException(msg=str(ex))
        finally:
            Disconnect(self.si)

    def _delete_diskgroup(self, dms, host, host_props):
        try:
            data_migration_action = "noAction"
            self.LOG.info("Removing the disk groups for host %s." %
                          host.name)
            dm = dms.QueryDiskMappings(host)
            dgm = [disk_group.mapping for disk_group in dm]
            if dgm:
                rdm_spec = vim.host.MaintenanceSpec(
                    vsanMode=vim.vsan.host.DecommissionMode(
                        objectAction=data_migration_action))
                rdm_task = host_props[host][
                    'configManager.vsanSystem'].RemoveDiskMapping_Task(dgm, rdm_spec, 0)
                self.vc_utils.wait_for_tasks([rdm_task, ], self.si)
            else:
                self.LOG.info("Host does not have any disk mappings !!")
        except Exception as e:
            self.LOG.error("Error removing diskgroup in host : %s" %e)
            raise

    def _remove_partition(self, hostprops, host, result):
        """
        # For Synergy servers,
        # disk.model = "iSCSIDisk" : Boot disk
        # disk.model = "LOGICAL VOLUME" : Bigbird disk
        # For Synergy Testing, if not (result.disk.model.strip() == "iSCSIDisk"):
        # For Local testing, apply the hack of checking the device path
        # if not (device_path == "/vmfs/devices/disks/mpx.vmhba1:C0:T0:L0")
        """
        device_path = result.disk.devicePath
        if (result.disk.model and not
                (result.disk.model.strip() == "iSCSIDisk")):
            self.LOG.debug("Erasing the disk partition : %s" % device_path)
            hostprops[host]['configManager.storageSystem'].UpdateDiskPartitions(
                result.disk.deviceName, vim.HostDiskPartitionSpec())
            self.LOG.debug("Erased the disk partition : %s" % device_path)

    def _erase_disk_partition(self, host, hostprops):
        try:
            vsan_system = hostprops[host]['configManager.vsanSystem']
            self.LOG.info("Removing the disk partition for host %s." %
                          host.name)
            for result in vsan_system.QueryDisksForVsan():
                if result.state == 'ineligible':
                    self.LOG.info('Found ineligible disks {} in host {}'.format(
                        result.disk.displayName,
                        hostprops[host]['name']))
                    self._remove_partition(hostprops, host, result)
        except Exception as e:
            self.LOG.error("Error removing disk partition : %s" %e)
            raise
