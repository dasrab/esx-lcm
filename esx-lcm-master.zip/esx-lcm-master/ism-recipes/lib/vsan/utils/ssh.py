#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

import os
from orch import log
import socket


class SSHUtils(object):

    def __init__(self):
        import paramiko
        self.LOG = log.getLogger(__name__)
        self.ssh_client = None

    def execute_command(self, command):
        try:
            self.LOG.info("*" * 80)
            self.LOG.info("Executing command : %s" % command)
            # ssh_stdin, ssh_stdout, ssh_stderr = self.ssh_client.exec_command(
            #     command)
            output = ssh_stdout.readlines()
            error = ssh_stderr.readlines()
            self.LOG.info(output)
            self.LOG.info("*" * 80)
            return(output, error)
        except paramiko.SSHException as e:
            self.LOG.error(
                "SSH Exception while executing command : %s" % command)

    def connect_host(self, host, username, password):
        try:
            self.LOG.info("Making SSH connection to the host : %s" % host)
            self.ssh_client = paramiko.SSHClient()
            self.ssh_client.load_system_host_keys()
            self.ssh_client.set_missing_host_key_policy(
                paramiko.AutoAddPolicy())
            self.ssh_client.connect(
                host, username=username, password=password, timeout=30)
            return self.ssh_client
        except (paramiko.BadHostKeyException,
                paramiko.AuthenticationException, paramiko.SSHException) as ex:
            self.LOG.error("Exception while connecting to the host: %s" % host)
            self.LOG.error(ex)
            raise ex
        except socket.error as e:
            self.LOG.error(
                "Socket Error while connecting to the host : %s" % host)
            self.LOG.error(e)
            raise e

    def close_connection(self):
        self.ssh_client.close()
