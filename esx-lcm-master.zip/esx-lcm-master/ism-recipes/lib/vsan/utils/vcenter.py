#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

import ssl
import sys
import time
from orch import log

from pyVim.connect import SmartConnect
from pyVmomi import vim, vmodl, SoapStubAdapter
from lib.vsan.common.exc import exceptions as exc

VSAN_API_VC_SERVICE_ENDPOINT = '/vsanHealth'
VIM_VERSION_10 = 'vim.version.version10'


class vCenterUtils(object):

    def __init__(self):
        self.LOG = log.getLogger(__name__)

    def connect(self, host, user, pwd, port):
        """
        Based on the vCenter details pre-provided, connect to the vCenter and
        return serviceInstance MO and the SSL context used to create the
        connection.
        :return: (serviceInstance MO, SSL context)
        """
        # For python 2.7.9 and later, the defaul SSL conext has more strict
        # connection handshaking rule. We may need turn of the hostname
        # checkingand client side cert verification
        context = None
        if sys.version_info[:3] > (2, 7, 8):
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE

        retries = 5
        retry_interval_sec = 10
        for i in range(0, retries):
            try:
                si = SmartConnect(host=host,
                                  user=user,
                                  pwd=pwd,
                                  port=int(port),
                                  sslContext=context)
                return (si, context)
            except ssl.SSLEOFError as sslError:
                # if we are here then we are certain that there is
                # SSL error. So, we will retry immediately as putting
                # a delay is not going to solve anything. It is just
                # to get rid of startup error.
                if i == retries-1:
                    self.LOG.error("Error connecting to vCenter due to SSL "
                                   "error, error details: %s" % str(sslError))
                    raise sslError
                else:
                    self.LOG.warning("Could not connect vCenter due to "
                                     "SSL error, reconnecting again... : "
                                     "%s" % str(sslError))

            except vim.fault.HostConnectFault as hostConnectFault:
                # if we are here then we are NOT sure what is
                # root cause of not being able to connect to host.
                # It can be because of SSL as well. So, we will try
                # without sleep if it is because of SSL else we
                # will pause for delay and then try...who know there
                # is intermittent connection issue...so delay will
                # help here.
                if i == retries - 1:
                    self.LOG.error("Error connecting to vCenter "
                                   "due to SSL error, error "
                                   "details: %s" % str(hostConnectFault))
                    raise hostConnectFault
                else:
                    self.LOG.warning("Could not connect vCenter host "
                                     "reconnecting again... : "
                                     "%s" % str(hostConnectFault))
                    ssl_error_msg = "EOF occurred in violation of protocol"
                    if not ssl_error_msg in hostConnectFault.msg:
                        # want to take some rest and then retry because
                        # it does not seem to be because of SSL, may
                        # be intermittent connection issue.
                        time.sleep(retry_interval_sec)

            except IOError as ioError:
                msg = "Error in connecting to vCenter %s: %s" % (host,
                                                                 str(ioError))
                self.LOG.error(msg)
                raise exc.VCenterConnectionException(vc_host=host,
                                                     error_desc=str(ioError))

            except vim.InvalidLogin as loginError:
                msg = "Error in login to vCenter %s: %s " % (host,
                                                             str(loginError))
                self.LOG.error(msg)
                raise exc.VCenterConnectionException(vc_host=host,
                                                     error_desc=str(loginError))
    
    def disconnect(self):
        pass

    def get_vsan_license(self, si):
        """
        Gets the vSAN license key to the specified cluster.
        :param si: service instance MO.
        :return: returns vSAN license present in inventory
        :raises: VsanLicenseException if no license available
        """
        # Possible set of vsan licenses, which system will
        # look at the time of vsan deployment. License types
        # are mentioned in order from highest to lowest:
        license_types = [
            'VMware vSAN Enterprise',
            'Virtual SAN Enterprise',
            'VMware vSAN Advanced',
            'Virtual SAN Advanced',
            'VMware vSAN Standard',
            'Virtual SAN Standard'
        ]

        all_licenses = si.content.licenseManager.licenses
        available_vsan_license = dict()
        for license in all_licenses:
            if license.name in license_types:
                available_vsan_license[license.name] = license
        if not available_vsan_license:
            msg = "No vSAN license found. Upload one for vSAN deployment"
            self.LOG.error(msg)
            raise exc.VsanLicenseException(msg=msg)

        for license_type in license_types:
            if available_vsan_license.get(license_type):
                return available_vsan_license[license_type]

    def apply_vsan_license(self, si, cluster, license):
        """
        Applies the vSAN license key to the specified cluster.
        :param si: service instance MO.
        :param cluster: cluster MO
        :return: returns feature set if successful.
        :raises: VsanLicenseException if failed to apply license
        """
        lam = si.content.licenseManager.licenseAssignmentManager
        try:
            lam.UpdateAssignedLicense(entity=cluster._moId,
                                      licenseKey=license.licenseKey)
            supported_features = list()
            properties = license.properties
            for property in properties:
                if property.key == 'feature':
                    supported_features.append(property.value.value)
            self.LOG.info("Applied %s license for %s "
                          "with following supported features: %s"
                          % (license.name, cluster._moId,
                             supported_features))
            return supported_features
        except vmodl.fault.InvalidArgument:
            msg = "Invalid vSAN license."
            self.LOG.error(msg)
            raise exc.VsanLicenseException(msg=msg)

    def get_cluster_instance(self, si, cname):
        """
        Returns the cluster instance MO.
        :param si: service instance MO.
        :return: cluster object if found.
        :raises: VsanClusterNotFoundException if custer not found
        """
        content = si.RetrieveContent()
        searchIndex = content.searchIndex
        datacenters = content.rootFolder.childEntity
        for datacenter in datacenters:
            cluster = searchIndex.FindChild(datacenter.hostFolder,
                                            cname)
            if cluster is not None:
                return cluster
        msg = "Cluster '%s' not found." % cname
        self.LOG.error(msg)
        raise exc.VsanClusterNotFoundException(msg=msg)

    def get_vsan_managed_objects(self, vcStub, context=None, version=VIM_VERSION_10):
        """
        Return the VSAN managed objects.
        :param vcStub:
        :param context:
        :param version:
        :return: dict of the form {MOID: MO}
        """
        vsan_stub = self._get_vc_stub(vcStub, context, version=version)
        vc_mos = {
            'vsan-disk-management-system': vim.cluster.VsanVcDiskManagementSystem(
                'vsan-disk-management-system',
                vsan_stub
            ),
            'vsan-cluster-config-system': vim.cluster.VsanVcClusterConfigSystem(
                'vsan-cluster-config-system',
                vsan_stub
            ),
            'vsan-performance-manager': vim.cluster.VsanPerformanceManager(
                'vsan-performance-manager',
                vsan_stub
            ),
            'vsan-cluster-space-report-system': vim.cluster.VsanSpaceReportSystem(
                'vsan-cluster-space-report-system',
                vsan_stub
            ),
            'vsan-cluster-health-system': vim.cluster.VsanVcClusterHealthSystem(
                'vsan-cluster-health-system',
                vsan_stub
            ),
        }
        return vc_mos

    def wait_for_tasks(self, tasks, si):
        """
        Blocks the caller unit the specified tasks are completed.
        :param tasks: list of tasks to monitor
        :param si: service instance
        :return: None on success, raises vmodl.MethodFault and other exceptions
                 specific to the task being performed
        """
        filter_spec = vmodl.query.PropertyCollector.FilterSpec()
        filter_spec.objectSet = [vmodl.query.PropertyCollector.ObjectSpec(obj=task)
                                 for task in tasks]
        filter_spec.propSet = [vmodl.query.PropertyCollector.PropertySpec(
            type=vim.Task, pathSet=[], all=True)]
        property_collector = si.content.propertyCollector
        filter_obj = property_collector.CreateFilter(filter_spec, True)

        task_list = [str(task) for task in tasks]
        try:
            version, state = None, None
            # monitor the tasks for updates till all the tasks complete
            # successfuly, if a task fails, raise the corresponding error.
            while len(task_list):
                update = property_collector.WaitForUpdates(version)
                for filter_set in update.filterSet:
                    for obj_set in filter_set.objectSet:
                        task = obj_set.obj
                        # only consider the tasks in our list
                        if not str(task) in task_list:
                            continue

                        for change in obj_set.changeSet:
                            if change.name == 'info':
                                state = change.val.state
                            elif change.name == 'info.state':
                                state = change.val
                            else:
                                continue

                            # if task has succeeded, remove it from the list
                            if state == vim.TaskInfo.State.success:
                                task_list.remove(str(task))
                            # if task has failed, raise the corresponding error
                            elif state == vim.TaskInfo.State.error:
                                raise task.info.error
                # Move to next version
                version = update.version
        finally:
            if filter_obj:
                filter_obj.Destroy()

    def collect_host_properties(self, content, objects):
        """
        Fetches the host properties.
        :param content: service instance content
        :param objects: list of objects (of the same type)
        :return: dict of the form {obj1: {prop1: val1, prop2: val2},}
                 on success
        :raises: VsanHostException
        """
        params = ['name', 'configManager.vsanSystem',
                  'configManager.storageSystem']
        host_props = self._collect_object_properties(content, objects, params)
        if not host_props:
            msg = "Failed to query vSAN host properties."
            self.LOG.error(msg)
            raise exc.VsanHostException(msg=msg)
        return host_props

    def _collect_object_properties(self, content, objects, parameters):
        """
        Queries the propertyCollector and creates a map of object and its
        properties.
        :param content: service instance content
        :param objects: list of objects (of the same type)
        :param parameters: list of paramters whose values are to be retrieved
        :return: dict of the form {obj1: {prop1: val1, prop2: val2}, }
        """
        if len(objects) == 0:
            return {}

        pc = content.propertyCollector
        prop_set = [vim.PropertySpec(type=objects[0].__class__,
                                     pathSet=parameters)]

        result = None
        while result is None and len(objects) > 0:
            try:
                object_set = map((lambda x: vim.ObjectSpec(obj=x)), objects)
                spec_set = [vim.PropertyFilterSpec(objectSet=object_set,
                                                   propSet=prop_set)]
                result = pc.RetrieveProperties(specSet=spec_set)
            except vim.ManagedObjectNotFound as ex:
                objects.remove(ex.obj)
                result = None

        out = {}
        if result:
            for x in result:
                out[x.obj] = {}
                for y in x.propSet:
                    out[x.obj][y.name] = y.val
        return out

    def _get_vc_stub(self, stub, context=None, version=VIM_VERSION_10):
        """
        Return a stub for accessing the vCenter side VSAN APIs.
        :param stub: service instance stub component
        :param context: SSL context used for connecting to vCenter
        :param version: VIM version
        :return: SoapStubAdapter instance
        """
        hostname, port = stub.host.split(':')
        vsan_stub = SoapStubAdapter(
            host=hostname,
            port=port,
            path=VSAN_API_VC_SERVICE_ENDPOINT,
            version=version,
            sslContext=context
        )
        vsan_stub.cookie = stub.cookie
        return vsan_stub
