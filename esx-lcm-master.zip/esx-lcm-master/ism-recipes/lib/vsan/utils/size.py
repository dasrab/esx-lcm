#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

def sizeof_fmt(num, suffix='B'):
    for unit in ['', 'Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi']:
        if int(num) < 1024:
            return "%3.1f%s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f%s%s" % (num, 'Yi', suffix)


def size_conv(num, base_unit, exp_unit, pow=2):
    units_p2 = ['', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB', 'EiB', 'ZiB', 'YiB']
    units_p10 = ['', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    units = units_p2 if pow == 2 else units_p10
    divisor = 1024.0 if pow == 2 else 1000
    if units.index(base_unit) < units.index(exp_unit):
        for unit in units[units.index(base_unit):]:
            if unit == exp_unit:
                return round(num, 2)
            num /= divisor
    elif units.index(base_unit) > units.index(exp_unit):
        for unit in units[units.index(exp_unit):
                          units.index(base_unit) + 1][::-1]:
            if unit == exp_unit:
                return round(num, 2)
            num *= divisor
    else:
        return round(num, 2)
