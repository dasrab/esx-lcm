# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

try:
    import redfish
except ImportError:
    redfish = None
import urlparse
import lib.vsan.ilo.exceptions as ilo_exc


REDFISH_URI = "/redfish/v1/Systems/1"


def fetch_ilo_addr_and_key(remote_console_url):
    """
    Parses the remote_console_url and returns the ilo host URL and
    session key.
    :param remote_console_url: remoteConsoleUrl as returned by OneView
    :return: tuple of ilo_host URL and session key.
    """
    pr = urlparse.urlparse(remote_console_url)
    qs = urlparse.parse_qs(pr.netloc)
    ilo_host = "https://%s" % qs['addr'][0]
    session_key = qs['sessionkey'][0]
    return (ilo_host, session_key)


def _do_get(ilo_client, url):
    response = ilo_client.get(url)
    if response.status != 200:
        msg = "Error querying iLO (error code %s)." % response.status
        raise ilo_exc.iLOQueryException(msg=msg)
    return response.dict


def _map_drive_info(ilo_info, controllers):
    def _fetch_ilo_info_by_drive_number(ilo_info, drive_number):
        for ld in ilo_info:
            if ld['LogicalDriveNumber'] == drive_number:
                return ld

    ctr_idx = 0
    for controller in controllers:
        for ld in controller['logical_drives']:
            ilo_ld = _fetch_ilo_info_by_drive_number(ilo_info,
                                                     ld['driveNumber'])
            if not ilo_ld:
                msg = "No matching logical drive found for controller %d, " \
                      "drive number %s" % (ctr_idx, ld['driveNumber'])
                raise ilo_exc.LogicalDriveNotFound(msg=msg)

            for param, value in ilo_ld.iteritems():
                ld[param] = value


def _get_array_controllers(ilo_client):
    response = _do_get(ilo_client, REDFISH_URI)

    ss_response = _do_get(
        ilo_client,
        response['Oem']['Hp']['links']['SmartStorage']['href'])

    return _do_get(ilo_client,
                   ss_response["links"]['ArrayControllers']['href'])


def _get_ld_for_controller(ilo_client, controller_uri):
    ac1_response = _do_get(ilo_client, controller_uri)
    return _do_get(ilo_client, ac1_response['links']['LogicalDrives']['href'])


def _get_pd_for_ld(ilo_client, ld_uri):
    ld1_response = _do_get(ilo_client, ld_uri)
    dd_response = _do_get(ilo_client,
                          ld1_response['links']['DataDrives']['href'])
    return (ld1_response['VolumeUniqueIdentifier'],
            ld1_response['LogicalDriveNumber'],
            dd_response)


def _validate_lun_constraints(dds):
    if len(dds) > 1:
        raise ilo_exc.InvalidLUNException(
            msg="Expected RAID LUN backed by single disk, however found "
                "multiple (%d) disk drive backed LUN." % len(dds))


def fetch_host_disks(ilo_host, session_key, controller_details):
    """
    Queries the iLO to fetch the details of all disks presented through
    Smart Array controller.
    :param ilo_host: ilo host URL like https://15.213.234.192
    :param session_key: session key string
    :param controller_details: map of controllers and logical drives
    :return: list containing detailed information for each disk. The
    information is: ControllerUri (Array Controller's URI),
                    VolumeUniqueIdentifier (matches VMware disk id)
                    LogicalDriveNumber (LUN number as seen by VMware)
                    MediaType (type of disk HDD/SSD)
                    CapacityGB (capacity of the data drive in GBs)
                    Protocol (SAS/SATA etc)
    :raises: InvalidLUNException or LogicalDriveNotFound.
    """
    ilo_client = redfish.rest_client(base_url=ilo_host,
                                     sessionkey=session_key)
    ac_response = _get_array_controllers(ilo_client)
    drive_info = []
    for ac in ac_response['links']['Member']:
        ld_response = _get_ld_for_controller(ilo_client, ac['href'])
        # if a controller has no logical drives, skip it.
        if 'Member' not in ld_response['links']:
            continue
        for ld in ld_response['links']['Member']:
            details = {'ControllerUri': ac['href']}

            uuid, lun_num, dd_response = _get_pd_for_ld(ilo_client, ld['href'])
            dds = dd_response['links']['Member']
            _validate_lun_constraints(dds)

            dd = dds[0]
            dd1_response = _do_get(ilo_client, dd['href'])
            details['MediaType'] = dd1_response['MediaType']
            details['CapacityGB'] = dd1_response['CapacityGB']
            details['Protocol'] = dd1_response['InterfaceType']
            details['VolumeUniqueIdentifier'] = uuid
            details['LogicalDriveNumber'] = lun_num
            drive_info.append(details)
    _map_drive_info(drive_info, controller_details)
    return controller_details
