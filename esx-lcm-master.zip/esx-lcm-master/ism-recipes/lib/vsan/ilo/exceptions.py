#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from  lib.vsan.common.exc import exceptions as exc


class iLOException(exc.VsanException):
    message = "%(msg)s"


class iLOQueryException(iLOException):
    message = "%(msg)s"


class InvalidLUNException(iLOException):
    message = "%(msg)s"


class LogicalDriveNotFound(iLOException):
    message = "%(msg)s"
