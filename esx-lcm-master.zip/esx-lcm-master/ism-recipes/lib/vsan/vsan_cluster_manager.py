#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

"""
The VsanClusterManager class facilitates processes related to vSAN cluster.
"""

import argparse
from orch import log
# this call is to extend pyVmomi with vSAN entities.
import vsanmgmtObjects
import sys

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.handlers import disk_validator as dv
from lib.vsan.handlers.vsan_lifecycle.prepare import VsanOperationInitializerHandler
from lib.vsan.handlers.vsan_lifecycle.deploy import VsanDeployHandler
from lib.vsan.handlers.vsan_lifecycle.scaleout import VsanScaleoutHandler
from lib.vsan.handlers.vsan_lifecycle.update import VsanUpdateHandler
from lib.vsan.handlers.vsan_lifecycle.delete import VsanDeleteHandler
from lib.vsan.utils.vcenter import vCenterUtils


class VsanClusterManager(object):
    def __init__(self):
        self.LOG = log.getLogger(__name__)
        self.vc = vCenterUtils()

    def setup_cluster(self, args):
        system_params = self.get_system_parameter(args)
        dh = VsanDeployHandler(system_params)
        return dh.do()

    def scale_out_cluster(self, args):
        system_params = self.get_system_parameter(args)
        sh = VsanScaleoutHandler(system_params)
        return sh.do(args={'batch': False})

    def pre_update_validation(self, args):
        system_params = self.get_system_parameter(args)
        uh = VsanUpdateHandler(system_params)
        return uh.pre_operation_validation()

    def vsan_pre_update_collect_info(self, args):
        system_params = self.get_system_parameter(args)
        uh = VsanUpdateHandler(system_params)
        return uh.do_pre_steps()

    def post_update_validation(self, args):
        system_params = self.get_system_parameter(args)
        uh = VsanUpdateHandler(system_params)
        return uh.post_operation_valdiation()

    def perform_pre_delete_operations(self, args):
        params = self.get_system_parameter(args)
        dh = VsanDeleteHandler(params)
        return dh.do_pre_steps()

    def delete_cluster(self, args):
        system_params = self.get_system_parameter(args)
        dh = VsanDeleteHandler(system_params)
        return dh.do()

    def prepare_new_host(self, args):
        system_params = self.get_system_parameter(args)
        bh = VsanOperationInitializerHandler(system_params)
        return bh.do(system_params)

    def perform_pre_host_creation_validations(self, args):
        """
        The set of validations that are performed before the SPT is created are
        only being performed at this stage. This method is expected to be
        called from a module which is invoked by a playbook before it attempts
        setting up the vSAN cluster.
        :return: tuple of the form (status, error) where
                 status can be True or False
                 error can be None or a string containing error description
        """
        params = self.get_system_parameter(args)
        self.setup_attributes(params)
        ncs_version = self._fetch_ncs_version()
        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            self.vc.get_vsan_license(si)
            self._validate_requested_features(ncs_version, args)
        except (exc.VsanInvalidFeatureException,
                exc.VsanUnsupportedFeatureException,
                exc.VsanInvalidConfigurationException,
                exc.VsanLicenseException,
                exc.VCenterConnectionException) as ex:
            return (False, str(ex))
        except Exception as ex:
            return (False, str(ex))
        else:
            return (True, None)

    def get_system_parameter(self, args):
        """
        Sets up the class attributes to specified values
        :param args: dict containing the parameters
        :return: None
        """
        system_parameters = dict()

        attrs = ['vc_host', 'vc_user', 'vc_password', 'vc_port', 'vc_cluster',
                 'storage_network_name', 'scaleout_hosts',
                 'vsan_disk_info', 'pre_update_data', 'wipe_disks',
                 'force_mark_local_disk_as_flash', 'force_delete']
        for attr in attrs:
            system_parameters[attr] = args.get(attr)

        # set is_all_flash depending on vsan_disk_info
        if system_parameters['vsan_disk_info']:
            system_parameters['is_all_flash'] = self._is_all_flash_deployment(
                system_parameters['vsan_disk_info'],
                system_parameters['force_mark_local_disk_as_flash'])
            if system_parameters['is_all_flash']:
                # enable deduplication by default for all-flash deployment
                system_parameters['deduplication'] = True
            else:
                # set explicitly to be on safer side
                system_parameters['deduplication'] = False

        # fetch VSAN feature parameters (if provided)
        fmap = self._fetch_feature_map()
        ncs_version = self._fetch_ncs_version()
        version_fmap = self._fetch_feature_map_for_version(ncs_version, fmap)
        # user configuration overrides default settings.
        for feature in fmap['all']:
            if args.get(feature) or args.get(feature) is False:
                system_parameters[feature] = args.get(feature)
            elif feature in version_fmap['default']:
                system_parameters[feature] = True

        return system_parameters

    def _is_all_flash_deployment(self, vsan_disk_info, force_local_as_flash):
        disk_info = dv.get_disk_info(vsan_disk_info)
        if (disk_info['capacity_type'] == 'SSD' and
                (disk_info['cache_type'] == 'SSD' or force_local_as_flash)):
            return True
        return False

    def setup_attributes(self, args):
        for attr in args:
            setattr(self, attr, args.get(attr))

    def _validate_requested_features(self, ncs_version, params):
        """
        Validate the user requested features can be enabled in the given mode
        of deployment.
        :param ncs_version: NCS version string like '1.0'
        :param params: dict of user provided feature settings.
        :return: None on success
        :raises: VsanInvalidFeatureException
        """
        fmap = self._fetch_feature_map()
        version_fmap = self._fetch_feature_map_for_version(ncs_version, fmap)

        user_settings = {}
        vsan_feature_prefix = 'vsan_feature_'
        for feature in params:
            if feature.startswith(vsan_feature_prefix):
                feature_key = feature[len(vsan_feature_prefix):]
                if feature_key in fmap['all']:
                    user_settings[feature_key] = params.get(feature)
                else:
                    raise exc.VsanInvalidFeatureException(feature=feature_key)

        deployment_type = 'all_flash' if self.is_all_flash else 'hybrid'
        for feature, value in user_settings.iteritems():
            if feature not in version_fmap[deployment_type] and value is True:
                msg = "%s is not supported in %s mode of deployment in " \
                      "version %s." % (feature, deployment_type, ncs_version)
                raise exc.VsanUnsupportedFeatureException(msg)

        # validate the fault domain format.
        if 'fault_domain' in user_settings:
            if isinstance(user_settings['fault_domain'], basestring):
                fds = user_settings['fault_domain'].split()
                for fd in fds:
                    parts = fd.split(':')
                    if len(parts) != 2:
                        msg = "Invalid vSAN cluster fault domain " \
                              "specification. Fault domain name and " \
                              "hosts should be ':' separated."
                        raise exc.VsanInvalidConfigurationException(msg)
            else:
                msg = "Invalid vSAN cluster fault domain " \
                      "specification. Expected fault domain format:" \
                      "'fd1:host1,host2,host3 fd2:host4 fd3:host5,host6'."
                raise exc.VsanInvalidConfigurationException(msg)

    def _fetch_ncs_version(self):
        """
        Stubbed at the moment to return the default NCS version since we do
        not have any mechanism to determine the NCS version as of now.
        :return: string
        """
        # TODO: Replace this to actually fetch the NCS version.
        fmap = self._fetch_feature_map()
        return fmap['default_ncs_version']

    def _fetch_feature_map(self):
        """
        Returns a map of the vSAN features supported by each NCS version per
        deployment type (hybrid/all-flash), also provides the list of
        features that are enabled by default and deprecated.
        Some fields like vsan_minver are only for information at the moment.
        :return: dict
        """
        fmap = {
            'all': ['deduplication', 'encryption', 'fault_domain',
                    'performance'],
            'default_ncs_version': '1.0',
            'vmap': [
                {
                    'ncs_minver': '1.0',
                    'vsan_minver': '6.6',
                    'all_flash': ['deduplication', 'performance'],
                    'hybrid': ['performance'],
                    'deprecated': [],
                    'default': [],
                },
            ]
        }
        return fmap

    def _fetch_feature_map_for_version(self, ncs_version, fmap):
        """
        Returns: Feature map where version comparison results 0, else the last
        map for which version comparison results 1.

        :param ncs_version: current NCS version
        :param fmap: map containing all the feature information
        :return: best matching feature map
        """
        idx_result = []
        for idx in range(len(fmap['vmap'])):
            idx_version = fmap['vmap'][idx]['ncs_minver']
            idx_result.append(self._compare_versions(ncs_version, idx_version))

        # check for exact version match.
        if 0 in idx_result:
            return fmap['vmap'][idx_result.index(0)]
        else:
            # return the fmap of the last version which is
            found = 0
            for idx in range(len(idx_result)):
                if idx_result[idx] == 1:
                    found = idx
            return fmap['vmap'][found]

    def _compare_versions(self, version1, version2):
        """
        Compares two version strings and returns an integer result.
        :param version1: version string
        :param version2: version string to compare against
        :return: int representing the result of version comparison as follows:
                 0 - meaning exact match OR
                 1 - meaning version1 > version2 OR
                -1 - meaning version1 < version2.
        """

        def get_version_split(version):
            version_list = version.split(".")
            minor = subminor = patch = '0'
            if len(version_list) > 3:
                major, minor, subminor, patch = version_list[:4]
            if len(version_list) == 3:
                major, minor, subminor = version_list[:3]
            elif len(version_list) == 2:
                major, minor = version_list[:2]
            elif len(version_list) == 1:
                major = version_list[0]
            else:
                major = version_list[0]
            return [major, minor, subminor, patch]

        def rec_compare(v1, v2, idx=0):
            if v1[idx] == v2[idx]:
                idx += 1
                if idx == len(v1):
                    return 0
                else:
                    return rec_compare(v1, v2, idx)
            else:
                return 1 if v1[idx] > v2[idx] else -1

        v1 = get_version_split(version1)
        v2 = get_version_split(version2)
        return rec_compare(v1, v2, 0)



# this is temporary method to demonstrate usage from CLI.
def get_args():
    """
    Supports the command-line arguments listed below.
    """
    parser = argparse.ArgumentParser(
        description='Process args for exercising vSAN SDKs')
    parser.add_argument('-s', '--vc-host', action='store',
                        default="172.18.200.106",
                        help='vCenter IP to connect to')
    parser.add_argument('-o', '--vc-port', type=int, default=443,
                        action='store',
                        help='Port to connect on')
    parser.add_argument('-u', '--vc-user', action='store',
                        default="Administrator@vsan.local",
                        help='User name to use when connecting to the vCenter')
    parser.add_argument('-p', '--vc-password', action='store',
                        default="Cloud#123",
                        help='Password to use when connecting to vCenter')
    parser.add_argument('-c', '--vc-cluster', action='store',
                        default="Cluster2",
                        help='Cluster name')
    parser.add_argument('-l', '--vsan-license', action='store', default='',
                        help='vSAN license')
    parser.add_argument('-f', '--is-all-flash', action='store_true',
                        default=False,
                        help='All Flash (default: False')
    parser.add_argument('-n', '--vsan-nic', action='store', default="vmk0",
                        help='vSAN nic (defualt: vmk0)')
    parser.add_argument('-H', '--esx-host', action='store',
                        default="172.18.200.233",
                        help='Esxi host name to add')
    parser.add_argument('-O', '--operation', action='store',
                        default="setup_cluster",
                        help='vSAN operation : setup \
                                               delete \
                                               scaleout(default: '
                             'setup)')
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = get_args()
    vsan_cm = VsanClusterManager()
    if str(args.operation).lower() == "setup":
        vsan_cm.setup_cluster(vars(args))
    elif str(args.operation).lower() == "scale":
        vsan_cm.scale_out_cluster(vars(args))
    elif str(args.operation).lower() == "delete":
        vsan_cm.delete_cluster(vars(args))
    else:
        msg = "Unsupported vSAN operation."
        print msg
        sys.exit(1)
