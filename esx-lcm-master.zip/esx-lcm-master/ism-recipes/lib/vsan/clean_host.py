#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


import argparse
from lib.vsan.devops.common.log import Logger
from lib.vsan.utils.cleaner.host import HostVCenterCleaner

log_file = "/var/log/host_cleaner.log"

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Process for cleaning up disk partitions of ESX Host')
    parser.add_argument('-s', '--ipaddress', action='store',
                        default="172.18.200.166",
                        help='IP Address of the VCenter or the server')
    parser.add_argument('-u', '--username', action='store',
                        default="root",
                        help='Username to connect with VCenter or Server')
    parser.add_argument('-p', '--password', action='store',
                        default="hpinvent123",
                        help='Password to connect with VCenter or Server')
    parser.add_argument('-o', '--vc_port', action='store',
                        default="443",
                        help='VCenter port')
    parser.add_argument('-c', '--cluster', action='store',
                        default="",
                        help='Cluster name')
    parser.add_argument('-i', '--hosts', action='store',
                        default=[],
                        help='List of host ips to be cleaned')
    args = parser.parse_args()
    Logger.setup_logging(filename=log_file)
    LOG = Logger.getLogger(__name__)
    LOG.info("ESX Hosts Cleanup started !!!")
    pcluster = args.cluster
    phosts = args.hosts
    if phosts:
        phosts = phosts.split(',')
    hc = HostVCenterCleaner(vars(args))
    hc.clean(cluster=pcluster, host_list=phosts)
    LOG.info("ESX Hosts Cleanup completed !!!")
