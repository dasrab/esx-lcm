#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


# ----------------------------------------------------------------------------
# It is very important to create class hierarchy of exception to reflect
# the correct message. Exception hierarchy is as follows:
#
#  VsanException
#       |
#       |____VCenterConnectionException
#       |
#       |____VsanLicenseException
#       |
#       |____VsanLifecycleException
#       |       |
#       |       |____VsanSetupException
#       |       |   |
#       |       |   |____VsanInvalidFeatureException
#       |       |   |
#       |       |   |____VsanUnsupportedFeatureException
#       |       |   |
#       |       |   |____VsanFaultDomainException
#       |       |
#       |       |____VsanUpdateException
#       |       |
#       |       |____VsanUpgradeException
#       |       |
#       |       |____VsanFlexException
#       |       |       |
#       |       |       |____VsanFlexUpException
#       |       |       |
#       |       |       |____VsanFlexDownException
#       |       |       |
#       |       |       |____VsanFlexOutException
#       |       |       |
#       |       |       |____VsanFlexInException
#       |       |
#       |       |____VsanDeleteException
#       |
#       |____VsanElementException
#       |       |
#       |       |____VsanEnableOperationException
#       |       |
#       |       |____VsanDisableOperationException
#       |       |
#       |       |____VsanHostLimitException
#       |       |
#       |       |____VsanHostDiskHomogenityException
#       |       |
#       |       |____VsanHostDiskRemoveException
#       |       |
#       |       |____VsanHostUncleanDiskException
#       |       |
#       |       |____VsanNetworkException
#       |       |
#       |       |____VsanHostException
#       |       |
#       |       |____VsanHostDiskCleanUpException
#       |       |
#       |       |____VsanDiskGroupException
#       |       |
#       |       |____VsanInvalidDiskTypeException
#       |       |
#       |       |____VsanClusterNotFoundException
#       |       |
#       |       |____VsanCheckClusterHaException
#       |       |
#       |       |____VsanClusterCollectInfoException
#       |       |
#       |       |____VsanServiceException
#       |       |
#       |       |____VsanInvalidConfigurationException
#       |       |
#       |       |_____VsanHostConnectionException
#       |       |
#       |       |_____VsanHostVersionException
#       |       |
#       |       |_____VsanClusterCapacityException
#       |
#       |_____VsanClusterUsageException
#               |
#               |____VsanGetCapacityException
#               |
#               |____VsanCreatePolicyException
#               |
#               |____VsanDisabledException
#               |
#               |____VsanCollectClusterInfoException

####################################
#
#  Devops Configuration Exceptions
#
# DevopsConfigException
# ----------------------------------------------------------------------------
class VsanException(Exception):

    """Base VsanException class.

    To correctly use this class, inherit from it and define
    a 'message' property. That message will get printf'd
    with the keyword arguments provided to the constructor.
    """
    message = "An unknown exception occurred."
    details = None

    def __init__(self, message=None, details=None, **kwargs):
        if not message:
            message = self.message
        try:
            message = message % kwargs
            if details:
                self.details = details % kwargs
        except Exception as exc:
            raise exc

        # at least get the core message out if something happened
        self.message = message
        super(VsanException, self).__init__(message)


# ----------------------------------------------------------------------------
# Exceptions related to connectivity of vCenter.
# ----------------------------------------------------------------------------
class VCenterConnectionException(VsanException):
    message = "Failed to connect to vCenter %(vc_host)s. %(error_desc)s"


# ----------------------------------------------------------------------------
# Exceptions related to license.
# ----------------------------------------------------------------------------
class VsanLicenseException(VsanException):
    message = "%(msg)s"


# ----------------------------------------------------------------------------
# Exceptions related to top level lifecycle operations and configuration.
# Base class of of this category is VsanLifecycleException.
# ----------------------------------------------------------------------------
class VsanLifecycleException(VsanException):
    message = "Failed to perform lifecycle operation of vSAN"


class VsanSetupException(VsanLifecycleException):
    message = "Exception occurred while setting up vSAN."


class VsanUpgradeException(VsanLifecycleException):
    message = "Exception occurred while upgrading vSAN."


class VsanFlexException(VsanLifecycleException):
    message = "Exception occurred while flexing %(operation)s vSAN."


class VsanDeleteException(VsanLifecycleException):
    message = "vSAN cluster delete operation failed."


# ----------------------------------------------------------------------------
# Exceptions specific to setup operation of vsan cluster. Base class of of
# this category is VsanSetupException.
# ----------------------------------------------------------------------------
class VsanUnsupportedFeatureException(VsanSetupException):
    message = "%(msg)s"


class VsanInvalidFeatureException(VsanSetupException):
    message = "%(feature)s is not a valid vSAN feature."


class VsanFaultDomainException(VsanSetupException):
    message = "Exception occurred while setting up vSAN fault domain."


# ----------------------------------------------------------------------------
# Exceptions which is at elemental level and is used across various lifecycle
# operations. For e.g. VsanHostDiskHomogenityException will be used during
# setup and flex. All these exceptions are derived from the
# VsanElementException exception.
# ----------------------------------------------------------------------------
class VsanElementException(VsanException):
    message = "Failed to perform lifecycle operation of vSAN"


class VsanHostConnectionException(VsanElementException):
    message = "vSAN host connectivity check failed."


class VsanHostVersionException(VsanElementException):
    message = "Hosts' VSAN version validation failed"


class VsanClusterCapacityException(VsanElementException):
    message = "Hosts' VSAN capacity fetch failed"


class VsanHostException(VsanElementException):
    message = "%(msg)s"


class VsanEnableOperationException(VsanElementException):
    message = "Exception occurred while enbling vSAN for the cluster " \
              "%(cluster)s."


class VsanDisableOperationException(VsanElementException):
    message = "Exception occurred while disabling vSAN for the cluster " \
              "%(cluster)s."


class VsanHostLimitException(VsanElementException):
    message = "Exception occurred while evaluating maximum host limit for " \
              "vSAN Cluster %(cluster)s"


class VsanHostDiskHomogenityException(VsanElementException):
    message = "%(msg)s"


class VsanHostDiskRemoveException(VsanElementException):
    message = "Exception occurred while removing disk from the host."


class VsanHostUncleanDiskException(VsanElementException):
    message = "%(msg)s"


class VsanNetworkException(VsanElementException):
    message = "%(msg)s"


class VsanHostException(VsanElementException):
    message = "%(msg)s"


class VsanHostDiskCleanUpException(VsanElementException):
    message = "%(msg)s"


class VsanDiskGroupException(VsanElementException):
    message = "%(msg)s"


class VsanInvalidDiskTypeException(VsanElementException):
    message = "%(msg)s"


class VsanClusterNotFoundException(VsanElementException):
    message = "%(msg)s"


class VsanCheckClusterHaException(VsanElementException):
    message = "Exception occurred while setup as HA pre-requiste was not met"


class VsanClusterCollectInfoException(VsanElementException):
    message = "%(msg)s"


class VsanServiceException(VsanElementException):
    message = "Exception occurred while enbling vSAN %(service)s service."


class VsanInvalidConfigurationException(VsanElementException):
    message = "%(msg)s"


# ----------------------------------------------------------------------------
# Exceptions related to accessing vSAN resources
# ----------------------------------------------------------------------------
class VsanClusterUsageException(VsanException):
    message = "Exception accessing vSAN resource %(resource)s."


class VsanGetCapacityException(VsanClusterUsageException):
    message = "%(msg)s"


class VsanCreatePolicyException(VsanClusterUsageException):
    message = "Exception occurred while creating vSAN storage policy."


class VsanDisabledException(VsanClusterUsageException):
    message = "%(msg)s"


class VsanCollectClusterInfoException(VsanClusterUsageException):
    message = "%(msg)s"
