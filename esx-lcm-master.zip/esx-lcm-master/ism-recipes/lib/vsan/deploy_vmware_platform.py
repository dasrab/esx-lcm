#!/usr/bin/env python
#
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
#

from lib.vsan.devops.utils import conf
from lib.vsan.devops import platform_batch_manager


if __name__ == '__main__':
    iterations = conf.get_conf(section="devops", option="iterations")
    print "=" * 100
    print "Started:  Batch Platform Lifecycle Devops"
    pbm = platform_batch_manager.PlatformBatchManager()
    pbm.run(int(iterations))
    print "Completed:  Batch Platform Lifecycle Devops"
    print "=" * 100