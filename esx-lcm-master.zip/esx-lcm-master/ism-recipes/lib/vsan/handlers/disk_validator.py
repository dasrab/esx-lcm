#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#


from orch import log
from lib.vsan.common.exc import exceptions as exc
from lib.vsan.handlers.vsan_lifecycle.constants import CORRECTION_FACTOR
from lib.vsan.utils import size as u_size


LOG = log.getLogger(__name__)


def get_system_diskmodel(vc_diskmap, hostprops, vsan_disk_info):
    """
    Returns a dictionary which is actually generated when Server Profile Templates
    are created.

    Currently we are cooking a dictionary to simulate the template

    Sample template:
    diskmodel = [
                {
                    'node': '172.18.200.245', // System generated
                    'host_ref': None // Processed information, retrieved from vCenter
                    'device_groups': [
                        {
                            'name': 'device-group-0',  // Cooked or feeded by SPT provisioned
                            'cache_device_id': None, // Processed information (assumes one entry as of now)
                            'vcenter_diskmap'" dict()  // Processed information but used for vSAN diskmap creation
                            'total_raw_capacity': 0,   // Processed information, computed during validation
                            'total_cache_capacity': 0, // Processed information, computed during validation
                            'devices': [
                                {
                                    'id': '766d686261313a313a30', // System generated
                                    'type': 'hdd', // System generated
                                    'size': '100'  // System generated
                                },
                                {
                                    'id': '0003766d686261313a323a30',
                                    'type': 'ssd',
                                    'size': '10'
                                }
                            ]
                        },
                        {
                            'name': 'device-group-1',
                            'cache_device_id': None,
                            'vcenter_diskmap'" dict()
                            'total_raw_capacity': 0,
                            'total_cache_capacity': 0,
                            'devices': [
                                {
                                    'id': '9781686261313a313a30',
                                    'type': 'hdd',
                                    'size': '100'
                                },
                                {
                                    'id': '0001766d686261313a323a30',
                                    'type': 'ssd',
                                    'size': '10'
                                }
                            ]
                        }
                    ]
                },
                {
                     'node': '172.18.200.246',
                     'host_ref': None
                     'device_groups': [
                        {
                            'name': 'device-group-0',
                            'cache_device_id': None,
                            'vcenter_diskmap'" dict()
                            'total_raw_capacity': 0,
                            'total_cache_capacity': 0,
                            'devices': [
                                {
                                    'id': '002766d686261313a313a30',
                                    'type': 'hdd',
                                    'size': '100'
                                },
                                {
                                    'id': '0000766d686261313a323a30',
                                    'type': 'ssd',
                                    'size': '10'
                                }
                            ]
                        }
                    ],
                }
            ]
    """
    diskmodel_template = populate_multi_dgs_model(vc_diskmap,
                                                  hostprops,
                                                  vsan_disk_info)
    return diskmodel_template


def populate_multi_dgs_model(vc_diskmap, hostprops, vsan_disk_info):
    """
    Creates a vSAN storage model template based on disks presented to host and
    seen by vCenter. It applies following logic for creation of storage model,
    which we will change as we move forward:
        1. Treats smaller SSD disks as cache disks
        2. Creates as many disks as many smaller SSD disks are there in system
        3. Distributes remaining disk evenly using rotation policy
        4. Does basic check like capacity disks are just enough for deployment
    :param vc_diskmap: disks presented to vCenter host
    :param hostprops: host properties
    :param vsan_disk_info: Host disk information fetched from Oneview
    :return: return cluster disk model
    """
    vsan_storage_model = []
    profile_disk_info = get_disk_info(vsan_disk_info)
    for host, disks in vc_diskmap.iteritems():
        host_diskmodel = dict()
        host_diskmodel['node'] = hostprops[host]['name']
        host_diskmodel['host_ref'] = None
        host_diskmodel['device_groups'] = list()

        if len(disks) < 2:
            raise exc.VsanDiskGroupException(
                "Host has '%s' device[s] and "
                "does not meet minimum criteria for disk count" %
                len(disks))
        cache_disks, capacity_disks = _partition_disks_based_on_size(
            disks,
            profile_disk_info)
        capacity_disk_chunks = _identify_capacity_disk_chunks(cache_disks,
                                                              capacity_disks)
        _populate_diskgroup(cache_disks, capacity_disk_chunks,
                            host_diskmodel)
        vsan_storage_model.append(host_diskmodel)
    return vsan_storage_model


def _populate_diskgroup(cache_disks, capacity_disk_chunks,
                        host_diskmodel):
    dg_index = 0
    max_dgs = len(cache_disks)
    for disk in cache_disks:
        device_group = dict()
        device_group['name'] = 'dg_group_' + str(dg_index)
        device_group['cache_device_id'] = disk.uuid  # We know, so set it.
        device_group['devices'] = []

        # Add cache device. Cache disk will always be SSD.
        _populate_disk_in_dg(device_group, disk)

        # Add capacity device(s). For last device_group, we might have more or
        # less devices based on disk configuration.
        capacity_disks = capacity_disk_chunks[dg_index]
        for cdisk in capacity_disks:
            _populate_disk_in_dg(device_group, cdisk)

        dg_index = dg_index + 1

        # Need to add leftover capacity disks (if any) to last device_group.
        # We know last dgs by comparing dg_index with max_dgs, which
        # is equal to number of cache disks.
        if dg_index == max_dgs and len(capacity_disk_chunks) > max_dgs:
            leftover_capacity_disks = capacity_disk_chunks[dg_index]
            for d in leftover_capacity_disks:
                _populate_disk_in_dg(device_group, d)

        host_diskmodel['device_groups'].append(device_group)


def _populate_disk_in_dg(device_group, disk):
    device = {}
    device['size'] = disk.capacity.block * disk.capacity.blockSize
    device['id'] = disk.uuid
    device['type'] = "ssd" if disk.ssd else "hdd"
    device_group['devices'].append(device)


def _identify_capacity_disk_chunks(cache_disks, capacity_disks):
    # Create as many dgs as many cache devices are. After that,
    # distribute capacity devices among different dg using
    # rotation policy. Let us assume that we do have 3 cache devices
    # and 10 capacity devices. We will have three disk groups where
    # first dg will have 4 disks, while later two will have
    # three disks each.
    if len(cache_disks) == 0:
        raise exc.VsanDiskGroupException("Disk group must have ONE SSD disk")
    min_disks_per_dg = len(capacity_disks) / len(cache_disks)
    capacity_disk_chunks = [capacity_disks[i:i + min_disks_per_dg]
                            for i in range(0, len(capacity_disks), min_disks_per_dg)]

    # Do some basic validation (minimal one) and cry if any below check pass:
    #   1. if number of cache disks are more than capacity disks
    #   2. if number of capacity chunks are less than cache disks i.e. dg groups
    #   3. if minimum no of  capacity disks per host are more than 7
    if (len(cache_disks) > len(capacity_disks) or
            len(capacity_disk_chunks) < len(cache_disks) or
            min_disks_per_dg >= 7):
        raise exc.VsanDiskGroupException(
            "Host devices are not appropriate to build diskgroups")
    return capacity_disk_chunks


def _partition_disks_based_on_source(disks, host_disk_info):
    """
    From the set of all disks presented to the hosts,
    identify smallest SSD Disk as cache disk and HDD Disk as capacity disk
    and collect them in list and return
    @param disks: List of all devices per host
    @param host_disk_info: Disk information from Oneview
    @return: List of capacity_disks and Cache disks
    """
    cache_disks = []
    capacity_disks = []
    cache_ids = []

    for controller in host_disk_info:
        for drive in controller['logical_drives']:
            if drive['source'] == "local":
                cache_ids.append(drive['VolumeUniqueIdentifier'])

    for disk in disks:
        if (disk.ssd and disk.devicePath.split("/")
                [-1].split(".")[-1].upper() in cache_ids):
            cache_disks.append(disk)
        else:
            capacity_disks.append(disk)
    return cache_disks, capacity_disks


def _partition_disks_based_on_size(disks, profile_disk_info):
    """
    From the set of all disks presented to the hosts,
    identify smallest SSD Disk as cache disk and HDD Disk as capacity disk
    and collect them in list and return
    @param disks: List of all devices per host
    @param profile_disk_info: Dict of the platform profile disk info
    @return: List of capacity_disks and Cache disks
    """
    cache_disks = []
    capacity_disks = []

    cache_size = profile_disk_info['cache_size']
    cache_margin = cache_size * CORRECTION_FACTOR

    for disk in disks:
        dsize = disk.capacity.block * disk.capacity.blockSize
        dsize_gb = u_size.size_conv(dsize, '', 'GB', pow=10)
        # if disk size falls in cache disk size range, consider it for cache
        if (disk.ssd and ((cache_size - cache_margin) <= dsize_gb <= (
                    cache_size + cache_margin))):
            # if cache disk count is reached, put further disks in capacity
            # bucket
            if len(cache_disks) == profile_disk_info['cache_count']:
                capacity_disks.append(disk)
            else:
                cache_disks.append(disk)
        # disk is non-SSD or does not fit in cache disk size range, so use it
        # as capacity
        else:
            capacity_disks.append(disk)
    return cache_disks, capacity_disks


def process_host_dg_sanity(dgs, vsan_type):
    """
    Ensure the sanity of disk group criteria.
    1. A host can have maximum 5 disk group.
    2. A device group can have maximum 8 disks.
    3. A device group should have minimum 2 disks.
    """
    host_dg_info = dict()
    total_dgs = len(dgs)

    if total_dgs > 5 or total_dgs < 1:
        raise exc.VsanDiskGroupException("Host contains '%s' disk groups. \
            A Host in VSAN Cluster can have 1 to 5 diskgroups." % total_dgs)

    for dg_index in range(total_dgs):
        devices = dgs[dg_index]['devices']
        total_devices = len(devices)
        if total_devices < 2 or total_devices > 8:
            msg = ("Disk group contains '%s' devices. "
                   "Disk Group in a VSAN can have only 2 to 8 disks "
                   "including one disk for cache") % total_devices
            raise exc.VsanDiskGroupException(msg)

        if vsan_type == "hybrid":
            (dg_capacity_size, dg_cache_size, cache_device_id) = \
                check_hybrid_vsan_diskmap_sanity(devices)
        else:
            (dg_capacity_size, dg_cache_size, cache_device_id) = \
                check_flash_vsan_diskmap_sanity(devices)

        dgs[dg_index]['total_raw_capacity'] = dg_capacity_size
        dgs[dg_index]['total_cache_capacity'] = dg_cache_size
        dgs[dg_index]['cache_device_id'] = cache_device_id


def check_hybrid_vsan_diskmap_sanity(devices):
    hdd_count = 0
    hdd_reference_size = 0
    total_capacity_size = 0
    hdd_size_outliar = False
    ssd_device = None
    for device in devices:
        if device['type'] == 'hdd':
            hdd_count = hdd_count + 1
            if hdd_count == 1:
                hdd_reference_size = device['size']
            if device['size'] != hdd_reference_size:
                hdd_size_outliar = True
            total_capacity_size = total_capacity_size + device['size']
        elif device['type'] == 'ssd':
            if ssd_device is not None:
                raise \
                    exc.VsanDiskGroupException(
                        "One Hybrid disk group can have ONLY ONE SSD disk")
            ssd_device = device
        else:
            LOG.error("Unsupported disk type: %s", device['id'])
            raise exc.VsanDiskGroupException("Unsupported disk type")

    if hdd_size_outliar:
        raise exc.VsanDiskGroupException(
            "All HDD Disks are not of uniform size")
    if ssd_device is None:
        raise exc.VsanDiskGroupException("Disk group must have ONE SSD disk")
    if ssd_device['size'] < (total_capacity_size * .1):
        LOG.warning("Cache size is lesser than 10% of total capacity size")
        raise exc.VsanDiskGroupException(
            "Cache size is lesser than 10 percent of total capacity size.")
    return (total_capacity_size, ssd_device['size'], ssd_device['id'])


# TODO Yet to test Flash disk group
def check_flash_vsan_diskmap_sanity(devices):
    # Find the device which deserve to be a cache disk. Criteria:
    #       1. smallest disk size
    #       2. should be local disk instead of big bird (logic not implemented)
    cache_device = devices[0]
    for device in devices:
        if device['type'] != 'ssd':
            LOG.error("Only %s is a non SSD disk. Only SSD disks allowed",
                      device['id'])
            raise exc.VsanDiskGroupException("Flash vSAN needs only SSD disks")
        if device['size'] < cache_device['size']:
            cache_device = device

    # Scan all devices (exceot the one we picked for cache) to perform
    # following sanity:
    #   1. No more disks are of same size as cache disk size
    #   2. All capacity flash disks are of same size.
    #   3. Cover the possibilty of all SSD (including cache) to be of same size
    capacity_reference_size = 0
    capacity_size_outliar = False
    total_capacity_size = total_capacity_disk_count = 0
    for device in devices:
        if device != cache_device:
            total_capacity_disk_count += 1
            total_capacity_size += device['size']
            if total_capacity_disk_count == 1:
                capacity_reference_size = device['size']
            if device['size'] != capacity_reference_size:
                capacity_size_outliar = True

    if capacity_size_outliar:
        LOG.error("Capacity disks of FLASH vSAN are not of same size")
        raise exc.VsanDiskGroupException(
            "Capacity disks of FLASH vSAN are not of same size")

    return (total_capacity_size, cache_device['size'], cache_device['id'])


def compare_dg_homogenity(ref_host_dgs, curr_host_dgs):
    if len(ref_host_dgs) != len(curr_host_dgs):
        return False

    for dg_index in range(len(ref_host_dgs)):
        dg1 = ref_host_dgs[dg_index]
        for curr_dg in curr_host_dgs:
            if dg1['name'] == curr_dg['name']:
                dg2 = curr_dg
                if ((len(dg1['cache_device_id']) != len(dg2['cache_device_id'])) or
                        (dg1['total_raw_capacity'] != dg2['total_raw_capacity']) or
                        (dg1['total_cache_capacity'] != dg2['total_cache_capacity']) or
                        (len(dg1['devices']) != len(dg2['devices']))):
                    return False
    return True


def build_vCenter_diskmap(vc_diskmap, host_diskmodel):
    """
    Add the references of vCenter disks into devicegroups of Host.
    For every device group, prepare a vcenter diskmap so
    that it can be used to create vsan disk group.
    """
    for dg in host_diskmodel['device_groups']:
        cache = []
        capacity = []
        cache_id = dg['cache_device_id']
        for device in dg['devices']:
            for disk in vc_diskmap[host_diskmodel['host_ref']]:
                if device['id'] == disk.uuid:
                    if device['type'] == 'ssd':
                        if cache_id == device['id']:
                            cache.append(disk)
                            vc_diskmap[host_diskmodel['host_ref']].remove(disk)
                            break
                        else:
                            # Capacity Tier of All Flash DG
                            capacity.append(disk)
                            vc_diskmap[host_diskmodel['host_ref']].remove(disk)
                            break
                    # We need to consider disk type checking! some work for future!
                    # Capacity Tier of Hybrid DG
                    elif device['type'] == 'hdd':
                        capacity.append(disk)
                        vc_diskmap[host_diskmodel['host_ref']].remove(disk)
                        break
        dg['vcenter_diskmap'] = dict()
        dg['vcenter_diskmap']['cache'] = cache
        dg['vcenter_diskmap']['capacity'] = capacity


def get_disk_info(vsan_disk_info):
    """
    Interpret the disk information available in the platform profile
    template for consumption here.
    :param vsan_disk_info: dict of disk information available in the platform
                           profile template. Format is as below:
        {
            "capacity_drive_type":"bigbird:SAS:HDD",
            "capacity_drive_count":4,
            "capacity_drive_size_gb":2048,
            "cache_drive_type":"local:SAS:SSD",
            "cache_drive_count":2,
            "cache_drive_size_gb":800
         }
    :return: A dict with following keys:
        capacity_count, capacity_type, capacity_size, cache_count
         cache_type, cache_size
    """
    def _get_drive_type(drive_type_str):
        return drive_type_str.split(":")[2].upper()
    capacity_drive_type = _get_drive_type(
        vsan_disk_info['capacity_drive_type'])
    cache_drive_type = _get_drive_type(vsan_disk_info['cache_drive_type'])
    return {"capacity_count": vsan_disk_info['capacity_drive_count'],
            "capacity_type": capacity_drive_type,
            "capacity_size": vsan_disk_info['capacity_drive_size_gb'],
            "cache_count": vsan_disk_info['cache_drive_count'],
            "cache_type": cache_drive_type,
            "cache_size": vsan_disk_info['cache_drive_size_gb']}


def validate_drive_type(disk_info, local_as_flash):
    """
    Ensures following:
    1. Cache disk is SSD.
    2. Capacity disk is either SSD or HDD.
    :param disk_info: dict containing platform profile template host_disk
                      information
    :param local_as_flash: flag indicating whether local disk should be
                           forced marked as flash.
    :return: None, raise VsanInvalidDiskTypeException with appropriate
             error message.
    """
    if disk_info['cache_type'] != 'SSD' and not local_as_flash:
        msg = "Non-SSD disk cannot be used for vSAN cache tier."
        LOG.error(msg)
        raise exc.VsanInvalidDiskTypeException(msg)

    if disk_info['capacity_type'] not in ('SSD', 'HDD'):
        msg = "Unknown Capacity drive type '%s'." % \
              disk_info['capacity_type']
        LOG.error(msg)
        raise exc.VsanInvalidDiskTypeException(msg)
