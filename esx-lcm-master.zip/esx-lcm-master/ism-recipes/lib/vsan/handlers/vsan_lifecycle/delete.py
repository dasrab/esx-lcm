#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from pyVim.connect import Disconnect
from pyVmomi import vim, vmodl

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler


class VsanDeleteHandler(VsanLifecycleHandler):

    def pre_operation_validation(self, args=None):
        pass

    def do_pre_steps(self, args=None):
        """
        Disable the vSAN performance service.
        :param args: dict containing vCenter details (user, password, host,
                      port) and cluster name.
        :return: tuple of the form (status, error) where
                  status can be True or False
                  error can be None or a string containing error description
        """
        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = self.vc.get_vsan_managed_objects(si._stub,
                                                      context=context)
            perf_system = vc_mos['vsan-performance-manager']
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            task = perf_system.DeleteStatsObjectTask(cluster)
            self.vc.wait_for_tasks([task], si)
            self.LOG.info("vSAN performance service disabled "
                          "successfully.")
            return True, None
        except vim.fault.NotFound as ex:
            self.LOG.debug("vSAN performance service is not enabled, "
                           "ignoring.")
            return True, None
        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                vmodl.RuntimeFault,
                Exception) as ex:
            return False, str(ex)
        finally:
            if 'si' in locals():
                Disconnect(si)


    def do(self, args=None):
        """
         Performs all the required steps to delete vSAN cluster.
         :param args: dict containing vCenter details (user, password, host,
                      port) and cluster name.
         :return: tuple of the form (status, error) where
                  status can be True or False
                  error can be None or a string containing error description
         :raises: VCenterConnectionException: for connection error
                  VsanDisableOperationException: for cluster operations error
                  VsanHostException: for host operations error
                  VsanDeleteException: for delete operation error
        """
        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = \
                self.vc.get_vsan_managed_objects(si._stub,
                                                 context=context)

            # 1. Get management objects from vCenter
            disk_management_system = vc_mos['vsan-disk-management-system']
            cluster_system = vc_mos['vsan-cluster-config-system']

            # 2. Get Cluster and Host Objects from vCenter
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            host_props = self.vc.collect_host_properties(si.content, cluster.host)
            hosts = host_props.keys()

            # 3.Check Vsan already disabled or not
            if not self.is_vsan_enabled(cluster, cluster_system):
                msg = "vSAN is already disabled for %s cluster." % \
                      cluster.name
                self.LOG.error(msg)
                raise exc.VsanDeleteException(msg)

            # 4.Check if HA disabled and hosts are in maintenance mode
            self._validate_requirements(cluster, hosts)

            # 5.Remove disk group
            self.remove_disk_mappings(si,
                                      disk_management_system,
                                      hosts,
                                      host_props)

            # 6. Disable vsan service and traffic for hosts
            self.disable_vsan_traffic(si, hosts, host_props)

            # 7.Disable Vsan for the cluster
            self._disable_vsan(cluster, si, cluster_system)

            # Check if vSAN disabled successfully
            if not self.is_vsan_enabled(cluster, cluster_system):
                self.LOG.info("vSAN disabled successfully.")
            else:
                raise exc.VsanDeleteException()

        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                exc.VsanHostException,
                exc.VsanCheckClusterHaException,
                exc.VsanDisableOperationException,
                exc.VsanDeleteException) as ex:
            return (False, str(ex))
        else:
            return (True, None)
        finally:
            if 'si' in locals():
                Disconnect(si)

    def do_post_steps(self, args=None):
        pass

    def post_operation_valdiation(self, args=None):
        pass

    def _validate_requirements(self, cluster, hosts):
        """
        Ensure HA is turned OFF and all hosts are in maintenance mode.
        If force_delete is ON, these will be skipped as atleast disk clean up
        can be performed even when both these conditions are not met.
        :param cluster: cluster MO
        :param hosts: list of host MOs
        :return: None on success, raises corresponding exception on error if
        force_delete is False.
        """
        try:
            self.validate_cluster_ha_settings(cluster)
            self.check_hosts_in_maintenance_mode(hosts)
        except Exception as ex:
            if not self.force_delete:
                raise ex

    def _disable_vsan(self, cluster, si, cluster_system):
        """
        Reconfigure vSAN parameters based on inputs like disable auto
        claiming of disks, enable compression & dedup only if is_all_flash is
        True and configure fault domains if provided.
        :param cluster: cluster instance
        :param si: service instance
        :param cluster_system: vsanClusterSystem MO
        :return: None on success
        :raises: VsanDisableOperationException
        """
        self.LOG.info('Disabling vSAN for the %s cluster' % cluster.name)
        vsanReconfigSpec = vim.VimVsanReconfigSpec(
            modify=True,
            vsanClusterConfig=vim.VsanClusterConfigInfo(
                enabled=False,
                defaultConfig=vim.VsanClusterConfigInfoHostDefaultInfo(
                    autoClaimStorage=False
                )
            )
        )

        task = cluster_system.VsanClusterReconfig(cluster, vsanReconfigSpec)
        try:
            self.vc.wait_for_tasks([task], si)
            self.LOG.info('vSAN disable operations successful.')
        except vmodl.MethodFault as ex:
            msg = "vSAN disable operation failed."
            err_msg = self.get_object_model_fault_message(ex)
            self.LOG.error("%s Error: %s" % (msg, err_msg))
            raise exc.VsanDisableOperationException(cluster=self.vc_cluster)
