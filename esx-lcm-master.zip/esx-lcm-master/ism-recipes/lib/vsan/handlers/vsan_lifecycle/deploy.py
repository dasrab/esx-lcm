#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from pyVim.connect import Disconnect
from pyVmomi import vim, vmodl

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.handlers.vsan_lifecycle.decorators import disk_cleanup
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
import lib.vsan.handlers.disk_validator as dv


class VsanDeployHandler(VsanLifecycleHandler):

    def pre_operation_validation(self, args=None):
        pass

    def do_pre_steps(self, args=None):
        pass

    @disk_cleanup
    def do(self, args=None):
        """
         Performs all the required steps to configure vSAN on the provided
         vCenter and enables it.
         :param args: dict containing vCenter details (user, password, host,
                      port), cluster name and vSAN  details (license, allFlash
                      and VMkernel adapter for vSAN traffic).
         :return: tuple of the form (status, error) where
                  status can be True or False
                  error can be None or a string containing error description
        """
        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = self.vc.get_vsan_managed_objects(si._stub,
                                                         context=context)
            vsan_license = self.vc.get_vsan_license(si)

            # 1. Get management objects from vCenter
            cluster_system = vc_mos['vsan-cluster-config-system']
            mob_disk_management = vc_mos['vsan-disk-management-system']
            performance_system = vc_mos['vsan-performance-manager']

            # 2a. Get Cluster and Host Objects from vCenter
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            host_props = self.vc.collect_host_properties(si.content, cluster.host)
            hosts = host_props.keys()

            # 3.Check cluster is HA enabled or not
            self.validate_cluster_ha_settings(cluster)

            # 4. Populate and prepare the disk model.
            diskmodel = self._prepare_diskmap(hosts, host_props)

            # 5. Validation on all entities required for vSan creation.
            self.validate_host_settings(hosts, host_props, diskmodel)

            # 6.Prepare for vSan Cluster
            self.LOG.debug('Enable vSAN with {} mode'.format(
                'all flash' if self.is_all_flash else 'hybrid'))

            self.enable_network_adapter_for_vsan_service(hosts, host_props, si)
            self.publish_compliance_report()

            self.reconfigure_cluster(hosts,
                                     host_props,
                                     cluster,
                                     si,
                                     cluster_system)

            # 7. Activate and monitor
            self.activate_disks(hosts, host_props,
                                si,
                                mob_disk_management,
                                diskmodel)
            self.enable_vsan_performance_service(cluster,
                                                 si,
                                                 performance_system)
            self.vc.apply_vsan_license(si,
                                    cluster,
                                    vsan_license)
        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                exc.VsanEnableOperationException,
                exc.VsanCheckClusterHaException,
                exc.VsanHostException,
                exc.VsanNetworkException,
                exc.VsanLicenseException,
                exc.VsanDiskGroupException,
                exc.VsanServiceException,
                exc.VsanHostDiskHomogenityException,
                Exception) as ex:
            return (False, str(ex))
        else:
            return (True, None)
        finally:
            if 'si' in locals():
                Disconnect(si)

    def do_post_steps(self, args=None):
        pass

    def post_operation_valdiation(self, args=None):
        pass

    def _prepare_diskmap(self, hosts, hostprops):
        """
        Prepares vCenter diskmap.
        1. Query the vCenter disk mappings.
        2. Get the system disk model for cluster
        3. Check the sanity  and homogenity of diskgroups.
        4. Build the disk model for validations.
        """
        vsan_type = 'allFlash' if self.is_all_flash else 'hybrid'
        self.LOG.debug("Querying vCenter for disks")
        vc_diskmap = self.query_vcenter_disks(hosts, hostprops)
        eligible_disks = vc_diskmap['eligible']

        # Get the system disk model template
        self.LOG.debug("Get the system defined disk model template")
        diskmodel = dv.get_system_diskmodel(eligible_disks, hostprops,
                                            self.vsan_disk_info)

        # Prepare the host dictionary needed for planting the vCenter
        # host references in model
        # Sample dictionary is
        #     {'172.18.200.245': 'vim.HostSystem:host-194',
        #     '172.18.200.244': 'vim.HostSystem:host-192'}

        host_dict = {}
        for host, props in hostprops.iteritems():
            host_dict[props['name']] = host

        # Check the sanity  and homogenity of diskgroups.
        first_host_dgs = curr_host_dgs = None
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, vsan_type)
            if first_host_dgs is None:
                # Store the first host dgs. We will use it for reference
                # and compare remaining host for homogenity.
                first_host_dgs = host_diskmodel['device_groups']
            else:
                # Ensure that current one meets homogenity constraint
                result = dv.compare_dg_homogenity(
                    first_host_dgs, curr_host_dgs)
                if not result:
                    self.LOG.error("Host disks model are not homegenous")
                    raise exc.VsanHostDiskHomogenityException(
                        "Host disks model are not homegenous")

            # Plant the vCenter references of hosts and disks in the model
            # needed for preparation for vCenter disk map.
            host_diskmodel['host_ref'] = host_dict[host_diskmodel['node']]
            dv.build_vCenter_diskmap(eligible_disks, host_diskmodel)

        # self.LOG.debug(diskmodel)
        return diskmodel

    def reconfigure_cluster(self, hosts, host_props, cluster, si,
                            cluster_system):
        """
        Reconfigure vSAN parameters based on inputs like disable auto
        claiming of disks, enable compression & dedup only if is_all_flash is
        True and configure fault domains if provided.
        :param hosts: list of host MO
        :param host_props: dict of host properties
        :param cluster: cluster instance
        :param si: service instance
        :param cluster_system: vsanClusterSystem MO
        :return: None on success
        :raises: VsanEnableOperationException
        """
        self.LOG.info('Enabling vSAN by claiming disks manually')
        vsanReconfigSpec = vim.VimVsanReconfigSpec(
            modify=True,
            vsanClusterConfig=vim.VsanClusterConfigInfo(
                enabled=True,
                defaultConfig=vim.VsanClusterConfigInfoHostDefaultInfo(
                    autoClaimStorage=False
                )
            )
        )

        if self.is_all_flash:
            if (hasattr(self, 'deduplication') and self.deduplication):
                self.LOG.info('Enabling deduplication and compression for '
                              'vSAN cluster "%s".' % self.vc_cluster)
                vsanReconfigSpec.dataEfficiencyConfig = \
                    vim.VsanDataEfficiencyConfig(
                        compressionEnabled=True,
                        dedupEnabled=True
                    )

        if (hasattr(self, 'fault_domain') and self.fault_domain):
            self.LOG.info('Adding fault domains in vSAN cluster "%s".' %
                          self.vc_cluster)
            fault_domains = []
            # args.faultdomains is a string like f1:host1,host2 f2:host3,host4
            for faultdomain in self.fault_domain.split():
                fname, hostnames = faultdomain.split(':')
                domainSpec = vim.cluster.VsanFaultDomainSpec(
                    name=fname,
                    hosts=[host for host in hosts
                           if host_props[host]['name'] in hostnames.split(',')]
                )
                fault_domains.append(domainSpec)

            vsanReconfigSpec.faultDomainsSpec = \
                vim.VimClusterVsanFaultDomainsConfigSpec(
                    faultDomains=fault_domains)

        if (hasattr(self, 'encryption') and self.encryption):
            self.LOG.info('Enabling encryption on vSAN cluster "%s".' %
                          self.vc_cluster)
            vsanReconfigSpec.dataEncryptionConfig = \
                vim.vsan.DataEncryptionConfig(encryptionEnabled=True)

        task = cluster_system.VsanClusterReconfig(cluster, vsanReconfigSpec)
        try:
            self.vc.wait_for_tasks([task], si)
        except vmodl.MethodFault as ex:
            msg = "vSAN cluster reconfiguration failed."
            err_msg = self.get_object_model_fault_message(ex)
            self.LOG.error("%s Error: %s" % (msg, err_msg))
            raise exc.VsanEnableOperationException(cluster=self.vc_cluster)
        self.LOG.info('vSAN cluster reconfigured successfully.')

    def enable_vsan_performance_service(self, cluster, si, performance_system):
        """
        Ebnables the vSAN performance service on the given cluster.
        :param cluster: cluster MO.
        :param si: service instance MO.
        :param performance_system: vsanPerfSystem MO.
        :return: None on success
        :raises: VsanServiceException.
        """
        if hasattr(self, 'performance') and self.performance:
            self.LOG.info('Enabling vSAN Performance service on the cluster')
            task = performance_system.CreateStatsObjectTask(cluster)
            try:
                self.vc.wait_for_tasks([task], si)
                self.LOG.info("Enabled vSAN Performance service on the "
                              "cluster.")
            except vim.fault.FileAlreadyExists:
                self.LOG.info("vSAN Performance service is already enabled on "
                              "this cluster, ignoring error!")
            except vmodl.MethodFault as ex:
                msg = "Error enabling vSAN performance service for cluster."
                err_msg = self.get_object_model_fault_message(ex)
                self.LOG.error("%s Error: %s" % (msg, err_msg))
                raise exc.VsanServiceException(service='performance')

    def publish_compliance_report(self):
        pass
