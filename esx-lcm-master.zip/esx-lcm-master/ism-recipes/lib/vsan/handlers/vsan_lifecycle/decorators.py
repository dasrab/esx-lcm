#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


def disk_cleanup(func):
    """
    This is a decorator for vSAN lifecycle operations like setup, scale out.
    It calls the wrapped method and if status of called method indicates an
    error, it calls the 'process_disk_cleanup' method on the calling instance.
    :param func: the wrapped method.
    :return: the method wrapper
    """
    cleanup_method = 'process_disk_cleanup'

    def inner(*args, **kwargs):
        caller_obj = args[0]
        status, err_msg = func(*args, **kwargs)
        if not status:
            # call the cleanup method.
            log_handler = getattr(caller_obj, 'LOG')
            log_handler.error("Encountered exception: %s" % str(err_msg))
            getattr(caller_obj, cleanup_method)()
        return status, err_msg
    return inner
