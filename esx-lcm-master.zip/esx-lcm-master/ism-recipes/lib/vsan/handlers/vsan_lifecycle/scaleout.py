#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from pyVim.connect import Disconnect

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.utils import size as sutils
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
import lib.vsan.handlers.disk_validator as dv


class VsanScaleoutHandler(VsanLifecycleHandler):

    def pre_operation_validation(self, args=None):
        pass

    def do_pre_steps(self, args=None):
        pass

    def _scaleout_single_host(self,
                              si,
                              vc_mos,
                              cluster,
                              hosts,
                              host_props,
                              sh_list):

        # 1) Prepare disk model
        mob_dms = vc_mos['vsan-disk-management-system']
        sh_disk_model = \
            self._prepare_scaleout_vcenter_diskmap(mob_dms,
                                                   hosts,
                                                   host_props,
                                                   sh_list)

        # 2) Validation on all entities required for vSan creation.
        self.validate_host_settings(sh_list, host_props, sh_disk_model)
        self.LOG.debug("Host settings validation succeeded !!")

        # 3) Prepare network for vSan Cluster
        self.enable_network_adapter_for_vsan_service(sh_list, host_props, si)
        self.LOG.debug("Enabled network adapter for VSAN traffic on host.")

        # 4) Get the cluster capacity before scaleout operation
        mob_css = vc_mos['vsan-cluster-space-report-system']
        pre_scaleout_capacity = self.get_cluster_capacity(cluster, mob_css)

        # 5) Activate and monitor progress
        self.activate_disks(hosts,
                            host_props,
                            si,
                            mob_dms,
                            sh_disk_model)

        # 6) Check if the cluster capacity is increased after scaleout
        post_scaleout_capacity = self.get_cluster_capacity(cluster, mob_css)
        if pre_scaleout_capacity >= post_scaleout_capacity:
            msg = ("Unexpected error: cluster capacity did not increase "
                       "even after scale out operation")
            self.LOG.error(msg)
            raise exc.VsanGetCapacityException(msg)
        msg = ("%s Cluster size increased from %s to %s after adding %s "
               "host(s)") % (self.vc_cluster,
                             sutils.sizeof_fmt(pre_scaleout_capacity),
                             sutils.sizeof_fmt(post_scaleout_capacity),
                             host_props[sh_list[0]]['name'])
        self.LOG.info(msg)

    def do(self, args=None):
        """
        Performs all the required steps to scale out vSAN cluster.
        :param args: dict() containing specifc field for scaleout operations.
        :return: tuple of (status, failure_details)
            If success : (True, None)
            If partial_success : (True/False ,{failed_ips : [], failure_reason:[]})
            If complete_falure : (False,  {failed_ips : [], failure_reason:[]})
        """
        try:
            failed_hosts = []
            result = True
            batch_processing = args.get('batch')
            failure_cause = []

            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = \
                self.vc.get_vsan_managed_objects(si._stub, context=context)

            # 1) Get Cluster and Host Objects from vCenter
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            host_props = self.vc.collect_host_properties(
                si.content, cluster.host)
            hosts = host_props.keys()

            # 2) Back off if vSAN is not enabled.
            cluster_system = vc_mos['vsan-cluster-config-system']
            if not self.is_vsan_enabled(cluster, cluster_system):
                msg = "vSAN is disabled for %s cluster." % cluster.name
                self.LOG.error(msg)
                raise exc.VsanDisabledException(msg=msg)

            # 3) Check maximum host limit. Raise exception if criteria is
            # not met. At this point of time criteria is not aligned with
            # maximum node per cluster being restricted by compute. It is
            # implicitly assumed to be internal vsan limit. It is not an
            # issue at run time but technically it is not correct.
            self._check_max_host_limit(hosts, '6.5')

            # 4) Get the MOBs of hosts to scaleout. And iterate through
            # each host to do scaling out operation. If some hosts fails
            # then collect that in failed host list.
            scaleout_hosts = self._get_scaleout_hosts(hosts, host_props)

            for sh in scaleout_hosts:
                self.LOG.info(
                    "Scaleout host :: %s " % host_props[sh]['name'])
                try:
                    self._scaleout_single_host(si,
                                               vc_mos,
                                               cluster,
                                               hosts,
                                               host_props,
                                               [sh])
                except (exc.VsanHostException,
                        exc.VsanNetworkException,
                        exc.VsanGetCapacityException,
                        exc.VsanDiskGroupException,
                        exc.VsanHostDiskHomogenityException,
                        Exception) as ex:
                    # if we are here, it means that we failed to perform
                    # single scaleout host operation. So, we need to
                    # collect the failed hosts so that we can notify caller
                    # correctly.
                    self.LOG.error(
                        "Failed to scaleout the host : %s" % host_props[sh]['name'])
                    self.LOG.error(str(ex))
                    failed_hosts.append(host_props[sh]['name'])
                    result = False
                    failure_cause.append(str(ex))

                if batch_processing and (not result):
                    # We do not need to continue further. A single host
                    # failure means complete operation failure.
                    self.LOG.debug(
                        "Marking all hosts as failed: %s" % self.scaleout_hosts)
                    failed_hosts = self.scaleout_hosts
                    break
            if failed_hosts:
                self.LOG.info(
                    "Initiate disk cleanup for failed hosts : %s" % failed_hosts)
                self.process_disk_cleanup(hosts=failed_hosts)
        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                exc.VsanHostLimitException,
                exc.VsanDisabledException,
                Exception) as ex:
            result = False
            failed_hosts = self.scaleout_hosts
            failure_cause.append(str(ex))
            self.LOG.error("Exception while scaleout cluster")
            self.LOG.error(str(ex))
        finally:
            if 'si' in locals():
                Disconnect(si)

        # Return proper values based on result, batch_processing
        if result:
            # Scaleout : Complete Success
            return (True, None)
        else:
            failure_details = {
                'failed_hosts': failed_hosts, 'Reason': failure_cause}
            return (False, failure_details)

    def do_post_steps(self, args=None):
        pass

    def post_operation_valdiation(self, args=None):
        pass

    def publish_compliance_report(self):
        pass

    def _get_scaleout_hosts(self, hosts, host_props):
        """
        Returns the host instance .
        :param hosts: list of hosts
        :param host_props: hosts' properties dictionary
        :return: host vmware object if found
        :raises VsanHostException
        """

        scaleout_hosts = []
        scaleout_hosts_list = [host for host in self.scaleout_hosts]

        for host in hosts:
            if host_props[host]['name'] in scaleout_hosts_list:
                scaleout_hosts.append(host)
                scaleout_hosts_list.remove(host_props[host]['name'])
            if not scaleout_hosts_list:
                break

        if scaleout_hosts_list:
            msg = "Host(s) '%s' are not part of the vCenter '%s' cluster." % (
                scaleout_hosts_list, self.vc_cluster)
            self.LOG.error(msg)
            raise exc.VsanHostException(msg)
        return scaleout_hosts

    def _prepare_scaleout_vcenter_diskmap(self,
                                          mob_disk_management,
                                          hosts,
                                          host_props,
                                          scaleout_hosts=[]):
        """
        Prepares a diskmap to identify eligible disks for capacity and cache
        tier. For flash vSAN, capacity and cache disks should be of SSD type.
        For hybrid vSAN, only cache disk needs to be of SSD type.

        :param hosts: list of host objects
        :param host_props: dict of host properties
        :param mob_disk_management: cluster disk management system
        :return: diskmodel with SCSI Disk and Host MO references
        """
        # Get any first host which is already part of cluster i.e.
        # does not exist in scaleout hosts list.
        for host in hosts:
            if host_props[host]['name'] not in self.scaleout_hosts:
                break

        vsan_type = 'allFlash' if self.is_all_flash else 'hybrid'
        old_host_diskmodel = \
            self._reverse_engineer_diskmodel(mob_disk_management,
                                             host,
                                             host_props,
                                             vsan_type)
        vc_diskmap = self.query_vcenter_disks(scaleout_hosts, host_props)
        scaleout_hosts_diskmodel = \
            dv.get_system_diskmodel(vc_diskmap['eligible'],
                                    host_props,
                                    self.vsan_disk_info)

        # Prepare the host dictionary needed for planting the vCenter
        # host references in model
        # Sample dictionary is
        #     {'172.18.200.245': 'vim.HostSystem:host-194',
        #     '172.18.200.244': 'vim.HostSystem:host-192'}

        host_dict = {}
        for host, props in host_props.iteritems():
            host_dict[props['name']] = host

        old_host_dgs = old_host_diskmodel['device_groups']
        for i in range(len(scaleout_hosts_diskmodel)):
            new_diskmodel = scaleout_hosts_diskmodel[i]
            scaleout_host_dgs = new_diskmodel['device_groups']
            dv.process_host_dg_sanity(scaleout_host_dgs, vsan_type)
            result = dv.compare_dg_homogenity(old_host_dgs, scaleout_host_dgs)
            if not result:
                msg = "%s scaleout host disks model are not homogeneous" % \
                      new_diskmodel['node']
                self.LOG.error(msg)
                raise exc.VsanHostDiskHomogenityException(msg)

            # Plant the vCenter references of hosts and disks in the model
            # needed for preparation for vCenter disk map.
            new_diskmodel['host_ref'] = host_dict[new_diskmodel['node']]
            dv.build_vCenter_diskmap(vc_diskmap['eligible'], new_diskmodel)

        return scaleout_hosts_diskmodel

    def _reverse_engineer_diskmodel(self,
                                    mob_disk_management,
                                    host,
                                    host_props,
                                    vsan_type):
        """
        Prepare disk model of already existing host in the format of vmware
        storage model so that we can compare old hosts with new host being
        added as part of scaleout operation

        :param host:
        :param mob_disk_management:
        :return: disk model as per vmware storage model
        """

        # We need to cook a disk model as per pre-defined template
        # so that we can leverage with for comparisons with disk model
        # of new hosts being added as part of scale-out operation.
        diskmaps = mob_disk_management.QueryDiskMappings(host)
        old_host_diskmodel = dict()
        old_host_diskmodel['node'] = host_props[host]['name']
        old_host_diskmodel['host_ref'] = None  # need to feed, we will see
        old_host_diskmodel['device_groups'] = list()
        name_index = 0

        for dm in diskmaps:
            dg = dict()
            # Here, we might have flaw in cooking device-group name
            # if the order of diskmap seen by vCenter is not same as
            # the one we created for new hosts i.e. scale out hosts
            # being added to system. We will take care it later. For
            # NCS v1, it might not be issue as all device groups are
            # homogenous.
            dg['name'] = "device-group-" + str(name_index)
            name_index = name_index + 1
            dg['cache_device_id'] = None
            dg['vcenter_diskmap'] = dict()
            dg['total_raw_capacity'] = 0
            dg['total_cache_capacity'] = 0
            dg['devices'] = list()

            # We need to populate devices of a disk group.
            # First, we will add cache disk and later we will
            # add all capacity disk.
            d = dict()
            d['id'] = dm.mapping.ssd.uuid
            d['type'] = 'ssd'
            d['size'] = dm.mapping.ssd.capacity.block * \
                dm.mapping.ssd.capacity.blockSize
            dg['total_cache_capacity'] = d['size']
            dg['cache_device_id'] = d['id']
            dg['devices'].append(d)

            # Time to fill capacity devices
            for disk in dm.mapping.nonSsd:
                d = dict()
                d['id'] = disk.uuid
                d['type'] = 'ssd' if vsan_type == 'allFlash' else 'hdd'
                d['size'] = disk.capacity.block * disk.capacity.blockSize
                dg['total_raw_capacity'] += d['size']
                dg['devices'].append(d)
            old_host_diskmodel['device_groups'].append(dg)
        return old_host_diskmodel

    def _check_max_host_limit(self, hosts, esx_version):
        """
        Gets the maximum host limit permitted for a the particular VSphere
        version.
        :param esx_versions: Vesion of VSphere
        :return: Host limit
        """
        # For now , return 64 for version 6.0
        if str(esx_version).rsplit('.')[0] == '6':
            self.max_host_limit = 64
        else:
            msg = "Cannot determine the maximum limit of hosts for cluster " \
                  "%s." % self.vc_cluster
            self.LOG.error(msg)
            raise exc.VsanHostLimitException(self.vc_cluster)
        if len(hosts) > self.max_host_limit:
            msg = "Cannot perform scale out operation: Maximum limit of " \
                  "hosts in a cluster is %d." % self.max_host_limit
            self.LOG.error(msg)
            raise exc.VsanHostLimitException(self.vc_cluster)
