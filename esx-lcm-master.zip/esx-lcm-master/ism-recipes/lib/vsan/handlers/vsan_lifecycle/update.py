#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from pyVim.connect import Disconnect

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.utils import size as sutils
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler


class VsanUpdateHandler(VsanLifecycleHandler):

    def pre_operation_validation(self, args=None):
        """
          Performs validation logic to do update. At this point of time,
          only check is whether hosts are in maintenance mode or not.
          :param cinfo: vCenter details
          :return: tuple of the form (status, error) where
                   status can be True or False
                   error can be None or a string containing error description
          :raises: HostException, if host is not in maintenance mode
          """
        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = \
                self.vc.get_vsan_managed_objects(si._stub,
                                              context=context)

            # Get Cluster and Host Objects from vCenter
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            host_props = self.vc.collect_host_properties(si.content, cluster.host)
            hosts = host_props.keys()
            self.check_hosts_in_maintenance_mode(hosts)
        except exc.VsanHostException as ex:
            return (False, str(ex))
        else:
            self.LOG.info("Pre-update check for vSAN passed.")
            return (True, None)
        finally:
            if 'si' in locals():
                Disconnect(si)

    def do_pre_steps(self, args=None):
        """
        Collect cluster information before update. It is matched with
        data collect post update to ensure things are in same state
        as before update.
        :param cinfo: vCenter details
        :return: tuple of the form (status, capacity, health, error) where
                 status can be True or False
                 error can be None or a string containing error description
        :raises: VCenterClusterException, .........
        """
        try:
            pre_update_data = self.collect_cluster_info(args)
        except exc.VsanCollectClusterInfoException as ex:
            return (False, pre_update_data, str(ex))
        else:
            return (True, pre_update_data, None)

    def do(self, args=None):
        pass

    def post_operation_valdiation(self, args=None):
        """
         Performs all the required steps to validate post-update vSAN
         cluster.
         :param args: dict containing vCenter details (user, password, host,
                      port) and cluster name.
         :return: tuple of the form (status, error) where
                  status can be True or False
                  error can be None or a string containing error description
         :raises: HostConnectionException: if host has lost connection with
                                            vSAN
                   HostVersionException: If vSAN version mismatch in hosts
        """
        try:
            post_update_data = self.collect_cluster_info(args)
            update_report = self.compare_cluster_data(self.pre_update_data,
                                                      post_update_data)
            msg = ""
            for k in update_report.keys():
                if update_report[k]:
                    if k == "capacity":
                        msg = msg + "Warning: During update %s space is " \
                                    "used.\n" % sutils.sizeof_fmt(
                                        self.pre_update_data['cluster_capacity'] -
                                        post_update_data['cluster_capacity'])
                        self.LOG.debug(msg)
                        continue
                    elif k == "health":
                        msg = msg + "Warning: During update cluster " \
                                    "health " \
                                    "declined from %s to %s.\n" % (
                                        self.pre_update_data['cluster_health'],
                                        post_update_data['cluster_health'])
                        self.LOG.debug(msg)
                        continue
            if not msg:
                msg = "vSAN cluster update operation completed " \
                      "successfully."
                self.LOG.debug(msg)
        except (exc.VsanHostConnectionException, exc.VsanHostVersionException,
                exc.VsanClusterCapacityException) as ex:
            return (False, str(ex))
        else:
            return (True, msg)

    def do_post_steps(self, args=None):
        pass
