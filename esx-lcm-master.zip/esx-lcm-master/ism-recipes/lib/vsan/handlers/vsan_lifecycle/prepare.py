#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from pyVmomi import vim, vmodl
from abc import abstractmethod

from lib.vsan.common.exc import exceptions as exc
from lib.vsan.handlers import disk_validator as dv
from lib.vsan.handlers.vsan_lifecycle.constants import CORRECTION_FACTOR
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
from lib.vsan.utils import size as u_size


class VsanOperationInitializerHandler(VsanLifecycleHandler):

    def pre_operation_validation(self, args=None):
        pass

    def do_pre_steps(self, args=None):
        pass

    def do(self, args=None):
        """
        Mark the all local disks (if force_mark_local_disk_as_flash flag is
        True) and all SSD disks as flash in vCenter.
        :param args: map containing vCenter details
        :return: tuple of the form (status, details) where:
                 status is True on success, False on failure
                 details a string of error details or an empty string on
                 success.
        """
        local_as_flash = args.get('force_mark_local_disk_as_flash')
        disk_info = dv.get_disk_info(self.vsan_disk_info)

        try:
            dv.validate_drive_type(disk_info, local_as_flash)
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            host_props = self.vc.collect_host_properties(si.content,
                                                         cluster.host)
            hosts = host_props.keys()
            # in scale out case, filter out the scaled out hosts.
            if self.scaleout_hosts:
                hosts = [host for host in hosts if host.name in
                         self.scaleout_hosts]
            # fetch the disk information from vCenter.
            all_disks = self.query_vcenter_disks(hosts, host_props)

            # ensure the disks are clean before proceeding.
            cleaner = self.get_host_cleaner()
            self.ensure_clean_disks(all_disks['ineligible'], self.wipe_disks,
                                    cleaner)

            # fetch the eligible disks from vCenter.
            all_disks = self.query_vcenter_disks(hosts, host_props)

            cache_margin = disk_info['cache_size'] * CORRECTION_FACTOR
            if self.is_all_flash:
                self.LOG.debug("Marking all disks as flash.")

            tasks = []
            for host in hosts:
                storage_system = host_props[host][
                    'configManager.storageSystem']
                cache_disk_cnt = 0
                for disk in all_disks['eligible'][host]:
                    # all flash deployment
                    if self.is_all_flash:
                        tasks.append(
                            storage_system.MarkAsSsd_Task(disk.uuid))
                    # hybrid deployment
                    else:
                        dsize = disk.capacity.block * disk.capacity.blockSize
                        dsize_gb = u_size.size_conv(dsize, '', 'GB', pow=10)
                        # if disk size falls in cache disk size range,
                        # mark it as flash.
                        if ((disk_info['cache_size'] - cache_margin) <=
                                dsize_gb <=
                                (disk_info['cache_size'] + cache_margin)):
                            if cache_disk_cnt == disk_info['cache_count']:
                                self.LOG.debug(
                                    "Disk %s (size=%s GB) satisfies cache "
                                    "disk size criteria but specified number "
                                    "of cache disks (%d) reached, skipping." %
                                    (disk.displayName, dsize_gb,
                                     disk_info['cache_count']))
                            else:
                                self.LOG.debug(
                                    "Disk %s (size=%s GB) satisfies cache "
                                    "size" % (disk.displayName, dsize_gb))
                                tasks.append(
                                    storage_system.MarkAsSsd_Task(disk.uuid))
                                cache_disk_cnt += 1
                        else:
                            self.LOG.debug(
                                "Skipping disk %s (size=%s GB) as it does "
                                "not fit any criteria" % (disk.displayName,
                                                          dsize_gb))
            if len(tasks) > 0:
                self.vc.wait_for_tasks(tasks, si)
        except (exc.VCenterConnectionException,
                exc.VsanClusterNotFoundException,
                exc.VsanHostException,
                exc.VsanHostUncleanDiskException,
                exc.VsanInvalidDiskTypeException,
                vim.fault.HostConfigFault,
                vim.fault.NotFound,
                vmodl.RuntimeFault) as ex:
            return (False, str(ex))
        except vmodl.MethodFault as ex:
            err_msg = self.get_object_model_fault_message(ex)
            msg = "Failed to mark compute disk(s) as SSDs. Error: %s" % err_msg
            return (False, msg)
        else:
            return (True, '')

    def do_post_steps(self, args=None):
        pass

    def post_operation_valdiation(self, args=None):
        pass