#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

import re

from pyVim.connect import Disconnect
from pyVmomi import vim, vmodl
from abc import abstractmethod

from lib.vsan.handlers.lifecycle import LifecycleHandler
from lib.vsan.common.exc import exceptions as exc
from lib.vsan.utils.vcenter import vCenterUtils
from lib.vsan.utils import size as sutils
from lib.vsan.utils.cleaner import host as host_cleaner


class VsanLifecycleHandler(LifecycleHandler):

    def __init__(self, args):
        super(VsanLifecycleHandler, self).__init__()
        for attr in args:
            setattr(self, attr, args.get(attr))
        self.vc = vCenterUtils()

    @abstractmethod
    def pre_operation_validation(self, args=None):
        pass

    @abstractmethod
    def do_pre_steps(self, args=None):
        pass

    @abstractmethod
    def do(self, args=None):
        pass

    @abstractmethod
    def do_post_steps(self, args=None):
        pass

    @abstractmethod
    def post_operation_valdiation(self, args=None):
        pass

    def get_disconnected_hosts(self, cluster, mob_cluster_health):
        health_summary = mob_cluster_health.QueryClusterHealthSummary(
            cluster=cluster)
        return health_summary.networkHealth.hostsCommFailure

    def get_vsan_version_status(self, cluster, mob_cluster_health):
        version_summary = \
            mob_cluster_health.QueryVerifyClusterHealthSystemVersions(
                cluster=cluster)
        return version_summary.issueFound

    def collect_cluster_info(self, cinfo):
        """
        Collects sets of information for a given cluster. At this point
        of time, the following sets of information is getting collected:
            1) capacity
            2) health
            3) version compatability of hosts
            4) vsan connectivitiy of hosts
        :param cinfo: vcenter details
        :return:
        """
        data = dict()
        data['cluster_capacity'] = None
        data['cluster_health'] = None
        data['vsan_version_compliant_flag'] = True
        data['vsan_host_connecitivity_status'] = True

        try:
            si, context = self.vc.connect(self.vc_host,
                                          self.vc_user,
                                          self.vc_password,
                                          self.vc_port)
            vc_mos = \
                self.vc.get_vsan_managed_objects(si._stub, context=context)
            cluster = self.vc.get_cluster_instance(si, self.vc_cluster)
            mob_cluster_health = vc_mos['vsan-cluster-health-system']
            mob_cluster_space = vc_mos['vsan-cluster-space-report-system']
            # capacity
            data['cluster_capacity'] = self.get_cluster_capacity(cluster,
                                                                 mob_cluster_space)
            # health
            data['cluster_health'] = self.get_cluster_health(cluster,
                                                             mob_cluster_health)
            # connectivity
            failed_hosts = self.get_disconnected_hosts(cluster,
                                                       mob_cluster_health)
            if failed_hosts:
                self.LOG.debug("Hosts %s cannot access VSAN: " %
                               failed_hosts)
                data['vsan_host_connecitivity_status'] = False
            # version
            version_status = self.get_vsan_version_status(cluster,
                                                          mob_cluster_health)
            if version_status:
                self.LOG.debug("vSAN versions are inconsistent.")
                data['vsan_version_compliant_flag'] = False
            return data
        except vmodl.fault.SystemError as ex:
            msg = "Error while collecting %s cluster info cluster." \
                  % self.vc_cluster
            self.LOG.error(msg)
            raise exc.VsanClusterCollectInfoException(msg)

        finally:
            if 'si' in locals():
                Disconnect(si)

    def get_cluster_health(self, cluster, mob_cluster_health):
        """
        Fetches the cluster health for the given cluster.
        :param cluster: cluster MO.
        :param mob_cluster_health: VsanHealthReportSystem MO.
        :return: cluster health
        """
        health_summary = mob_cluster_health.QueryClusterHealthSummary(
            cluster=cluster)
        return health_summary.overallHealth

    def compare_cluster_data(self, old_data, new_data):
        compare_report = dict()
        compare_report['health'] = False
        compare_report['capacity'] = False
        old_health = old_data['cluster_health']
        new_health = new_data['cluster_health']
        if old_health != new_health:
            if (old_health == "green" and
                new_health == "yellow") or \
                    (old_health == "green" and
                     new_health == "red"):
                compare_report['health'] = True
            elif (old_health == "yellow" and
                  new_health == "red"):
                compare_report['health'] = True

        old_capacity = old_data['cluster_capacity']
        new_capacity = new_data['cluster_capacity']
        if new_capacity < old_capacity:
            compare_report['capacity'] = True
        return compare_report

    def get_cluster_capacity(self, cluster, mob_cluster_space):
        """
        Fetches the cluster capacity for the given cluster.
        :param cluster: cluster MO.
        :param mob_cluster_space: VsanSpaceReportSystem MO.
        :return: cluster capacity in bytes
        """
        cluster_capacity = mob_cluster_space.QuerySpaceUsage(cluster)
        return cluster_capacity.totalCapacityB

    def validate_cluster_ha_settings(self, cluster):
        """
        Performs validations for a Cluster HA setting's
        :param Cluster:  cluster object
        :return: None on success
        :raises: VsanCheckClusterHaException
        """
        if cluster.configurationEx.dasConfig.enabled:
            msg = "Cluster '%s' HA settings need to be disabled." % \
                  cluster.name
            self.LOG.error(msg)
            raise exc.VsanCheckClusterHaException(msg=msg)

    def is_vsan_enabled(self, cluster, cluster_system):
        """
        Queries the cluster to information.
        :param cluster: cluster MO.
        :param cluster_system: vsanClusterSystem MO
        :return: boolean : True if vSANs enabled
                           False if vSAN disabled
        """
        VsanConfigInfo = cluster_system.VsanClusterGetConfig(cluster)
        return VsanConfigInfo.enabled

    def validate_network_settings(self, host):
        return True

    def disable_vsan_traffic(self, si, hosts, host_props):
        """
        Disable the vSAN service and vSAN traffic on the host.
        :param si: service instance object
        :param hosts: list of host MO
        :param host_props: properties of hosts
        :return: None on success
        :raises VsanDeleteException on error.
        """
        for host in hosts:
            self.LOG.info(
                "Disabling vSAN service and vSAN traffic on host %s." %
                host.name)
            host_config = vim.vsan.host.ConfigInfo(
                enabled=False,
                networkInfo=vim.vsan.host.ConfigInfo.NetworkInfo(
                    port=[]))
            dis_vsan_task = host_props[host]['configManager.vsanSystem'] \
                .UpdateVsan_Task(host_config)
            try:
                self.vc.wait_for_tasks([dis_vsan_task, ], si)
                self.LOG.info("Successfully disabled vSAN service and vSAN "
                              "traffic on host %s." % host.name)
            except vmodl.MethodFault as ex:
                msg = "Failed to disable vSAN service on host %s ." % host.name
                err_msg = self.get_object_model_fault_message(ex)
                self.LOG.error("%s Error: %s" % (msg, err_msg))
                raise exc.VsanDeleteException(operation='in', msg=err_msg)

    def remove_disk_mappings(self, si, disk_management_sys, hosts, host_props):
        """
        Remove all the disk mappings for the specified host.
        :param si: service instance object
        :param disk_management_sys: VsanVcDiskManagementSystem instance
        :param hosts: List of hosts
        :param host_props: properties of hosts
        :return: None on success
        :raises: VsanHostDiskRemoveException on error.
        """
        rdm_tasks = []
        complete_success = True
        self.data_migration_action = "evacuateAllData"
        for host in hosts:
            self.LOG.info("Removing the disk mappings for host %s." %
                          host.name)
            dm = disk_management_sys.QueryDiskMappings(host)
            dgm = [disk_group.mapping for disk_group in dm]
            rdm_spec = vim.host.MaintenanceSpec(
                vsanMode=vim.vsan.host.DecommissionMode(
                    objectAction=self.data_migration_action))
            if dgm:
                rdm_task = host_props[host]['configManager.vsanSystem'] \
                    .RemoveDiskMapping_Task(dgm, rdm_spec, 0)
                try:
                    self.vc.wait_for_tasks([rdm_task, ], si)
                except vmodl.MethodFault as ex:
                    msg = "Failed to remove disk mappings for host %s ." % \
                          host.name
                    err_msg = self.get_object_model_fault_message(ex)
                    self.LOG.error("%s Error: %s" % (msg, err_msg))
                    complete_success = False
                    if not self.force_delete:
                        raise exc.VsanHostDiskRemoveException(err_msg)
        if complete_success:
            self.LOG.info("Successfully removed the disk mappings for "
                          "all the hosts.")
        else:
            self.LOG.info("Successfully removed the disk mappings for "
                          "some of the hosts.")


    def check_hosts_in_maintenance_mode(self, hosts):
        """
        Queries the host to ensure that the specified host is in
        maintenance mode.
        :param hosts: list of vim.HostSystem MOs
        :return: None on success
        :raises: VsanHostException on error.
        """
        for host in hosts:
            if host.runtime.inMaintenanceMode:
                continue
            msg = "Host (%s) of vSAN cluster is not in maintenance mode." % \
                  host.name
            self.LOG.error(msg)
            raise exc.VsanHostException(msg)

    def validate_host_settings(self, hosts, host_props, vc_diskmodel):
        """
        Performs all the required validations for a host that is intended to
        be a part of the vSAN cluster
        :param esx_host_list:  list of host MO
        :param host_props: dict of host properties
        :param diskmap: dict of the form {host: {'cache':[],'capacity':[]}
        :return: None on success
        :raises: VsanHostException
        """
        # TODO: implement these host checks
        failed_hosts = []
        for host in hosts:
            network_status = self.validate_network_settings(host)

            for vc_host in vc_diskmodel:
                if host == vc_host['host_ref']:
                    dg_count = len(vc_host['device_groups'])
                    # Consider the cache size as the maximum size of the cache
                    #  disk of all the device group
                    # we are making a safe assumption that in case we support
                    #  non uniform cache disk across the device groups
                    cache_disk_size = sutils.sizeof_fmt(
                        max([(dg['vcenter_diskmap']['cache'][0].capacity.block
                              * dg['vcenter_diskmap']['cache'][
                                  0].capacity.blockSize)
                             for dg in vc_host['device_groups']])
                    )
                    memory_status = self._validate_memory_settings(
                        host, cache_disk_size, len(hosts), dg_count)
            if network_status and memory_status:
                # all is well, validate next host
                continue
            else:
                failed_hosts.append(host_props[host]['name'])
        if len(failed_hosts) > 0:
            failed_hosts_str = ', '.join(failed_hosts)
            msg = "Hosts %s do not meet vSAN requirement." % failed_hosts_str
            self.LOG.error(msg)
            raise exc.VsanHostException(msg=msg)

    def get_object_model_fault_message(self, ex):
        """
        Extracts the best possible error message from the MethodFault
        exception instance.
        :param ex: MethodFault exception instance
        :return: string containing the fault message or an empty string
        """
        if hasattr(ex, 'reason'):
            err_msg = ex.reason
        elif hasattr(ex, 'faultMessage') and len(ex.faultMessage) > 0:
            err_msg = ex.faultMessage[0].message
        elif hasattr(ex, 'message') and ex.message and len(ex.message) > 0:
            err_msg = ex.message
        elif hasattr(ex, 'msg') and ex.msg and len(ex.msg) > 0:
            err_msg = ex.msg
        else:
            err_msg = 'Unknown'
        return err_msg

    def enable_network_adapter_for_vsan_service(self, hosts, host_props, si):
        """
        Enable vSAN traffic for the pre-specified VMKernel adapter.
        :param hosts: list of host MO
        :param host_props: dict of host properties
        :param si: service instance MO
        :return: None on success
        :raises: VsanNetworkException if network criteria is not meet
        """
        tasks = []
        for host in hosts:
            vsan_nics = self._fetch_vsan_nic(host)
            nic_count = len(vsan_nics)
            if nic_count == 0:
                msg = "VMkernel adapter interface does not meet vSAN " \
                      "requirement, discovered nics count = %s" % nic_count
                self.LOG.error(msg)
                raise exc.VsanNetworkException(msg=msg)

            ports = [vim.VsanHostConfigInfoNetworkInfoPortConfig(device=nic)
                     for nic in vsan_nics]
            configInfo = \
                vim.VsanHostConfigInfo(
                    networkInfo=vim.VsanHostConfigInfoNetworkInfo(port=ports))
            self.LOG.info('Enabling vSAN traffic in host {} with {}'.format(
                host_props[host]['name'], vsan_nics))
            vsan_system = host_props[host]['configManager.vsanSystem']
            task = vsan_system.UpdateVsan_Task(configInfo)
            tasks.append(task)

        try:
            self.vc.wait_for_tasks(tasks, si)
        except vmodl.MethodFault as ex:
            msg = "Failed to enable kernel adapter for one of nic " \
                  "in '%s'" % vsan_nics
            self.LOG.error("%s Error information: %s"
                           % (msg, self.get_object_model_fault_message(ex)))
            raise exc.VsanNetworkException(msg=msg)

    def query_vcenter_disks(self, hosts, hostprops):
        """
        Query the vCenter and build a diskmap dict for all host in cluster
        {'eligible': {host1: [], host2: []},
         'ineligible': {host1: [], host2: []}}
        """
        diskmap = {'eligible': {}, 'ineligible': {}}
        for host in hosts:
            eligible_disks = []
            ineligible_disks = []
            vsan_system = hostprops[host]['configManager.vsanSystem']
            for result in vsan_system.QueryDisksForVsan():
                if result.state == 'eligible':
                    eligible_disks.append(result.disk)
                elif result.state == 'ineligible':
                    self.LOG.info(
                        'Found ineligible disks {} in host {}'.format(
                            result.disk.displayName,
                            hostprops[host]['name']))
                    ineligible_disks.append(result.disk)

            diskmap['eligible'][host] = eligible_disks
            diskmap['ineligible'][host] = ineligible_disks
        return diskmap

    def activate_disks(self, hosts, host_props, si, mob_disk_management,
                       vc_diskmodel):
        """
        Creates disk map and initializes the vSAN disks, creating disk groups.
        :param host_props: dict of host properties
        :param si: service instance
        :param disk_management_system: vsanVcDiskManagementSystem MO.
        :param diskmap: dict of the form {host: {'cache':[],'capacity':[]}
        :return: None on success
        :raises: VsanDiskGroupException
        """
        self._claim_disks(vc_diskmodel, mob_disk_management, si)
        self._ensure_disk_groups(hosts, mob_disk_management, host_props)

    def _fetch_vsan_nic(self, host):
        """
        Figure out the DVS created on the host for storage network and find out
        the corresponding vnics.
        :param host: vim.HostSystem MO.
        :return: list of nics on which vSAN traffic should be enabled.
        """
        dvs_uuid = None
        nics = []
        # identify the UUID of the DVSwitch for storage network
        for nw in host.network:
            if nw.name == self.storage_network_name:
                dvs_uuid = nw.config.distributedVirtualSwitch.uuid
                break

        if dvs_uuid:
            # identify the vnic name
            for nic in host.config.network.vnic:
                if nic.spec.distributedVirtualPort and \
                                nic.spec.distributedVirtualPort.switchUuid == dvs_uuid:
                    nics.append(nic.device)
        return nics

    def _claim_disks(self, vc_diskmodel, mob_disk_management, si):
        """
        Create the disk groups on all the hosts based on the information
        provided in diskmap object.
        :param vc_diskmodel: List of host dictionaries with device groups
                             and devices.
        :param mob_disk_management:  vsanVcDiskManagementSystem MO.
        :param si: service instance
        :return: None
        """
        tasks = []
        self.LOG.info("Initializing disk mappings.")
        for host in vc_diskmodel:
            for device_group in host['device_groups']:
                dm = vim.VimVsanHostDiskMappingCreationSpec(
                    cacheDisks=device_group['vcenter_diskmap']['cache'],
                    capacityDisks=device_group['vcenter_diskmap']['capacity'],
                    creationType='allFlash' if self.is_all_flash else 'hybrid',
                    host=host['host_ref']
                )
                task = mob_disk_management.InitializeDiskMappings(dm)
                tasks.append(task)

            if len(tasks) > 0:
                self.LOG.debug('Waiting for create disk group tasks to finish '
                               'for host %s' % host['node'])
                try:
                    self.vc.wait_for_tasks(tasks, si)
                except vmodl.MethodFault as ex:
                    msg = "Error creating disk group."
                    err_msg = self.get_object_model_fault_message(ex)
                    self.LOG.error("%s Error: %s" % (msg, err_msg))
                    raise exc.VsanDiskGroupException(msg)
        self.LOG.info("Initialized disk mappings successfully.")

    def _ensure_disk_groups(self, hosts, mob_disk_management, host_props):
        """
        Query and return the disk groups (Cache and capacity disk info) for
        each host.
        :param hosts: list of host objects
        :param mob_disk_management: vsanVcDiskManagementSystem MO.
        :param host_props: dict of host properties
        :return: None on success
        :raises: VsanDiskGroupException
        """
        disk_group_exists = False
        self.LOG.debug('Verifying disk group availability')
        for host in hosts:
            diskMaps = mob_disk_management.QueryDiskMappings(host)

            for index, diskMap in enumerate(diskMaps, 1):
                disk_group_exists = True
                msg = 'Host:{}, DiskGroup:{}, Cache Disks:{}, Capacity ' \
                      'Disks:{}' \
                    .format(host_props[host]['name'], index,
                            diskMap.mapping.ssd.displayName,
                            [disk.displayName for disk in
                             diskMap.mapping.nonSsd])
                self.LOG.info(msg)

        if not disk_group_exists:
            msg = "Failed to create Disk group(s)!"
            self.LOG.error(msg)
            raise exc.VsanDiskGroupException(msg)

    def _memory_constants_6_5(self):
        global VSAN_BASE_CONS_GB, VSAN_BASE_CONS_ADD_GB, VSAN_CACHE_FLASH_MB
        global VSAN_CACHE_HYBRID_MB, VSAN_DB_BASE_CONS_MB, VSAN_NODE_LIMIT
        # Memory consumed by vSAN per ESXi host, upto 16 hosts
        VSAN_BASE_CONS_GB = 3.0
        # Memory consumed by vSAN per ESXi host, > 16 hosts
        VSAN_BASE_CONS_ADD_GB = 3.3
        # SSD Memory OverheadPerGB 7 MB if all flash system
        VSAN_CACHE_FLASH_MB = 7
        # SSD Memory OverheadPerGB 2 MB if hybrid system
        VSAN_CACHE_HYBRID_MB = 2
        # Memory consumed each individual disk group.
        VSAN_DB_BASE_CONS_MB = 500.0
        VSAN_NODE_LIMIT = 16

    def _validate_memory_settings(self, host, cache_disk_size, node_count,
                                  dg_count):
        """
        Warn if host memory is lest then vSAN cluster consumption
        :param host: Host MO
        :param cache_disk_size: Cache disk size
        :param node_count: Number of hosts in cluster.
        :param dg_nums: Number of DiskGroup's
        :return: True
        """
        self._memory_constants_6_5()
        host_memory = sutils.size_conv(host.hardware.memorySize, '', 'GiB')
        base_consumption_gb = (VSAN_BASE_CONS_GB,
                               VSAN_BASE_CONS_ADD_GB)[
            node_count > VSAN_NODE_LIMIT]
        ssd_mem_overhead_per_gb = (VSAN_CACHE_FLASH_MB,
                                   VSAN_CACHE_HYBRID_MB)[
            self.is_all_flash]
        dg_base_consumption_mb = VSAN_DB_BASE_CONS_MB
        reg_cache_device_size = re.match(r"([0-9.]+)([a-zA-Z]+)",
                                         cache_disk_size)
        cache_device_size = sutils.size_conv(float(reg_cache_device_size.group(1)),
                                                 reg_cache_device_size.group(2), 'GiB')
        # TODO Need to handle scenario with host memory < 32GiB
        min_req_memory = base_consumption_gb + \
                         (dg_count * sutils.size_conv((dg_base_consumption_mb +
                                                           (ssd_mem_overhead_per_gb *
                                                            cache_device_size)), 'MiB',
                                                          'GiB'))
        if (host_memory < min_req_memory):
            self.LOG.warning("Host '%s' has memory less then minimum"
                             " requirment %s GiB " %
                             (host.name, min_req_memory))
        return True

    def get_host_cleaner(self):
        args = {'ipaddress': self.vc_host, 'username': self.vc_user,
                'password': self.vc_password, 'vc_port': self.vc_port}
        hc = host_cleaner.HostVCenterCleaner(args)
        return hc

    def ensure_clean_disks(self, diskmap, wipe_disks, host_cleaner):
        """
        Performs following:
        1. find if any host(s) has more than 1 ineligible disk (assuming 1
        bootable disk will be shown ineligible).
        2. if no host needs clean up return.
        3. if there are host(s) requiring clean up and wipe_disks is False,
        raise exception. If wipe_disks is True, invoke the disk cleaner utility.
        :param diskmap: map of the form
                                {hostip1: [d1, d2], hostip2: [d3, d4],
                                hostip3: []}
        :param wipe_disks: bool indicating whether disk can be cleaned up.
        :param host_cleaner: instance of a subclass of HostCleaner class.
        :return: None on success, raises VsanHostUncleanDiskException on error.
        """
        cleanup_hosts = []
        for host, disks in diskmap.iteritems():
            if len(disks) > 1:
                cleanup_hosts.append(host.name)

        if len(cleanup_hosts) > 0:
            if wipe_disks:
                try:
                    self.LOG.info("Node(s) %s in the cluster need a clean "
                                  "up, attempting a disk clean up." %
                                  cleanup_hosts)
                    host_cleaner.clean(self.vc_cluster, cleanup_hosts)
                    self.LOG.info("Disk clean up completed.")
                except Exception as ex:
                    err_msg = "Error wiping disk(s): %s" % str(ex)
                    self.LOG.error(err_msg)
                    raise ex
            else:
                hosts_str = ', '.join(cleanup_hosts)
                err_msg = 'Found some disks with existing data on hosts (%s).' \
                          ' The disks need a clean up to be eligible for ' \
                          'consumption.' % hosts_str
                self.LOG.error(err_msg)
                raise exc.VsanHostUncleanDiskException(msg=err_msg)

    def process_disk_cleanup(self, hosts=[]):
        """
        Fetches the host cleaner and requests disk clean up on the
        appropriate hosts in the cluster.
        :return: None on success, raises exception on error.
        """
        cleaner = self.get_host_cleaner()
        try:
            self.LOG.info("Attempting a disk clean up.")
            cleaner.clean(self.vc_cluster, host_list=hosts)
            self.LOG.info("Disk clean up completed.")
        except exc.VsanHostDiskCleanUpException as ex:
            err_msg = "Error wiping disk(s): %s" % str(ex)
            self.LOG.error(err_msg)
            raise ex
