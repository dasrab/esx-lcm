# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

# disk size correction factor
CORRECTION_FACTOR = 0.1  # i.e. 10% of disk size
