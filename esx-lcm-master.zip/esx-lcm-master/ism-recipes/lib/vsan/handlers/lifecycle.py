#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

from orch import log

class LifecycleHandler(object):

    def __init__(self):
        self.LOG = log.getLogger(__name__)
