#!/usr/bin/env python
#
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
#


from lib.vsan.devops.utils import conf
from lib.vsan.devops.common.log import Logger
from lib.vsan.handlers.platform_lifecycle.lcm.lcm_handlers import LcmApiHandler


class LcmDeleteHandler(LcmApiHandler):

    def __init__(self):
        super(LcmDeleteHandler, self).__init__()

    def do(self):
        self.LOG.info("Executing Platform Delete using ESX LCM API ")
        cluster_response = self._delete_cluster()
        if cluster_response['has_error']:
            return cluster_response
        zone_response = self._delete_zone()
        return zone_response

    def _delete_cluster(self):
        """
        This method is expected to delete the cluster forcefully
        """
        zone_info = "/" + self.zone_name + "/DeleteClusters?force=true"
        data = {
            "name": self.zone_name,
            "oneViewSettings": self._get_oneview_settings(),
            "vcenterSettings": self._get_vcenter_settings()
        }
        cluster_response = self.delete_zone(zone_info, data)
        if cluster_response['has_error']:
            self.LOG.error("Delete Cluster operation failed with error : %s"
                           % cluster_response['error_message'])
        else:
            self.LOG.info(
                "Successfully deleted the cluster : %s" % self.zone_name)
        return cluster_response

    def _delete_zone(self):
        """
        This method is expected to delete the zone which will inturn
        delete the SPT Blueprints
        """
        zone_info = "/" + self.zone_name + "/DeleteZone"
        data = {
            "id": self.zone_name,
            "name": self.zone_name,
            "managed": True,
            "applianceUri": self.appliance_uri
        }
        zone_response = self.delete_zone(zone_info, data)
        if zone_response['has_error']:
            self.LOG.error("Delete Zone operation failed with error : %s"
                           % zone_response['error_message'])
        else:
            self.LOG.info("Successfully deleted the Zone : %s" %
                          self.zone_name)
        return zone_response
