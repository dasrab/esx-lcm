#!/usr/bin/env python
#
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
#


from lib.vsan.devops.utils import conf
from lib.vsan.devops.common.log import Logger
from lib.vsan.handlers.platform_lifecycle.lcm.lcm_handlers import LcmApiHandler


class LcmDeployHandler(LcmApiHandler):

    def __init__(self):
        super(LcmDeployHandler, self).__init__()
        self.cluster_resource_capacity = \
            conf.get_conf(section="esx-lcm", option="cluster_resource_capacity")

    def do(self):
        """
        Deploy platform using ESX LCM API
        """
        self.LOG.info("Executing Platform Deployment using ESX LCM API ")
        zone_response = self._create_zone()
        if zone_response['has_error']:
            return zone_response
        add_response = self._add_capacity()
        return zone_response

    def _create_zone(self):
        data = {"id": self.zone_name,
                "applianceUri": self.appliance_uri,
                "name": self.zone_name,
                "managed": True,
                "resourceProfile": self.platform_profile_name,
              "networkSettings": self._get_network_settings(),
              "oneViewSettings": self._get_oneview_settings(),
              "vcenterSettings": self._get_vcenter_settings()
              }
        self.LOG.info("Creating Zone : %s" %self.zone_name)
        zone_response = self.create_zone(data)
        if zone_response['has_error']:
            self.LOG.error("Create Zone operation failed with error : %s"
                           %zone_response['error_message'])
        else:
            self.LOG.info("Successfully created Zone : %s"%self.zone_name)
        return zone_response

    def _add_capacity(self):
        data = {"id": self.zone_name,
                "name": self.zone_name,
                "managed": True,
                "platformProfileName": self.platform_profile_name,
                "networkSettings": self._get_network_settings(),
                "resourceCapacity": int(self.cluster_resource_capacity),
                "oneViewSettings": self._get_oneview_settings(),
                "vcenterSettings": self._get_vcenter_settings(),
                "regionURI": self.region_uri,
                "providerURI": self.provider_uri,
                "osRegionName": self.zone_name
                }
        self.LOG.info("Adding Capacity to Zone : %s" %self.zone_name)
        capacity_response = self.add_capacity(data)
        if capacity_response['has_error']:
            self.LOG.error(
                "Error occured while adding the capacity on zone : %s"
                % self.zone_name)
            self.LOG.error("Exception : %s " % capacity_response['error_message'])
        else:
            self.LOG.info(
                "Successfully added the capacity to zone %s"%self.zone_name)
        return capacity_response
