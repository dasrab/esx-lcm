#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


from lib.vsan.devops.utils import conf
from lib.vsan.devops.common.log import Logger
from lib.vsan.handlers.platform_lifecycle.lcm.lcm_handlers import LcmApiHandler


class LcmScaleoutHandler(LcmApiHandler):

    def __init__(self):
        super(LcmScaleoutHandler, self).__init__()
        self.scaleout_resource_capacity = \
            conf.get_conf(section="esx-lcm", option="scaleout_resource_capacity")

    def do(self):
        """
        Flexup the existing zone with configured number of servers
        """
        self.LOG.info("Executing Platform FlexUP using ESX LCM API ")
        # Add Capacity Input json
        data = {"id": self.zone_name,
                "name": self.zone_name,
                "managed": True,
                "platformProfileName": self.platform_profile_name,
                "networkSettings": self._get_network_settings(),
                "resourceCapacity": int(self.scaleout_resource_capacity),
                "oneViewSettings": self._get_oneview_settings(),
                "vcenterSettings": self._get_vcenter_settings(),
                "regionURI": self.region_uri,
                "providerURI": self.provider_uri,
                "osRegionName": self.zone_name
                }
        data = self.add_capacity(data)
        if not data['has_error']:
            self.LOG.info(
                "Successfully flexed up the capacity to existing zone")
        else:
            self.LOG.error(
                "Error occured while flexing up the zone : %s"
                % self.zone_name)
            self.LOG.error("Exception : %s " % data['error_message'])