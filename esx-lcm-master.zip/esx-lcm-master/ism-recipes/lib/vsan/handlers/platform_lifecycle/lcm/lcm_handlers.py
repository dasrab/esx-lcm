#!/usr/bin/env python
#
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
#

import time
from lib.vsan.devops.utils import conf
from lib.vsan.devops.common.log import Logger
from lib.vsan.handlers.platform_lifecycle.api_handlers import ApiHandler


class LcmApiHandler(ApiHandler):

    def __init__(self):
        super(LcmApiHandler, self).__init__()
        self.api_endpoint =  \
            conf.get_conf(section="esx-lcm", option="api_endpoint")
        self.zone_uri = conf.get_conf(section="esx-lcm", option="zone_uri")
        self.appliance_uri = conf.get_conf(
            section="esx-lcm", option="applianceUri")
        self.region_uri = \
            conf.get_conf(section="esx-lcm", option="region_uri")
        self.provider_uri = \
            conf.get_conf(section="esx-lcm", option="provider_uri")
        self.zone_name = \
            conf.get_conf(section="esx-lcm", option="zone_name")
        self.platform_profile_name = \
            conf.get_conf(section="cluster", option="platformProfileName")
        self.LOG = Logger.getLogger(__name__)

    def _get_network_settings(self):
        return {
            "ncsManagementNetwork":
            conf.get_conf(section="cluster", option="ncsManagementNetwork"),
            "storageNetwork":
            conf.get_conf(section="cluster", option="storageNetwork"),
            "vMotionNetwork":
            conf.get_conf(section="cluster", option="vMotionNetwork"),
            "productionNetworks":
            [conf.get_conf(section="cluster", option="productionNetworks")],
            "esxManagementNetwork":
            conf.get_conf(section="cluster", option="esxManagementNetwork")
        }

    def _get_oneview_settings(self):
        return {
            "ipAddress":
            conf.get_conf(section="oneview", option="hostname"),
            "username":
            conf.get_conf(section="oneview", option="username"),
                "password":
            conf.get_conf(section="oneview", option="password")
        }

    def _get_vcenter_settings(self):
        return {
            "ipAddress":
            conf.get_conf(section="vcenter", option="hostname"),
            "username":
            conf.get_conf(section="vcenter", option="username"),
                "password":
            conf.get_conf(section="vcenter", option="password")
        }

    def create_zone(self, data):
        self.LOG.info("Invoking ESX LCM API : Create Zone")
        url = self.api_endpoint + "/rest/zones"
        response = self.do_request("POST", url, payload=data)
        if not response.get("has_error"):
            task_url = response.get('uri')
            response = self.check_task_status(task_url, wait_time=1)
        self.LOG.info("Create Zone Response")
        self.LOG.info(response)
        return response

    def add_capacity(self, data):
        self.LOG.info("Invoking ESX LCM API : Add Capacity")
        url = self.api_endpoint + "/rest/zones/" + \
            self.zone_uri + "/AddCapacity"
        response = self.do_request("PUT", url, payload=data)
        if not response.get("has_error"):
            task_url = response.get('uri')
            response = self.check_task_status(task_url)
        self.LOG.info("Add Capacity Response")
        self.LOG.info(response)
        return response

    def get_zones(self):
        url = self.api_endpoint + "/rest/zones"
        response = self.do_request("GET", url)
        return response

    def delete_zone(self, zone_info, data):
        url = self.api_endpoint + "/rest/zones" + zone_info
        response = self.do_request("PUT", url, payload=data)
        if not response.get("has_error"):
            task_url = response.get('uri')
            response = self.check_task_status(task_url)
        return response

    def check_task_status(self, task_url, wait_time=5):
        """
        This method will constantly make calls to ESX LCM API to
        get the status of task url untill it gets stable state like
        completed, failed.

        If the status is running, again fetch the task status  after 5 minutes
        """
        minutes = wait_time
        delay_interval = 60 * minutes
        job_running = True
        task_url = self.api_endpoint + task_url
        response_data = self.do_request("GET", task_url)
        while job_running:
            self.LOG.info("State of infrastucture tasks  is :  %s"
                          % response_data.get("state"))
            self.LOG.info("Infrastucture tasks  is  %s percent completed"
                          % response_data.get("percentComplete"))
            if (response_data.get("state") in ['Running', 'Created'] and
                    response_data.get("percentComplete") < 100):
                self.LOG.info("Waiting for %s minutes to poll the tasks further "
                              % minutes)
                time.sleep(delay_interval)
                response_data = self.do_request("GET", task_url)
            elif (response_data.get("state") in ['Completed'] and
                  response_data.get("percentComplete") == 100):
                job_running = False
                response = {'has_error': False, 'error_message': ""}
                if response_data.get("taskFailed"):
                    error_details = response_data.get("error").get("details")
                    if error_details:
                        self.LOG.error(
                            "Infrastructure Task failed : %s", error_details)
                        response = {
                            'has_error': True, 'error_message': error_details}
        return response
