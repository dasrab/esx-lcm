#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


from lib.vsan.handlers.lifecycle import LifecycleHandler
from abc import abstractmethod


class PlatformLifecycleHandler(LifecycleHandler):

    @abstractmethod
    def do(self):
        pass
