#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


from vsan.handlers.platform_lifecycle.api_handlers import ApiHandler


class NcsApiHandler(ApiHandler):

    def __init__(self):
        pass
