#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

import json
import requests
from lib.vsan.devops.common.log import Logger


class ApiHandler(object):

    def __init__(self):
        self.LOG = Logger.getLogger(__name__)

    def do_request(self, method, url, **kwargs):
        """
        Generic method for making API call
        """
        payload = kwargs.get('payload', None)
        headers = kwargs.get('headers', None)

        if headers:
            headers.update({'content-type': 'application/json'})
        else:
            headers = {'content-type': 'application/json'}

        request_method = {
            'GET': requests.get,
            'PATCH': requests.patch,
            'POST': requests.post,
            'PUT': requests.put,
            'DELETE': requests.delete}
        req = request_method[method]
        self.LOG.info(
            "~~~~~~~~~~~~~ API Request Details ~~~~~~~~~~~~~~~~~~~~~")
        self.LOG.info("URL : " + url)
        self.LOG.info("HTTP method : " + method)
        self.LOG.info(
            "Data : " + json.dumps(payload, indent=4, sort_keys=True))
        self.LOG.info("Headers : " + str(headers))
        try:
            response_body = req(url, data=json.dumps(payload), headers=headers)
            self.LOG.info("Response : %s" % response_body.text)
            self.LOG.info(
                "~~~~~~~~~~~~~ API Request Details ~~~~~~~~~~~~~~~~~~~~~")
            return self._handle_response(response_body)
        except (requests.exceptions.ConnectionError,
                requests.exceptions.RequestException) as e:
            data = {'has_error': True, 'error_message': e.message}
            return data
        except ValueError as e:
            msg = "Cannot read response, %s" % (e.message)
            data = {'has_error': True, 'error_message': msg}
            return data
        except Exception as e:
            data = {'has_error': True, 'error_message': msg}
            return data

    def _handle_response(self, response_body):
        """
        Handle the response based on status code
        """
        if (response_body.status_code) in [200, 201, 202, 203]:
            data = response_body.json()
            data.update({'has_error': False, 'error_message': ''})
            return data
        elif response_body.status_code == 204:
            return {'has_error': False, 'error_message': ''}
        elif response_body.status_code >= 400:
            return {'has_error': True, 'error_message': response_body.text}
