#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

import unittest

from lib.vsan.common.exc import exceptions as vsan_exc
from lib.vsan import vsan_cluster_manager as vsan_cm


class TestPreHostCreationValidations(unittest.TestCase):
    def setUp(self):
        self.cm = vsan_cm.VsanClusterManager()
        self.ncs_version = '1.0'

    def tearDown(self):
        del self.cm

    def test_validate_requested_features_success(self):
        self.cm.is_all_flash = False
        params = {'vsan_feature_performance': True}
        self.cm._validate_requested_features(self.ncs_version, params)

        self.cm.is_all_flash = True
        params = {'vsan_feature_deduplication': True}
        self.cm._validate_requested_features(self.ncs_version, params)

    def test_validate_requested_features_hybrid_fail(self):
        self.cm.is_all_flash = False
        params = {'vsan_feature_deduplication': True}
        self.assertRaises(vsan_exc.VsanUnsupportedFeatureException,
                          self.cm._validate_requested_features,
                          self.ncs_version,
                          params)

    def test_validate_requested_features_hybrid_fail_fault_domain(self):
        self.cm.is_all_flash = False
        params = {'vsan_feature_fault_domain': True}
        self.assertRaises(vsan_exc.VsanUnsupportedFeatureException,
                          self.cm._validate_requested_features,
                          self.ncs_version,
                          params)

        params = {'vsan_feature_fault_domain': 'fd1'}
        self.assertRaises(vsan_exc.VsanInvalidConfigurationException,
                          self.cm._validate_requested_features,
                          self.ncs_version,
                          params)

        params = {'vsan_feature_fault_domain': 'fd1 fd2'}
        self.assertRaises(vsan_exc.VsanInvalidConfigurationException,
                          self.cm._validate_requested_features,
                          self.ncs_version,
                          params)

    def fake_connect_to_vcenter(self, host, user, password, port):
        return "si", "context"

    def fake_get_vsan_license(self, si):
        return

    def fake_connect_to_vcenter_exc(self, host, user, password, port):
        raise vsan_exc.VCenterConnectionException(
            vc_host='vc_host',
            error_desc="failed to connect")

    def fake_get_vsan_license_exc(self, si):
        msg = "No vSAN license found. Upload one for vSAN deployment"
        raise vsan_exc.VsanLicenseException(msg=msg)

    def test_perform_pre_host_creation_validations_v1_encyrption_fail(self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'vsan_feature_encryption': True,
                  'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:HDD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertFalse(status, error)
        self.assertIn('encryption is not supported in hybrid mode '
                      'of deployment in version 1.0', error)
        self.assertFalse(self.cm.is_all_flash)
        self.assertFalse(self.cm.deduplication)

    def test_perform_pre_host_creation_validations_v1_hybrid_success(self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:HDD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertTrue(status, error)
        self.assertEqual(error, None)
        self.assertFalse(self.cm.deduplication)

    def test_perform_pre_host_creation_validations_v1_hybrid_perf_success(
            self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'performance': True,
                  'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:HDD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertTrue(status, error)
        self.assertEqual(error, None)
        self.assertTrue(self.cm.performance)
        self.assertFalse(self.cm.deduplication)

    def test_perform_pre_host_creation_validations_v1_hybrid_fail_unknown(
            self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'vsan_feature_unknown': True,
                  'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:HDD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertFalse(status)
        self.assertFalse(hasattr(self.cm, 'unknown'))
        self.assertEqual(error, 'unknown is not a valid vSAN feature.')

    def test_perform_pre_host_creation_validations_all_flash_success(self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:SSD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertTrue(self.cm.is_all_flash)
        self.assertTrue(self.cm.deduplication)
        self.assertTrue(status, error)
        self.assertEqual(error, None)

    def test_perform_pre_host_creation_validations_vcenter_connection_fail(self):
        self.cm.vc.connect = self.fake_connect_to_vcenter_exc
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license
        params = {'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:SSD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertFalse(status)
        self.assertEqual(
            error, "Failed to connect to vCenter vc_host. failed to connect")

    def test_perform_pre_host_creation_validations_get_vsan_license_fail(self):
        self.cm.vc.connect = self.fake_connect_to_vcenter
        self.cm.vc.get_vsan_license = self.fake_get_vsan_license_exc
        msg = "No vSAN license found. Upload one for vSAN deployment"
        params = {'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:SSD"}}
        status, error = self.cm.perform_pre_host_creation_validations(params)
        self.assertFalse(status)
        self.assertEqual(error, msg)

    def test_get_system_parameter_flash(self):
        args = {'storage_network_name': "vsan_net",
                'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:SSD"},
                'force_mark_local_disk_as_flash': False,
                'force_delete': True,
                'performance': True}
        params = self.cm.get_system_parameter(args)
        self.assertEqual(params['force_delete'], args['force_delete'])
        self.assertEqual(params['storage_network_name'], args['storage_network_name'])
        self.assertFalse(params['force_mark_local_disk_as_flash'])
        self.assertTrue(params['is_all_flash'])
        self.assertTrue(params['deduplication'])
        self.assertTrue(params['performance'])

    def test_get_system_parameter_flash_non_ssd_cache(self):
        args = {'storage_network_name': "vsan_net",
                'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:HDD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:SSD"},
                'force_mark_local_disk_as_flash': True,
                'force_delete': True,
                'performance': True}
        params = self.cm.get_system_parameter(args)
        self.assertEqual(params['force_delete'], args['force_delete'])
        self.assertEqual(params['storage_network_name'], args['storage_network_name'])
        self.assertTrue(params['force_mark_local_disk_as_flash'])
        self.assertTrue(params['is_all_flash'])
        self.assertTrue(params['deduplication'])
        self.assertTrue(params['performance'])

    def test_get_system_parameter_hybrid(self):
        args = {'storage_network_name': "vsan_net",
                'vsan_disk_info': {
                    "cache_drive_count": 1,
                    "cache_drive_size_gb": 1200,
                    "cache_drive_type": "local:SAS:SSD",
                    "capacity_drive_count": 2,
                    "capacity_drive_size_gb": 2000,
                    "capacity_drive_type": "bigbird:SATA:HDD"},
                'force_mark_local_disk_as_flash': False,
                'force_delete': False,
                'performance': False}
        params = self.cm.get_system_parameter(args)
        self.assertEqual(params['force_delete'], args['force_delete'])
        self.assertEqual(params['storage_network_name'], args['storage_network_name'])
        self.assertFalse(params['force_mark_local_disk_as_flash'])
        self.assertFalse(params['is_all_flash'])
        self.assertFalse(params['deduplication'])
        self.assertFalse(params['performance'])


    def test_setup_attributes(self):
        def validate(args, obj):
            for feature, value in args.items():
                msg = "Feature: %s, expected: %s, actual: %s" % (
                    feature, value, getattr(obj.cm, feature))
                obj.assertEqual(getattr(obj.cm, feature), value, msg)

        arg_list = [{'deduplication': True, 'encryption': True,
                     'fault_domain': 'fd1:h1,h2,h3 fd2:h4 fd3:h5',
                     'performance': True},
                    {'deduplication': False, 'encryption': False,
                     'performance': True}]

        for args in arg_list:
            self.cm.setup_attributes(args)
            validate(args, self)
            # need to delete the VsanClusterManager instance since the
            # attributes stay set once enabled from a test data
            del self.cm
            self.cm = vsan_cm.VsanClusterManager()

    def test__compare_versions(self):
        test_data = [('1.0', '1.0', 0),
                     ('1.0', '1.0.1', -1),
                     ('1.0', '1.2', -1),
                     ('1.0.5', '1.2', -1),
                     ('1.0.5', '1.0.2', 1),
                     ('2.0', '1.0.2', 1),
                     ('1.2.3.4', '1.0', 1),
                     ('1.2.3.4', '1.2.3.4', 0),
                     ('1.5.0.7', '2.0', -1)]
        for td in test_data:
            result = self.cm._compare_versions(td[0], td[1])
            self.assertEqual(result, td[2],
                             "For v1:%s, v2:%s, expected: %d, actual:%d" %
                             (td[0], td[1], td[2], result))

    def test_fetch_feature_map_for_version(self):
        fmap = {
            'vmap': [
                {'ncs_minver': '1.0', '1.0': 'dummy'},
                {'ncs_minver': '1.0.5', '1.0.5': 'dummy'},
                {'ncs_minver': '1.5', '1.5': 'dummy'},
                {'ncs_minver': '2.0', '2.0': 'dummy'}
            ]}

        ncs_versions = {'1.0': '1.0',
                        '1.0.0.1': '1.0',
                        '1.0.1': '1.0',
                        '1.0.5': '1.0.5',
                        '1.0.7': '1.0.5',
                        '2.1': '2.0',
                        '1.7.5.3': '1.5'}
        for requested_version, match_key in ncs_versions.iteritems():
            val = self.cm._fetch_feature_map_for_version(requested_version,
                                                         fmap)
            self.assertIn(match_key,
                          val,
                          "For %s expected to return vmap that contains key "
                          "%s, but got vmap with keys: %s." % (
                              requested_version, match_key, val.keys()))


class FakeClusterSystem:
    def __init__(self):
        self.cluster = None
        self.reconfig_spec = None

    def VsanClusterReconfig(self, cluster, reconfig_spec):
        self.cluster = cluster
        self.reconfig_spec = reconfig_spec
