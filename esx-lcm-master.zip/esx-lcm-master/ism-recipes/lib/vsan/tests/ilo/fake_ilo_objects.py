# (C) Copyright 2017 Hewlett Packard Enterprise Development LP


class IloResponse:
    def __init__(self, status, response_dict):
        self.status = status
        self.dict = response_dict


class IloClient:
    def __init__(self, response_status, response_dict):
        self.response_status = response_status
        self.response_dict = response_dict

    def get(self, url):
        return IloResponse(self.response_status, self.response_dict)


class RedfishRestClient:
    pass


def do_get(ilo_client, uri):
    if uri == "/redfish/v1/Systems/1":
        return {'Oem': {'Hp': {'links': {'SmartStorage': {'href': "u1"}}}}}
    elif uri == "u1":
        return {"links": {'ArrayControllers': {'href': 'u2'}}}
    elif uri == "u2":
        return {'links': {'Member': [{'href': 'u3'}, {'href': 'u32'}],
                          'self': {'href': 's1'}}}
    elif uri == "u3":
        return {'links': {'LogicalDrives': {'href': 'u4'}}}
    elif uri == "u32":
        return {'links': {'LogicalDrives': {'href': 'u5'}}}
    elif uri == "u4":
        return {'links': {'Member': [{'href': 'drive1'}, {'href': 'drive2'}],
                          'self': {'href': 's1'}}}
    elif uri == "u5":
        return {'links': {'self': {'href': 's2'}}}
    elif uri == "drive1":
        return {'VolumeUniqueIdentifier': 1, 'LogicalDriveNumber': 1,
                'links': {'DataDrives': {'href': "data_drive_1"}}}
    elif uri == "drive2":
        return {'VolumeUniqueIdentifier': 2, 'LogicalDriveNumber': 2,
                'links': {'DataDrives': {'href': "data_drive_2"}}}
    elif uri == "data_drive_1":
        # this is where need to add 2 member to raise the exception
        return {'links': {'Member': [{'href': 'u7'}]}}
    elif uri == "data_drive_2":
        # this is where need to add 2 member to raise the exception
        return {'links': {'Member': [{'href': 'u8'}]}}
    elif uri == "u7":
        return {'MediaType': 'HDD', 'CapacityGB': 2000,
                'InterfaceType': 'SATA'}
    elif uri == "u8":
        return {'MediaType': 'SSD', 'CapacityGB': 1200,
                'InterfaceType': 'SAS'}
    else:
        return False


def map_drive_info(ilo_info, controller_details):
    controller_details[0]['logical_drives'][0]['MediaType'] = 'HDD'
    controller_details[0]['logical_drives'][0]['CapacityGB'] = 2000
    controller_details[0]['logical_drives'][0]['Protocol'] = 'SATA'
    controller_details[0]['logical_drives'][0]['VolumeUniqueIdentifier'] = 1
    controller_details[0]['logical_drives'][0]['ControllerUri'] = 'u3'
    controller_details[0]['logical_drives'][0]['VolumeUniqueIdentifier'] = 1
    controller_details[0]['logical_drives'][1]['MediaType'] = 'SSD'
    controller_details[0]['logical_drives'][1]['CapacityGB'] = 1200
    controller_details[0]['logical_drives'][1]['Protocol'] = 'SAS'
    controller_details[0]['logical_drives'][1]['VolumeUniqueIdentifier'] = 2
    controller_details[0]['logical_drives'][1]['ControllerUri'] = 'u3'
    controller_details[0]['logical_drives'][1]['VolumeUniqueIdentifier'] = 2
    return controller_details


def do_get_fail(ilo_client, uri):
    if uri == "/redfish/v1/Systems/1":
        return {'Oem': {'Hp': {'links': {'SmartStorage': {'href': "u1"}}}}}
    elif uri == "u1":
        return {"links": {'ArrayControllers': {'href': 'u2'}}}
    elif uri == "u2":
        return {'links': {'Member': [{'href': 'u3'}]}}
    elif uri == "u3":
        return {'links': {'LogicalDrives': {'href': 'u4'}}}
    elif uri == "u4":
        return {'links': {'Member': [{'href': 'drive1'}, {'href': 'drive2'}]}}
    elif uri == "drive1":
        return {'VolumeUniqueIdentifier': 1, 'LogicalDriveNumber': 1,
                'links': {'DataDrives': {'href': "data_drive_1"}}}
    elif uri == "drive2":
        return {'VolumeUniqueIdentifier': 2, 'LogicalDriveNumber': 2,
                'links': {'DataDrives': {'href': "data_drive_2"}}}
    elif uri == "data_drive_1":
        # this is where need to add 2 member to raise the exception
        return {'links': {'Member': [{'href': 'u7'}, {'href': 'u8'}]}}
    else:
        return False
