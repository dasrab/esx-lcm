# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest

from lib.vsan.ilo import utils as utils
from lib.vsan.ilo import exceptions as ilo_exc
from mock import patch

import fake_ilo_objects


@unittest.skipIf(utils.redfish is None, "Skipping iLO tests.")
class TestUtils(unittest.TestCase):
    def test_fetch_ilo_addr_and_key(self):
        ip = '15.213.234.190'
        key = 'abcd'
        rc_url = "hplocons://addr=%s&sessionkey=%s" % (ip, key)
        ilo_host, session_key = utils.fetch_ilo_addr_and_key(rc_url)
        self.assertEqual(ilo_host, "https://%s" % ip)
        self.assertEqual(session_key, key)

    def test_do_get(self):
        response_code = 200
        response_dict = {"k": "v"}
        ilo_client = fake_ilo_objects.IloClient(response_code, response_dict)
        url = "https://15.213.234.190%s" % utils.REDFISH_URI

        response = utils._do_get(ilo_client, url)
        self.assertEqual(response, response_dict)

    def test_do_get_negative(self):
        response_code = 401
        response_dict = {"k": "v"}
        ilo_client = fake_ilo_objects.IloClient(response_code, response_dict)
        url = "https://15.213.234.190%s" % utils.REDFISH_URI

        with self.assertRaises(ilo_exc.iLOQueryException):
            utils._do_get(ilo_client, url)

    def test_map_drive_info(self):
        td = [{'logical_drives': [{'driveNumber': 1, 'somekey': 'data1'},
                                  {'driveNumber': 2, 'somekey': 'data2'}]}, ]
        ilo_info = [{'LogicalDriveNumber': 1, 'VolumeUniqueIdentifier': 1},
                    {'LogicalDriveNumber': 2, 'VolumeUniqueIdentifier': 2}]
        expected_ld0 = {'driveNumber': 1, 'somekey': 'data1',
                        'LogicalDriveNumber': 1, 'VolumeUniqueIdentifier': 1}
        expected_ld1 = {'driveNumber': 2, 'somekey': 'data2',
                        'LogicalDriveNumber': 2, 'VolumeUniqueIdentifier': 2}

        utils._map_drive_info(ilo_info, td)
        self.assertEqual(len(td), 1)
        self.assertTrue('logical_drives' in td[0])
        self.assertEqual(len(td[0]['logical_drives']), 2)
        ld0 = td[0]['logical_drives'][0]
        ld1 = td[0]['logical_drives'][1]

        self.assertDictEqual(ld0, expected_ld0)
        self.assertDictEqual(ld1, expected_ld1)

    def test_map_drive_info_negative(self):
        td = [{'logical_drives': [{'driveNumber': 1, 'somekey': 'data1'},
                                  {'driveNumber': 2, 'somekey': 'data2'}]}, ]
        ilo_info = [{'LogicalDriveNumber': 3, 'VolumeUniqueIdentifier': 3},
                    {'LogicalDriveNumber': 2, 'VolumeUniqueIdentifier': 2}]

        with self.assertRaises(ilo_exc.LogicalDriveNotFound):
            utils._map_drive_info(ilo_info, td)

    @patch('lib.vsan.ilo.utils.redfish.rest_client')
    @patch('lib.vsan.ilo.utils._do_get')
    @patch('lib.vsan.ilo.utils._map_drive_info')
    def test_fetch_host_disks(self, mock_map, mock_do_get, mock_client):
        mock_map.side_effect = fake_ilo_objects.map_drive_info
        mock_do_get.side_effect = fake_ilo_objects.do_get
        mock_client.return_value = fake_ilo_objects.RedfishRestClient()

        td = [{'logical_drives': [{'driveNumber': 1, 'somekey': 'data1'},
                                  {'driveNumber': 2, 'somekey': 'data2'}]}, ]

        ilo_info = utils.fetch_host_disks('ilo_host', 'session_key', td)
        self.assertEqual(len(ilo_info), 1)
        exp_d1_info = {'MediaType': 'HDD', 'CapacityGB': 2000,
                       'Protocol': 'SATA', 'VolumeUniqueIdentifier': 1,
                       'ControllerUri': 'u3', 'driveNumber': 1,
                       'somekey': 'data1'}
        exp_d2_info = {'MediaType': 'SSD', 'CapacityGB': 1200,
                       'Protocol': 'SAS', 'VolumeUniqueIdentifier': 2,
                       'ControllerUri': 'u3', 'driveNumber': 2,
                       'somekey': 'data2'}
        self.assertDictEqual(ilo_info[0]['logical_drives'][0], exp_d1_info)
        self.assertDictEqual(ilo_info[0]['logical_drives'][1], exp_d2_info)

    @patch('lib.vsan.ilo.utils.redfish.rest_client')
    @patch('lib.vsan.ilo.utils._do_get')
    @patch('lib.vsan.ilo.utils._map_drive_info')
    def test_fetch_host_disks_negative(self, mock_map, mock_do_get,
                                       mock_client):
        mock_map.side_effect = fake_ilo_objects.map_drive_info
        mock_do_get.side_effect = fake_ilo_objects.do_get_fail
        mock_client.return_value = fake_ilo_objects.RedfishRestClient()

        td = [{'logical_drives': [{'driveNumber': 1, 'somekey': 'data1'},
                                  {'driveNumber': 2, 'somekey': 'data2'}]}, ]

        with self.assertRaises(ilo_exc.InvalidLUNException):
            utils.fetch_host_disks('ilo_host', 'session_key', td)
