# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

class FakeHostSystem():
    def __init__(self, host_name):
        self.name = host_name
        self.runtime = self.Runtime()

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True


class Fakecluster:
    def __init__(self):
        self.name = 'Fake_cluster'


class FakeconfigManager:
    def __init__(self):
        self.vsanSystem = None

    def UpdateVsan_Task(self, configInfo):
        pass

