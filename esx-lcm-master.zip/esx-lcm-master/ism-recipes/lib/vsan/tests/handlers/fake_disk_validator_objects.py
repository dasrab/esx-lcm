#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


hosts = [
    'vim.HostSystem:host-186',
    'vim.HostSystem:host-192',
    'vim.HostSystem:host-194']

hostprops = {
    'vim.HostSystem:host-186': {'name': '172.18.200.23'},
    'vim.HostSystem:host-192': {'name': '172.18.200.244'},
    'vim.HostSystem:host-194': {'name': '172.18.200.245'}
}



local_disk_id = "600508B1001CF4FC6E4AF9916A1F0972"

vsan_disk_info = {
    "capacity_drive_type":"bigbird:SAS:HDD",
    "capacity_drive_count":10,
    "capacity_drive_size_gb": 500,
    "cache_drive_type":"local:SAS:SSD",
    "cache_drive_count":3,
    "cache_drive_size_gb": 250
}


# ----------------------------------------------------------------------------
# Mocked system and its objects
# ----------------------------------------------------------------------------
MUL_FACTOR = 24696061L

class SSDDisk(object):

    def __init__(self, uuid="2", disksize=10, source="bigbird"):
        disksize *= MUL_FACTOR
        self.__dict__ = {
            'deviceType': 'disk',
            'uuid': uuid,
            'ssd': True,
            'localDisk': True,
            'capacity': Capacity(disksize),
            'devicePath': '/vmfs/devices/disks/naa.' + local_disk_id if source == "local" else '/vmfs/devices/disks/naa.' + "someid"
        }
    def __repr__(self):
        return "%s (%s)" % (self.__dict__['uuid'], self.__dict__['capacity'].__dict__['blockSize'])

class HDDDisk(object):

    def __init__(self, uuid="1", disksize=20, source="bigbird"):
        disksize *= MUL_FACTOR
        self.__dict__ = {
            'deviceType': 'disk',
            'uuid': uuid,
            'ssd': False,
            'localDisk': True,
            'capacity': Capacity(disksize),
            'devicePath': '/vmfs/devices/disks/naa.' + local_disk_id if source == "local" else '/vmfs/devices/disks/naa.' + "someid"
        }
    def __repr__(self):
        return "%s (%s)" % (self.__dict__['uuid'], self.__dict__['capacity'].__dict__['blockSize'])

class Capacity(object):

    def __init__(self, disksize):
        self.__dict__ = {
            'blockSize': disksize,
            'block': 1000L
        }


class VsanSystem:
    def __init__(self, all_flash, disk_info):
        self.all_flash = all_flash
        self.disk_info = disk_info

    def QueryDisksForVsan(self):
        disks = []
        dpath = '/vmfs/devices/disks/naa.'
        if self.all_flash:
            for controller in self.disk_info:
                index = 1
                for ld in controller['logical_drives']:
                    disk = SSDDisk(uuid=str(index))
                    disk.devicePath = dpath + ld['VolumeUniqueIdentifier']
                    disks.append(DiskResult(disk=disk))
                    index += 1
        else:
            for controller in self.disk_info:
                lds = len(controller['logical_drives'])
                for index, ld in enumerate(controller['logical_drives'],
                                           start=1):
                    disk = HDDDisk(uuid=str(index))
                    disk.devicePath = dpath + ld['VolumeUniqueIdentifier']
                    if index != lds:
                        disks.append(DiskResult(disk=disk))

                disk = SSDDisk(uuid=str(index))
                disk.devicePath = dpath + ld['VolumeUniqueIdentifier']
                disks.append(DiskResult(disk=disk))
        return disks


class DiskResult:
    def __init__(self, state='eligible', disk=HDDDisk()):
        self.state = state
        self.disk = disk


class StorageSystem:
    def __init__(self):
        self.faked_disk_list = []

    def MarkAsSsd_Task(self, disk_uuid):
        self.faked_disk_list.append(disk_uuid)



# ----------------------------------------------------------------------------
# Utility method working on mocked system and its objects
# ----------------------------------------------------------------------------
def query_vcenter_disks_for_flash(device_count):
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for index in range(device_count):
            disks.append(SSDDisk(uuid=str(index)))
        if device_count > 1:
            disks.append(
                SSDDisk(uuid=str(index + 1), disksize=1, source="local"))
        vc_diskmap[host] = disks
    vsan_disk_info = {
        "capacity_drive_type": "bigbird:SAS:SSD",
        "capacity_drive_count": device_count - 1,
        "capacity_drive_size_gb": 250,
        "cache_drive_type": "local:SAS:SSD",
        "cache_drive_count": 1,
        "cache_drive_size_gb": 25
    }
    return (vc_diskmap, vsan_disk_info)

def get_hostprops():
    return hostprops

def get_vsan_disk_info():
    return vsan_disk_info

def query_vcenter_disks_for_flash_same_size(device_count):
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for index in range(device_count - 1):
            disks.append(SSDDisk(uuid=str(index)))
        disks.append(SSDDisk(uuid=str(index + 1), source="local"))
        vc_diskmap[host] = disks

    vsan_disk_info = {
        "capacity_drive_type":"bigbird:SAS:SSD",
        "capacity_drive_count":device_count-1 if device_count > 1 else
        device_count,
        "capacity_drive_size_gb": 250,
        "cache_drive_type":"local:SAS:SSD",
        "cache_drive_count":1 if device_count > 1 else 0,
        "cache_drive_size_gb": 250
    }
    return (vc_diskmap, vsan_disk_info)


def query_vcenter_disks_for_hybrid(device_count):
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for index in range(device_count - 1):
            disks.append(HDDDisk(uuid=str(index + 1)))
        disks.append(SSDDisk(uuid=str(device_count), source="local"))
        vc_diskmap[host] = disks
    return vc_diskmap


def query_vcenter_disks_for_hybrid_without_ssd(device_count):
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for index in range(device_count):
            disks.append(HDDDisk(uuid=str(index + 1)))
        vc_diskmap[host] = disks
    return vc_diskmap


def query_vcenter_disks_for_hybrid_with_capacity_constraint(
        device_count):
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for index in range(device_count - 1):
            disks.append(HDDDisk(uuid=str(index)))
        disks.append(SSDDisk(uuid=str(index + 1), disksize=1, source="local"))
        vc_diskmap[host] = disks

    vsan_disk_info = {
        "capacity_drive_type": "bigbird:SAS:SSD",
        "capacity_drive_count": device_count - 1,
        "capacity_drive_size_gb": 500,
        "cache_drive_type": "local:SAS:SSD",
        "cache_drive_count": 1,
        "cache_drive_size_gb": 25
    }
    return (vc_diskmap, vsan_disk_info)


def query_vcenter_disks_hybrid_multi_dgs():
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for i in range(3):
            disks.append(SSDDisk(uuid="ssd-" + str(i), source="local"))
        for i in range(10):
            disks.append(HDDDisk(uuid="hdd-" + str(i)))
        vc_diskmap[host] = disks
    return vc_diskmap


def query_vcenter_disks_flash_multi_dgs():
    vc_diskmap = {}
    for host in hosts:
        disks = []
        for i in range(3):
            disks.append(SSDDisk(uuid="ssd-" + str(i), source="local"))
        for i in range(10):
            disks.append(SSDDisk(uuid="capssd-" + str(i), disksize=20))
        vc_diskmap[host] = disks
    return vc_diskmap
