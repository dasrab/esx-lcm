# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import unittest
from pyVmomi import vim, vmodl
from mock import MagicMock, patch, call, Mock

from lib.vsan.handlers.vsan_lifecycle.delete import VsanDeleteHandler
import lib.vsan.common.exc.exceptions as vsan_exc


class FakeHostSystem():
    def __init__(self):
        self.name = "test-host"
        self.runtime = self.Runtime()

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True


class FakeclusterSystem:
    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class VsanClusterGetConfig:
        def __init__(self, cluster):
            if cluster == 'cluster_mo':
                self.enabled = True
            else:
                self.enabled = False


class FakeCluster:
    def __init__(self):
        self.name = 'Fake_cluster'
	self.host = []

class FakeconfigManager:
    def __init__(self):
        self.vsanSystem = None

    def UpdateVsan_Task(self, configInfo):
        pass


class FakeDiskManagementSystem:
    pass


class FakeSi:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'

class FakeClusterSystem:
    def __init__(self):
        self.host = 'fake_host'


class TestVsanDeleteHandler(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.args = {'vc_host': 'fake_host',
                     'vc_user': 'fake_user',
                     'vc_password': 'fake_password',
                     'vc_port': 443,
                     'vc_cluster': 'fake_cluster',
                     'is_all_flash': 'False',
                     'vsan_license': 'fake_licence',
                     'performance': 'False',
                     'storage_network_name': '', 'scaleout_hosts': '',
                     'vsan_disk_info': ''}
        self.dh = VsanDeleteHandler(self.args)

    def tearDown(self):
        """Cleaning up after the test"""
        del self.dh

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_disable_vsan_pass(self, mock_log, mock_wait_for_tasks):
        mock_wait_for_tasks.return_value = False
        fake_cluster = FakeCluster()
        fake_si = FakeSi()
        fake_cs = FakeclusterSystem()
        self.dh._disable_vsan(fake_cluster, fake_si, fake_cs)
        mock_log.assert_called_with('vSAN disable operations successful.')

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_disable_vsan_fail(self, mock_log, mock_wait_for_tasks):
        mock_wait_for_tasks.side_effect = vmodl.MethodFault()
        fake_cluster = FakeCluster()
        fake_si = FakeSi()
        fake_cs = FakeclusterSystem()
        with self.assertRaises(vsan_exc.VsanDisableOperationException):
            self.dh._disable_vsan(fake_cluster, fake_si, fake_cs)
        mock_log.assert_called_with('vSAN disable operation failed. Error: '
                                    'Unknown')

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanLifecycleHandler.is_vsan_enabled')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanLifecycleHandler.validate_cluster_ha_settings')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanLifecycleHandler.check_hosts_in_maintenance_mode')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanLifecycleHandler.remove_disk_mappings')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanLifecycleHandler.disable_vsan_traffic')
    @patch('lib.vsan.handlers.vsan_lifecycle.delete.VsanDeleteHandler'
           '._disable_vsan')
    def test_do(self,
                mock_disable_vsan,
                mock_disable_traffic,
                mock_remove_disks,
                mock_maintenance_mode,
                mock_validate_ha,
                mock_vsan_enabler,
                mock_host_props,
                mock_cluster,
                mock_mos,
                mock_si):
        mock_si.return_value = (FakeSi(), 'context')
        mock_mos.return_value = {
            'vsan-disk-management-system': 'vsan-disk-management-system',
            'vsan-cluster-config-system': 'vsan-cluster-config-system'}
        mock_cluster.return_value = FakeCluster()
        mock_host_props.return_value = {'host1': 'host1', 'host2': 'host2'}
        mock_vsan_enabler.return_value = True
        self.dh.do(self.args)


if __name__ == '__main__':
    unittest.main()

