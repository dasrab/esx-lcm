#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#


hosts = ['vim.HostSystem:host-94',
         'vim.HostSystem:host-111',
         'vim.HostSystem:host-96']

host_props = {
    'vim.HostSystem:host-94': {
        u'configManager.storageSystem': 'vim.host.StorageSystem:storageSystem-94',
        u'configManager.vsanSystem': 'vim.host.VsanSystem:vsanSystem-94',
        u'name': '172.18.200.221'
    },
    'vim.HostSystem:host-111': {
        u'configManager.storageSystem': 'vim.host.StorageSystem:storageSystem-111',
        u'configManager.vsanSystem': 'vim.host.VsanSystem:vsanSystem-111',
        u'name': '172.18.200.227'},
    'vim.HostSystem:host-96': {
        u'configManager.storageSystem': 'vim.host.StorageSystem:storageSystem-96',
        u'configManager.vsanSystem': 'vim.host.VsanSystem:vsanSystem-96',
        u'name': '172.18.201.9'}
}

diskmap = [
    {
        'node': '172.18.200.221',
        'host_ref': 'vim.HostSystem:host-94',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 42949672960,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    }
]



# ----------------------------------------------------------------------------
# Mocked system and its objects
# ----------------------------------------------------------------------------
def get_old_host_diskmodel(n=1):

    diskmodel = {
        'node': '172.18.200.227',
        'host_ref': None,
        'device_groups': [
            {'total_cache_capacity': 42949672960 * n,
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960 * n},
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600 * n}
             ],
             'cache_device_id': '0000000000766d686261313a313a30',
             'vcenter_diskmap': {},
             'total_raw_capacity': 429496729600 * n
             }
        ]
    }
    return diskmodel


def get_scaleout_host_diskmodel(n=1):

    diskmodel = [{
        'node': '172.18.200.221',
        'host_ref': None,
        'device_groups': [
            {'total_cache_capacity': 42949672960,
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960},
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600}
             ],
             'cache_device_id': '0000000000766d686261313a313a30',
             'vcenter_diskmap': {},
             'total_raw_capacity': 429496729600
             }
        ]
    }
    ]
    return diskmodel
