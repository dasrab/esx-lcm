# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
from pyVmomi import vim, vmodl
from mock import MagicMock, patch, call, Mock

from lib.vsan.handlers.vsan_lifecycle.prepare import \
    VsanOperationInitializerHandler
from lib.vsan.common.exc import exceptions as vsan_exc


class FakeHostSystem():
    def __init__(self, name):
        self.name = name
        self.runtime = self.Runtime()

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True


class FakeStorageManager:
    def __init__(self):
        self.vsanSystem = None

    def MarkAsSsd_Task(self, uuid):
        pass


class Disk:
    def __init__(self, path, uuid):
        self.devicePath = path
        self.uuid = uuid


class FakeClusterSystem:
    def __init__(self):
        self.host = 'fake_host'


class FakeSi:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'


class TestOperationInitializerHandler(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.args = {'vc_host': 'fake_host',
                     'vc_user': 'fake_user',
                     'vc_password': 'fake_password',
                     'vc_port': 443,
                     'vc_cluster': 'fake_cluster',
                     'is_all_flash': 'False',
                     'vsan_license': 'fake_licence',
                     'performance': 'False',
                     'storage_network_name': '', 'scaleout_hosts': '',
                     'vsan_disk_info': {
                         'capacity_drive_count': 1,
                         'capacity_drive_size_gb': 2000,
                         'capacity_drive_type': 'bigbird:SAS:HDD',
                         'cache_drive_count': 1,
                         'cache_drive_size_gb': 800,
                         'cache_drive_type': 'bigbird:SAS:SSD',},
                     'wipe_disks': True
                     }
        self.ph = VsanOperationInitializerHandler(self.args)

    def tearDown(self):
        del self.ph

    def get_fake_reconfigure_cluster_args(self):
        fake_hosts = []
        fake_host_props = {}
        for i in range(1):
            host = FakeHostSystem('h%s' % str(i + 1))
            fake_hosts.append(host)
            fake_host_props[host] = {
                'name': 'h%s' % str(
                    i + 1),
                'configManager.storageSystem': FakeStorageManager()}

        fake_cluster = FakeClusterSystem()
        fake_si = FakeSi()
        return (
            fake_hosts, fake_host_props, fake_cluster,
            fake_si
            )

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'query_vcenter_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'get_host_cleaner')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'ensure_clean_disks')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    def test_do(self, mock_wait, mock_ensure_clean_disks,
                mock_get_host_cleaner, mock_query_vcenter_disks,
                mock_collect_host_properties, mock_get_cluster_instance,
                mock_connect):
        hosts, host_props, cluster, si = \
            self.get_fake_reconfigure_cluster_args()
        mock_connect.return_value = si, 'context'
        mock_get_cluster_instance = cluster
        mock_collect_host_properties.return_value = host_props
        eligible_disks = {hosts[0]: [Disk('dir1/dir2.cache1',
                                                  'uuid1')]}
        mock_query_vcenter_disks.return_value = {'eligible': eligible_disks,
                                                 'ineligible': {}
                                                 }

        success, msg = self.ph.do({'force_mark_local_disk_as_flash': True})
        self.assertTrue(success)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'query_vcenter_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'get_host_cleaner')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'ensure_clean_disks')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    def test_do_fail_tasks(self, mock_wait, mock_ensure_clean_disks,
                mock_get_host_cleaner, mock_query_vcenter_disks,
                mock_collect_host_properties, mock_get_cluster_instance,
                mock_connect):
        hosts, host_props, cluster, si = \
            self.get_fake_reconfigure_cluster_args()
        mock_connect.return_value = si, 'context'
        mock_get_cluster_instance = cluster
        mock_collect_host_properties.return_value = host_props
        eligible_disks = {hosts[0]: [Disk('dir1/dir2.cache1',
                                                  'uuid1')]}
        mock_query_vcenter_disks.return_value = {'eligible': eligible_disks,
                                                 'ineligible': {}
                                                 }
        mock_wait.side_effect = vmodl.MethodFault()
        status, msg = self.ph.do({'force_mark_local_disk_as_flash': True})
        self.assertFalse(status)
        self.assertEquals(msg, "Failed to mark compute disk(s) as SSDs. "
                               "Error: Unknown")

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'query_vcenter_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'get_host_cleaner')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           'ensure_clean_disks')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    def test_do_fail(self, mock_wait, mock_ensure_clean_disks,
                mock_get_host_cleaner, mock_query_vcenter_disks,
                mock_collect_host_properties, mock_get_cluster_instance,
                mock_connect):
        hosts, host_props, cluster, si = \
            self.get_fake_reconfigure_cluster_args()
        mock_connect.return_value = si, 'context'
        mock_get_cluster_instance = cluster
        mock_collect_host_properties.return_value = host_props
        eligible_disks = {hosts[0]: [Disk('dir1/dir2.cache1',
                                                  'uuid1')]}
        mock_query_vcenter_disks.return_value = {'eligible': eligible_disks,
                                                 'ineligible': {}
                                                 }
        err_msg = ('Found some disks with existing data on hosts '
                   '(h1). The disks need a clean up to be '
                   'eligible for consumption.')
        mock_ensure_clean_disks.side_effect = \
            vsan_exc.VsanHostUncleanDiskException(msg=err_msg)
        status, msg = self.ph.do({'force_mark_local_disk_as_flash': True})
        self.assertFalse(status)
        self.assertEquals(msg, err_msg)
