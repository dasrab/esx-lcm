# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
from mock import MagicMock, patch, call, Mock


from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
from lib.vsan.handlers.vsan_lifecycle.update import VsanUpdateHandler


class FakeclusterSystem:
    def __init__(self):
        self.host = 'Fake_host'

    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class VsanClusterGetConfig:
        def __init__(self, cluster):
            if cluster == 'cluster_mo':
                self.enabled = True
            else:
                self.enabled = False

class FakeHealthReportSystem:
    class QueryClusterHealthSummary:
        def __init__(self, cluster):
            self.overallHealth = "green"
            self.networkHealth = self.networkHealth()

        class networkHealth:
            def __init__(self):
                self.hostsCommFailure = False


class FakeSpaceReportSystem:
    class QuerySpaceUsage:
        def __init__(self, cluster):
            self.totalCapacityB = 12345


class Fake_Si:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'

class TestVsanClusterUpdate(unittest.TestCase):
    def setUp(self):
        self.args = {
            'vc_host': 'fake_host',
            'vc_user': 'fake_user',
            'vc_password': 'fake_password',
            'vc_port': '',
            'vc_cluster': '', 'is_all_flash': '',
            'storage_network_name': '', 'scaleout_hosts': '',
            'vsan_disk_info': '',
            'pre_update_data': {
                'cluster_capacity': 12345,
                'cluster_health': 'yellow',
                'vsan_version_compliant_flag': True,
                'vsan_host_connecitivity_status': True
            }
        }
        self.vsan_lcm = VsanLifecycleHandler(self.args)
        self.vsan_uh = VsanUpdateHandler(self.args)

    def tearDown(self):
        del self.vsan_lcm
        del self.vsan_uh

    def test_get_cluster_capacity(self):
        cluster = 'cluster_mo'
        mob_cluster_space = FakeSpaceReportSystem()
        capacity = self.vsan_lcm.get_cluster_capacity(cluster,
                                                      mob_cluster_space)
        self.assertEqual(capacity, 12345)

    def test_get_cluster_health(self):
        cluster = 'cluster_mo'
        mob_cluster_health = FakeHealthReportSystem()
        health = self.vsan_lcm.get_cluster_health(cluster, mob_cluster_health)
        self.assertEqual(health, 'green')

    def test_get_disconnected_hosts_pass(self):
        cluster = 'cluster_mo'
        mob_cluster_health = FakeHealthReportSystem()
        failed_hosts = self.vsan_lcm.get_disconnected_hosts(cluster,
                                                            mob_cluster_health)
        self.assertFalse(failed_hosts)

    def test_compare_cluster_data(self):
        fake_old_data = {
            'cluster_capacity': "123456",
            'cluster_health': 'yellow'
        }
        fake_new_data = {
            'cluster_capacity': "12345",
            'cluster_health': 'red'
        }
        compare_report = self.vsan_lcm.compare_cluster_data(fake_old_data,
                                                            fake_new_data)
        self.assertTrue(compare_report['health'])


    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.check_hosts_in_maintenance_mode')
    def test_pre_operation_validation(self,
                                      mock_maintenance_check, 
                                      mock_host_props,
                                      mock_cluster, 
                                      mock_mos,
                                      mock_si):
        mock_si.return_value = (Fake_Si(), 'fake_context')
        mock_mos.return_value = {
            'vsan-cluster-health-system': 'vsan-cluster-health-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system'}
        mock_cluster.return_value = FakeclusterSystem()
        mock_host_props.return_value = {'host1': 'host1', 'host2': 'host2'}
        status, exc = self.vsan_uh.pre_operation_validation(self.args)
        self.assertTrue(status)

    @patch(
        'lib.vsan.handlers.vsan_lifecycle.update.VsanUpdateHandler.collect_cluster_info')
    def test_do_pre_steps(self, mock_preupdate):
        mock_preupdate.return_value = 'fake_preupdate_data'
        self.vsan_uh.do_pre_steps(self.args)
        status, pre_update_data, exc = self.vsan_uh.do_pre_steps(self.args)
        self.assertTrue(status)

    @patch(
        'lib.vsan.handlers.vsan_lifecycle.update.VsanUpdateHandler.collect_cluster_info')
    def test_post_operation_valdiation(self, mock_postupdate):
        fake_postupdate_data = {'cluster_capacity': 1234,
                                'cluster_health': 'red',
                                'vsan_version_compliant_flag': True,
                                'vsan_host_connecitivity_status': True}
        mock_postupdate.return_value = fake_postupdate_data
        status, exc = self.vsan_uh.post_operation_valdiation(self.args)
        self.assertTrue(status)


if __name__ == '__main__':
    unittest.main()

