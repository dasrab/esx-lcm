# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import unittest
from pyVmomi import vim, vmodl
from mock import MagicMock, patch, call, Mock

from lib.vsan.handlers.vsan_lifecycle.deploy import VsanDeployHandler
import lib.vsan.common.exc.exceptions as vsan_exc


non_homogeneous_diskmodel = [
    {
        'node': 'h1',
        'host_ref': 'vim.HostSystem:host-94',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 4294967296,
                'cache_device_id': '0000000000766d686261313a313a30'
            },
            {'vcenter_diskmap': {},
             'name': 'device-group-1',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 4294967296,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    },
    {
        'node': 'h2',
        'host_ref': 'vim.HostSystem:host-95',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 42949672960,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    },
    {
        'node': 'h3',
        'host_ref': 'vim.HostSystem:host-96',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 42949672960,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    }
]


homogeneous_diskmodel = [
    {
        'node': 'h1',
        'host_ref': 'vim.HostSystem:host-94',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 4294967296,
                'cache_device_id': '0000000000766d686261313a313a30'
            },
        ]
    },
    {
        'node': 'h2',
        'host_ref': 'vim.HostSystem:host-95',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 42949672960,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    },
    {
        'node': 'h3',
        'host_ref': 'vim.HostSystem:host-96',
        'device_groups': [
            {'vcenter_diskmap': {},
             'name': 'device-group-0',
             'devices': [
                 {'type': 'ssd',
                  'id': '0000000000766d686261313a313a30',
                  'size': 42949672960
                  },
                 {'type': 'hdd',
                  'id': '0000000000766d686261313a323a30',
                  'size': 429496729600
                  }
            ],
                'total_raw_capacity': 429496729600,
                'total_cache_capacity': 42949672960,
                'cache_device_id': '0000000000766d686261313a313a30'
            }
        ]
    }
]


class FakeClusterSystem:
    def __init__(self):
        self.host = 'fake_host'

    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class VsanClusterGetConfig:
        def __init__(self, cluster):
            if cluster == 'cluster_mo':
                self.enabled = True
            else:
                self.enabled = False


class FakeHostSystem():
    def __init__(self, host):
        self.name = host
        self.runtime = self.Runtime()

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True


class FakePerformanceSystem:
    def CreateStatsObjectTask(self, cluster):
        pass


class FakeConfigManager:
    def __init__(self):
        self.vsanSystem = None

    def UpdateVsan_Task(self, configInfo):
        pass


class FakeSi:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'


class FakeReconfigSpec:
    def __init__(self):
        self.dataEfficiencyConfig = None


class TestHandlerDeploy(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.args = {'vc_host': 'fake_host',
                 'vc_user': 'fake_user',
                 'vc_password': 'fake_password',
                 'vc_port': 443,
                 'vc_cluster': 'fake_cluster',
                 'is_all_flash': False,
                 'vsan_license': 'fake_licence',
                 'performance': 'False',
                 'storage_network_name': '', 'scaleout_hosts': '',
                 'vsan_disk_info': '',
                 'deduplication': True,
                 'fault_domain': 'f1:h1,h2 f2:h3',
                 'encryption': True
                }
        self.dh = VsanDeployHandler(self.args)


    def tearDown(self):
        """Cleaning up after the test"""
        del self.dh

    def get_fake_reconfigure_cluster_args(self):
        fake_hosts = []
        fake_host_props = {}
        for i in range(3):
            host = FakeHostSystem('h%s' % str(i + 1))
            fake_hosts.append(host)
            fake_host_props[host] = {
                'name': 'h%s' % str(
                    i + 1),
                'configManager.vsanSystem': FakeConfigManager()}

        fake_cluster = 'cluster_mo'
        fake_si = 'si'
        fake_ps = FakePerformanceSystem()
        fake_cs = FakeClusterSystem()
        return (
            fake_hosts, fake_host_props, fake_cluster,
            fake_si,
            fake_cs, fake_ps)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_license')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.validate_cluster_ha_settings')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler._prepare_diskmap')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.validate_host_settings')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.enable_network_adapter_for_vsan_service')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.reconfigure_cluster')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.activate_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.enable_vsan_performance_service')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.apply_vsan_license')
    def test_do(self,
                mock_apply,
                mock_performance,
                mock_activate,
                mock_reconfigure,
                mock_enable,
                mock_validate,
                mock_diskmodel,
                mock_ha,
                mock_host_props,
                mock_cluster,
                mock_license,
                mock_mos,
                mock_si):
        mock_si.return_value = (FakeSi(), 'context')
        mock_mos.return_value = {
            'vsan-cluster-config-system': 'vsan-cluster-config-system',
            'vsan-disk-management-system': 'vsan-disk-management-system',
            'vsan-performance-manager': 'vsan-performance-manager'}
        mock_license.return_value = 'fake_license'
        mock_cluster.return_value = FakeClusterSystem()
        mock_host_props.return_value = {'host1': 'host1', 'host2': 'host2'}
        mock_diskmodel.return_value = 'diskmodel'
        self.dh.do(self.args)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_enable_vsan_performance_service_pass(self, mock_log,
                                                  mock_wait_for_tasks):
        mock_wait_for_tasks.return_value = False
        _, _, cluster, si, _, ps = \
            self.get_fake_reconfigure_cluster_args()
        self.dh.performance = True
        self.dh.enable_vsan_performance_service(cluster, si, ps)
        mock_log.assert_called_with(
            "Enabled vSAN Performance service on the cluster.")

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_enable_vsan_performance_service_fail(self, mock_log_info,
                                                  mock_log,
                                                  mock_wait_for_tasks):
        mock_wait_for_tasks.side_effect = vmodl.MethodFault()
        _, _, cluster, si, _, ps = \
            self.get_fake_reconfigure_cluster_args()
        self.dh.performance = True
        with self.assertRaises(vsan_exc.VsanServiceException):
            self.dh.enable_vsan_performance_service(
                cluster,
                si, ps)
        mock_log.assert_called_with(
            "Error enabling vSAN performance service for cluster. Error: "
            "Unknown")

        mock_wait_for_tasks.side_effect = vim.fault.FileAlreadyExists()
        self.dh.enable_vsan_performance_service(cluster, si, ps)
        mock_log_info.assert_called_with(
            "vSAN Performance service is already enabled on this cluster, ignoring error!")

    @patch('lib.vsan.handlers.disk_validator.build_vCenter_diskmap')
    @patch('lib.vsan.handlers.disk_validator.get_system_diskmodel')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.'
           'query_vcenter_disks')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_prepare_diskmap_fail(self, mock_log,
                                  mock_query_vc_disks,
                                  mock_dm,
                                  mock_build_vc_dm):
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        mock_query_vc_disks.return_value = {
            'eligible': None,
            'ineligible': None
        }
        mock_dm.return_value = non_homogeneous_diskmodel
        with self.assertRaises(vsan_exc.VsanHostDiskHomogenityException):
            self.dh._prepare_diskmap(hosts, host_props)
        mock_log.assert_called_with("Host disks model are not homegenous")

    @patch('lib.vsan.handlers.disk_validator.build_vCenter_diskmap')
    @patch('lib.vsan.handlers.disk_validator.get_system_diskmodel')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.'
           'query_vcenter_disks')
    def test_prepare_diskmap_pass(self, mock_query_vc_disks,
                                  mock_dm, mock_build_vc_dm):
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        mock_query_vc_disks.return_value = {
            'eligible': None,
            'ineligible': None
        }
        mock_dm.return_value = homogeneous_diskmodel
        diskmodel = self.dh._prepare_diskmap(hosts, host_props)
        self.assertIsNotNone(diskmodel)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.vsan.'
           'DataEncryptionConfig')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VimClusterVsanFaultDomainsConfigSpec')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.cluster.'
           'VsanFaultDomainSpec')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VsanDataEfficiencyConfig')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VsanClusterConfigInfoHostDefaultInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.VsanClusterConfigInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.VimVsanReconfigSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_reconfigure_cluster(self, mock_log, mock_reconfig,
                                 mock_cluster_config_info,
                                 mock_cluster_config_info_host_default_info,
                                 mock_data_efficiency_config,
                                 mock_vsan_fault_domain_spec,
                                 mock_vsan_fault_domains_config_spec,
                                 mock_data_encryption_config,
                                 mock_wait):
        mock_reconfig.return_value = FakeReconfigSpec()
        mock_data_efficiency_config.return_value = 'data_efficiency_config'
        mock_vsan_fault_domain_spec.return_value = 'domain_spec'
        mock_vsan_fault_domains_config_spec.return_value = \
            'fault_domains_config_spec'
        mock_data_encryption_config.return_value = 'data_encryption_config'
        hosts, host_props, cluster, \
            si, cluster_system, _ = self.get_fake_reconfigure_cluster_args()
        self.dh.is_all_flash = True
        self.dh.reconfigure_cluster(hosts, host_props, cluster, si,
                                    cluster_system)
        mock_log.assert_called_with('vSAN cluster reconfigured successfully.')

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.vsan.'
           'DataEncryptionConfig')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VimClusterVsanFaultDomainsConfigSpec')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.cluster.'
           'VsanFaultDomainSpec')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VsanDataEfficiencyConfig')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.'
           'VsanClusterConfigInfoHostDefaultInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.VsanClusterConfigInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.vim.VimVsanReconfigSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_reconfigure_cluster_fail(self, mock_log, mock_reconfig,
                                 mock_cluster_config_info,
                                 mock_cluster_config_info_host_default_info,
                                 mock_data_efficiency_config,
                                 mock_vsan_fault_domain_spec,
                                 mock_vsan_fault_domains_config_spec,
                                 mock_data_encryption_config,
                                 mock_wait):
        mock_reconfig.return_value = FakeReconfigSpec()
        mock_data_efficiency_config.return_value = 'data_efficiency_config'
        mock_vsan_fault_domain_spec.return_value = 'domain_spec'
        mock_vsan_fault_domains_config_spec.return_value = \
            'fault_domains_config_spec'
        mock_data_encryption_config.return_value = 'data_encryption_config'
        mock_wait.side_effect = vmodl.MethodFault()
        hosts, host_props, cluster, \
            si, cluster_system, _ = self.get_fake_reconfigure_cluster_args()
        self.dh.is_all_flash = True
        with self.assertRaises(vsan_exc.VsanEnableOperationException):
            self.dh.reconfigure_cluster(hosts, host_props, cluster, si,
                                        cluster_system)
        mock_log.assert_called_with('vSAN cluster reconfiguration failed. '
                                    'Error: Unknown')

if __name__ == '__main__':
    unittest.main()
