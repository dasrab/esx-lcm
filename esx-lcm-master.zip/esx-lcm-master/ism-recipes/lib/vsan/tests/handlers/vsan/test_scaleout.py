# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import unittest
from mock import MagicMock, patch, call, Mock

from lib.vsan.handlers.vsan_lifecycle.scaleout import VsanScaleoutHandler
from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
from lib.vsan.common.exc import exceptions as vsan_exc
from lib.vsan.tests.handlers.vsan import fake_scaleout_objects as fakes


class FakeDiskManagementSystem:
    def __init__(self, diskgroups=1):
        self.diskgroups_count = diskgroups

    def QueryDiskMappings(self, host):
        diskmaps = []
        for i in range(self.diskgroups_count):
            diskmaps.append(self.diskmap())
        return diskmaps

    class diskmap:
        def __init__(self):
            self.mapping = self.mapping()

        class mapping:
            def __init__(self):
                self.ssd = self.ssd()
                self.nonSsd = [self.nonSsd()]

            class ssd:
                def __init__(self):
                    self.capacity = self.capacity()
                    self.uuid = "0000000000766d686261313a313a30"

                class capacity:
                    def __init__(self):
                        self.block = 83886080
                        self.blockSize = 512

            class nonSsd:
                def __init__(self):
                    self.capacity = self.capacity()
                    self.uuid = "0000000000766d686261313a323a30"

                class capacity:
                    def __init__(self):
                        self.block = 838860800
                        self.blockSize = 512


class FakeClusterSystem:
    def __init__(self):
        self.host = 'fake_host'


class FakeSi:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'


class FakeClusterCapacity:
            def __init__(self):
                self.capacity = 1000

            def fake_get_cluster_capacity(self, *args, **kwargs):
                self.capacity += 1
                return self.capacity


class FakeHostSystem():
    def __init__(self, host):
        self.name = host
        self.runtime = self.Runtime()

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True


class TestScaleoutHandler(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.args = {'vc_host': 'fake_host',
                     'vc_user': 'fake_user',
                     'vc_password': 'fake_password',
                     'vc_port': 443,
                     'vc_cluster': 'fake_cluster',
                     'is_all_flash': False,
                     'vsan_license': 'fake_licence',
                     'performance': 'False',
                     'storage_network_name': '',
                     'scaleout_hosts': ['172.18.200.221'],
                     'vsan_disk_info': ''}
        self.sh = VsanScaleoutHandler(self.args)

    def tearDown(self):
        del self.sh

    def test_check_max_host_limit_pass(self):
        esx_version = 6.5
        self.sh._check_max_host_limit(fakes.hosts, esx_version)
        self.assertEqual(self.sh.max_host_limit, 64)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_check_max_host_limit_fail(self, mock_log):
        esx_version = 7.5
        with self.assertRaises(vsan_exc.VsanHostLimitException):
            self.sh._check_max_host_limit(fakes.hosts,
                                              esx_version)
        mock_log.assert_called_with(
            "Cannot determine the maximum limit of hosts for cluster %s." %
            self.sh.vc_cluster)

        esx_version = 6.5
        fake_hosts = []
        for i in range(70):
            host = FakeHostSystem('h%s' % str(i + 1))
            fake_hosts.append(host)

        with self.assertRaises(vsan_exc.VsanHostLimitException):
            self.sh._check_max_host_limit(fake_hosts,
                                              esx_version)
        mock_log.assert_called_with(
            "Cannot perform scale out operation: Maximum limit of hosts "
            "in a cluster is %d." % self.sh.max_host_limit)

    @patch('lib.vsan.handlers.disk_validator.build_vCenter_diskmap')
    @patch('lib.vsan.handlers.disk_validator.get_system_diskmodel')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.query_vcenter_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanScaleoutHandler'
           '._reverse_engineer_diskmodel')
    def test_prepare_scaleout_vcenter_diskmap_homogenity_pass(
            self,
            mock_reverse_engineer_diskmodel,
            mock_query_vcenter_disks,
            mock_get_system_diskmodel,
            mock_build_vCenter_diskmap):
        disk_management_system = FakeDiskManagementSystem()
        self.sh.scaleout_hosts = ['172.18.200.221']
        self.sh.vsan_disk_info = {'172.18.200.221': {'logical_drives': [
            {
                "driveNumber": 1, "source": "bigbird", 'MediaType': 'HDD',
                'CapacityGB': 2000, 'Protocol': 'SATA',
                'VolumeUniqueIdentifier': 1, 'ControllerUri': 'u3'
            },
            {
                "driveNumber": 2, "source": "bigbird", 'MediaType': 'HDD',
                'CapacityGB': 2000, 'Protocol': 'SATA',
                'VolumeUniqueIdentifier': 2, 'ControllerUri': 'u3'
            },
            {
                "driveNumber": 3, "source": "local", 'MediaType': 'SSD',
                'CapacityGB': 1200, 'Protocol': 'SAS',
                'VolumeUniqueIdentifier': 3, 'ControllerUri': 'u3'
            }
        ]}}
        mock_reverse_engineer_diskmodel.return_value = \
            fakes.get_old_host_diskmodel()
        vc_diskmap = {
           'eligible': list(),
           'ineligible': list()
        }
        mock_query_vcenter_disks.return_value = vc_diskmap
        mock_get_system_diskmodel.return_value = fakes.\
            get_scaleout_host_diskmodel()
        mock_build_vCenter_diskmap.return_value = "diskmap"
        actual_diskmap = self.sh._prepare_scaleout_vcenter_diskmap(
            disk_management_system, fakes.hosts, fakes.host_props)
        expected_diskmap = fakes.diskmap
        self.assertEqual(actual_diskmap, expected_diskmap)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    @patch('lib.vsan.handlers.disk_validator.build_vCenter_diskmap')
    @patch('lib.vsan.handlers.disk_validator.get_system_diskmodel')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.query_vcenter_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanScaleoutHandler'
           '._reverse_engineer_diskmodel')
    def test_prepare_scaleout_diskmap_homogenity_fail(
            self,
            mock_reverse_engineer_diskmodel,
            mock_query_vcenter_disks,
            mock_get_system_diskmodel,
            mock_build_vCenter_diskmap, mock_log):
        dms = FakeDiskManagementSystem()
        self.sh.scaleout_hosts = ['172.18.200.221']
        self.sh.vsan_disk_info = {'172.18.200.221': {'logical_drives': [
            {
                "driveNumber": 1, "source": "bigbird", 'MediaType': 'HDD',
                'CapacityGB': 2000, 'Protocol': 'SATA',
                'VolumeUniqueIdentifier': 1, 'ControllerUri': 'u3'
            },
            {
                "driveNumber": 2, "source": "bigbird", 'MediaType': 'HDD',
                'CapacityGB': 2000, 'Protocol': 'SATA',
                'VolumeUniqueIdentifier': 2, 'ControllerUri': 'u3'
            },
            {
                "driveNumber": 3, "source": "local", 'MediaType': 'SSD',
                'CapacityGB': 1200, 'Protocol': 'SAS',
                'VolumeUniqueIdentifier': 3, 'ControllerUri': 'u3'
            }
        ]}}
        mock_reverse_engineer_diskmodel.return_value = \
            fakes.get_old_host_diskmodel(2)

        vc_diskmap = {
           'eligible': list(),
           'ineligible': list()
        }
        mock_query_vcenter_disks.return_value = vc_diskmap
        mock_get_system_diskmodel.return_value = \
            fakes.get_scaleout_host_diskmodel()
        mock_build_vCenter_diskmap.return_value = "diskmap"
        with self.assertRaises(vsan_exc.VsanHostDiskHomogenityException):
            self.sh._prepare_scaleout_vcenter_diskmap(dms,
                                                      fakes.hosts,
                                                      fakes.host_props)
        self.assertTrue(mock_log.called)

    def test_reverse_engineer_diskmodel(self):
        disk_management_system = FakeDiskManagementSystem()
        host = fakes.hosts[1]
        old_host_diskmodel = self.sh._reverse_engineer_diskmodel(
            disk_management_system, host, fakes.host_props, "hybrid")
        self.assertEqual(old_host_diskmodel,
                         fakes.get_old_host_diskmodel())

    def test_get_scaleout_hosts_pass(self):
        host = self.sh._get_scaleout_hosts(fakes.hosts,
                                           fakes.host_props)
        self.assertIsNotNone(host)

    def test_get_scaleout_hosts_fail(self):
        self.sh.scaleout_hosts = ['172.18.200.111']
        with self.assertRaises(vsan_exc.VsanHostException):
            self.sh._get_scaleout_hosts(fakes.hosts,
                                        fakes.host_props)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.is_vsan_enabled')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.get_cluster_capacity')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout'
           '.VsanScaleoutHandler._check_max_host_limit')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanScaleoutHandler'
           '._prepare_scaleout_vcenter_diskmap')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.validate_host_settings')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler.enable_network_adapter_for_vsan_service')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.activate_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.enable_vsan_performance_service')
    def test_do(self,
                mock_performance,
                mock_activate,
                mock_enable_nw,
                mock_validate,
                mock_diskmodel,
                mock_check_limit,
                mock_cluster_capacity,
                mock_vsan_enabler,
                mock_host_props,
                mock_cluster,
                mock_mos,
                mock_si):
        mock_si.return_value = (FakeSi(), 'context')
        mock_mos.return_value = {
            'vsan-disk-management-system': 'vsan-disk-management-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system',
            'vsan-cluster-config-system': 'vsan-cluster-config-system'}
        mock_cluster.return_value = FakeClusterSystem()
        mock_host_props.return_value = fakes.host_props
        mock_vsan_enabler.return_value = True
        mock_cluster_capacity.return_value = 12345
        mock_diskmodel.return_value = fakes.diskmap
        fake_capacity = FakeClusterCapacity()
        with patch.object(self.sh, 'get_cluster_capacity',
                          new=fake_capacity.fake_get_cluster_capacity):
            status, err_msg = self.sh.do(self.args)
            self.assertTrue(status)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.collect_host_properties')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.is_vsan_enabled')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.get_cluster_capacity')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout'
           '.VsanScaleoutHandler._check_max_host_limit')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanScaleoutHandler'
           '._prepare_scaleout_vcenter_diskmap')
    @patch('lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler'
           '.validate_host_settings')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.scaleout.VsanLifecycleHandler.enable_network_adapter_for_vsan_service')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanLifecycleHandler.activate_disks')
    @patch('lib.vsan.handlers.vsan_lifecycle.deploy.VsanDeployHandler.enable_vsan_performance_service')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.process_disk_cleanup')
    def test_do_fail(self,
                     mock_process_disk_cleanup,
                     mock_performance,
                     mock_activate,
                     mock_enable_nw,
                     mock_validate,
                     mock_diskmodel,
                     mock_check_limit,
                     mock_cluster_capacity,
                     mock_vsan_enabler,
                     mock_host_props,
                     mock_cluster,
                     mock_mos,
                     mock_si):
        mock_process_disk_cleanup.return_value = None
        mock_si.return_value = (FakeSi(), 'context')
        mock_mos.return_value = {
            'vsan-disk-management-system': 'vsan-disk-management-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system',
            'vsan-cluster-config-system': 'vsan-cluster-config-system'}
        mock_cluster.return_value = FakeClusterSystem()
        mock_host_props.return_value = fakes.host_props
        mock_vsan_enabler.return_value = True
        mock_cluster_capacity.side_effect = 12345
        mock_diskmodel.return_value = fakes.diskmap
        mock_enable_nw.side_effect = vsan_exc.VsanNetworkException(msg='')
        status, err_msg = self.sh.do(self.args)
        self.assertFalse(status)


if __name__ == '__main__':
    unittest.main()

