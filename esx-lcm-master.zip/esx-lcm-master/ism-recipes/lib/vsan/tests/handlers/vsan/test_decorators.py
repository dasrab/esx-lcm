# (c) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest

from lib.vsan.handlers.vsan_lifecycle.decorators import disk_cleanup


class FakeLogger:
    def __init__(self):
        self.error_msg = ''

    def error(self, msg):
        self.error_msg = msg


class FakeHandler:
    def __init__(self):
        self.process_disk_cleanup_called = False
        self.LOG = FakeLogger()

    def process_disk_cleanup(self):
        self.process_disk_cleanup_called = True

    @disk_cleanup
    def do_success(self):
        return True, ''

    @disk_cleanup
    def do_fail(self, msg):
        return False, msg


class TestDecorators(unittest.TestCase):
    def setUp(self):
        self.handler = FakeHandler()

    def test_disk_cleanup_success(self):
        self.handler.do_success()
        self.assertFalse(self.handler.process_disk_cleanup_called)
        self.assertEqual(self.handler.LOG.error_msg, '')

    def test_disk_cleanup_fail(self):
        msg = 'Fake exception occurred.'
        self.handler.do_fail(msg)
        self.assertTrue(self.handler.process_disk_cleanup_called)
        self.assertEqual(self.handler.LOG.error_msg,
                         "Encountered exception: %s" % msg)
