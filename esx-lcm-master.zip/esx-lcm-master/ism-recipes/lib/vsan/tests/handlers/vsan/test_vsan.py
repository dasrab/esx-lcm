# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import unittest
from pyVmomi import vim, vmodl
from mock import MagicMock, patch, call, Mock

from lib.vsan.handlers.vsan_lifecycle.vsan import VsanLifecycleHandler
import lib.vsan.common.exc.exceptions as vsan_exc


class FakeClusterSystem:
    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class VsanClusterGetConfig:
        def __init__(self, cluster):
            if cluster == 'cluster_mo':
                self.enabled = True
            else:
                self.enabled = False


class FakeCluster:
    def __init__(self):
        self.name = 'Fake_cluster'
        self._moId = '_moId'
        self.configurationEx = self.configurationEx()
        self.host = []

    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class configurationEx:
        def __init__(self):
            self.dasConfig = self.dasConfig()

        class dasConfig:
            def __init__(self):
                self.enabled = False


class FakeConfigManager:
    def __init__(self):
        self.vsanSystem = None

    def UpdateVsan_Task(self, configInfo):
        pass

    def RemoveDiskMapping_Task(self, dgm, rdm_spec, n):
        pass

    def QueryDisksForVsan(self):
        disks = list()
        disks.append(FakeConfigManager.Disk('eligible', 'disk1'))
        disks.append(FakeConfigManager.Disk('ineligible','disk2'))
        return disks

    class Disk:
        def __init__(self, state, name):
            self.state = state
            self.disk = self.ssd(name)

        class ssd:
            def __init__(self, name):
                self.displayName = name
                self.capacity = self.capacity()
                self.uuid = "0000000000766d686261313a313a30"

            class capacity:
                def __init__(self):
                    self.block = 83886080
                    self.blockSize = 512


class FakeSsd:
    def __init__(self, name):
        self.displayName = name
        self.capacity = self.capacity()
        self.uuid = "0000000000766d686261313a313a30"

    class capacity:
        def __init__(self):
            self.block = 83886080
            self.blockSize = 512


class FakePerformanceSystem:
    def CreateStatsObjectTask(self, cluster):
        pass


class FakeHostSystem():
    def __init__(self, host):
        self.name = host
        self.runtime = self.Runtime()
        self.hardware = self.Hardware()
        self.config = self.HostConfig()
        self.network = [FakeHostSystem.Network('Mgmt', 'swuuid1'),
                        FakeHostSystem.Network('vsan_net', 'swuuid2'),
                        FakeHostSystem.Network('vmotion_net', 'swuuid3')]

    class Runtime:
        def __init__(self):
            self.inMaintenanceMode = True

    class Hardware:
        def __init__(self):
            self.memorySize = 123123123123123

    class Network:
        def __init__(self, name, switch_uuid):
            self.name = name
            self.config = FakeHostSystem.NetworkConfig(switch_uuid)

    class NetworkConfig:
        def __init__(self, switch_uuid):
            self.distributedVirtualSwitch = \
                FakeHostSystem.DVSwitch(switch_uuid)

    class DVSwitch:
        def __init__(self, switch_uuid):
            self.uuid = switch_uuid

    class HostConfig:
        def __init__(self):
            self.network = FakeHostSystem.ConfigNetwork()

    class ConfigNetwork:
        def __init__(self):
            self.vnic = [FakeHostSystem.Vnic(i) for i in range(3)]

    class Vnic:
        def __init__(self, switch_uuid):
            self.spec = FakeHostSystem.VnicSpec('swuuid%d' % switch_uuid)
            self.device = 'vmk%d' % switch_uuid

    class VnicSpec:
        def __init__(self, switch_uuid):
            self.distributedVirtualPort = FakeHostSystem.DVPort(switch_uuid)

    class DVPort:
        def __init__(self, switch_uuid):
            self.switchUuid = switch_uuid


class FakeDiskManagementSystem:
    def __init__(self, diskgroups=1):
        self.diskgroups_count = diskgroups

    def QueryDiskMappings(self, host):
        diskmaps = []
        for i in range(self.diskgroups_count):
            diskmaps.append(self.diskmap())
        return diskmaps

    def InitializeDiskMappings(self, dm):
        pass

    class diskmap:
        def __init__(self):
            self.mapping = self.mapping()

        class mapping:
            def __init__(self):
                self.ssd = self.ssd()
                self.nonSsd = [self.nonSsd()]

            class ssd:
                def __init__(self):
                    self.capacity = self.capacity()
                    self.uuid = "0000000000766d686261313a313a30"
                    self.displayName = "0000000000766d686261313a313a30"

                class capacity:
                    def __init__(self):
                        self.block = 83886080
                        self.blockSize = 512

            class nonSsd:
                def __init__(self):
                    self.capacity = self.capacity()
                    self.uuid = "0000000000766d686261313a323a30"
                    self.displayName = "0000000000766d686261313a313a30"

                class capacity:
                    def __init__(self):
                        self.block = 838860800
                        self.blockSize = 512


class FakeSpaceReportSystem:
    class QuerySpaceUsage:
        def __init__(self, cluster):
            self.totalCapacityB = 12345


class FakeSi:
    def __init__(self):
        self._stub = 'fake_stub'
        self.content = 'fake_content'


class FakeCleaner:
    def __init__(self, goodboy, args=dict()):
        self.goodboy = goodboy

    def clean(self, cluster=None, host_list=[]):
        if not self.goodboy:
            raise vsan_exc.VsanHostDiskCleanUpException(msg='Failed')


class FakeHostcleaner:
    def __init__(self, raise_exc=False):
        self.raise_exc = raise_exc

    def clean(self, cluster, hosts):
        if self.raise_exc:
            raise Exception


class TestHandlerVsan(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.args = {'vc_host': 'fake_host',
                 'vc_user': 'fake_user',
                 'vc_password': 'fake_password',
                 'vc_port': 443,
                 'vc_cluster': 'fake_cluster',
                 'is_all_flash': False,
                 'vsan_license': 'fake_licence',
                 'storage_network_name': 'vsan_net',
                 'scaleout_hosts': '',
                 'vsan_disk_info': '',
                 'force_delete': False}
        self.vsan = VsanLifecycleHandler(self.args)


    def tearDown(self):
        """Cleaning up after the test"""
        del self.vsan

    def get_fake_reconfigure_cluster_args(self):
        fake_hosts = []
        fake_host_props = {}
        for i in range(3):
            host = FakeHostSystem('h%s' % str(i + 1))
            fake_hosts.append(host)
            fake_host_props[host] = {
                'name': 'h%s' % str(
                    i + 1),
                'configManager.vsanSystem': FakeConfigManager()}

        fake_cluster = 'cluster_mo'
        fake_si = 'si'
        fake_ps = FakePerformanceSystem()
        fake_cs = FakeClusterSystem()
        return (
            fake_hosts, fake_host_props, fake_cluster,
            fake_si,
            fake_cs, fake_ps)

    def test_validate_cluster_ha_settings_pass(self):
        cluster = FakeCluster()
        success = self.vsan.validate_cluster_ha_settings(cluster)
        self.assertEqual(success, None)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_validate_cluster_ha_settings_fail(self, mock_log):
        cluster = FakeCluster()
        cluster.configurationEx.dasConfig.enabled = True
        with self.assertRaises(vsan_exc.VsanCheckClusterHaException):
            self.vsan.validate_cluster_ha_settings(cluster)
        self.assertTrue(mock_log.called)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler._fetch_vsan_nic')
    def test_enable_network_adapter_for_vsan_service_pass(self,
                                                          mock_fetch_vsan_nic,
                                                          mock_wait_for_tasks):
        mock_fetch_vsan_nic.return_value = ['vmk0']
        mock_wait_for_tasks.return_value = False
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        success = self.vsan.enable_network_adapter_for_vsan_service(
            hosts, host_props, si)
        self.assertIsNone(success)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler._fetch_vsan_nic')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_enable_network_adapter_for_vsan_service_multi_net_pass(self,
                                                                    mock_log,
                                                                    mock_fetch,
                                                                    mock_wait):
        mock_wait.return_value = False
        vsan_nic = ['vmk0', 'vmk1']
        mock_fetch.return_value = vsan_nic
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        success = \
            self.vsan.enable_network_adapter_for_vsan_service(hosts,
                                                                  host_props,
                                                                  si)
        self.assertIsNone(success)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler._fetch_vsan_nic')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_enable_network_adapter_for_vsan_service_fail_no_net(self,
                                                                 mock_log,
                                                                 mock_fetch,
                                                                 mock_wait):
        mock_wait.side_effect = vmodl.MethodFault()
        vsan_nic = []
        mock_fetch.return_value = vsan_nic
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        with self.assertRaises(vsan_exc.VsanNetworkException):
            self.vsan.enable_network_adapter_for_vsan_service(
                hosts,
                host_props, si)
        mock_log.assert_called_with("VMkernel adapter interface does not meet "
                                    "vSAN requirement, discovered nics count "
                                    "= 0")


    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler._fetch_vsan_nic')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_enable_network_adapter_for_vsan_service_fail(self, mock_log,
                                                          mock_fetch_vsan_nic,
                                                          mock_wait_for_tasks):
        mock_wait_for_tasks.side_effect = vmodl.MethodFault()
        vsan_nic = ['vmk0']
        mock_fetch_vsan_nic.return_value = vsan_nic
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        with self.assertRaises(vsan_exc.VsanNetworkException):
            self.vsan.enable_network_adapter_for_vsan_service(
                hosts,
                host_props, si)
        mock_log.assert_called_with("Failed to enable kernel adapter for one "
                                    "of nic in '%s' Error information: Unknown"
                                    % vsan_nic)
    def test_is_vsan_enabled_pass(self):
        fake_cluster = 'cluster_mo'
        fake_cs = FakeClusterSystem()
        self.assertTrue(self.vsan.is_vsan_enabled(fake_cluster, fake_cs))

    def test_is_vsan_enabled_false(self):
        fake_cluster = 'false_cluster_mo'
        fake_cs = FakeClusterSystem()
        self.assertFalse(self.vsan.is_vsan_enabled(fake_cluster, fake_cs))

    def test_check_hosts_in_maintenance_mode_pass(self):
        host1 = FakeHostSystem('host1')
        host2 = FakeHostSystem('host2')
        success = \
            self.vsan.check_hosts_in_maintenance_mode([host1, host2, ])
        self.assertIsNone(success)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_check_hosts_in_maintenance_mode_fail(self, mock_log):
        host1 = FakeHostSystem('host1')
        host2 = FakeHostSystem('host2')
        host1.runtime.inMaintenanceMode = False
        with self.assertRaises(vsan_exc.VsanHostException):
            self.vsan.check_hosts_in_maintenance_mode([host1, host2, ])
        mock_log.assert_called_with(
            "Host (%s) of vSAN cluster is not in "
            "maintenance mode." %
            host1.name)

    def test_get_cluster_capacity(self):
        cluster = 'cluster_mo'
        space_system = FakeSpaceReportSystem()
        capacity = self.vsan.get_cluster_capacity(cluster, space_system)
        self.assertEqual(capacity, 12345)

    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_host_cleaner')
    def test_process_disk_cleanup_pass(self,
                                       mock_get_host_cleaner):
        mocked_cleaner = FakeCleaner(True)
        mock_get_host_cleaner.return_value = mocked_cleaner
        self.vsan.process_disk_cleanup()

    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_host_cleaner')
    def test_process_disk_cleanup_failed(self,
                                         mock_fake_cleaner):
        mock_fake_cleaner.return_value = FakeCleaner(False)
        with self.assertRaises(vsan_exc.VsanHostDiskCleanUpException):
            self.vsan.process_disk_cleanup()

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch(
        'lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_capacity')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_health')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_disconnected_hosts')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_vsan_version_status')
    def test_collect_cluster_info(self, mock_version_status, mock_failed_hosts,
                                  mock_health, mock_capacity, mock_cluster,
                                  mock_mangaged_obj, mock_si):
        mock_si.return_value = (FakeSi(), 'fake_context')
        mock_mangaged_obj.return_value = {
            'vsan-cluster-health-system': 'vsan-cluster-health-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system'}
        mock_cluster.return_value = 'fake_cluster'
        mock_capacity.return_value = '1234'
        mock_health.return_value = 'fake_health'
        mock_failed_hosts.return_value = ""
        mock_version_status.return_value = False
        cluster_info = self.vsan.collect_cluster_info(self.args)
        self.assertTrue(cluster_info)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch(
        'lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_capacity')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_health')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_disconnected_hosts')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_vsan_version_status')
    def test_collect_cluster_info_failed_api_data(self,
                                                  mock_version_status,
                                                  mock_failed_hosts,
                                                  mock_health,
                                                  mock_capacity,
                                                  mock_cluster,
                                                  mock_mangaged_obj,
                                                  mock_si):
        mock_si.return_value = (FakeSi(), 'fake_context')
        mock_mangaged_obj.return_value = {
            'vsan-cluster-health-system': 'vsan-cluster-health-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system'}
        mock_cluster.return_value = 'fake_cluster'
        mock_capacity.return_value = '1234'
        mock_health.return_value = 'fake_health'
        mock_failed_hosts.return_value = "host1"
        mock_version_status.return_value = True
        cluster_info = self.vsan.collect_cluster_info(self.args)
        self.assertTrue(cluster_info)
        self.assertEquals(cluster_info['vsan_host_connecitivity_status'],
                          False)
        self.assertEquals(cluster_info['vsan_version_compliant_flag'], False)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.connect')
    @patch('lib.vsan.utils.vcenter.vCenterUtils.get_vsan_managed_objects')
    @patch(
        'lib.vsan.utils.vcenter.vCenterUtils.get_cluster_instance')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_capacity')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_cluster_health')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_disconnected_hosts')
    @patch(
        'lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.get_vsan_version_status')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_collect_cluster_info_fail(self, mock_log,
                                       mock_version_status,
                                       mock_failed_hosts,
                                       mock_health,
                                       mock_capacity,
                                       mock_cluster,
                                       mock_mangaged_obj,
                                       mock_si):
        mock_si.side_effect = vmodl.fault.SystemError()
        mock_mangaged_obj.return_value = {
            'vsan-cluster-health-system': 'vsan-cluster-health-system',
            'vsan-cluster-space-report-system': 'vsan-cluster-space-report-system'}
        mock_cluster.return_value = 'fake_cluster'
        mock_capacity.return_value = '1234'
        mock_health.return_value = 'fake_health'
        mock_failed_hosts.return_value = ""
        mock_version_status.return_value = False
        with self.assertRaises(vsan_exc.VsanClusterCollectInfoException):
            self.vsan.collect_cluster_info(self.args)
        mock_log.assert_called_with(
            "Error while collecting %s cluster info cluster." %
            self.args['vc_cluster'])

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.vsan.host.ConfigInfo.NetworkInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.vsan.host.ConfigInfo')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_disable_vsan_traffic(self, mock_log, mock_config, mock_nw_info,
                                  mock_wait):
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        success = self.vsan.disable_vsan_traffic(si, hosts, host_props)
        self.assertIsNone(success)
        mock_log.assert_called_with(
            "Successfully disabled vSAN service and "
            "vSAN traffic on host %s." % hosts[2].name)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.vsan.host.ConfigInfo.NetworkInfo')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.vsan.host.ConfigInfo')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_disable_vsan_traffic_fail(self, mock_log, mock_config,
                                       mock_nw_info,
                                       mock_wait):
        mock_wait.side_effect = vmodl.MethodFault()
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        with self.assertRaises(vsan_exc.VsanDeleteException):
            self.vsan.disable_vsan_traffic(si, hosts, host_props)
        mock_log.assert_called_with(
            "Failed to disable vSAN service on host %s . Error: Unknown"
            % hosts[0].name)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.host.MaintenanceSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_remove_disk_mappings(self, mock_log, mock_maintainence_spec,
                                  mock_wait):
        fake_dms = FakeDiskManagementSystem()
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        success = self.vsan.remove_disk_mappings(si, fake_dms, hosts,
                                                 host_props)
        self.assertIsNone(success)
        mock_log.assert_called_with("Successfully removed the disk mappings "
                                    "for all the hosts.")

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.host.MaintenanceSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_remove_disk_mappings_fail(self, mock_log, mock_maintainence_spec,
                                       mock_wait):
        mock_wait.side_effect = vmodl.MethodFault()
        fake_dms = FakeDiskManagementSystem()
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        with self.assertRaises(vsan_exc.VsanHostDiskRemoveException):
            self.vsan.remove_disk_mappings(si, fake_dms, hosts, host_props)
        mock_log.assert_called_with(
            "Failed to remove disk mappings for host %s . Error: Unknown"
            % hosts[0].name)

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.host.MaintenanceSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_remove_disk_mappings_force_delete(self, mock_log,
                                               mock_maintainence_spec,
                                               mock_wait):
        self.vsan.force_delete = True
        mock_wait.side_effect = vmodl.MethodFault()
        fake_dms = FakeDiskManagementSystem()
        hosts, host_props, _, si, _, _ = \
            self.get_fake_reconfigure_cluster_args()

        status = self.vsan.remove_disk_mappings(si, fake_dms, hosts,
                                                host_props)
        self.assertIsNone(status)
        mock_log.assert_called_with(
            "Failed to remove disk mappings for host %s . Error: Unknown"
            % hosts[len(hosts)-1].name)
        self.assertEqual(mock_log.call_count, len(hosts))

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.warning")
    def test_validate_memory_settings_warn(self, mock_log):
        host = FakeHostSystem('h1')
        host.hardware.memorySize = 123
        success = self.vsan._validate_memory_settings(host, '200GiB', 4,
                                                        dg_count=1)
        self.assertTrue(success, "Memory validation should pass for the host")
        self.assertTrue(mock_log.called)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.warning")
    def test_validate_memory_settings_not_warn(self, mock_log):
        host = FakeHostSystem('h1')
        success = self.vsan._validate_memory_settings(host, '200GiB', 4,
                                                        dg_count=1)
        self.assertTrue(success, "Memory validation should pass for the host")
        self.assertFalse(mock_log.called)

    def test_fetch_vsan_nic_single(self):
        host = FakeHostSystem('h1')
        vnics = self.vsan._fetch_vsan_nic(host)
        expected_vnic = ['vmk2']
        self.assertEqual(vnics, expected_vnic)

    def test_fetch_vsan_nic_none(self):
        host = FakeHostSystem('h1')
        self.vsan.storage_network_name = 'no_such_net'
        vnics = self.vsan._fetch_vsan_nic(host)
        self.assertEqual(len(vnics), 0)

    def test_fetch_vsan_nic_multiple(self):
        host = FakeHostSystem('h1')
        vnic0 = host.config.network.vnic[0]
        vnic2 = host.config.network.vnic[2]
        # define multiple vnics for a DVS.
        vnic0.spec.distributedVirtualPort.switchUuid = \
            vnic2.spec.distributedVirtualPort.switchUuid
        expected_vnics = ['vmk0', 'vmk2']
        vnics = self.vsan._fetch_vsan_nic(host)
        self.assertEqual(vnics, expected_vnics)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_ensure_disk_groups(self, mock_log):
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        fake_dms = FakeDiskManagementSystem()
        success = self.vsan._ensure_disk_groups(hosts, fake_dms, host_props)
        self.assertIsNone(success)
        self.assertTrue(mock_log.called)

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_ensure_disk_groups_fail(self, mock_log):
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        fake_dms = FakeDiskManagementSystem(0)
        with self.assertRaises(vsan_exc.VsanDiskGroupException):
            self.vsan._ensure_disk_groups(hosts, fake_dms, host_props)
        mock_log.assert_called_with("Failed to create Disk group(s)!")

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.'
           'VimVsanHostDiskMappingCreationSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_claim_disks(self, mock_log, mock_dm_creation_spec, mock_wait):
        vc_dm = [{'node': 'h1', 'host_ref': None,
                  'device_groups': [
                      {'vcenter_diskmap': {'cache': '', 'capacity': ''}}]}]
        fake_dms = FakeDiskManagementSystem()
        self.vsan._claim_disks(vc_dm, fake_dms, 'si')
        mock_log.assert_called_with("Initialized disk mappings successfully.")

    @patch('lib.vsan.utils.vcenter.vCenterUtils.wait_for_tasks')
    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.vim.'
           'VimVsanHostDiskMappingCreationSpec')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_claim_disks_fail(self, mock_log, mock_dm_creation_spec,
                                       mock_wait):
        mock_wait.side_effect = vmodl.MethodFault()
        vc_dm = [{'node': 'h1', 'host_ref': None,
                  'device_groups': [
                      {'vcenter_diskmap': {'cache': '', 'capacity': ''}}]}]
        fake_dms = FakeDiskManagementSystem()
        with self.assertRaises(vsan_exc.VsanDiskGroupException):
            self.vsan._claim_disks(vc_dm, fake_dms, 'si')
        mock_log.assert_called_with("Error creating disk group. Error: "
                                    "Unknown")

    def test_query_vcenter_disks(self):
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()
        dm = self.vsan.query_vcenter_disks(hosts, host_props)
        self.assertEquals(len(dm['eligible']), 3)
        self.assertEquals(len(dm['ineligible']), 3)

    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           '_validate_memory_settings')
    def test_validate_host_settings(self, mock_mem_settings):
        mock_mem_settings.return_value = True
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()

        vc_diskmodel = [
            {
                'node': '172.18.200.221',
                'host_ref': hosts[0],
                'device_groups': [
                    {'vcenter_diskmap': {'cache': [FakeSsd('ssd1')]},
                     'name': 'device-group-0',
                     'devices': [
                         {'type': 'ssd',
                          'id': '0000000000766d686261313a313a30',
                          'size': 42949672960
                          },
                         {'type': 'hdd',
                          'id': '0000000000766d686261313a323a30',
                          'size': 429496729600
                          }
                    ],
                        'total_raw_capacity': 429496729600,
                        'total_cache_capacity': 42949672960,
                        'cache_device_id': '0000000000766d686261313a313a30'
                    }
                ]
            }
        ]
        success = self.vsan.validate_host_settings(hosts, host_props,
                                                   vc_diskmodel)
        self.assertIsNone(success)

    @patch('lib.vsan.handlers.vsan_lifecycle.vsan.VsanLifecycleHandler.'
           '_validate_memory_settings')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_validate_host_settings(self, mock_log, mock_mem_settings):
        mock_mem_settings.return_value = False
        hosts, host_props, _, _, _, _ = \
            self.get_fake_reconfigure_cluster_args()

        vc_diskmodel = [
            {
                'node': '172.18.200.221',
                'host_ref': hosts[0],
                'device_groups': [
                    {'vcenter_diskmap': {'cache': [FakeSsd('ssd1')]},
                     'name': 'device-group-0',
                     'devices': [
                         {'type': 'ssd',
                          'id': '0000000000766d686261313a313a30',
                          'size': 42949672960
                          },
                         {'type': 'hdd',
                          'id': '0000000000766d686261313a323a30',
                          'size': 429496729600
                          }
                    ],
                        'total_raw_capacity': 429496729600,
                        'total_cache_capacity': 42949672960,
                        'cache_device_id': '0000000000766d686261313a313a30'
                    }
                ]
            }
        ]

        with self.assertRaises(vsan_exc.VsanHostException):
            self.vsan.validate_host_settings(hosts, host_props, vc_diskmodel)
        mock_log.assert_called_with("Hosts h1, h2, h3 do not meet vSAN "
                                    "requirement.")

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.info")
    def test_ensure_clean_disks(self, mock_log):
        diskmap = {
            FakeHostSystem('h1'): ['disk1', 'disk2']
        }
        wipe_disks = True
        host_cleaner = FakeHostcleaner()
        success = self.vsan.ensure_clean_disks(diskmap, wipe_disks,
                                               host_cleaner)
        self.assertIsNone(success)
        mock_log.assert_called_with("Disk clean up completed.")

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_ensure_clean_disks_wipe_disks_fail(self, mock_log):
        diskmap = {
            FakeHostSystem('h1'): ['disk1', 'disk2']
        }
        wipe_disks = True
        host_cleaner = FakeHostcleaner(raise_exc=True)
        with self.assertRaises(Exception):
            self.vsan.ensure_clean_disks(diskmap, wipe_disks, host_cleaner)
        mock_log.assert_called_with("Error wiping disk(s): ")

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_ensure_clean_disks_fail(self, mock_log):
        diskmap = {
            FakeHostSystem('h1'): ['disk1', 'disk2']
        }
        wipe_disks = False
        host_cleaner = FakeHostcleaner()
        with self.assertRaises(vsan_exc.VsanHostUncleanDiskException):
            self.vsan.ensure_clean_disks(diskmap, wipe_disks, host_cleaner)
        mock_log.assert_called_with('Found some disks with existing data on '
                                    'hosts (h1). The disks need a clean up to '
                                    'be eligible for consumption.')


if __name__ == '__main__':
    unittest.main()

