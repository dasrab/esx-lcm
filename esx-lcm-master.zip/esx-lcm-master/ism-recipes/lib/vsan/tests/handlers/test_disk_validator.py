#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#
import unittest

from lib.vsan.handlers import disk_validator as dv
from lib.vsan.common.exc import exceptions as exc
from lib.vsan.tests.handlers import fake_disk_validator_objects as fakes

expected_hybrid_diskmodel = [
    {
        'node': '172.18.200.23',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size':
                        10000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '1', 'size':
                        20000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '2', 'size':
                        20000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    },
    {
        'node': '172.18.200.245',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size':
                        10000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '1', 'size':
                        20000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '2', 'size':
                        20000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    },
    {
        'node': '172.18.200.244',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '1', 'size': 20000L * fakes.MUL_FACTOR},
                    {'type': 'hdd', 'id': '2', 'size': 20000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    }
]

expected_flash_diskmodel = [
    {
        'node': '172.18.200.23',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size': 1000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '0', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '1', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '2', 'size': 10000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    },
    {
        'node': '172.18.200.245',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size': 1000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '0', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '1', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '2', 'size': 10000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    },
    {
        'node': '172.18.200.244',
        'host_ref': None,
        'device_groups': [
            {
                'devices': [
                    {'type': 'ssd', 'id': '3', 'size': 1000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '0', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '1', 'size': 10000L * fakes.MUL_FACTOR},
                    {'type': 'ssd', 'id': '2', 'size': 10000L * fakes.MUL_FACTOR}
                ],
                'name': 'dg_group_0',
                'cache_device_id': '3'
            }
        ]
    }
]


class TestDiskModel(unittest.TestCase):

    def setUp(self):
        self.vc_hybrid_diskmap = fakes.query_vcenter_disks_for_hybrid(3)
        (self.vc_flash_diskmap, self.vsan_flash_disk_info) = \
            fakes.query_vcenter_disks_for_flash(3)
        self.hostprops = fakes.get_hostprops()
        self.vsan_disk_info = fakes.get_vsan_disk_info()

    def test_get_system_diskmodel_hybrid(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        self.assertEqual(diskmodel, expected_hybrid_diskmodel,
                         "Hybrid diskmodel template is not generated as expected")

    def test_get_system_diskmodel_hybrid_multi_dgs(self):
        vc_diskmap = fakes.query_vcenter_disks_hybrid_multi_dgs()
        diskmodel = \
            dv.populate_multi_dgs_model(vc_diskmap,
                                        self.hostprops,
                                        self.vsan_disk_info)
        self.assertEqual(len(diskmodel[0]['device_groups']), 3)

    def test_get_system_diskmodel_hybrid_without_ssd_disks(self):
        vc_diskmap = fakes.query_vcenter_disks_for_hybrid_without_ssd(3)
        with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                     "Disk group must have ONE SSD disk"):
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)

    def test_get_system_diskmodel_flash(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        self.assertEqual(diskmodel, expected_flash_diskmodel,
                         "Flash diskmodel template is not generated as expected")

    def test_get_system_diskmodel_multiple_dg_flash(self):
        vc_flash_diskmap = fakes.query_vcenter_disks_flash_multi_dgs()
        diskmodel = \
            dv.get_system_diskmodel(vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        self.assertEqual(len(diskmodel[0]['device_groups']), 3)
        self.assertEqual(len(diskmodel[0]['device_groups'][0]['devices']), 4)
        self.assertEqual(len(diskmodel[0]['device_groups'][1]['devices']), 4)
        self.assertEqual(len(diskmodel[0]['device_groups'][2]['devices']), 5)

    def test_process_host_dg_sanity_for_hybrid_success(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            self.assertEqual(len(diskmodel[0]['device_groups']), 1)
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_cache_capacity'],
                10000L * fakes.MUL_FACTOR)
            self.assertEqual(
                host_diskmodel['device_groups'][0]['name'], 'dg_group_0')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['cache_device_id'], '3')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_raw_capacity'],
                40000L * fakes.MUL_FACTOR)

    def test_process_host_dg_sanity_multiple_hybrid_success(self):
        vc_diskmap = fakes.query_vcenter_disks_hybrid_multi_dgs()
        diskmodel = \
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            self.assertEqual(
                len(host_diskmodel['device_groups'][0]['devices']), 4)
            self.assertEqual(
                len(host_diskmodel['device_groups'][1]['devices']), 4)
            self.assertEqual(
                len(host_diskmodel['device_groups'][2]['devices']), 5)
            self.assertEqual(len(host_diskmodel['device_groups']), 3)
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_cache_capacity'],
                10000L * fakes.MUL_FACTOR)
            self.assertEqual(
                host_diskmodel['device_groups'][0]['name'], 'dg_group_0')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['cache_device_id'], 'ssd-0')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_raw_capacity'],
                60000L * fakes.MUL_FACTOR)

    def test_process_host_dg_sanity_for_flash_success(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "allFlash")
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_cache_capacity'],
                1000L * fakes.MUL_FACTOR)
            self.assertEqual(
                host_diskmodel['device_groups'][0]['name'], 'dg_group_0')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['cache_device_id'], '3')
            self.assertEqual(
                host_diskmodel['device_groups'][0]['total_raw_capacity'],
                30000L * fakes.MUL_FACTOR)

    def test_compare_dg_homogenity_hybrid_success(self):
        vc_diskmap = fakes.query_vcenter_disks_hybrid_multi_dgs()
        diskmodel = \
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        first_host_dgs = None
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            if first_host_dgs == None:
                first_host_dgs = host_diskmodel['device_groups']
            else:
                result = \
                    dv.compare_dg_homogenity(first_host_dgs, curr_host_dgs)
                self.assertTrue(result, "Host disks model are not homegenous")

    def test_compare_dg_homogenity_with_different_dg_count(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        first_host_dgs = None
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            if first_host_dgs == None:
                first_host_dgs = host_diskmodel['device_groups']
            else:
                # change the reference groups for failure scenario
                curr_host_dgs.append(host_diskmodel['device_groups'])
                result = \
                    dv.compare_dg_homogenity(first_host_dgs, curr_host_dgs)
                self.assertFalse(result, "Host disks model are not homegenous")

    def test_compare_dg_homogenity_with_different_dgs(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        first_host_dgs = None
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            if first_host_dgs == None:
                first_host_dgs = host_diskmodel['device_groups']
            else:
                curr_host_dgs[0]['total_raw_capacity'] = 1234
                result = \
                    dv.compare_dg_homogenity(first_host_dgs, curr_host_dgs)
                self.assertFalse(result, "Host disks model are not homegenous")

    def test_build_vCenter_diskmap_hybrid_success(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        host_dict = {'172.18.200.245': 'vim.HostSystem:host-194',
                     '172.18.200.244': 'vim.HostSystem:host-192',
                     '172.18.200.23': 'vim.HostSystem:host-186'}
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "hybrid")
            hdm['host_ref'] = host_dict[hdm['node']]
            dv.build_vCenter_diskmap(self.vc_hybrid_diskmap, hdm)
            cache_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['cache'])
            capacity_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['capacity'])
            self.assertEqual(cache_device_count, 1)
            self.assertEqual(capacity_device_count, 2)

    def test_build_vCenter_diskmap_flash_success(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        host_dict = {'172.18.200.245': 'vim.HostSystem:host-194',
                     '172.18.200.244': 'vim.HostSystem:host-192',
                     '172.18.200.23': 'vim.HostSystem:host-186'}
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "allFlash")
            hdm['host_ref'] = host_dict[hdm['node']]
            dv.build_vCenter_diskmap(self.vc_flash_diskmap, hdm)
            cache_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['cache'])
            capacity_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['capacity'])
            self.assertEqual(cache_device_count, 1)
            self.assertEqual(capacity_device_count, 3)

    def test_process_host_dg_sanity_hybrid_with_capacity_outliar(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            curr_host_dgs[0]['devices'][1]['size'] = 12346L
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "All HDD Disks are not of "
                                         "uniform size"):
                dv.process_host_dg_sanity(curr_host_dgs, "hybrid")

    def test_process_host_dg_sanity_for_hybrid_unsupported_disk(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            curr_host_dgs[0]['devices'][0]['type'] = "random-disk"
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "Unsupported disk type"):
                dv.process_host_dg_sanity(curr_host_dgs, "hybrid")

    def test_process_host_dg_sanity_invalid_dg_count(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            curr_host_dgs = []
            with self.assertRaises(exc.VsanDiskGroupException):
                dv.process_host_dg_sanity(curr_host_dgs, "hybrid")

    def test_process_host_dg_sanity_flash_with_capacity_outliar(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        for i in range(len(diskmodel)):
            host_diskmodel = diskmodel[i]
            curr_host_dgs = host_diskmodel['device_groups']
            curr_host_dgs[0]['devices'][1]['size'] = 12346L
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "Capacity disks of FLASH vSAN are "
                                         "not of same size"):
                dv.process_host_dg_sanity(curr_host_dgs, "allFlash")

    def test_process_host_dg_sanity_flash_with_one_small_disk(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            curr_host_dgs[0]['devices'][0]['size'] = 5000L * fakes.MUL_FACTOR
            dv.process_host_dg_sanity(curr_host_dgs, "allFlash")
            cache_capacity = hdm['device_groups'][0]['total_cache_capacity']
            self.assertEqual(cache_capacity, 5000L * fakes.MUL_FACTOR)

    def test_process_host_dg_sanity_flash_with_two_small_disk(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            curr_host_dgs[0]['devices'][0]['size'] = 5000L * fakes.MUL_FACTOR
            curr_host_dgs[0]['devices'][1]['size'] = 5000L * fakes.MUL_FACTOR
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "Capacity disks of FLASH vSAN are "
                                         "not of same size"):
                dv.process_host_dg_sanity(curr_host_dgs, "allFlash")

    def test_process_host_dg_sanity_hybrid_multiple_ssds(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_hybrid_diskmap,
                                    self.hostprops,
                                    self.vsan_disk_info)
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            curr_host_dgs[0]['devices'][0]['type'] = "ssd"
            curr_host_dgs[0]['devices'][1]['type'] = "ssd"
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "One Hybrid disk group can have "
                                         "ONLY ONE SSD disk"):
                dv.process_host_dg_sanity(curr_host_dgs, "hybrid")

    def test_process_host_dg_sanity_hybrid_capacity_constraint(self):
        vc_diskmap, vsan_disk_info = \
            fakes.query_vcenter_disks_for_hybrid_with_capacity_constraint(3)
        diskmodel = \
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    vsan_disk_info)
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "Cache size is lesser than 10 "
                                         "percent of total capacity size."):
                dv.process_host_dg_sanity(curr_host_dgs, "hybrid")

    def test_process_host_dg_sanity_flash_with_nonssd(self):
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    self.vsan_flash_disk_info)
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            curr_host_dgs[0]['devices'][0]['type'] = "Badtype"
            with self.assertRaisesRegexp(exc.VsanDiskGroupException,
                                         "Flash vSAN needs only SSD disks"):
                dv.process_host_dg_sanity(curr_host_dgs, "allFlash")

    def test_get_system_diskmodel_with_one_disk(self):
        vc_diskmap, vsan_disk_info = fakes.query_vcenter_disks_for_flash(1)
        with self.assertRaises(exc.VsanDiskGroupException):
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    vsan_disk_info)

    def test_get_system_diskmodel_with_ten_disk(self):
        vc_diskmap, vsan_disk_info = fakes.query_vcenter_disks_for_flash(10)
        with self.assertRaises(exc.VsanDiskGroupException):
            dv.get_system_diskmodel(vc_diskmap,
                                    self.hostprops,
                                    vsan_disk_info)

    def test_build_vCenter_diskmap_flash_all_same_size(self):
        self.vc_flash_diskmap, vsan_disk_info = \
            fakes.query_vcenter_disks_for_flash_same_size(4)
        diskmodel = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops,
                                    vsan_disk_info)
        host_dict = {
            '172.18.200.245': 'vim.HostSystem:host-194',
            '172.18.200.244': 'vim.HostSystem:host-192',
            '172.18.200.23': 'vim.HostSystem:host-186'
        }
        for i in range(len(diskmodel)):
            hdm = diskmodel[i]
            curr_host_dgs = hdm['device_groups']
            dv.process_host_dg_sanity(curr_host_dgs, "allFlash")
            hdm['host_ref'] = host_dict[hdm['node']]
            dv.build_vCenter_diskmap(self.vc_flash_diskmap, hdm)
            cache_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['cache'])
            capacity_device_count = \
                len(hdm['device_groups'][0]['vcenter_diskmap']['capacity'])
            self.assertEqual(cache_device_count, 1)
            self.assertEqual(capacity_device_count, 3)

    def test_get_system_diskmodel_all_same_size(self):
        # Make this work
        self.vc_flash_diskmap, vsan_disk_info = \
            fakes.query_vcenter_disks_for_flash_same_size(4)
        dm = \
            dv.get_system_diskmodel(self.vc_flash_diskmap,
                                    self.hostprops, vsan_disk_info)
        self.assertEqual(len(dm[0]['device_groups']), 1)
        self.assertEqual(dm[0]['device_groups'][0]['cache_device_id'],
                               "0")


if __name__ == "__main__":
    unittest.main()
