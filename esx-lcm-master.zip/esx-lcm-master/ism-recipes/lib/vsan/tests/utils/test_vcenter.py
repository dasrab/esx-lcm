#!/usr/bin/env python
#
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP
#

import ssl
from mock import MagicMock, patch, call, Mock
import unittest
from pyVmomi import vim, vmodl

from lib.vsan.utils.vcenter import vCenterUtils
import lib.vsan.common.exc.exceptions as vsan_exc

class FakeCluster:
    def __init__(self, name='fake_cluster'):
        self.name = name
        self._moId = '_moId'
        self.configurationEx = self.ConfigurationEx()
        self.host = []

    def get_cluster_name(self):
        return self.name

    def VsanClusterReconfig(self, cluster, reconfig_spec):
        pass

    class ConfigurationEx:
        def __init__(self):
            self.dasConfig = self.DasConfig()

        class DasConfig:
            def __init__(self):
                self.enabled = False


class FakeSi(object):
    def __init__(self, license_name=None):
        search_index_data = dict()
        search_index_data['host_folder_1'] = 'cluster_1'
        search_index_data['host_folder_2'] = 'cluster_2'
        search_index_data['host_folder_3'] = 'cluster_3'
        datacenters = list()
        datacenters.append(FakeDataCenter('host_folder_1'))
        datacenters.append(FakeDataCenter('host_folder_2'))
        datacenters.append(FakeDataCenter('host_folder_3'))
        self.content = FakeContent(FakeLicenseManager(license_name),
                                   FakeSearchIndex(search_index_data),
                                   FakeRootFolder(datacenters))

    def RetrieveContent(self):
	return self.content


class FakeContent(object):
    def __init__(self,
                 license_manager=None,
                 search_indexer=None,
                 root_folder=None):
        self.licenseManager = license_manager
        self.searchIndex = search_indexer
        self.rootFolder = root_folder


class FakeRootFolder(object):
     def __init__(self, datacenters):
	self.childEntity = datacenters


class FakeDataCenter(object):
    def __init__(self, hostFolder):
        self.hostFolder = hostFolder


class FakeSearchIndex(object):
    def __init__(self, datastores=dict()):
        self.data = datastores

    def FindChild(self, folder, cname):
        for folder in self.data.keys():
	   if self.data[folder] ==  cname:
              return FakeCluster(cname)
        return None


class FakeLicenseManager(object):
    def __init__(self, license_names=[]):
        self.licenses = list()
        if license_names:
            for license_name in license_names:
                self.licenses.append(FakeLicense(license_name))
        self.licenseAssignmentManager = FakeLicenseAssignmentManager()


class FakeLicenseAssignmentManager(object):
    def __init__(self):
        pass

    def UpdateAssignedLicense(self, entity, licenseKey):
        return True


class Property(object):
    def __init__(self, key=None, value=None):
        self.key = key
        self.value = value


class Feature(object):
    def __init__(self, value=None):
        self.value = value


class FakeLicense:
    def __init__(self, name=None):
        self.name = name
        self.licenseKey = "licenceKey"
        self.properties = [Property('feature', Feature('All Flash')),
                           Property('feature', Feature('Stretched Cluster'))]


class FakeContext(object):
    def __init__(self):
        self.check_hostname = False
        self.verify_mode = ssl.CERT_NONE


class TestvCenterUtils(unittest.TestCase):
    def setUp(self):
        """ Setting up for the test """
        self.vCenterUtils = vCenterUtils()

    def tearDown(self):
        """Cleaning up after the test"""
        del self.vCenterUtils

    @patch('lib.vsan.utils.vcenter.ssl')
    @patch('lib.vsan.utils.vcenter.SmartConnect')
    def test_connect_pass(self,
                          mock_SmartConnect,
                          mock_ssl):

        mock_ssl.create_default_context.return_value = FakeContext()
        mock_SmartConnect.return_value = FakeSi()
        si, context = self.vCenterUtils.connect('fake_host',
                                                'fake_user',
                                                'fake_pwd',
                                                403)

        self.assertIsInstance(si, FakeSi)
        self.assertEqual(context.check_hostname, FakeContext().check_hostname)
        self.assertEqual(context.verify_mode, mock_ssl.CERT_NONE)

    def test_disconnect(self):
        pass

    @patch('lib.vsan.utils.vcenter.SmartConnect')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_connect_fail(self, mock_log, mock_SmartConnect):
        mock_SmartConnect.side_effect = vim.InvalidLogin()
        with self.assertRaises(vsan_exc.VCenterConnectionException):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)

        mock_SmartConnect.side_effect = IOError()
        with self.assertRaises(vsan_exc.VCenterConnectionException):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)

    @patch('lib.vsan.utils.vcenter.SmartConnect')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_connect_fail_ssl_exception(self, mock_log, mock_SmartConnect):
        mock_SmartConnect.side_effect = vim.InvalidLogin()
        with self.assertRaises(vsan_exc.VCenterConnectionException):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)

        mock_SmartConnect.side_effect = ssl.SSLEOFError
        with self.assertRaises(ssl.SSLEOFError):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)
        self.assertEqual(mock_SmartConnect.call_count, 6)

    @patch('lib.vsan.utils.vcenter.SmartConnect')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_connect_fail_host_connect_fault_ssl_error(self, mock_log, mock_SmartConnect):
        mock_SmartConnect.side_effect = vim.InvalidLogin()
        with self.assertRaises(vsan_exc.VCenterConnectionException):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)

        exc = vim.fault.HostConnectFault(msg="EOF occurred in violation of protocol")
        mock_SmartConnect.side_effect = exc
        with self.assertRaises(type(exc)):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)
        self.assertEqual(mock_SmartConnect.call_count, 6)

    @patch('lib.vsan.utils.vcenter.SmartConnect')
    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_connect_fail_host_connect_fault_nonssl_error(self, mock_log, mock_SmartConnect):
        mock_SmartConnect.side_effect = vim.InvalidLogin()
        with self.assertRaises(vsan_exc.VCenterConnectionException):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)
        self.assertEqual(mock_SmartConnect.call_count, 1)

        exc = vim.fault.HostConnectFault(msg="Some non-ssl error")
        mock_SmartConnect.side_effect = exc
        with self.assertRaises(type(exc)):
            self.vCenterUtils.connect('fake_host', 'fake_user' , 'fake_pwd', 123)
        self.assertTrue(mock_log.called)

    def test_get_vsan_license_pass(self):
        fake_si = FakeSi(license_name=['VMware vSAN Standard',
                                       'VMware vSAN Advanced'])

        most_advanced_license = self.vCenterUtils.get_vsan_license(fake_si)
        self.assertEqual(most_advanced_license.name, "VMware vSAN Advanced")

    @patch("lib.vsan.handlers.lifecycle.log.logging.Logger.error")
    def test_get_vsan_license_fail(self, mock_log):
        fake_si = FakeSi(license_name=None)
        with self.assertRaises(vsan_exc.VsanLicenseException):
             self.vCenterUtils.get_vsan_license(fake_si)
        err_msg = ("No vSAN license found. Upload one for vSAN deployment")
        mock_log.assert_called_with(err_msg)

    def test_get_apply_vsan_license_pass(self):
        fake_si = FakeSi(license_name=['VMware vSAN Enterprise',
                                       'VMware vSAN Advanced'])
        most_advanced_license = vCenterUtils().get_vsan_license(fake_si)
        self.assertEqual(most_advanced_license.name, "VMware vSAN Enterprise")
        fake_cluster = FakeCluster()
        expected_features = ['All Flash', 'Stretched Cluster']
        features = self.vCenterUtils.apply_vsan_license(fake_si,
                                                          fake_cluster,
                                                   most_advanced_license)
        self.assertEqual(features, expected_features)

    def test_get_cluster_instance(self):
        si = FakeSi()
        cluster = self.vCenterUtils.get_cluster_instance(si, 'cluster_1')
        self.assertIsInstance(cluster, FakeCluster)
        self.assertEqual('cluster_1', cluster.get_cluster_name())

    def test_get_vsan_managed_objects(self):
        pass

    def test_wait_for_tasks(self):
        pass

    def test_collect_host_properties(self):
        pass

if __name__ == '__main__':
    unittest.main()
