# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import unittest
from lib.vsan.utils import size as sutils


class TestUtils(unittest.TestCase):

    def test_size_conv(self):
        self.assertEqual(sutils.size_conv(1024, 'MiB', 'GiB'), 1)
        self.assertEqual(sutils.size_conv(10, 'GiB', 'MiB'), 10240.0)
