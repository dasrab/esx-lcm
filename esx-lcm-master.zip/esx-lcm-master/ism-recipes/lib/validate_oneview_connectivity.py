# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from builtins import range
from hpOneView.exceptions import *
from orch import log
from common.oneview_connector import OneviewConnector
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error

from common import utils


class Validate_Oneview_Connectivity(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        ov_host = params.get('ov_host')
        ov_port = params.get('ov_port')
        username = params.get('ov_username')
        password = params.get('ov_password')

        credential = {'userName': username, 'password': password}
        connection = OneviewConnector(ov_host, ov_port).connect()

        # Login
        retries = 3
        for i in range(1, retries):
            try:
                connection.login(credential)
                break
            except HPOneViewException as e:
                result = {'is_valid': False, 'details': str(e),
                          'error_code': 'SYN_ISM_LOGIN_ONEVIEW_FAILED'}
                return self.exit_success(result)
            except Exception as e:
                if "Connection timed out" in str(e) and i < retries:
                    self.LOG.debug(
                        "Time out detected. Retrying more " + str(retries - i) + "x times.")
                    pass
                else:
                    result = {'is_valid': False, 'details': str(e),
                              'error_code': 'SYN_ISM_LOGIN_ONEVIEW_FAILED'}
                    return self.exit_success(result)
        result = {'is_valid': True, 'details': '',
                  'error_code': ''}
        return self.exit_success(result)
