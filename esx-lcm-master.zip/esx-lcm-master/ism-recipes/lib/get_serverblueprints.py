# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log
from orch.moduleBase import ModuleBase

from common import utils


class Get_Serverblueprints(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            result = AppManProxy.get_serverblueprints()
            if not result:
                self.LOG.debug("No serverblueprints available to fetch")
                return self.exit_success(result)
            else:
                self.LOG.debug("Successsfully fetched Serverblueprints")
                return self.exit_success(result)
        except Exception as exception:
            self.LOG.error("Could not fetch Serverblueprints")
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(str(exception))
