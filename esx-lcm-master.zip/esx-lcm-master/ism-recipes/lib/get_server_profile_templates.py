# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector

from hpOneView.resources.servers import server_profile_templates
import traceback


class Get_Server_Profile_Templates(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.debug('Executing Get_Server_Profile_Templates')
        server_profile_template_uri = []
        ov_host = params.get("_ov_host")
        ov_port = params.get("_ov_port")
        auth = params.get("_auth")
        self.LOG.debug('Required parameters: ' +
                       str(ov_host) + ' ' + str(auth))

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            server_connection = server_profile_templates.ServerProfileTemplate(
                connection)
            server_profile_template_members = server_connection.get_all()

            for member in server_profile_template_members:
                server_profile_template_uri.append(
                    {'server_profile_template_uri': member['uri']})

            return self.exit_success(server_profile_template_uri)
        except Exception as e:
            self.LOG.debug('Get Server Profile Templates failed!')
            self.LOG.debug(traceback.format_exc())
            return self.exit_fail(str(e))
