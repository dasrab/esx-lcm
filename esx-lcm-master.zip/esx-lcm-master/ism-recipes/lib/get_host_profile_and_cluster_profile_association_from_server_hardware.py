# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error
from common.oneview_connector import OneviewConnector
import hpOneViewClrm as hpovclrm
from hpOneView.resources.servers import server_profiles
import json


class Get_Host_Profile_And_Cluster_Profile_Association_From_Server_Hardware(
        ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        self.LOG.debug(
            "Creating the cluster profile and host profile association from Server hardware")

        server_hardware_list = params.get('_server_hardware')
        ov_host = params.get("_ov_hostname")
        ov_auth = params.get("_ov_auth")
        cluster_profile_uri = params.get("_cluster_profile_uri")

        association = {
            "cluster_profile": cluster_profile_uri, "host_profile": []}

        try:
            connection = OneviewConnector(ov_host, ov_auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            hypervisor_host_profile_list = hypervisor_cluster_profile.get(
                "hypervisorHostProfileUris")
            hypervisor_profiles = hpovclrm.hypervisor_profiles(connection)
            server_connection = server_profiles.ServerProfiles(connection)

            for hypervisor_host_profile in hypervisor_host_profile_list:
                host_profile_body = hypervisor_profiles.get_hypervisor_profile_by_uri(
                    hypervisor_host_profile)
                server_profile_uri = host_profile_body.get("serverProfileUri")
                self.LOG.debug(str(server_profile_uri))

                server_profile = server_connection.get(server_profile_uri)

                server_hardware_uri = server_profile.get("serverHardwareUri")
                self.LOG.debug(str(server_hardware_uri))
                for server_hardware in server_hardware_list:
                    if server_hardware_uri == server_hardware:
                        association["host_profile"].append(
                            hypervisor_host_profile)

            self.LOG.debug("Association:" + json.dumps(association))
            body_dict = {"association": association}
            return self.exit_success(body_dict)

        except Exception as e:
            self.LOG.debug(
                'Failing to retrieve the cluster profile and host profile association from server hardware')
            return self.exit_fail(str(e))
