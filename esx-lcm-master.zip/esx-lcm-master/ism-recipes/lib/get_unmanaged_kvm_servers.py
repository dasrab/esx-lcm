# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import json
import re
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from orch.zone_controller import ZoneController

from lib.common import constants
from lib.hpeGateway import utils

LOG = log.getLogger(__name__)


class Get_Unmanaged_Kvm_Servers(ModuleBase):

    def _generate_server_uri(self, zone_id, host_id, zone_ctrl):
        zone_conn = zone_ctrl.get_by_uuid(zone_id, host_id)
        if zone_conn:
            return '/'.join([constants.SERVERS_URL, zone_conn.get('id')])

    def _get_valid_volumes(self, host_agent):
        # Invalid volumes

        # "volumes": [
        #    "Error: No vgs command found."
        # ]

        # "volumes": [
        #     {
        #         "name": "No",
        #         "free": "groups",
        #         "size": "volume"
        #     }
        # ]

        valid_volumes = list()
        volumes = utils.get_val(
            host_agent, 'extensions', 'volumes_present', 'data')
        for volume in volumes:
            if isinstance(volume, dict):
                size_str = volume.get('size')
                if size_str:
                    size_digit = re.findall('\d+\.\d+', size_str)
                    if size_digit:
                        volume['size'] = float(size_digit[0])
                        valid_volumes.append(volume)
        return valid_volumes

    def execute(self, params):
        resource_mgr_info = params['resource_mgr_info']
        try:
            _headers = {
                "Content-Type": "application/json",
                "X-Auth-Token": resource_mgr_info.get('token')
            }
            _url = urlparse.urlsplit(resource_mgr_info['resmgr_url'])
            _path = ''.join([_url.path, constants.V1_HOSTS_PATH])

            host_agents = utils.get_host_agents(
                _url.netloc, _path[:-1], _headers)

            zone_ctrl = ZoneController(self.private_request)
            unmanaged_kvm_servers = list()
            for host_agent in host_agents:
                is_healthy, error_msg = utils.is_healthy_host(host_agent)
                if (host_agent['hypervisor_info']['hypervisor_type'] ==
                        constants.KVM_HYPERVISOR):
                    # Assuming hostname is unique and will not change.
                    kvm_server = dict()
                    kvm_server['name'] = host_agent['info']['hostname']
                    kvm_server['id'] = host_agent['info']['hostname']
                    server_uri = self._generate_server_uri(
                        params['zone_id'], host_agent.get('id'), zone_ctrl)
                    if server_uri:
                        kvm_server['serverUri'] = server_uri
                    kvm_server['volumes'] = self._get_valid_volumes(host_agent)
                    kvm_server['state'] = constants.DISABLED
                    if not is_healthy:
                        kvm_server['status'] = constants.CRITICAL
                        kvm_server['error'] = utils.generate_ism_error(error_msg)
                    else:
                        kvm_server['status'] = constants.OK
                        kvm_server['error'] = {}
                    if (host_agent.get('role_status') ==
                            constants.HOST_AGENT_ROLE_STATUS_OK):
                        kvm_server['state'] = constants.ENABLED
                        if not host_agent['info'].get('responding'):
                            kvm_server['status'] = constants.CRITICAL
                    unmanaged_kvm_servers.append(kvm_server)
            LOG.info("KVM hosts obtained from gateway: {}"
                     .format(json.dumps(unmanaged_kvm_servers, indent=4)))
            return self.exit_success(unmanaged_kvm_servers)
        except Exception as e:
            LOG.exception("Failed to get KVM hosts from gateway")
            LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
