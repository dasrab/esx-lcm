# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log
from orch.moduleBase import ModuleBase

from common import utils


class Deallocate_Servers(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            server_hw_uris = []
            for _ in range(len(params['server_uris'])):
                AppManProxy.deallocate_server(params['server_uris'][_])
                self.LOG.debug("Successfully Deallocated Server: '{}'"
                       .format(params['server_uris'][_]))
                server_hw_uris.append(params['server_uris'][_])
            msg = ("Deallocated requested Servers: '{}'"
                   .format(params['server_uris']))
            self.update_parent_task(40, msg)
            return self.exit_success(msg)
        except Exception as exception:
            err_msg = ("Deallocate Server(s) Failed: '{}'! got '{}'"
                       .format(params['server_uris'], str(exception)))
            self.update_parent_task(40, err_msg)
            self.LOG.error(err_msg)
            return self.exit_fail(str(exception))
