# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import netaddr
import os
import sys
import tarfile
import time
from threading import Timer
import urlparse

from pyVim import task
from pyVmomi import vim, vmodl
from requests.packages import urllib3

from common.vcenter_utils import VcenterUtils
from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils
from hpeGateway.model import Proxy_Server

urllib3.disable_warnings()
VM_RAMDISK = 8
MIN_VMDISK_SIZE_GB = 40
MIN_PROVISION_SPACE = (MIN_VMDISK_SIZE_GB + VM_RAMDISK) * 1024 * 1024 * 1024
TASK_WAIT_DELAY = 5
VM_TOOLS_RETRY_COUNT = 11
NET_INFO_COUNT = 10
HOST_AGENT_RETRY_COUNT = 10


class Hpe_Gateway_Ova_Upload(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def execute(self, params):
        self._args = params
        if not self._args['appliance_ip']:
            res_mgr_info = utils.get_resource_manager_endpoint(
                self._args['keystone_url'], self._args['username'],
                self._args['password'], self._args['tenant'], self._args['region'])
            if not res_mgr_info:
                return self.exit_fail(
                    "Compute OVA deploy failed. Couldn't connect to region '{}'" .format(
                        self._args['region']))

            self._args['appliance_ip'] = self._get_appliance_ip(res_mgr_info)
            self._args['appliance_name'] = self._args['appliance_prefix'] + \
                "_" + self._args['appliance_ip']
        si = self._vc_utils.get_service_instance(
            self._args['vcenter_ip'], self._args['vcenter_username'],
            self._args['vcenter_password'], self._args['vcenter_port'],
            self._args.get('cert_path'))
        dc = self._vc_utils.get_obj(
            si.content, [vim.Datacenter], self._args['datacenter'])
        if not dc:
            return self.exit_fail("Couldn't find the Datacenter '{}'"
                                  .format(self._args['datacenter']))
        cluster = self._vc_utils.get_obj(
            si.content, [vim.ClusterComputeResource],
            self._args['cluster'])
        if not cluster:
            return self.exit_fail("Couldn't find the Cluster '{}'"
                                  .format(self._args['cluster']))
        resource_pool = cluster.resourcePool
        ds = self._get_datastore(cluster)
        if not ds:
            return self.exit_fail("Couldn't find any valid shared datastore "
                                  "to deploy the OVA")
        ovf_handle = OvfHandler(self._args['ova_path'],
                                self._args['vcenter_ip'])
        import_spec_result = self._get_ovf_import_spec_result(
            si, dc, ds, resource_pool, ovf_handle)
        if len(import_spec_result.error):
            self.LOG.error("The following errors will prevent import of "
                           "the OVA:")
            for error in import_spec_result.error:
                self.LOG.error({}.format(error))
            return self.exit_fail("Couldn't import the OVA because of the "
                                  "failures occurred before !")
        ovf_handle.set_spec(import_spec_result)
        lease = resource_pool.ImportVApp(
            import_spec_result.importSpec, dc.vmFolder)
        while lease.state == vim.HttpNfcLease.State.initializing:
            self.LOG.debug("Waiting for lease to be ready...")
            time.sleep(1)
        if lease.state == vim.HttpNfcLease.State.error:
            return self.exit_fail("Lease error: {}".format(lease.error))
        self.LOG.info("Started deploying '{}' ...".
                      format(self._args['ova_path']))
        deployed_vm = ovf_handle.upload_ova(lease)
        if deployed_vm:
            self._power_on_vm(si, deployed_vm)
            if self._validate_deployment(deployed_vm):
                return self.exit_success({"Status": "SUCCESS"})
        return self.exit_fail(
            "Failed to deploy the OVA '{}'".format(self._args['ova_path']))

    def _get_appliance_ip(self, res_mgr_info):
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": res_mgr_info['token']
                   }
        _url = urlparse.urlsplit(res_mgr_info['resmgr_url'])
        path = '/'.join([_url.path, 'v1/hosts'])
        assigned_ip_address_list = list()
        host_agents = utils.get_host_agents(_url.netloc, path, headers)
        for host_agent in host_agents:
            host_agent_ip = utils.get_val(
                host_agent, 'extensions', 'interfaces',
                'data', 'iface_ip', 'br-int')
            assigned_ip_address_list.append(str(host_agent_ip))
        return utils.generate_new_ip(self._args['appliance_start_ipaddress'],
                                     self._args['appliance_end_ipaddress'],
                                     assigned_ip_address_list)

    def _run_post_ova_deploy_ops(self, si, vm):
        vm_conf = vim.vm.ConfigSpec(cpuHotAddEnabled=True,
                                    memoryHotAddEnabled=True)
        self._vc_utils.reconfigure_vm(si, vm, vm_conf)
        self._power_on_vm(si, vm)

    def _get_ovf_properties(self):
        ovf_properties = dict()
        ovf_property_keys = {
            'vcenter_ip': 'host_ip',
            'vcenter_username': 'host_username',
            'vcenter_password': 'host_password',
            'proxy_server': 'proxy_ip',
            'proxy_port': 'proxy_port',
            'appliance_ip': 'static_ip',
            'appliance_netmask': 'static_netmask',
            'appliance_gateway': 'static_gateway',
            'appliance_dns': 'static_dns'
        }
        for k, v in self._args.iteritems():
            if k in ovf_property_keys:
                ovf_properties[ovf_property_keys[k]] = v
        return ovf_properties

    def _get_ovf_import_spec_result(self, si, dc, ds,
                                    resource_pool,
                                    ovf_handle):
        network = self._vc_utils.get_obj(
            si.content, [vim.Network], self._args['network_name'],
            dc.networkFolder)
        network_mapping = vim.OvfManager.NetworkMapping(
            name=self._args['network_name'], network=network)
        property_mappings = []
        ovf_properties = self._get_ovf_properties()
        for key, value in ovf_properties.iteritems():
            param = vim.KeyValue()
            param.key = key
            param.value = value
            property_mappings.append(param)
        import_spec_params = vim.OvfManager.CreateImportSpecParams()
        import_spec_params.entityName = self._args['appliance_name']
        import_spec_params.diskProvisioning = 'thin'
        import_spec_params.networkMapping = [network_mapping]
        import_spec_params.propertyMapping = property_mappings
        import_spec_params.ipAllocationPolicy = 'fixedPolicy'
        import_spec_params.ipProtocol = 'static'
        import_spec_result = si.content.ovfManager.CreateImportSpec(
            ovf_handle.get_descriptor(), resource_pool,
            ds, import_spec_params)
        config_spec = import_spec_result.importSpec.configSpec
        config_spec.cpuHotAddEnabled = True
        config_spec.memoryHotAddEnabled = True
        return import_spec_result

    def _get_datastore(self, cluster):
        cluster_hosts = cluster.host
        datastores = cluster.datastore
        shared_storages = list()
        for datastore in datastores:
            datastore_hosts = [host.key for host in datastore.host]
            if set(cluster_hosts).issubset(set(datastore_hosts)):
                shared_storages.append(datastore)
        if not shared_storages:
            return self._validate_datastore(datastores, cluster_hosts)
        return self._validate_datastore(shared_storages, cluster_hosts)

    def _get_max_capacity_datastore(self, datastores):
        ds_available_space = {ds.summary.freeSpace: ds for ds in datastores}
        max_free_space = max(ds_available_space, key=long)
        if max_free_space > MIN_PROVISION_SPACE:
            return ds_available_space.get(max_free_space)

    def _validate_datastore(self, datastores, cluster_hosts):
        valid_ds = []
        for ds in datastores:
            if (ds.summary.accessible and
                    ds.summary.maintenanceMode == 'normal'):
                host_mounts = ds.host
                for host_mount in host_mounts:
                    if (host_mount.key in cluster_hosts and
                            host_mount.mountInfo.mounted):
                        valid_ds.append(ds)
        if valid_ds:
            return self._get_max_capacity_datastore(valid_ds)

    def _power_on_vm(self, si, vm):
        if vm.runtime.powerState != 'poweredOn':
            try:
                self.LOG.info("Powering on '{}'".format(vm.name))
                power_on_task = vm.PowerOn()
                task.WaitForTask(power_on_task, si)
            except Exception as e:
                self.LOG.exception("Exception occurred while powering on '{}'"
                                   .format(vm.name))
                raise e

    def _wait_for_vmware_tools(self, vm):
        retry_count = 0
        while True:
            retry_count += 1
            current_state = vm.guest.toolsStatus
            if current_state in ('toolsOk', 'toolsOld'):
                return
            if retry_count < VM_TOOLS_RETRY_COUNT:
                self.LOG.info("VM tools service is not running inside '{}', "
                              "Retrying again in {} seconds"
                              .format(vm.name, TASK_WAIT_DELAY * retry_count))
                time.sleep(TASK_WAIT_DELAY * retry_count)
            else:
                msg = ("Timed out while waiting for VMware Tools to be "
                       "ready. This means either VMware Tools is not "
                       "installed on the VM '{}' or the guest OS took "
                       "more than 5 mins to boot up").format(vm.name)
                self.LOG.exception(msg)
                raise Exception(msg)

    def _wait_for_ip_config(self, vm):
        retry_count = 0
        while True:
            retry_count += 1
            nic_infos = vm.guest.net
            if nic_infos:
                for nic in nic_infos:
                    ip_list = nic.ipAddress
                    if ip_list:
                        for ip in ip_list:
                            if (netaddr.valid_ipv4(ip) and
                                    ip == self._args['appliance_ip']):
                                return
            if retry_count < NET_INFO_COUNT:
                self.LOG.info("Network information is not assigned for '{}'. "
                              "Retrying again in {} seconds".format(
                                  vm.name, TASK_WAIT_DELAY * retry_count))
                time.sleep(TASK_WAIT_DELAY * retry_count)
            else:
                msg = ("Timed out while waiting for IP to be "
                       "populated in the VM '{}'").format(vm.name)
                self.LOG.exception(msg)
                raise Exception(msg)

    def _wait_for_being_paired(self):
        Proxy_Server.set_proxy_details(
            self._args["proxy_server"], self._args["proxy_port"])
        res_mgr_info = utils.get_resource_manager_endpoint(
            self._args['keystone_url'], self._args['username'],
            self._args['password'], self._args['tenant'], self._args['region'])
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": res_mgr_info['token']
                   }
        _url = urlparse.urlsplit(res_mgr_info['resmgr_url'])
        path = '/'.join([_url.path, 'v1/hosts'])
        retry_count = 0
        while True:
            retry_count += 1
            host_agents = utils.get_host_agents(_url.netloc, path, headers)
            if host_agents:
                for host_agent in host_agents:
                    host_agent_ip = utils.get_val(
                        host_agent, 'extensions', 'interfaces',
                        'data', 'iface_ip', 'br-int')
                    if host_agent_ip == self._args['appliance_ip']:
                        paired_status = utils.get_val(
                            host_agent, 'extensions', 'hypervisor_details',
                            'data', 'pair_status')
                        if paired_status == 'paired':
                            return True
            if retry_count < HOST_AGENT_RETRY_COUNT:
                self.LOG.info("Host '{}' is not yet paired with DU "
                              "Retrying again in {} seconds."
                              .format(self._args['appliance_ip'],
                                      TASK_WAIT_DELAY * retry_count))
                time.sleep(TASK_WAIT_DELAY * retry_count)
            else:
                msg = ("Timed out while waiting for the host to pair with "
                       "HPE gateway DU. Please check /var/log/pf9/pf9_install.log")
                self.LOG.exception(msg)
                raise Exception(msg)

    def _validate_deployment(self, vm):
        # Wait for the VM to boot up and
        # the vmware tools to be ready
        self.LOG.info("Waiting for VM to boot up and vm tools to be ready...")
        self._wait_for_vmware_tools(vm)
        # Now check IP is assigned or not
        self.LOG.info("Waiting for IP assignment...")
        self._wait_for_ip_config(vm)
        # IP configured ! Now check DU registration
        self.LOG.info("Waiting for host to be paired with DU...")
        return self._wait_for_being_paired()


class OvfHandler(ModuleBase):

    def __init__(self, ovafile, vc):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._handle = self._create_file_handle(ovafile)
        self._tarfile = tarfile.open(fileobj=self._handle)
        ovffilename = list(filter(lambda x: x.endswith('.ovf'),
                                  self._tarfile.getnames()))[0]
        ovffile = self._tarfile.extractfile(ovffilename)
        self._descriptor = ovffile.read().decode()
        self._vc = vc

    def _create_file_handle(self, entry):
        if os.path.exists(entry):
            return FileHandle(entry)
        else:
            raise Exception("Not able to find the OVA '{}'".format(entry))

    def get_descriptor(self):
        return self._descriptor

    def set_spec(self, spec):
        self._spec = spec

    def _get_disk(self, fileItem, lease):
        ovffilename = list(filter(lambda x: x == fileItem.path,
                                  self._tarfile.getnames()))[0]
        return self._tarfile.extractfile(ovffilename)

    def _get_device_url(self, fileItem, lease):
        for deviceUrl in lease.info.deviceUrl:
            if deviceUrl.importKey == fileItem.deviceId:
                return deviceUrl
        return self.exit_fail("Failed to find deviceUrl for file {}"
                              .format(fileItem.path))

    def _get_tarfile_size(self, tarfile):
        if hasattr(tarfile, 'size'):
            return tarfile.size
        size = tarfile.seek(0, 2)
        tarfile.seek(0, 0)
        return size

    def upload_ova(self, lease):
        """
        Uploads all the ova contents, with a progress keep-alive.
        """
        self.lease = lease
        try:
            self._start_timer()
            for file_item in self._spec.fileItem:
                self._upload_disk(file_item, lease)
            lease.Complete()
            self.LOG.info("OVA deployed successfully !")
            return lease.info.entity
        except vmodl.MethodFault as e:
            self.LOG.error("Hit an error in upload: {}".format(e))
            lease.Abort(e)
            raise e
        except Exception as e:
            self.LOG.exception("Hit an error in upload: {}".format(e))
            lease.Abort(vmodl.fault.SystemError(reason=str(e)))
            raise e

    def _upload_disk(self, fileItem, lease):
        ovffile = self._get_disk(fileItem, lease)
        if not ovffile:
            return
        deviceUrl = self._get_device_url(fileItem, lease)
        headers = {'Content-length': str(self._get_tarfile_size(ovffile))}
        method = 'POST'
        if not deviceUrl.disk:
            headers['Overwrite'] = 't'
            method = 'PUT'
        _url = urlparse.urlparse(deviceUrl.url.replace('*', self._vc))
        with urllib3.HTTPSConnectionPool(
                _url.netloc, maxsize=1,
                assert_fingerprint=deviceUrl.sslThumbprint) as conn:
            response = conn.request(method=method, url=_url.path,
                                    body=ovffile, headers=headers)
            if response.status != 201:
                raise urllib3.exceptions.HTTPError(
                    "Exception occurred while uploading {}"
                    .format(ovffile.name))

    def _start_timer(self):
        Timer(5, self._timer).start()

    def _timer(self):
        try:
            prog = self._handle.progress()
            self.lease.Progress(prog)
            if self.lease.state not in [vim.HttpNfcLease.State.done,
                                        vim.HttpNfcLease.State.error]:
                self._start_timer()
            sys.stdout.write("Progress: %d%%\r" % prog)
            sys.stdout.flush()
        except BaseException:  # Any exception means we should stop updating progress.
            pass


class FileHandle(object):

    def __init__(self, filename):
        self.filename = filename
        self.fh = open(filename, 'rb')

        self.st_size = os.stat(filename).st_size
        self.offset = 0

    def __del__(self):
        self.fh.close()

    def tell(self):
        return self.fh.tell()

    def seek(self, offset, whence=0):
        if whence == 0:
            self.offset = offset
        elif whence == 1:
            self.offset += offset
        elif whence == 2:
            self.offset = self.st_size - offset

        return self.fh.seek(offset, whence)

    def seekable(self):
        return True

    def read(self, amount):
        self.offset += amount
        result = self.fh.read(amount)
        return result

    def progress(self):
        return int(100.0 * self.offset / self.st_size)
