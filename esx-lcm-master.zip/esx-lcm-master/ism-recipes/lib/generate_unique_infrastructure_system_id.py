# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error

from pyVmomi import vim

from common.vcenter_utils import VcenterUtils


class Generate_Unique_Infrastructure_System_Id(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)
        self._vc_utils = VcenterUtils()

    def execute(self, params):
        try:
            si = self._vc_utils.get_service_instance(
                params['vc_host'],
                params['vc_user'], params['vc_password'],
                params['vc_port'])
            dc = self._vc_utils.get_obj(
                si.content, [vim.Datacenter], params['datacenter_name'])
            if not dc:
                raise Exception("Couldn't find the Datacenter '{}'"
                                .format(params['datacenter_name']))
            cluster = self._vc_utils.get_obj(
                si.content, [vim.ClusterComputeResource],
                params['cluster_name'], dc.hostFolder)
            if not cluster:
                raise Exception("Couldn't find the Cluster '{}'"
                                .format(params['cluster_name']))
            cluster_id = '_'.join(
                [si.content.about.instanceUuid, cluster._moId])
            # Converting cluster id to lower case
            cluster_id = cluster_id.lower()
            return self.exit_success(cluster_id)
        except Exception as e:
            self.LOG.exception('Failed to generate InfrastructureSystem Id: {}'.format(e))
            raise Ism_Error(
                "HCOE_ISM_GENERATE_INFRA_ID_FAILED",
                details=str(e))
