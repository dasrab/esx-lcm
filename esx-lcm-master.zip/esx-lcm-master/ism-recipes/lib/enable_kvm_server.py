# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import json
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from orch.zone_controller import ZoneController

from lib.common import constants
from lib.hpeGateway import utils
from lib.hpeGateway.kvm_roles_util import KVMRolesUtil
from lib.hpeGateway.physnetutil import PhysnetUtil

LOG = log.getLogger(__name__)


class Enable_Kvm_Server(ModuleBase):

    def _clear_roles_if_enable_fails(
            self, _url, _headers, v1_hosts_path):

        # This method will be invoked for two cases:
        # 1. Converge failed, Will clean up all roles.
        # 2. Timed out and state is still converging.
        host_agent = utils.get_kvm_host_agent(
            _url.netloc, v1_hosts_path, _headers)
        num_enabled_servers = utils.get_number_of_enabled_kvm_servers(
                _url.netloc, ''.join([_url.path, constants.V1_HOSTS_PATH]),
                _headers)
        if (host_agent.get('role_status') ==
                constants.HOST_AGENT_ROLE_STATUS_FAILED):
            kvm_role_util = KVMRolesUtil(
                net_loc=_url.netloc, res_mgr_path=_url.path,
                headers=_headers, host_agent=host_agent
            )
            LOG.info("Deleting all the applied roles because the enable server"
                     " operation failed!")
            kvm_role_util.delete_all_roles()
            LOG.info("Successfully deleted all roles !")
            if not utils._wait_for_kvm_host_agent(
                    _url.netloc, v1_hosts_path, _headers, disable=True):
                LOG.error("Failed to delete all the roles!")
            # Remove physnets if last server.
            if num_enabled_servers == 1:
                PhysnetUtil(
                    _url.netloc, ''.join([_url.path, constants.V1_PATH]),
                    _headers, host_agent
                ).clean_physnet()
        elif (host_agent.get('role_status') ==
              constants.HOST_AGENT_ROLE_STATUS_CONVERGING):
            LOG.error("Cannot delete roles, because the host agent status of "
                      "server '{}' is still in '{}' state !"
                      .format(host_agent['info']['hostname'],
                              constants.HOST_AGENT_ROLE_STATUS_CONVERGING))

    def execute(self, params):
        try:
            intransit_server = params['intransit_kvm_servers'][0]
            server_id = intransit_server['serverUri'][
                intransit_server['serverUri'].rfind('/') + 1:]
            zone_ctrl = ZoneController(self.private_request).get(
                params['zone_id'], server_id)
            LOG.debug("ZoneController Settings: {}"
                      .format(json.dumps(zone_ctrl, indent=4)))
            resource_mgr_info = params['resource_mgr_info']
            host_id = zone_ctrl['uuid']
            _headers = {
                "Content-Type": "application/json",
                "X-Auth-Token": resource_mgr_info.get('token')
            }
            _url = urlparse.urlsplit(resource_mgr_info['resmgr_url'])
            v1_hosts_path = ''.join(
                [_url.path, constants.V1_HOSTS_PATH, host_id])

            host_agent = utils.get_kvm_host_agent(
                _url.netloc, v1_hosts_path, _headers)

            hostname = host_agent['info']['hostname']
            if not host_agent:
                msg = ("Couldn't find any host with id='{}' in gateway"
                       .format(server_id))
                LOG.error(msg)
                raise Exception(msg)

            if (host_agent.get('role_status') ==
                    constants.HOST_AGENT_ROLE_STATUS_CONVERGING):
                raise Exception(
                    "Enable/Disable is already going on host '{}' . "
                    "Cannot enable this".format(hostname))

            LOG.info("Enabling KVM host '{}'...".format(hostname))

            kvm_roles_util = KVMRolesUtil(
                net_loc=_url.netloc, res_mgr_path=_url.path,
                headers=_headers, host_agent=host_agent,
                kvm_ip=zone_ctrl['location']['ipAddress'],
                is_enable=True
            )

            LOG.info("Validating and creating physnets ...")
            physnet_util = PhysnetUtil(
                _url.netloc, ''.join([_url.path, constants.V1_PATH]),
                _headers, host_agent)
            physnet_util.validate_and_create_physnets()

            if intransit_server['roles']:
                for role in intransit_server['roles']:
                    if role in constants.SECONDARY_KVM_ROLES:
                        constants.PRIMARY_KVM_ROLES += (
                            constants.SECONDARY_KVM_ROLES.get(role))

            for role_name in constants.PRIMARY_KVM_ROLES:
                kvm_roles_util.apply_role(role_name)

            if not utils._wait_for_kvm_host_agent(
                    _url.netloc, v1_hosts_path, _headers):
                raise Exception(
                    "Failed to enable KVM host '{}'".format(hostname))
            return self.exit_success(
                "Successfully enabled KVM host '{}'"
                .format(hostname))
        except Exception as e:
            LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
        finally:
            self._clear_roles_if_enable_fails(
                _url, _headers, v1_hosts_path)
