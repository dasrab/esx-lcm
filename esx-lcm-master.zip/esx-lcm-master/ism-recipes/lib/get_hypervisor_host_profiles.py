# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector

import hpOneViewClrm as hpovclrm
import traceback


class Get_Hypervisor_Host_Profiles(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.debug('Getting Hypervisor host profiles')

        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_ov_auth')
        cluster_profile_uri = params.get('_cluster_profile_uri')

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_cluster_profile = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            hypervisor_host_profiles = hypervisor_cluster_profile.get(
                "hypervisorHostProfileUris")
            return self.exit_success(hypervisor_host_profiles)
        except Exception as e:
            self.LOG.debug(
                'Getting Hypervisor host profiles!' +
                traceback.format_exc())
            return self.exit_fail(str(e))
