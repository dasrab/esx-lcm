# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from orch.ism_sdk.activity import Ism_Error
from orch.moduleBase import ModuleBase
from orch.ism_sdk import InfrastructureSystems
from requests.exceptions import HTTPError
from lib.common import constants as const

class Synchronize_Unmanaged_Resource(ModuleBase):

    def categorize_resource(self, ism_client, cluster_info,
                            zone_uri):
        clustersId_from_gateway = [cluster.get('id')
                                   for cluster in cluster_info]
        self.LOG.debug("ClustersId for HPE Gateway =%s", clustersId_from_gateway)
        all_infra_systems_from_esx_lcm = (
            ism_client.get_all_infrastructure_systems())
        infra_sys_for_zone = [
            infra_sys_zone
            for infra_sys_zone in all_infra_systems_from_esx_lcm
            if infra_sys_zone.get("associatedZoneURI") == zone_uri]
        # existing_resources has both green field and brownfield resources
        existing_resources = []
        new_unmanaged_resources = []
        unmanaged_resource_to_be_deleted = []

        for cluster in cluster_info:
            new_resource = True
            for resource in infra_sys_for_zone:
                if cluster.get('id') == resource["id"]:
                    new_resource = False
                    existing_resources.append(resource)
                    break
            if new_resource and not self.is_zone_managed:
                new_unmanaged_resources.append(cluster)

        for resource in infra_sys_for_zone:
            if resource["id"] not in clustersId_from_gateway and not self.is_zone_managed:
                unmanaged_resource_to_be_deleted.append(resource)

        return {
            "existing_unmanaged_resources": existing_resources,
            "new_unmanaged_resources": new_unmanaged_resources,
            "unmanaged_resource_to_be_deleted":
                unmanaged_resource_to_be_deleted}

    def _categorize_datastores(self, datastores_from_gateway,
                               datastores_from_db):
        existing_datastores = []
        new_datastores = []
        datastores_to_be_deleted = []
        for new_ds in datastores_from_gateway:
            new_datastore = True
            for existing_ds in datastores_from_db:
                if new_ds['id'] == existing_ds['id']:
                    new_datastore = False
                    existing_datastores.append(existing_ds)
                    break
            if new_datastore:
                new_datastores.append(new_ds)
        for existing_ds in datastores_from_db:
            if existing_ds not in existing_datastores:
                datastores_to_be_deleted.append(existing_ds)

        return {"existing_datastores": existing_datastores,
                "new_datastores": new_datastores,
                "datastores_to_be_deleted": datastores_to_be_deleted}

    def _form_datastores_dict(self, datastores):
        datastore_list = list()
        for datastore in datastores:
            datastore_dict = {'id': datastore['id'],
                              'name': datastore['name'],
                              'sizeGiB': datastore['storage_capacity_gb'],
                              'type': datastore.get('type', "")}
            datastore_list.append(datastore_dict)
        return datastore_list

    def _get_datastores_dict_from_clusters(self, resource, cluster_info):
        datastores = list()
        for cluster in cluster_info:
            if cluster['id'] == resource['id']:
                datastores = datastores + cluster.get('datastores')
                break
        return self._form_datastores_dict(datastores)

    def _is_update_required(self, resource, cluster_info,
                            datastores_from_gateway):
        update_required = False
        for cluster in cluster_info:
            if resource['id'] == cluster['id']:
                # Check for Cluster Name Change
                if resource['name'] != cluster['cluster_name']:
                    self.LOG.info("Resource %s should be updated with name=%s from name= %s" % (
                        resource.get("id"), cluster.get("cluster_name"),
                        resource.get("name")))
                    update_required = True
                # Check for Cluster State change
                if resource['state'] != cluster['state']:
                    self.LOG.info("Resource %s should be updated with state=%s from state= %s" % (
                        resource.get("id"), cluster.get("state"),
                        resource.get("state")))
                    update_required = True
                # Check for Cluster Status change
                if resource['status'] != cluster['status']:
                    self.LOG.info("Resource %s should be updated with status=%s from status= %s" % (
                        resource.get("id"), cluster.get("status"),
                        resource.get("status")))
                    update_required = True

                # Instead of checking each field of host , lets compare the
                # whole list. Any change in the list attributes will evaluate
                # to not equal
                if resource.get('hosts', []) != cluster.get('hosts', []):
                    self.LOG.info(
                        "Update is required because the host resources has "
                        "been changed for cluster '{}'".format(
                            cluster.get("cluster_name")))
                    update_required = True

                # Get the existing datatsores from the resource
                datastores_from_db = resource.get('datastores')
                # Categorize Datastores
                categorized_datastores = self._categorize_datastores(
                    datastores_from_gateway, datastores_from_db)
                # Check for New Datastores Added
                if categorized_datastores.get('new_datastores'):
                    self.LOG.info("Update needed as New Datastores=%s added for Resource %s" % (
                        categorized_datastores['new_datastores'],
                        resource.get("id")))
                    update_required = True
                # Check for Existing Datastores Removed
                if categorized_datastores.get('datastores_to_be_deleted'):
                    self.LOG.info("Update needed as Existing Datastores=%s removed from Resource %s" % (
                        categorized_datastores['datastores_to_be_deleted'],
                        resource.get("id")))
                    update_required = True
                # Check for Datastore paramter changes
                if categorized_datastores.get('existing_datastores'):
                    for existing_ds in categorized_datastores.get(
                                        'existing_datastores'):
                        for new_ds in datastores_from_gateway:
                            if new_ds['id'] == existing_ds['id']:
                                # Check for Datastore Name Change
                                if new_ds['name'] != existing_ds['name']:
                                    self.LOG.info("Existing Datastore=%s should be updated with name=%s from name=%s" % (
                                        new_ds.get("id"),
                                        new_ds.get("name"),
                                        existing_ds.get("name")))
                                    update_required = True
                                # Check Datastore Total Disk Capacity Change
                                if new_ds['sizeGiB'] != existing_ds['sizeGiB']:
                                    self.LOG.info("Existing Datastore=%s should be updated with sizeGiB=%s from sizeGiB=%s" % (
                                        new_ds.get("id"),
                                        new_ds.get("sizeGiB"),
                                        existing_ds.get("sizeGiB")))
                                    update_required = True
            if update_required:
                break
        return update_required

    def sync_unmanaged_resource_for_esx_lcm(self, cluster_info, zone_uri,
                                            collect_hosts=False):
        allowed_states = ['Running']
        intermediate_states = ['Enabling', 'Disabling']
        ism_client = InfrastructureSystems(self.private_request)
        categorized_resource = self.categorize_resource(
            ism_client, cluster_info, zone_uri)
        for new_resource_to_be_created in categorized_resource[
                                            "new_unmanaged_resources"]:
            cluster_name = new_resource_to_be_created.get("cluster_name")
            cluster_id = new_resource_to_be_created.get("id")
            cluster_state = new_resource_to_be_created.get("state")
            cluster_status = new_resource_to_be_created.get("status")
            extraPayloadArgs = {
                "id": cluster_id,
                "managed": "False",
                "associatedZoneURI": zone_uri,
                "state": cluster_state,
                "status": cluster_status,
                "datastores": [],
                "hosts": []
            }

            if collect_hosts:
                extraPayloadArgs['hosts'] = new_resource_to_be_created.get(
                    'hosts')

            # Get the datastores from new cluster
            datastore_list = self._form_datastores_dict(
                new_resource_to_be_created.get('datastores'))
            if datastore_list:
                extraPayloadArgs['datastores'] = datastore_list
            try:
                ism_client.create_infrastructure_system(
                    cluster_name,
                    extraPayloadArgs=extraPayloadArgs)
                self.LOG.info("New resource named %s created with id %s and %s state" % (
                     cluster_name, cluster_id, cluster_state))
            except HTTPError as e:
                # handle only db conflict exception. For rest raise the exception.
                if "409 Client Error" in e.message:
                    self.LOG.warn("Ignoring the above exception: %s" % (
                        e.message))
                else:
                    self.LOG.warn("An exception occurred during infrastructure create: %s" % e.message)
                    raise e
        for existing_unmanaged_resource in categorized_resource[
                "existing_unmanaged_resources"]:
            self.LOG.debug("Resource %s with name %s already existing" % (
                          existing_unmanaged_resource["id"],
                          existing_unmanaged_resource["name"]))
            # Synchronization logic
            if existing_unmanaged_resource['infraState'] in allowed_states:
                if existing_unmanaged_resource['state'] in intermediate_states:
                    continue
                datastores_from_gateway = (
                    self._get_datastores_dict_from_clusters(
                        existing_unmanaged_resource, cluster_info))
                # Check whether updating the cluster is required
                updated_required = self._is_update_required(
                    existing_unmanaged_resource, cluster_info,
                    datastores_from_gateway)
                if not updated_required:
                    self.LOG.debug("Skipping Update for resource %s with name %s" % (
                        existing_unmanaged_resource.get("id"),
                        existing_unmanaged_resource.get("name")))
                    continue
                for cluster in cluster_info:
                    if cluster['id'] == existing_unmanaged_resource['id']:
                        new_state = cluster['state']
                        new_name = cluster['cluster_name']
                        new_status = cluster['status']
                        payload = [{"op": "replace",
                                    "path": "/name",
                                    "value": new_name},
                                   {"op": "replace",
                                    "path": "/datastores",
                                    "value": datastores_from_gateway},
                                   {"op": "replace",
                                    "path": "/state",
                                    "value": new_state},
                                   {"op": "replace",
                                    "path": "/status",
                                    "value": new_status}
                                   ]

                        if collect_hosts:
                            operation = "replace"
                            if not existing_unmanaged_resource.get('hosts'):
                                operation = "add"
                            payload.append(
                                {
                                    "op": operation,
                                    "path": "/hosts",
                                    "value": cluster.get('hosts')
                                }
                            )

                        if new_status == const.CRITICAL:
                            err = Ism_Error(
                                "LCM_HPE_GATEWAY_NOT_RESPONDING",
                                error_msg="HPE gateway agent is not responding ",
                                details=(
                                    "Possible reasons: "
                                    "1)The agent services in gateway not running, "
                                    "2)The gateway is powered off, "
                                    "3)IP of the gateway is changed, "
                                    "4)Any connectivity issue, "
                                )
                            ).to_error()
                        elif new_status == const.OK:
                            err = {}

                        payload.append({'op': 'replace',
                                        'path': '/error',
                                        'value': err})

                        break
                ism_client.update_infrastructure_system(
                    existing_unmanaged_resource['uri'],
                    payload)
                self.LOG.info(
                    "Existing resource %s has been updated with %s state" % (
                        new_name,
                        new_state))
            else:
                self.LOG.debug(
                    "Existing resource %s is not in desired state, i.e %s" % (
                        existing_unmanaged_resource.get("name"),
                        existing_unmanaged_resource.get("state")))
        for unmanaged_resource_to_be_deleted in categorized_resource[
                "unmanaged_resource_to_be_deleted"]:
            if unmanaged_resource_to_be_deleted['managed'] == "True":
                self.LOG.debug(
                    "Skipping Delete of resource %s with name %s" % (
                    unmanaged_resource_to_be_deleted["id"],
                    unmanaged_resource_to_be_deleted["name"]) +
                    " as it is not managed")
                continue
            self.LOG.info(
                "Deleting resource %s with name %s" % (
                unmanaged_resource_to_be_deleted["id"],
                unmanaged_resource_to_be_deleted["name"]) +
                " which is not existing in HPE gateway, but is there in esx lcm db")
            ism_client.delete_infrastructure_system(
                unmanaged_resource_to_be_deleted["uri"])
            self.LOG.info("Resource %s deleted with name %s" % (
                          unmanaged_resource_to_be_deleted["id"],
                          unmanaged_resource_to_be_deleted["name"]))

    def execute(self, params):
        cluster_info = params.get("unmanaged_resources")
        zone_uri = params.get("zone_uri")
        self.is_zone_managed = params.get("is_zone_managed")
        if isinstance(cluster_info, list):
            self.sync_unmanaged_resource_for_esx_lcm(
                cluster_info, zone_uri, params.get('collect_hosts'))
        else:
            # this should never happen
            self.LOG.warn(
                "get unmanaged servers returned non list object. Skipping synchronization")
        return self.exit_success("Synchornization completed successfully")
