#!/usr/bin/env python
# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP
"""
Created on Mar 21, 2016
@author: madhuchitloor@hpe.com
Module create_cluster_profile will handle cluster related task
"""

import base64
import traceback
import hpOneViewClrm as hpovclrm

from common import constants
from common.oneview_connector import OneviewConnector

from hpOneView.resources import task_monitor as tm
from hpOneView.exceptions import HPOneViewException

from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from orch.ism_sdk.activity import Ism_Error


DOCUMENTATION = '''
---
module: Create_Cluster_Profile
description: Creates Cluster Profile.
options:
    _ov_host:
        description:
            - appliance's address.
    _auth:
        description:
            - Oneview authentication token.
    _hypervisor_settings
        description:
             - hypervisor settings
    _hypervisor_manager_uri
        description:
             - hypervisor manager uri
    _network_uris
        description:
              uri of management networks
    _server_profile_template_uri
        description:
             - server profile template uri
    _server_hardware_types:
        description:
            - Array of server hardware types.
    _servers:
        description:
            - Array of server hardwares.
    _hypervisor_type:
        description:
            - Hypervisor type.
'''

EXAMPLES = '''
- name: create cluster profile
  create_cluster_profile:
    _ov_host: {{ ov_host }}
    _auth: {{ auth }}
    _hypervisor_settings: {{ hypervisorSettings }}
    _hypervisor_manager_uri: {{ hypervisor_manager_uri }}
    _network_uris: {{ mgmt_networks }}
    _server_profile_template_uri: {{server_profile_templates}}
    _server_hardware_types: {{ server_hardware_types }}
    _servers: {{ imported_nodes }}
    _hypervisor_type: "vSphere"
  register: hypervisor_cluster_profile
'''

RESPONSE = '''
{
    "hypervisorHostProfileUris": [
        "1212",
        "1313"
    ]
}
'''


class Create_Cluster_Profile(ModuleBase):
    """ Create_Cluster_Profile class will take care of creation of cluster profile"""

    def __init__(self):
        # 90 min is clrm create cluster profile time out another 5 min added
        # for safety
        self.task_timeout = constants.MIN_150
        self.step_tout = constants.SEC_30
        ModuleBase.__init__(self)

    def create_cluster_profile(
            self,
            cluster_profile,
            cluster_profile_name,
            hypervisor_type,
            server_profile_template_uri,
            deployment_plan_uri,
            server_password,
            server_hardware_uri,
            hypervisor_manager_uri,
            management_network_uri,
            datacenter_path,
            vSwitchType='Distributed',
            haEnabled=False,
            multiNicVMotion=False):
        """ create_cluster_profile method will make library call to create cluster"""
        self.LOG.debug("cluster_profile_name   '" + cluster_profile_name + "'")
        self.LOG.debug("hypervisor_type   '" + hypervisor_type + "'")

        for server_hardware_uri_element in server_hardware_uri:
            self.LOG.debug(server_hardware_uri_element)
            self.LOG.debug(
                "hypervisor_manager_uri '" +
                hypervisor_manager_uri +
                "'")
            self.LOG.debug("_datacenter_path   '" + datacenter_path + "'")

        self.LOG.debug(management_network_uri)

        task = cluster_profile.create_cluster_profile(
            cluster_profile_name,
            hypervisor_type,
            server_profile_template_uri,
            deployment_plan_uri,
            server_password,
            server_hardware_uri,
            hypervisor_manager_uri,
            None,
            datacenter_path,
            vSwitchType,
            haEnabled,
            multiNicVMotion,
            blocking=False)

        return task

    @staticmethod
    def get_hypervisor_cluster_prefix(name):
        """ get_hypervisor_cluster_prefix return cluster prefix passed in hyperviosr_settings"""
        return name

    @with_task('HCOE_ISM_CREATE_CLUSTER_PROFILE')
    def execute(self, params):
        try:
            ov_host = params.get('_ov_host')
            ov_port = params.get('_ov_port')
            auth = params.get('_auth')
            cluster_profile_name = self.get_hypervisor_cluster_prefix(
                params.get('_name'))
            hypervisor_type = params.get('_hypervisor_type')
            server_profile_template_uri = params.get(
                '_server_profile_template_uri')
            servers = params.get('_servers')
            deployment_plan_uri = params.get('_deployment_plan_uri')
            server_hardware_uris = []
            for server in servers:
                server_hardware_uris.append(server)

            hypervisor_manager_uri = params.get('_hypervisor_manager_uri')
            datacenter_path = params.get('_datacenterPath')
            server_password = base64.b64decode(params.get('_hostPassword'))

            msg = "Cluster Profile (%s) Creation " % cluster_profile_name
            fail_msg = msg + "Failed"
            self.LOG.debug(msg + "Started")

            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profile = hpovclrm.cluster_profile(connection)
            # will not block
            task = self.create_cluster_profile(
                cluster_profile,
                cluster_profile_name,
                hypervisor_type,
                server_profile_template_uri,
                deployment_plan_uri,
                server_password,
                server_hardware_uris,
                hypervisor_manager_uri,
                [],
                datacenter_path)

            self.update_task(20, msg + "Started")
            self.LOG.info("Checking OneView task: %s" % task['uri'])

            task_monitor = tm.TaskMonitor(connection)
            cluster_profile_resp = task_monitor.wait_for_task(
                task, timeout=self.task_timeout)

            self.LOG.debug("hypervisorHostProfileUris  '" +
                           str(cluster_profile_resp['hypervisorHostProfileUris']) + "'")
            self.LOG.debug("hypervisorclusterProfileUri  '" +
                           str(cluster_profile_resp['uri']) + "'")

            self.update_task(90, msg + "Completed")
            self.update_parent_task(70, msg + "Completed")
            return self.exit_success(cluster_profile_resp)

        except HPOneViewException as exe:
            self.update_task(90, fail_msg)
            self.update_parent_task(70, fail_msg)
            self.LOG.error(fail_msg)
            self.LOG.error(traceback.format_exc())
            raise Ism_Error('HCOE_ISM_CREATE_CLUSTER_PROFILE_FAILED',
                            details=fail_msg + '! got (' + str(exe) + ')')
        except Exception as e:
            self.update_task(90, fail_msg)
            self.update_parent_task(70, fail_msg)
            self.LOG.error(fail_msg)
            return self.exit_fail(str(e))
