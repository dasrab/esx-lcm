# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import time
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase

from common import constants
from hpeGateway import utils

LOG = log.getLogger(__name__)


class Synchronize_Kvm_Server_Roles(ModuleBase):

    def _wait_for_host_agent_gateway_connection(
            self, netloc, _path, _headers, host_id):
        retry_count = 0
        while True:
            host_agents = utils.get_host_agents(
                netloc, _path, _headers)
            for host_agent in host_agents:
                if host_agent.get('id') == host_id:
                    return
            if retry_count < constants.HOST_AGENT_RETRY_COUNT:
                self.LOG.info(
                    "Host id='{}' is not yet paired with gateway ! Re-check "
                    "again in {} seconds.".format(
                        host_id, constants.TASK_WAIT_DELAY * retry_count))
                time.sleep(constants.TASK_WAIT_DELAY * retry_count)
                retry_count += 1
        raise Exception("Timed out while waiting for KVM host id='{}' to be "
                        "connected with gateway!".format(host_id))

    def execute(self, params):
        resource_mgr_info = params['resource_mgr_info']
        try:
            host_id = params['host_id']
            _headers = {
                "Content-Type": "application/json",
                "X-Auth-Token": resource_mgr_info.get('token')
            }
            _url = urlparse.urlsplit(resource_mgr_info['resmgr_url'])
            v1_host_path = ''.join([_url.path, constants.V1_HOSTS_PATH])

            self._wait_for_host_agent_gateway_connection(
                _url.netloc, v1_host_path[:-1], _headers, host_id)

            host_path = ''.join([v1_host_path, host_id])
            if not utils._wait_for_kvm_host_agent(
                    _url.netloc, host_path, _headers):
                raise Exception("Failed to synchronize roles for KVM host "
                                "id='{}'".format(host_id))
            return self.exit_success("Successfully synchronized roles for KVM "
                                     "host id='{}'".format(host_id))
        except Exception as e:
            LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
