#!/usr/bin/env python
#
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.ism_sdk.activity import Ism_Error
from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector

from hpOneView.resources.servers.server_profiles import ServerProfiles
from hpOneView.resources.servers.server_hardware import ServerHardware
import hpOneViewClrm as hpovclrm


DOCUMENTATION = '''
---
module: Get the information like hypervisor hosts profile uris and
server hardware uris and publish it as ansible variable
options:
    _ov_host:
        description:
            Hostname of the OneView
    _auth:
        description:
            Auth key of Oneview
    _failed_hosts_ip:
        description:
            - Lists of hosts ips whose host profile and server hardware needs
            to be fetched
    _expanded_hypervisor_cluster_profiles:
        description:
            - The cluster profile whose hosts are not configured properly.
'''

EXAMPLES = '''
    - name: Get Failed Hosts Details
      vsan_get_failed_hosts:
         _ov_host: "15.213.234.167"
         _auth: "{{  auth }}"
         _failed_hosts_ip: "{{"172.18.11.11", "172.19.22.22"}}"
         _expanded_hypervisor_cluster_profiles:
                             "{{ hypervisor_cluster_profile }}"
      register: failed_hosts_details'''


class Vsan_Get_Failed_Hosts(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.debug("Fetching the host profiles and"
                       " server hardware details of hosts")
        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        failed_hosts_lists = params.get('_failed_hosts_ip')
        cluster_profile = params.get('_expanded_hypervisor_cluster_profiles')

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            hp_obj = hpovclrm.hypervisor_profiles(connection)
            sp_obj = ServerProfiles(connection)

            failed_host_profile_uris = []
            failed_server_hardware_uris = []

            for hp_uri in cluster_profile['hypervisorHostProfileUris']:
                host = hp_obj.get_hypervisor_profile_by_uri(hp_uri)
                ip_address = host['ipSettings']['ip']
                if ip_address in failed_hosts_lists:
                    sp = sp_obj.get(host['serverProfileUri'])
                    failed_server_hardware_uris.append(sp['serverHardwareUri'])
                    failed_host_profile_uris.append(hp_uri)

            self.LOG.debug("Host profiles and Server hardware uris "
                           "of failed hosts collected successfully")
            failed_hosts_details = {
                'hypervisor_host_profile_uris': failed_host_profile_uris,
                'server_hardware_uris': failed_server_hardware_uris}
            return self.exit_success(failed_hosts_details)
        except Exception as exc:
            self.LOG.exception("Failed to get host profile and "
                               "server hardware uris : %s" % str(exc))
            raise Ism_Error("NCS_VSAN_GET_HOST_DETAILS_FAILED",
                            details=str(exc))
