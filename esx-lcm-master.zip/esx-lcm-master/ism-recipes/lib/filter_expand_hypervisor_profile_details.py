# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
'''
Created on February 15, 2017
@author: mahalakshmi.mohankumar@hpe.com
'''

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Filter_Expand_Hypervisor_Profile_Details(ModuleBase):
    def execute(self, params):
        try:
            hypervisor_cluster_profile = params.get(
                "_hypervisor_cluster_profile")
            hypervisor_host_profile_uris = hypervisor_cluster_profile[
                'hypervisorHostProfileUris']

            expand_hypervisor_cluster_profile = params.get(
                "_expand_hypervisor_cluster_profile")
            expanded_hypervisor_host_profile_uris = expand_hypervisor_cluster_profile[
                'hypervisorHostProfileUris']

            new_hypervisor_host_profile_uris = []
            for host_profile_uri in list(expanded_hypervisor_host_profile_uris):
                if host_profile_uri not in hypervisor_host_profile_uris:
                    new_hypervisor_host_profile_uris.append(host_profile_uri)

            hypervisor_cluster_profile['hypervisorHostProfileUris'] = new_hypervisor_host_profile_uris

            return self.exit_success(hypervisor_cluster_profile)

        except Exception as e:
            self.LOG.exception(
                "Error during filtering of the expanded hypervisor profile details")
            raise Ism_Error(
                "HCOE_ISM_FILTER_EXPAND_HYPERVISOR_PROFILE_DETAILS_FAILED",
                details=str(e))
