# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import httplib
import time
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase

from common import constants
from hpeGateway import utils


class Check_Kvm_Host_Agent_Connection_Status(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        self.LOG = log.getLogger(__name__)

    def execute(self, params):
        resource_mgr_info = params['info']
        try:
            host_id = params['host_id']
            _headers = {
                "Content-Type": "application/json",
                "X-Auth-Token": resource_mgr_info.get('token')
            }
            _url = urlparse.urlsplit(resource_mgr_info['resmgr_url'])
            _path = ''.join([_url.path, constants.V1_HOSTS_PATH, host_id])

            retry_count = 0
            while True:
                host_agent = None
                try:
                    host_agent = utils.get_kvm_host_agent(
                        _url.netloc, _path, _headers)
                except httplib.HTTPException as e:
                    if str(httplib.NOT_FOUND) in e.message:
                        # Host id is not there in v1/hosts. Wait !
                        pass
                    else:
                        raise e
                if host_agent:
                    break
                if retry_count < constants.HOST_AGENT_RETRY_COUNT:
                    self.LOG.info(
                        "Host id='{}' is not yet paired with gateway! Retrying"
                        " again in {} seconds.".format(
                            host_id, constants.TASK_WAIT_DELAY * retry_count))
                    time.sleep(constants.TASK_WAIT_DELAY * retry_count)
                    retry_count += 1
                else:
                    msg = ("Timed out while waiting for the host to pair with "
                           "gateway. Please check "
                           "/var/log/host-agent-installation.log")
                    self.LOG.error(msg)
                    raise Exception(msg)

            hostname = host_agent['info']['hostname']
            is_healthy, _ = utils.is_healthy_host(host_agent)
            if not is_healthy:
                raise Exception(
                    "Host '{}' is not properly configured because of the "
                    "above errors !".format(hostname))

            self.LOG.info("Host agent with id='{}' | hostname='{}' is "
                          "successfully paired with gateway"
                          .format(host_agent['id'], hostname))
            return self.exit_success(
                {
                    'id': host_agent['id'],
                    'name': host_agent['info']['hostname'],
                    'paired': True
                }
            )

        except Exception as e:
            self.LOG.exception("Failed to determine kvm host agent id='{}' and"
                               "gateway pairing status !".format(host_id))
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
