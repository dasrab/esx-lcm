# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils


class Validate_Hostagent_Roles(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": None}

    def execute(self, params):
        host_agent_info = {}
        resmgr_info = params['info']
        self.headers['X-Auth-Token'] = resmgr_info['token']
        try:
            allowed_roles = ["pf9-monasca-agent", "pf9-cindervolume-other",
                             "pf9-cindervolume-base", "pf9-glance-role-vmw",
                             "pf9-ostackhost-vmw"]
            _, net_location, path, _, _ = urlparse.urlsplit(
                resmgr_info['resmgr_url'])
            # Do a REST call to get the roles from HPE gateway
            host_agent_roles = utils.get_all_host_agent_roles(net_location,
                                                              path,
                                                              self.headers)
            for role in allowed_roles:
                if role not in host_agent_roles:
                    msg = "%s role is not present in hpe gateway" % role
                    result = {'is_valid': False,
                              'details': msg, 'error_code': ''}
                    return self.exit_success(result)
            result = {'is_valid': True, 'details': '', 'error_code': ''}
            return self.exit_success(result)
        except Exception as e:
            result = {'is_valid': False, 'details': str(e), 'error_code': ''}
            return self.exit_success(result)
