# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

'''
Created on Jan 30, 2017

@author: arunkumar.viswanathan@hpe.com

'''

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Check_Minimum_Criteria(ModuleBase):

    def execute(self, params):

        self.LOG.debug("Host Name:" + self.private_request.hostname)

        operation = params.get("_operation")

        if operation == 'expand' or operation == 'build':
            raise Ism_Error(
                "SYN_ISM_MIN_CRITERIA_NOT_MET_ON_EXPAND",
                details="Minimum criteria not met during expand, leaving system in error state")

        return self.exit_success("")
