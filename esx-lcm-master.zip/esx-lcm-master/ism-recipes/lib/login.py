# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP


import traceback

from builtins import range
from future import standard_library

from common.oneview_connector import OneviewConnector
from hpOneView.exceptions import HPOneViewException
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error

standard_library.install_aliases()

DOCUMENTATION = '''
---
module: login
short_description: Login into the appliance.
description:
    - Login into the appliance and returns the authentication token.
options:
    _ov_host:
        description:
            - appliance's address.
    _username:
        description:
            - username.
    _password:
        description:
            - password.
'''

EXAMPLES = '''
  - name: login
    login:
      _ov_host:  '{{ applianceIP }}'
      _username:  'administrator'
      _password:  'hpvse123'
    register: return_json
'''


class Login(ModuleBase):
    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        ov_host = params.get('_ov_host')
        username = params.get('_username')
        password = params.get('_password')
        ov_port = params.get('_ov_port')

        credential = {'userName': username, 'password': password}
        connection = OneviewConnector(ov_host, ov_port).connect()

        # Login
        retries = 3
        for i in range(1, retries):
            try:
                connection.login(credential)
                break;
            except HPOneViewException as e:
                self.LOG.debug('Module failed! : ' + traceback.format_exc())
                raise Ism_Error("SYN_ISM_LOGIN_ONEVIEW_FAILED", details=str(e))
            except Exception as e:
                if "Connection timed out" in str(e) and i < retries:
                    self.LOG.debug(
                        "Time out detected. Retrying more " + str(retries - i) + "x times.")
                    pass
                else:
                    self.LOG.debug('Module failed! : ' +
                                   traceback.format_exc())
                    raise Ism_Error(
                        "SYN_ISM_LOGIN_ONEVIEW_FAILED", details=str(e))

        # Accept EULA
        try:
            if connection.get_eula_status() is True:
                connection.set_eula('no')
        except Exception as e:
            self.LOG.debug(' Module failed! : ' + traceback.format_exc())
            raise Ism_Error("SYN_ISM_UNABLE_TO_EULA_ONEVIEW", details=str(e))

        body_dict = {
            'auth': connection.get_session_id()
        }

        return self.exit_success(body_dict)
