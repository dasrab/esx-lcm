# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase
from common import utils
from common import models


class Allocate_Servers(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def _cleanup_allocated_server(self, AppManProxy, server_uri):
        try:
            AppManProxy.deallocate_server(server_uri)
            self.LOG.debug("Deallocated the Server: "
                           "'{}'".format(server_uri))
            return (0, None)
        except Exception:
            self.LOG.error("Couldnot Deallocate the Server: "
                           "'{}'".format(server_uri))
            return (1, server_uri)

    def _deallocate_servers(self, AppManProxy, servers):
        deallocation_failed_servers = []
        self.LOG.debug("De-allocating the servers previously allocated")
        for server in servers:
            if server.get('uri') is not None:
                ret_id, ret_value = self._cleanup_allocated_server(
                    AppManProxy, server['uri'])
                if ret_id == 1:
                    deallocation_failed_servers.append(ret_value)
        if not deallocation_failed_servers:
            return None
        else:
            self.LOG.error(
                "List of Servers Failed to Deallocate after allocation:"
                " {}".format(deallocation_failed_servers))
            return deallocation_failed_servers

    def execute(self, params):
        server_model = {}
        servers = []
        server_uris = []
        AppManProxy, response = None, None
        err_msg = ""
        try:
            server_model['serverBlueprintUri'] = params['serverBlueprintUri']
            server_model['requestedState'] = "Allocated"
            server_model['_type'] = "Server"
            server_model['_version'] = "1"
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            server_count = params['server_count']
            err_msg = ("Allocate Servers failed for '{}'"
                       .format(params['serverBlueprintUri']))
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            for _ in range(server_count):
                result = AppManProxy.allocate_server(server_model)
                server = models.Server(result)
                serialize_server = server.serialize()
                self.LOG.debug(
                    "Successfully Allocated Server: "
                    "'{}' for serverBlueprint '{}'".format(
                        server._get_server_uri(),
                        server._get_sbp_uri()))
                server_uris.append(server._get_server_uri())
                servers.append(serialize_server)
            msg = ("Servers Allocated '{}' for serverBlueprint {}"
                   .format(server_uris, params['serverBlueprintUri']))
            self.update_parent_task(40, msg)
            return self.exit_success(servers)
        except KeyError as e:
            self.LOG.error(err_msg)
            self.update_parent_task(40, err_msg + "! got " + str(e))
            if AppManProxy is not None:
                servers.append(result)
                response = self._deallocate_servers(AppManProxy, servers)
            return self.exit_fail(
                str(e), str("Servers failed to deallocate: "
                            "{}".format(response)))
        except Exception as exception:
            self.LOG.error(err_msg)
            self.update_parent_task(40, err_msg + "! got " + str(exception))
            if (AppManProxy and servers):
                response = self._deallocate_servers(AppManProxy, servers)
            return self.exit_fail(
                str(exception), str("Servers failed to deallocate: "
                                    "{}".format(response)))
