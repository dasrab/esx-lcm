# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error

DOCUMENTATION = '''
---
module: validate_less_than_or_equal
short_description: Validate if if expected value is less than or equal actual value
description:
    -  Validate if the expected value is less than or equal the actual value. This module returns a boolean indicating
    if the condition is true or fails raising an Ism_Error in case it's false.
options:
    _validation_name:
        description:
             - name of validation being performed
    _error_code:
        description:
             - error code to be used in case of failure
    _actual:
        description:
            - actual value
    _expected:
        description:
            - expected value
'''

EXAMPLES = '''
- name: Validate Necessary Count
  validate_less_than_or_equal:
    _validation_name: "Mgmt IP Range"
    _actual: 1
    _expected: 16

How to test with ModuleDebug:

python 	moduleDebug.py validate_less_than_or_equal -e '{
    "_validation_Name": "Mgmt IP Range",
    "_actual": 3,
    "_expected": 2
}'
'''


class Validate_Less_Than_Or_Equal(ModuleBase):

    def execute(self, params):
        self.LOG.debug("Validating less than or equal...")

        validation_name = params.get('_validation_name')
        actual = params.get('_actual')
        expected = params.get('_expected')
        error_code = params.get('_error_code')

        # Validation name is used only for debugging messages, so, it shouldn't
        # be mandatory.
        if validation_name is None or not isinstance(
                validation_name, basestring):
            validation_name = ""

        # By default, error_code is a generic key to support backward
        # compatibility.
        if error_code is None or not isinstance(error_code, basestring):
            error_code = "SYN_ISM_GENERIC_MODULE_ERROR"

        if actual is None or not isinstance(actual, int):
            return self.exit_success(
                {"is_valid": False, "error_code": "HCOE_ISM_VALIDATE_NET_INVALID_ACTUAL_SIZE", "details": ""})

        if expected is None or not isinstance(expected, int):
            return self.exit_success(
                {"is_valid": False, "error_code": "HCOE_ISM_VALIDATE_NET_INVALID_EXPECTED_SIZE", "details": ""})

        if expected <= actual:
            return self.exit_success(
                {"is_valid": True, "error_code": "", "details": ""})
        else:
            failure_details = validation_name + " Validation error: should have " + \
                str(expected) + ", but has only " + str(actual)
            self.LOG.exception(failure_details)
            return self.exit_success(
                {"is_valid": False, "error_code": error_code, "details": failure_details})
