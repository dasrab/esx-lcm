# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

'''
Created on Jan 27, 2017

@author: arunkumar.viswanathan@hpe.com

'''

from orch.moduleBase import ModuleBase


class Get_Association_For_Cleanup(ModuleBase):

    def execute(self, params):

        hypervisor_cluster_profile_uri = params.get(
            "_hypervisor_cluster_profile_uri")
        hypervisor_host_profile_uris = params.get(
            "_hypervisor_host_profile_uris")
        server_hardware_uris = params.get("_server_hardware_uris")

        association = {"cluster_profile": hypervisor_cluster_profile_uri,
                       "host_profile": hypervisor_host_profile_uris,
                       "server_hardware": server_hardware_uris}

        body_dict = {"association": association}
        return self.exit_success(body_dict)
