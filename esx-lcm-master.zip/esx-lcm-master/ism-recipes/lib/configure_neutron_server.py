# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import json
import urlparse
import traceback

from hpeGateway import utils
from orch import log
from orch.moduleBase import ModuleBase
from lib.hpeGateway import vmware_neutron_utils


class Configure_Neutron_Server(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            neutron = {"enabled": params['vmware_neutron'],
                       "ep_present": params['res_mgr_info']['neutron_ep_present']}
            if utils.is_neutron_enabled(neutron):
                self.LOG.debug("Configuring neutron server")
                # Create a VMWareNeutronConf object
                neutron = vmware_neutron_utils.VMwareNeutronConf(params)
                neutron.update_neutron_server_conf()
            else:
                #TODO: DO we get into this Situation? I hope NO
                self.LOG.warning("Neutron is disabled")
            return self.exit_success(True)
        except Exception as e:
            self.LOG.exception("Configuring Neutron Server Failed!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))

