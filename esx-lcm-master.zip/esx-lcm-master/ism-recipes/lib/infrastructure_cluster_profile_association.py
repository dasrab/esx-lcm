# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase


class Infrastructure_Cluster_Profile_Association(ModuleBase):

    def execute(self, params):
        try:
            self.LOG.debug(
                'Executing Infrastructure_Cluster_Profile_Association')

            hypervisor_cluster_name = params.get('_hypervisor_cluster_name')
            hypervisor_clusters = params.get('_hypervisor_clusters')
            target_cluster_profile_uri = None
            target_cluster_uri = None

            for hypervisor_cluster in hypervisor_clusters:
                if (type(hypervisor_cluster) is dict) and (
                        hypervisor_cluster_name == hypervisor_cluster.get("name")):
                    target_cluster_profile_uri = hypervisor_cluster.get("uri")
                    target_cluster_uri = hypervisor_cluster.get(
                        "hypervisorClusterUri")

            association = {"cluster_profile_uri": target_cluster_profile_uri,
                           "cluster_uri": target_cluster_uri
                           }

            bodyDict = {"association": association}
            self.LOG.debug('Association Data : ' + str(bodyDict))

            return self.exit_success(bodyDict)

        except Exception as e:
            self.LOG.debug("Some exception occured in infrastructure system "
                           "and cluster profile association")
            self.exit_fail(str(e))
