#!/usr/bin/env python
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback

from future import standard_library

from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector
import hpOneViewClrm as hpovclrm
from hpOneView.resources.servers import server_profiles


standard_library.install_aliases()

DOCUMENTATION = '''
---
module: get_all_server_hardware_from_hypervisor_cluster_profile_uri
short_description: Get all server hardwares
description:
    - Get all server hardware from oneview
'''


class Get_All_Server_Hardware_From_Hypervisor_Cluster_Profile_Uri(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        try:
            server_hardwares = []
            cluster_profile_uri = params.get("_cluster_profile_uri")
            self.LOG.debug(
                "Getting all server hardwares of hypervisor cluster profile - " +
                str(cluster_profile_uri))
            ov_host = params.get("_ov_host")
            auth = params.get("_auth")
            connection = OneviewConnector(ov_host, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_host_profiles = hpovclrm.hypervisor_profiles(
                connection)
            server_connection = server_profiles.ServerProfiles(connection)
            hypervisor_cluster = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            hypervisor_Host_Profile_Uris = hypervisor_cluster.get(
                "hypervisorHostProfileUris")
            for hypervisorHostProfile in hypervisor_Host_Profile_Uris:
                host_profile_body = hypervisor_host_profiles.get_hypervisor_profile_by_uri(
                    hypervisorHostProfile)
                server_profile_uri = host_profile_body.get("serverProfileUri")
                server_profile = server_connection.get(server_profile_uri)
                server_hardware_uri = server_profile.get("serverHardwareUri")
                server_hardwares.append(server_hardware_uri)
            self.LOG.debug(
                "List of server hardwares of hypervisor cluster profile - " +
                str(server_hardwares))

            return self.exit_success(server_hardwares)
        except Exception as e:
            self.LOG.debug(
                "Some exception occured in Getting all server hardwares of hypervisor cluster profile")
            return self.exit_fail(e)
