# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase
from common import utils


class Unregister_Applianceimages(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            AppManProxy.unregister_applianceimage(params['app_image_uri'])
            return self.exit_success("Deleted requested ApplianceImage: "
                                     "{}".format(params['app_image_uri']))
        except Exception as exception:
            self.LOG.error("Failed to delete ApplianceImage {}".format(
                params['app_image_uri']))
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(str(exception))
