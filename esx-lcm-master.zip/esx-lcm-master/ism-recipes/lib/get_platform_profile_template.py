# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import traceback
from orch import log
from common import constants

from orch.moduleBase import ModuleBase

PLATFORM_PROFILE_FILE_NAME = "platform_profile_template.json"


class Get_Platform_Profile_Template(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def _read_file(self, filename):
        with open(filename, 'r+') as content:
            return (json.load(content))

    def execute(self, params):

        try:
            template_name = params.get("profile_template_name")
            template_file = constants.TEMPLATES_PATH + '/' + PLATFORM_PROFILE_FILE_NAME
            profile_template_json = self._read_file(template_file)
            if not template_name:
                template_name = profile_template_json[
                    "default_profile_template"]
            for template in profile_template_json["profile_templates"]:
                if template["name"] == template_name:
                    return self.exit_success(template)
            return self.exit_fail(
                "Invalid Platform Profile Template name specified.")
        except Exception as e:
            self.LOG.exception("Get Platform Profile Template failed.!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
