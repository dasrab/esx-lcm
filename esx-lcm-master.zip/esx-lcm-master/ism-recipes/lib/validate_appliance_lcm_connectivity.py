# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase

from common import utils


class Validate_Appliance_Lcm_Connectivity(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            appliance_lcm_info = {}
            appliance_lcm_info['appliance_ip'] = params['appliance_manager_ip']
            appliance_lcm_info['appliance_port'] = (
                params['appliance_manager_port'])
            AppManProxy = utils.ApplianceManagerProxy(appliance_lcm_info)
            result = AppManProxy.get_servers()
            result = {'is_valid': True, 'details': '', 'error_code': ''}
            return self.exit_success(result)
        except Exception as e:
            result = {'is_valid': False, 'details': str(e), 'error_code': ''}
            return self.exit_success(result)
