#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback

from future import standard_library

from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector
import hpOneViewClrm as hpovclrm

standard_library.install_aliases()

DOCUMENTATION = '''
---
module: get_inventory_hypervisor_clusters
short_description: Get all hypervisor clusters in ISM inventory
description:
    - Get all hypervisor clusters in ISM inventory
'''

EXAMPLES = '''
  - name: Get Inventory Hypervisor Clusters
    get_inventory_hypervisor_clusters: {}
'''


class Get_Inventory_Hypervisor_Clusters(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        self.LOG.debug("Getting all hypervisor clusters")

        try:
            ov_host = params.get("_ov_host")
            ov_port = params.get("_ov_port")
            auth = params.get("_auth")
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_clusters = cluster_profiles.get_cluster_profiles()
            return self.exit_success(hypervisor_clusters)
        except Exception as e:
            self.LOG.debug(
                "Exception occured in getting all hypervisor clusters")
            return self.exit_fail(e)
