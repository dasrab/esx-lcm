# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Fail_When(ModuleBase):
    def execute(self, params):
        condition = params.get("_condition")
        error_code = params.get("_error_code")
        task_name = params.get("_task_name")
        details = params.get("_details")

        if not error_code:
            error_code = "SYN_ISM_GENERIC_VALIDATION_ERROR"

        if not details:
            details = ''
        else:
            details = str(details)

        if task_name:
            self.add_task(self.parent_id, task_name)

        if condition:
            self.LOG.debug(
                'Fail_when failed the execution with condition: ' +
                str(condition))
            raise Ism_Error(error_code, details=details)

        return self.exit_success({})
