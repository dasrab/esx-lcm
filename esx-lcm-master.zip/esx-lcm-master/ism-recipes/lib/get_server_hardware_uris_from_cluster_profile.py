# (C) Copyright 2018 Hewlett Packard Enterprise Development LP
import traceback

from orch.moduleBase import ModuleBase
import hpOneViewClrm as hpovclrm

from common.oneview_connector import OneviewConnector
from hpOneView.resources.servers import server_profiles as ov_server_profiles


class Get_Server_Hardware_Uris_From_Cluster_Profile(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        self.LOG.debug("Getting all hypervisor clusters")

        try:
            server_hardware_uris = list()
            ov_host = params.get("_ov_host")
            ov_port = params.get("_ov_port")
            auth = params.get("_auth")
            cluster_profile_uri = params.get("_cluster_profile_uri")
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_cluster = cluster_profiles.get_cluster_by_uri(cluster_profile_uri)
            hypervisor_profiles = hpovclrm.hypervisor_profiles(connection)
            server_profiles = ov_server_profiles.ServerProfiles(connection)
            for host_profile_uri in hypervisor_cluster['hypervisorHostProfileUris']:
                host_profile = hypervisor_profiles.get_hypervisor_profile_by_uri(host_profile_uri)
                server_profile = server_profiles.get(host_profile['serverProfileUri'])
                server_hardware_uris.append(server_profile['serverHardwareUri'])
            return self.exit_success(server_hardware_uris)
        except Exception as e:
            self.LOG.debug(
                "Exception occured in getting server hardware uris from cluster profile")
            self.LOG.debug(traceback.format_exc())
            return self.exit_fail(e)
