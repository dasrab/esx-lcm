#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager

DOCUMENTATION = '''
---
module: Pre update VSAN cluster validation
description: Performs the validation for VSAN cluster before update
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
'''

EXAMPLES = '''
- name: Execute pre-update check for VSAN
    vsan_pre_update_validation:
      vc_host: "172.18.200.106"
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_port: 443
      vc_cluster: "Nested_Vsan"'''


class Vsan_Pre_Update_Validation(ModuleBase):
    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        self.LOG.info("Performing per update validations.")
        (status, error_msg) = vsan_cm.pre_update_validation(
            params)
        if status:
            return self.exit_success({'status': status, 'error': error_msg})
        else:
            self.LOG.error(error_msg)
            return self.exit_fail(status, error_msg)
