#!/usr/bin/env python
# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase

import hpOneViewClrm as hpovclrm
from hpOneView.resources import task_monitor as tm
from common.oneview_connector import OneviewConnector

from common import constants
from hpOneView.exceptions import *

DOCUMENTATION = '''
---
module: Update Cluster HA
description: Enable and Disable cluster HA settings
options:
    _ov_host:
        description:
            - Oneview host IP.
    _auth:
        description:
            - Oneview Auth token
    _cluster:
       description:
            - Name of the vCenter cluster
    _ha_enable:
        description: Bool
            - True: To enable cluster HA.
                    Skip if already enabled.
            - False: To disable cluster HA.
                     Skip if already disabled.
'''

EXAMPLES = '''
- name: VSAN HA settings
  update_cluster_ha:
     _ov_host: "172.18.208.201"
     _auth: "LTcyOTMyNjQwNjQ3wBx7v6lcFXKm_0oHuQyxLaDRbqNHmi"
     _ha_enable: True
     _cluster: "Ace-cluster"'''


class Update_Cluster_Ha(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        self.task_timeout = constants.MIN_3
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def get_cluster_profile(self, cluster_profiles, cluster):
        for cluster_profile in cluster_profiles:
            if cluster_profile['name'] == cluster:
                return cluster_profile
        return None

    def execute(self, params):
        self.LOG.debug('Executing update cluster HA')

        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        ha_enable = params.get('_ha_enable')
        cluster = params.get('_cluster')

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            ov_clrm_sdk = hpovclrm.cluster_profile(connection)
            cluster_profiles = ov_clrm_sdk.get_cluster_profiles()

            update_cluster_profile = self.get_cluster_profile(
                cluster_profiles, cluster)
            if update_cluster_profile is None:
                self.LOG.error("No cluster with name '%s' found" % cluster)
                return self.exit_fail(cluster + ": Not found")
            if update_cluster_profile['hypervisorClusterSettings'][
                    'haEnabled'] is not(ha_enable):
                update_cluster_profile['hypervisorClusterSettings'][
                    'haEnabled'] = ha_enable
            else:
                mgs = "HA settings are already " +\
                    ("disabled", "enabled")[ha_enable]
                self.LOG.info(mgs)
                return self.exit_success(True)
            task = ov_clrm_sdk.update_cluster_profile(update_cluster_profile)
            task_monitor = tm.TaskMonitor(connection)
            self.LOG.debug("Waiting for task to %s cluster ha settings to "
                           "complete" % ("disabled", "enabled")[ha_enable])
            task_monitor.get_completed_task(task, timeout=self.task_timeout)

        except HPOneViewException as exc:
            self.LOG.error(
                'Task %s cluster ha settings failed. Could not update cluster'
                '("%s")' % (("disabled", "enabled")[ha_enable], cluster))
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(ov_host + ": " + str(exc))
        except (HPOneViewException, HPOneViewTimeout, Exception) as exc:
            self.LOG.error(
                'Task %s cluster ha settings failed. Could not update cluster'
                '("%s")' % (("disabled", "enabled")[ha_enable], cluster))
            return self.exit_fail(cluster + ": " + str(exc))
        return self.exit_success(True)
