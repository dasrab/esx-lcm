#!/usr/bin/env python
# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import traceback
from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from common import constants
from common.oneview_connector import OneviewConnector
from hpOneView.exceptions import HPOneViewTimeout
from hpOneView.exceptions import HPOneViewException

import hpOneViewClrm as hpovclrm
from hpOneView.resources import task_monitor as tm


class Update_Cluster_Profile(ModuleBase):
    """ Update_Cluster_Profile class will take care of updation of cluster profile"""

    def __init__(self):
        # 90 min is clrm create cluster profile time out another 5 min added
        # for safety
        self.task_timeout = constants.MIN_150
        self.step_tout = constants.SEC_30
        ModuleBase.__init__(self)

    def update_cluster_profile(self, cluster_profile, cluster_profile_uri):
        """ update_cluster_profile method will make library call to remediate cluster"""
        task = cluster_profile.remediate(
            cluster_profile_uri=cluster_profile_uri)
        return task

    @staticmethod
    def get_hypervisor_cluster_prefix(hypervisor_settings):
        """ get_hypervisor_cluster_prefix return cluster prefix passed in hyperviosr_settings"""
        return hypervisor_settings['hypervisorCluster']['name']

    @with_task('HCOE_ISM_UPDATE_CLUSTER_PROFILE')
    def execute(self, params):
        ov_host = params.get('_ov_host')
        auth = params.get('_auth')
        cluster_profile_uri = params.get('_cluster_profile_uri')
        hypervisor_settings = params.get('_hypervisor_settings')
        cluster_profile_name = self.get_hypervisor_cluster_prefix(
            hypervisor_settings)

        self.LOG.debug("Updating cluster Profile  - " + cluster_profile_name)

        connection = OneviewConnector(ov_host, auth).connect()
        cluster_profile = hpovclrm.cluster_profile(connection)

        self.LOG.debug(
            "Updating cluster profile '" +
            cluster_profile_name +
            "'")

        try:
            # will not block
            task = self.update_cluster_profile(
                cluster_profile, cluster_profile_uri)

        except HPOneViewException as exe:
            self.LOG.error(
                'Task update cluster profile failed. Could not update cluster: ' +
                cluster_profile_name)
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(cluster_profile_name + ": " + str(exe))
        except Exception as exception:
            self.LOG.error(
                'Task update cluster profile failed. Could not update cluster: ' +
                cluster_profile_name)
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(cluster_profile_name + ": " + str(exception))

        self.LOG.debug("Checking task  :'" + task['uri'] + "'")

        try:
            task_monitor = tm.TaskMonitor(connection)
            cluster_profile_resp = task_monitor.wait_for_task(
                task, timeout=self.task_timeout)

            self.LOG.debug("hypervisorHostProfileUris  '" +
                           str(cluster_profile_resp['hypervisorHostProfileUris']) + "'")
            self.LOG.debug("hypervisorclusterProfileUri  '" +
                           str(cluster_profile_resp['uri']) + "'")

            return self.exit_success(cluster_profile_resp)

        except HPOneViewTimeout as etimeout:
            self.LOG.error(
                'Task update cluster profile failed. Could not update cluster: ' +
                cluster_profile_name)
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(cluster_profile_name + ": " + str(etimeout))
        except Exception as e:
            self.LOG.error(
                'Task update cluster profile failed. Could not update cluster: ' +
                cluster_profile_name)
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(cluster_profile_name + ": " + str(e))
