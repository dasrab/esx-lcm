# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils


class Get_Managed_Clusters(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        host_agent_info = params['all_host_agent_info']
        resmgr_info = params['resmgr_info']
        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": resmgr_info['token']}
        try:
            _url = urlparse.urlsplit(resmgr_info['resmgr_url'])
            path = '/'.join([_url.path, 'v1/hosts'])
            managed_clusters = list()
            for host_agent in host_agent_info:
                role_path = path + "/" + host_agent['id']
                clusters = utils.get_all_managed_clusters_from_hpe_gateway(
                    _url.netloc, role_path, headers)
                agent = dict()
                agent['host_id'] = host_agent['id']
                agent['ip_address'] = host_agent['ip_address']
                agent['name'] = host_agent['hostname']
                agent['clusters'] = clusters
                managed_clusters.append(agent)
            return self.exit_success(managed_clusters)
        except Exception as e:
            self.LOG.exception('Get Managed Clusters failed!')
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
