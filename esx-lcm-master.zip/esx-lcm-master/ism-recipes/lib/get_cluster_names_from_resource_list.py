# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback

from orch import log
from orch.moduleBase import ModuleBase


class Get_Cluster_Names_From_Resource_List(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            cluster_names = {'enable_clusters': [],
                             'disable_clusters': []}
            resource_list = params['resource_list']
            for resources in resource_list:
                if resources['state'] == 'Enabling':
                    cluster_names['enable_clusters'].append(resources['name'])
                if resources['state'] == 'Disabling':
                    cluster_names['disable_clusters'].append(resources['name'])
            return self.exit_success(cluster_names)

        except Exception as e:
            self.LOG.debug("Exception in getting clusters from resource list")
            self.LOG.debug(traceback.format_exc())
            return self.exit_fail(str(e))
