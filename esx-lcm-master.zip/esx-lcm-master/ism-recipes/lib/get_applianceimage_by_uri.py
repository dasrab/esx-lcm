# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log
from orch.moduleBase import ModuleBase

from common import utils


class Get_Applianceimage_By_Uri(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            result = AppManProxy.get_applianceimage_by_uri(
                params['applianceimage_uri'])
            self.LOG.debug("Successsfully fetched ApplianceImage: "
                           "'{}'".format(result['name']))
            return self.exit_success(result)
        except Exception as exception:
            self.LOG.error(
                "Could not get requested ApplianceImage: "
                "'{}'".format(params['applianceimage_uri']))
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(
                params['applianceimage_uri'] +
                ": " +
                str(exception))
