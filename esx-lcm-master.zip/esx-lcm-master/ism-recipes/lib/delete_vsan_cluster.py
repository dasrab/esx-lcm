#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager

DOCUMENTATION = '''
---
module: Delete VSAN cluster
description: Deletes the VSAN cluster.
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
    force_delete:
        description:
            - Whether cluster should be force deleted
'''

EXAMPLES = '''
- name: Delete VSAN cluster
    delete_vsan_cluster:
      vc_host: "172.18.200.106"
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_port: 443
      vc_cluster: "Nested_Vsan"
      force_delete: False
    register: delete_result'''


class Delete_Vsan_Cluster(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        self.LOG.info("Deleting VSAN cluster.")
        force_delete = params.get('force_delete')
        try:
            (status, error_msg) = vsan_cm.delete_cluster(params)
        except Exception as exc:
            self.LOG.exception('Exception in execute of Vsan_Get_Disk_Info :: '
                               '%s' % str(exc))
            if force_delete:
                # since force_delete, do not fail.
                return self.exit_success({'status': True,
                                          'error': str(exc),
                                          'errorCode': ''})
            else:
                return self.exit_fail(status, str(exc))
        else:
            self.LOG.info("Delete VSAN cluster status: %s" % str(status))
            if status or force_delete:
                return self.exit_success({'status': True, 'error': error_msg})
            else:
                self.LOG.error(error_msg)
                return self.exit_fail(status, error_msg)
