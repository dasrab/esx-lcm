#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback
import hpOneViewClrm as hpovclrm

from common.oneview_connector import OneviewConnector
from orch.moduleBase import ModuleBase
from time import sleep

DOCUMENTATION = '''
---
module: delete_hypervisor_manager
short_description: Delete the given Hypervisor Manager.
description:
    -  Delete the given hypervisor manager from Oneview.
options:
    _ov_host:
        description:
            - appliance's address.
    _auth:
        description:
             - Oneview authentication token.
    _hypervisor_manager_uri:
        description:
             - hypervisor manager uri in Oneview
'''

EXAMPLES = '''
- name: delete hypervisor manager
  delete_hypervisor_manager:
    _ov_host:  {{ ov_host }}
    _auth:  {{ auth }}
    _hypervisor_manager_uri: "{{ hypervisor_manager_uri }}"
  register: return_json
'''


class Delete_Hypervisor_Manager(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        hypervisor_manager_uri = params.get('_hypervisor_manager_uri')

        connection = OneviewConnector(ov_host, ov_port, auth).connect()
        hypervisor_managers = hpovclrm.hypervisor_managers(connection)

        self.LOG.debug("Deleting Hypervisor Manager  '" + str(hypervisor_manager_uri) + "'")
        _retries = 3
        self.LOG.debug('Retry deleting Hypervisor manager is set to 3 !')
        for i in range(_retries):
            try:
                hypervisor_managers.delete_hypervisor_manager(
                    hypervisor_manager_uri, blocking=True)
                self.LOG.debug("Successfully deleted Hypervisor Manager '" + str(hypervisor_manager_uri) + "'")
                return self.exit_success(hypervisor_manager_uri)
            except Exception as exception:
                if i < _retries - 1:    # i is zero indexed
                    sleep(5)
                    continue
                else:
                    self.LOG.warn('Failed to delete Hypervisor Manager with URI ' + str(hypervisor_manager_uri))
                    self.LOG.warn(traceback.format_exc())
                    return self.exit_success(hypervisor_manager_uri)
