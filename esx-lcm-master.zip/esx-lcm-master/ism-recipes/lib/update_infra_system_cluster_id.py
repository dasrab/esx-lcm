# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from orch.ism_sdk import InfrastructureSystems
from orch.ism_sdk.activity import Ism_Error


class Update_Infra_System_Cluster_Id(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            ism_client = InfrastructureSystems(self.private_request)
            cluster_id = params.get('cluster_id')
            payload = [{"op": "replace",
                        "path": "/id",
                        "value": cluster_id}]
            ism_client.update_infrastructure_system(
                params.get('infra_system_uri'), payload)

            self.LOG.info("Successfully updated InfrastructureSystem "
                          "id={}".format(cluster_id))
            return self.exit_success(
                {
                    'infra_system_uri': params.get('infra_system_uri'),
                    'id': cluster_id
                })
        except Exception as e:
            self.LOG.exception('Failed to update InfrastructureSystem Id: {}'.format(e))
            raise Ism_Error(
                "HCOE_ISM_UPDATE_INFRA_ID_FAILED",
                details=str(e))
