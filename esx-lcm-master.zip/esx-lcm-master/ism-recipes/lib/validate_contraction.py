# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase

DOCUMENTATION = '''
module: validate_contraction
short_description: Validate the rules for contraction
description:
    Rules for contraction validation:
    - The selected target-hosts must belong to the same cluster
    - After flexdown is done the cluster must have node equal to min_nodes_for_cluster
      which can be edited in ism-recipes/playbooks/properties/cluster_configuration_parameters.yml
'''


class Validate_Contraction(ModuleBase):

    min_nodes_for_clusters = None

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        self.LOG.debug("Validating target hosts for contraction")
        servers_flex_down = params.get('_servers_to_flex_down')
        self.min_nodes_for_clusters = params.get('_min_cluster_nodes')
        servers_cluster_profile = params.get(
            '_server_hardwares_of_hypervisor_cluster_profile')

        try:
            self.validate_cluster_hosts(
                servers_flex_down, servers_cluster_profile)
            self.validate_cluster_size(
                servers_flex_down, servers_cluster_profile)
        except Exception as exception:
            self.LOG.debug(
                "Cluster Contraction cannot be executed: " +
                str(exception))
            return self.exit_fail(exception)

        return self.exit_success(
            "Contraction validation completed with success")

    def validate_cluster_hosts(
            self,
            servers_flex_down,
            servers_cluster_profile):
        for servers in servers_flex_down:
            if servers not in servers_cluster_profile:
                self.LOG.debug(
                    str(servers) + " does not belong to current cluster")
                raise Exception(
                    "Error - All hosts should belong to the same cluster")

    def validate_cluster_size(
            self,
            servers_flex_down,
            servers_cluster_profile):

        if len(servers_cluster_profile) - \
                len(servers_flex_down) < self.min_nodes_for_clusters:
            raise Exception("Error - You cannot have a single cluster with less than '" +
                            str(self.min_nodes_for_clusters) +
                            "' nodes per cluster"
                            )
