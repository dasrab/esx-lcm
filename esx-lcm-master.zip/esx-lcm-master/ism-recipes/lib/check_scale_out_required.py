# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback

from orch import log
from orch.moduleBase import ModuleBase


class Check_Scale_Out_Required(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        managed_clusters = params['managed_clusters']
        cluster_scale_count = int(params['cluster_scale_count'])
        new_cluster_list = params['new_cluster_list']
        clusters_allowed = 0
        try:
            for managed_cluster in managed_clusters:
                clusters_allowed += cluster_scale_count - \
                    len(managed_cluster['clusters'])
            # Compute whether existing host agents can manage new clusters
            # also.
            if clusters_allowed >= len(new_cluster_list):
                return self.exit_success({"new_ova_required": "False"})
            else:
                return self.exit_success({"new_ova_required": "True"})
        except Exception as e:
            self.LOG.exception('Check for New Host Agent failed!')
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
