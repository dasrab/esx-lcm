# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase


class Get_Server_Hardware_Uris(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):

        try:
            server_hardware_uris = list()
            allocated_servers = params['allocated_servers']
            for server in allocated_servers:
                server_hardware_uris.append(server['serverHardwareUri'])
            return self.exit_success(server_hardware_uris)
        except Exception as e:
            self.LOG.exception("Get Server Hardware Uris failed.!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
