# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import hpOneViewClrm as hpovclrm

from orch.moduleBase import ModuleBase
from orch.ism_sdk import InfrastructureSystems
from orch.ism_sdk.activity import Ism_Error

from common.oneview_connector import OneviewConnector


class Update_Infra_System_Node_Count(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        try:
            connection = OneviewConnector(params['_ov_host'], params['_ov_port'], params['_auth']).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            hypervisor_cluster_profile = (
                cluster_profiles.get_cluster_profile_by_uri(
                    params['cluster_profile_uri']))
            hypervisor_host_profile_uris = hypervisor_cluster_profile.get(
                "hypervisorHostProfileUris")
            node_count = len(hypervisor_host_profile_uris)

            ism_client = InfrastructureSystems(self.private_request)

            payload = [
                {
                    "op": "replace",
                    "path": "/nodeCount",
                    "value": node_count
                },
                {
                    "op": "replace",
                    "path": "/inTransitNodeCount",
                    "value": 0
                }
            ]

            ism_client.update_infrastructure_system(
                params['infra_system_uri'], payload)

            self.LOG.info("Successfully updated InfrastructureSystem "
                          "nodeCount={}".format(node_count))
            return self.exit_success(
                {
                    'infra_system_uri': params['infra_system_uri'],
                    'nodeCount': node_count
                }
            )
        except Exception as e:
            self.LOG.exception("Exception occurred while updating the "
                               "nodeCount of infrastructureSystem")
            raise Ism_Error(
                "HCOE_ISM_UPDATE_INFRA_NODE_COUNT_FAILED",
                details=str(e))
