#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.ism_sdk.activity import Ism_Error
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager


DOCUMENTATION = '''
---
module: Disable vSAN performance service for the cluster.
description: Check if vSAN performance service is running and disable it if
found running.
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
    force_delete:
        description:
            - Whether cluster should be force deleted
'''

EXAMPLES = '''
- name: Query disk information from iLO
  vsan_disable_performance_service:
      vc_host: "172.18.200.106"
      vc_port: 443
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_cluster: "Cluster1"
      force_delete: False
  register: vsan_disable_performance_service_result'''


class Vsan_Disable_Performance_Service(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.info("Disabling vSAN performance service.")
        force_delete = params.get('force_delete')
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        try:
            (status, error_msg) = vsan_cm.perform_pre_delete_operations(params)
        except Exception as exc:
            self.LOG.exception('Exception in execute of Vsan_Get_Disk_Info :: '
                               '%s' % str(exc))
            if force_delete:
                # since force_delete, do not fail.
                return self.exit_success({'status': True,
                                          'error': str(exc),
                                          'errorCode': ''})
            else:
                raise Ism_Error("NCS_VSAN_DISABLE_PERFORMANCE_SERVICE_FAILED",
                                details=str(exc))
        else:
            if status or force_delete:
                return self.exit_success({'status': True,
                                          'error': error_msg,
                                          'errorCode': ''})
            else:
                raise Ism_Error("NCS_VSAN_DISABLE_PERFORMANCE_SERVICE_FAILED",
                                details=error_msg)
