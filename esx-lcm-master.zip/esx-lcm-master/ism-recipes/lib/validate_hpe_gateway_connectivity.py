# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway.model import Proxy_Server
from hpeGateway import utils


class Validate_Hpe_Gateway_Connectivity(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": None}

    def execute(self, params):
        try:
            # Set Proxy Details
            Proxy_Server.set_proxy_details(
                params["proxy_server"],
                params["proxy_port"])
            token = utils.get_token_v3(params['keystone_url'],
                                       params['username'],
                                       params['password'],
                                       params['tenant'])
            result = {'is_valid': True, 'details': '', 'error_code': ''}
            return self.exit_success(result)
        except Exception as e:
            result = {'is_valid': False, 'details': '', 'error_code': ''}
            return self.exit_success(result)
