# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway import utils


class Validate_Hostagent_Status(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": None}

    def execute(self, params):
        host_agent_info = {}
        resmgr_info = params['info']
        self.headers['X-Auth-Token'] = resmgr_info['token']
        try:
            _, net_location, path, _, _ = urlparse.urlsplit(
                resmgr_info['resmgr_url'])
            path = path + "/v1/hosts"
            # Do a REST call to get the host information from HPE gateway
            with utils.do_request("GET", net_location,
                                  path, self.headers, {}) as response:
                host_agent = json.loads(response.read())
            # TODO(Manju) Need to enhance it for multiple host
            # For now assuming there is only one host
            host_agent_info['id'] = host_agent[0]['id']
            # Record the initial status of host
            if host_agent[0]['roles']:
                host_agent_status = host_agent[0]['role_status']
            else:
                # Status will be None if None of the roles are present
                host_agent_status = None
            if host_agent_status == 'ok' or not host_agent_status:
                result = {'is_valid': True, 'details': '', 'error_code': ''}
                return self.exit_success(result)
            else:
                msg = "Host Agent is not required state to perform this operation"
                result = {'is_valid': False, 'details': str(msg), 'error_code': ''}
                return self.exit_success(result)
        except Exception as e:
            result = {'is_valid': False, 'details': str(e), 'error_code': ''}
            return self.exit_success(result)
