# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback

from orch import log
from orch.moduleBase import ModuleBase
from hpeGateway.model import Proxy_Server
from hpeGateway import utils


class Get_Resource_Manager_Endpoint(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        # Set Proxy Details
        Proxy_Server.set_proxy_details(
            params["proxy_server"],
            params["proxy_port"])
        # Get the required parameters to get the token
        keystone_url = params.get('keystone_url')
        username = params.get('username')
        password = params.get('password')
        tenant = params.get('tenant')
        region = params.get('region')
        vmware_neutron = params.get('vmware_neutron')
        output_body = {}
        try:
            output_body = utils.get_resource_manager_endpoint(keystone_url,
                                                              username,
                                                              password,
                                                              tenant,
                                                              region,
                                                              vmware_neutron)
            return self.exit_success(output_body)
        except Exception as e:
            self.LOG.debug('Get Resource Mangager Endpoint failed!')
            self.LOG.debug(traceback.format_exc())
            return self.exit_fail(str(e))
