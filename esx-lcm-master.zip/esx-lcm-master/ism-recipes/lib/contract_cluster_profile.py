# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback
import hpOneViewClrm as hpovclrm

from hpOneView.resources import task_monitor as tm
from hpOneView.exceptions import HPOneViewException
from common.oneview_connector import OneviewConnector

from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from orch.ism_sdk.activity import Ism_Error

class Contract_Cluster_Profile(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    @with_task("HCOE_ISM_CONTRACT_CLUSTER_PROFILE")
    def execute(self, params):

        ov_host = params.get('_ov_hostname')
        ov_port = params.get('_ov_port')
        auth = params.get('_ov_auth')
        cluster_host_server_association = params.get(
            '_cluster_host_server_association')
        error_code, fail_msg = None, ""
        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            host_profiles_conn = hpovclrm.hypervisor_profiles(connection)
            cluster_profile_uri = cluster_host_server_association[
                "association"]["cluster_profile"]
            host_profiles_list = cluster_host_server_association[
                "association"]["host_profile"]
            cluster_profile_body = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            existing_hostprofiles_list = cluster_profile_body[
                'hypervisorHostProfileUris']

            # get the cluster uri and the list of host uris (to be consumed
            # during ISM inventory deletion)
            cluster_uri = cluster_profile_body['hypervisorClusterUri']
            cluster_name = cluster_profile_body['name']

            host_uri_list = []
            host_name_list = []
            for host_profile in host_profiles_list:
                host_profile_body = host_profiles_conn.get_hypervisor_profile_by_uri(
                    host_profile)
                if host_profile_body['hypervisorHostUri'] != "null" and host_profile_body[
                        'hypervisorHostUri'] is not None:
                    host_uri_list.append(
                        host_profile_body['hypervisorHostUri'])
                    hypervisor_host = host_profiles_conn.get_hypervisor_host_by_uri(
                        host_profile_body['hypervisorHostUri'])
                    if hypervisor_host != "null" and hypervisor_host is not None:
                        host_name_list.append(hypervisor_host["name"])

            # dictionary which holds the information about deleted hosts uri
            # (and its cluster uri)
            contracted_cluster_host_info = {
                "cluster_name": "",
                "cluster_uri": "",
                "host_uri_list": [],
                "host_name_list": []}
            cluster_profile_uri += "?force=true"
            del_msg = "Cluster Profile (%s) Deletion " % cluster_name
            con_msg = "Cluster Profile (%s) Contraction " % cluster_name

            if set(existing_hostprofiles_list) == set(host_profiles_list):
                start_msg = del_msg + "Started"
                fail_msg = del_msg + "Failed"
                done_msg = del_msg + "Completed"
                error_code = "HCOE_ISM_DELETE_CLUSTER_PROFILE_FAILED"
                task = cluster_profiles.delete_cluster_profile(
                    cluster_profile_uri, blocking=False)
            else:
                start_msg = con_msg + "Started"
                fail_msg = con_msg + "Failed"
                done_msg = con_msg + "Completed"
                error_code = "HCOE_ISM_CONTRACT_CLUSTER_PROFILE_FAILED"
                task = cluster_profiles.contract_cluster_profile(
                    cluster_profile_uri, host_profiles_list, blocking=False)

                # if hypervisor_host_profile_uris does not exist in hypervisor_cluster_profiles
                # then contraction is no-op so OV task is None
                if task is None:
                    contracted_cluster_host_info["cluster_name"] = cluster_name
                    contracted_cluster_host_info["cluster_uri"] = cluster_uri
                    contracted_cluster_host_info[
                        "host_uri_list"] = host_uri_list
                    contracted_cluster_host_info[
                        "host_name_list"] = host_name_list
                    return self.exit_success(contracted_cluster_host_info)

            self.LOG.debug(start_msg)
            self.update_task(20, start_msg)
            self.LOG.debug("Checking OneView task: %s" % task['uri'])

            task_monitor = tm.TaskMonitor(connection)
            task_monitor.get_completed_task(task, timeout=95 * 60)

            self.update_task(90, done_msg)
            self.update_parent_task(70, done_msg)

            contracted_cluster_host_info["cluster_name"] = cluster_name
            contracted_cluster_host_info["cluster_uri"] = cluster_uri
            contracted_cluster_host_info["host_uri_list"] = host_uri_list
            contracted_cluster_host_info["host_name_list"] = host_name_list
            return self.exit_success(contracted_cluster_host_info)

        except HPOneViewException as exe:
            self.update_task(90, fail_msg)
            self.update_parent_task(70, fail_msg)
            self.LOG.error(fail_msg)
            self.LOG.error(traceback.format_exc())
            raise Ism_Error(error_code, details=fail_msg + '! got ('
                                                + str(exe) + ')')
        except Exception as e:
            self.update_task(90, fail_msg)
            self.LOG.exception(fail_msg)
            return self.exit_fail(str(e))
