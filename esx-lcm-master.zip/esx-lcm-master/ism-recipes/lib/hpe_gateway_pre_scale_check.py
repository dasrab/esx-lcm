# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import urlparse

from orch.moduleBase import ModuleBase
from hpeGateway import utils

HPEGateway_NOVA_PROXY_ROLE = 'pf9-ostackhost-vmw'


class Hpe_Gateway_Pre_Scale_Check(ModuleBase):

    """
    Recipe to decide scale-up or scale-out is required or not
    """

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        host_agent_info = params['hostagent_info']
        res_mgr_info = params['res_mgr_info']
        hostagent_status = host_agent_info['status']
        host_id = host_agent_info['id']
        do_scale = False
        if hostagent_status == 'ok' or not hostagent_status:
            headers = {"Content-Type": "application/json",
                       "X-Auth-Token": res_mgr_info['token']}
            _url = urlparse.urlsplit(res_mgr_info['resmgr_url'])
            path = '/'.join([_url.path, 'v1/hosts', host_id])
            if HPEGateway_NOVA_PROXY_ROLE in host_agent_info['roles']:
                managed_clusters = (
                    utils.get_all_managed_clusters_from_hpe_gateway(
                        _url.netloc, path, headers))

                if len(managed_clusters) == params['cluster_scale_count']:
                    msg = (
                        "Couldn't scale up hpe-gateway because number of "
                        "managed clusters has reached the number of cluster "
                        "scale up count of {} ."
                        .format(params['cluster_scale_count']))
                    return self.exit_fail(msg)

                if not (len(managed_clusters) %
                        int(params['cluster_scale_count'])):
                    # Hitting this block means number of managed clusters is
                    # multiple of <cluster_scale_count>. And right now we
                    # are going to allocate one more which means we have to
                    # either scale up or scale out before allocating the
                    # cluster.
                    do_scale = True

        return self.exit_success(do_scale)
