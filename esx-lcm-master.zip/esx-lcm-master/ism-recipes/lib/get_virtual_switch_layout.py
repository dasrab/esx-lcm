# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import traceback
from orch import log
from orch.moduleBase import ModuleBase

from common import utils


class Get_VirtualSwitchLayout(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def get_network_map_from_sbp(self, serverblueprint):
        network_map = {}
        ref_map = {"SBP.ESX.MGMT": "esxManagementNetwork", "SBP.ESX.vSAN": "storageNetwork",
                   "SBP.ESX.vMOTION": "vMotionNetwork", "SBP.NCS.MGMT": "ncsManagementNetwork",
                   "SBP.ESX.GUEST.Tenant": "productionNetworks"}
        for ethernet_network in serverblueprint['networkMap']:
            if ethernet_network['name'] != "SBP.ESX.Deployment":
                network_map[ref_map[ethernet_network['name']]] = ethernet_network['netUris']
        return network_map

    def execute(self, params):
        try:
            appman_params = {}
            appman_params['appliance_ip']= params.get('appliance_manager_ip')
            appman_params['appliance_port'] = params.get('appliance_manager_port')
            serverblueprint_uri = params.get('serverProfileBlueprintUri')
            appliance_uri = params.get('appliance_uri')

            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            serverblueprint_uri += '?view=oneview'
            serverblueprint = AppManProxy.get_serverblueprint_by_uri(serverblueprint_uri)
            if not serverblueprint:
                self.LOG.debug("No serverblueprints available to fetch")
            else:
                self.LOG.debug("Successsfully fetched Serverblueprints")

            network_map = self.get_network_map_from_sbp(serverblueprint)
            if not network_map:
                self.LOG.debug("Could not fetch network map from blueprint")
            else:
                self.LOG.debug("Successsfully fetched network map from blueprint")

            eth_net_results = AppManProxy.get_l2networks(appliance_uri)
            if not eth_net_results:
                self.LOG.debug("Could not fetch ethernet networks")
            else:
                self.LOG.debug("Successsfully fetched Ethernet networks")

            switch_layout_obj = utils.SwitchLayoutRenderer(eth_net_results,serverblueprint, network_map)
            virtual_switch_layout = switch_layout_obj.render_switchLayout_template()
            if not virtual_switch_layout:
                self.LOG.debug("Could not fetch virtual_switch_layout")
            else:
                self.LOG.debug("Successsfully fetched virtual_switch_layout")
            return virtual_switch_layout

        except Exception as exception:
            self.LOG.error("Could not fetch virtual_switch_layout")
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(str(exception))

