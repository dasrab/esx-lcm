# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
'''
Created on Mar 7, 2017


'''

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Check_Task_Failure(ModuleBase):

    def execute(self, params):

        task_result = params.get('_task_result')
        task_failed = False
        error_code = ''
        details = ''

        if isinstance(task_result, basestring):
            return self.exit_success(
                {"cleanup_needed": task_failed, "error_code": error_code, "details": details})

        if isinstance(task_result, list):
            for result in task_result:
                if Ism_Error.is_ism_error(result):
                    task_failed = True
                    error_code = result['errorCode']
                    details = result['details']
                    break
        else:
            if Ism_Error.is_ism_error(task_result):
                task_failed = True
                error_code = task_result['errorCode']
                details = task_result['details']

        return self.exit_success(
            {"cleanup_needed": task_failed, "error_code": error_code, "details": details})
