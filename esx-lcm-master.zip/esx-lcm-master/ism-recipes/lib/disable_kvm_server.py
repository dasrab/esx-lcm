# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import httplib
import json
import traceback
import urlparse

from orch import log
from orch.moduleBase import ModuleBase
from orch.zone_controller import ZoneController

from lib.common import constants
from lib.hpeGateway import utils
from lib.hpeGateway.kvm_roles_util import KVMRolesUtil
from lib.hpeGateway.physnetutil import PhysnetUtil

LOG = log.getLogger(__name__)


class Disable_Kvm_Server(ModuleBase):

    def execute(self, params):
        try:
            intransit_server = params['intransit_kvm_servers'][0]
            server_id = intransit_server['serverUri'][
                intransit_server['serverUri'].rfind('/') + 1:]
            zone_ctrl = ZoneController(self.private_request).get(
                params['zone_id'], server_id)
            LOG.debug("ZoneController Settings: {}"
                      .format(json.dumps(zone_ctrl, indent=4)))
            resource_mgr_info = params['resource_mgr_info']
            host_id = zone_ctrl['uuid']
            _headers = {
                "Content-Type": "application/json",
                "X-Auth-Token": resource_mgr_info.get('token')
            }
            _url = urlparse.urlsplit(resource_mgr_info['resmgr_url'])
            v1_hosts_path = ''.join(
                [_url.path, constants.V1_HOSTS_PATH, host_id])

            host_agent = utils.get_kvm_host_agent(
                _url.netloc, v1_hosts_path, _headers)

            if not host_agent:
                msg = ("Couldn't find any host with id='{}' in gateway"
                       .format(server_id))
                LOG.error(msg)
                raise Exception(msg)
            hostname = host_agent['info']['hostname']
            if (host_agent.get('role_status') ==
                    constants.HOST_AGENT_ROLE_STATUS_CONVERGING):
                raise Exception(
                    "Enable/Disable is going on host '{}', Cannot disable "
                    "this server !".format(hostname))
            if not host_agent['roles']:
                msg = ("Host '{}' has no roles to disable !"
                       .format(hostname))
                LOG.warn(msg)
                return self.exit_success(msg)

            LOG.info("Disabling KVM host '{}' ...".format(hostname))

            enabled_host_count = utils.get_number_of_enabled_kvm_servers(
                _url.netloc, ''.join([_url.path, constants.V1_HOSTS_PATH]),
                _headers)
            kvm_roles_util = KVMRolesUtil(
                net_loc=_url.netloc, res_mgr_path=_url.path,
                headers=_headers, host_agent=host_agent,
                kvm_ip=zone_ctrl['location']['ipAddress'])

            kvm_roles_util.delete_all_roles()

            wait_for_host_agent = False
            try:
                wait_for_host_agent = utils._wait_for_kvm_host_agent(
                    _url.netloc, v1_hosts_path, _headers, disable=True)
            except httplib.HTTPException as e:
                if str(httplib.NOT_FOUND) in e.message:
                    wait_for_host_agent = True
            if not wait_for_host_agent:
                raise Exception("Failed to disable KVM host '{}'"
                                .format(hostname))

            # Invoke this only for the last host !
            if enabled_host_count == 1:
                LOG.info("Updating physnets ...")
                physnet_util = PhysnetUtil(
                    _url.netloc, ''.join([_url.path, constants.V1_PATH]),
                    _headers, host_agent)
                physnet_util.clean_physnet()

            return self.exit_success("Successfully disabled KVM host '{}'"
                                     .format(hostname))
        except Exception as e:
            LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
