#!/usr/bin/env python
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
'''
Created on Jan18, 2017

@author: arunkumar.viswanathan@hpe.com
'''

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Get_Contracted_Servers(ModuleBase):

    def execute(self, params):
        try:
            ov_servers = params.get("_ov_servers")
            contracted_servers_uri = params.get("_contracted_servers_uri")
            contracted_servers = []

            # Validate the input parameters
            self.validate_parameters(ov_servers, contracted_servers_uri)

            for server in ov_servers:
                if server["ov_server_hardware_uri"] in contracted_servers_uri:
                    contracted_servers.append(server)

            if len(contracted_servers) > 0:
                return self.exit_success(contracted_servers)
            else:
                raise Ism_Error("SYN_ISM_GET_CONTRACTED_SERVERS_FAILED",
                                details="Contracted servers list was empty")

        except Exception as e:
            raise Ism_Error(
                "SYN_ISM_GET_CONTRACTED_SERVERS_FAILED", details=str(e))

    @staticmethod
    def validate_parameters(ov_servers, contracted_servers_uri):
        if not ov_servers:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Contracted_Servers module failed because "
                "ov_servers was None or the list was empty")

        if not contracted_servers_uri:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Get_Contracted_Servers module failed because "
                "contracted_servers_uri was None or the list was empty")
