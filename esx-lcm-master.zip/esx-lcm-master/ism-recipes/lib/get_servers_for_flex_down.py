# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error


class Get_Servers_For_Flex_Down(ModuleBase):

    def execute(self, params):
        try:
            self.LOG.debug('Executing Get_Servers_For_Contract')
            servers = params.get('_servers_list')
            server_hardware_uris = []
            for server in servers:
                server_hardware_uris.append(server['managedServerUri'])
            return self.exit_success(server_hardware_uris)

        except Exception as e:
            self.LOG.exception(
                "Error in getting the servers for flex down:" + str(e))
            raise Ism_Error(
                "HCOE_ISM_GET_SERVERS_FOR_FLEX_DOWN", details=str(e))
