#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.ism_sdk.activity import Ism_Error
from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from vsan import vsan_cluster_manager


DOCUMENTATION = '''
---
module: Mark all local disks and non-local SSD disk as flash
description: Mark all local disks and non-local SSD disk as flash.
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
    vsan_disk_info:
        description:
            - Host disk information from platform profile template
'''

EXAMPLES = '''
- name: Mark all local disks and non-local SSD disk as flash
    vsan_mark_disks_as_flash:
      vc_host: "172.18.200.106"
      vc_port: 443
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_cluster: "Cluster1"
      vsan_disk_info: {
            "cache_drive_count": 1,
            "cache_drive_size_gb": 1200,
            "cache_drive_type": "local:SAS:HDD",
            "capacity_drive_count": 2,
            "capacity_drive_size_gb": 2000,
            "capacity_drive_type": "bigbird:SATA:HDD" }
    register: fake_as_flash_result'''


class Vsan_Mark_Disks_As_Flash(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def _update_tasks_progress(self, msg):
        self.update_task(90, msg)
        self.update_parent_task(80, msg)

    @with_task("HCOE_ISM_MARK_DISK_AS_FLASH_FOR_VSAN")
    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()

        cluster_name = params.get('vc_cluster')
        msg = "Marking disk(s) as flash for Cluster (%s) " % cluster_name
        self.LOG.info(msg + "Started")
        self.update_task(20, msg + "Started")
        try:
            (status, error_msg) = vsan_cm.prepare_new_host(params)
        except Exception as exc:
            self._update_tasks_progress(msg + "Failed")
            self.LOG.exception('Exception in execute of '
                               'Vsan_Mark_Disks_As_Flash :: %s' % str(exc))
            raise Ism_Error("NCS_VSAN_FAILED_TO_TAG_SSD_DISK",
                            details=str(exc))

        if status:
            self._update_tasks_progress(msg + "Completed")
            self.LOG.info(msg)
            return self.exit_success({'status': status, 'error': error_msg,
                                      'errorCode': ''})
        else:
            self._update_tasks_progress(msg + "Failed")
            self.LOG.error(error_msg)
            raise Ism_Error("NCS_VSAN_FAILED_TO_TAG_SSD_DISK",
                            details=error_msg)
