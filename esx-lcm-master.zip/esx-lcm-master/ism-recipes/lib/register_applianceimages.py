# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log

from orch.moduleBase import ModuleBase
from common import utils
from common import models
from unregister_applianceimages import Unregister_Applianceimages


class Register_Applianceimages(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            app_image_model = {}
            app_image_model['name'] = params['appliance_image_name']
            app_image_model['imageUrl'] = params['image_artifact_url']
            app_image_model['applianceUri'] = params['target_appliance_uri']
            appman_params = {k: params[k] for k in ('appliance_ip',
                                                    'appliance_port')}
            AppManProxy = utils.ApplianceManagerProxy(appman_params)
            try:
                result = AppManProxy.register_applianceimage(app_image_model)
                app_image = models.ApplianceImage(result)
                app_image_uri = app_image._get_uri()
                self.LOG.debug("Successfully Registered ApplianceImage: "
                               "'{}'. ApplianceImageUri is '{}'".format(
                                   app_image.name, app_image.uri))
            except KeyError as e:
                if result.get('uri'):
                    self.LOG.error(
                        "Required mandatory keys are not present "
                        "in the response from appliance-manager. "
                        "Unregistering the Applianceimage '{}'".format(
                            result.get('uri')))
                    appman_params['app_image_uri'] = result.get('uri')
                    try:
                        Unregister_Applianceimages().execute(appman_params)
                        self.LOG.debug("Unregistered the Applianceimage: "
                                       "'{}'".format(result.get('uri')))
                    except Exception:
                        self.LOG.error("Failed to Unregister Applianceimage: "
                                       "'{}'".format(result.get('uri')))
                        pass
                raise Exception(e)
            return self.exit_success(app_image_uri)
        except Exception as exception:
            self.LOG.error(
                "ApplianceImage Register failed. Could not register"
                "ApplianceImage: {}".format(app_image_model['name']))
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(str(exception))
