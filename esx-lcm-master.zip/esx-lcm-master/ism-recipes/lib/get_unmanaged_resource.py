# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback
import urlparse

from orch.moduleBase import ModuleBase

from hpeGateway import utils
from hpeGateway.model import Proxy_Server
from lib.common import constants as const


class Get_Unmanaged_Resource(ModuleBase):

    def find_resource(self, ism_client, resource_name):
        infra_systems = ism_client.get_all_infrastructure_systems()
        for systems in infra_systems:
            if resource_name == systems["name"]:
                self.LOG.debug("Resource %s is existing." % resource_name)
                return systems["uri"]
        self.LOG.debug("Resource %s not yet created" % str(resource_name))

    def _get_all_clusters(self, params):
        Proxy_Server.set_proxy_details(
            params["proxy_server"], params["proxy_port"])
        res_mgr_info = utils.get_resource_manager_endpoint(
            params['keystone_url'], params['username'], params['password'],
            params['tenant'], params['region'], params['vmware_neutron'])
        cluster_names = []
        if not res_mgr_info:
            self.LOG.warn("The region %s for provided keystone URL %s is not available",
                          params['region'], params['keystone_url'])
            return cluster_names

        headers = {"Content-Type": "application/json",
                   "X-Auth-Token": res_mgr_info['token']
                   }
        _url = urlparse.urlsplit(res_mgr_info['resmgr_url'])
        path = '/'.join([_url.path, 'v1/hosts'])
        host_agents = utils.get_host_agents(_url.netloc, path, headers)
        managed_clusters = []
        neutron = {"enabled": params['vmware_neutron'],
                   "ep_present": res_mgr_info['neutron_ep_present']
                  }
        clusters_info = []
        for host_agent in host_agents:
            hypervisor_type = utils.get_val(
                host_agent, 'hypervisor_info', 'hypervisor_type')
            # TODO: Only one host_agent is for beta. Change it later!
            if hypervisor_type == 'VMWareCluster':
                clusters = utils.get_val(
                    host_agent, 'extensions', 'hypervisor_details',
                    'data', 'clusters')
                cluster_inventories = utils.get_val(
                    host_agent, 'extensions', 'cluster_inventory', 'data')
                vcenter_id = utils.get_val(
                    host_agent, 'extensions', 'hypervisor_details',
                    'data', 'vcenter_id')
                # Convert the vcenter_id to lower case
                if vcenter_id:
                    vcenter_id = vcenter_id.lower()
                if not clusters:
                    continue
                clusters_info = [cluster for cluster in clusters
                                 if cluster['cluster_usable']]
                self.LOG.debug("Clusters obtained from platform: %s"
                              % str(clusters_info))
                roles = host_agent.get("roles", [])
                # Compute Role for Nova Enabled DU
                role = 'pf9-ostackhost-vmw'
                if utils.is_neutron_enabled(neutron):
                    # Compute Role for Neutron Enabled DU
                    role = 'pf9-ostackhost-neutron-vmw'
                if role in roles:
                    role_path = path + "/" + host_agent['id']
                    managed_clusters = utils.get_all_managed_clusters_from_hpe_gateway(
                        _url.netloc, role_path, headers, neutron)
                self.LOG.debug("Managed clusters obtained from platform are: %s"
                              % str(managed_clusters))
                break

        cluster_info_list = list()
        for cluster in clusters_info:
            status = const.OK
            datastores = list()
            state = const.DISABLED
            if cluster['name'] in managed_clusters:
                state = const.ENABLED
            if not host_agent['info'].get('responding'):
                status = const.CRITICAL

            if vcenter_id:
                # Form Cluster Unique ID
                cluster_id = vcenter_id + "_" + cluster['cluster_moid']
                for datastore in cluster.get('datastores'):
                    # Form Datastore Unique ID
                    datastore['id'] = vcenter_id + "_" + datastore['moid']
                    datastores.append(datastore)
            else:
                cluster_id = cluster.get('name')
                for datastore in cluster.get('datastores'):
                    datastore['id'] = datastore.get('name')
                    datastores.append(datastore)

            cluster_name_state = {
                'cluster_name': cluster.get('name'),
                'id': cluster_id,
                'state': state,
                'status': status,
                'datastores': datastores
            }

            if cluster_inventories:
                for cluster_inventory in cluster_inventories:
                    if cluster_inventory['name'] == cluster['name']:
                        cluster_name_state['hosts'] = cluster_inventory[
                            'hosts']

            cluster_info_list.append(cluster_name_state)
        self.LOG.debug("Cluster Info =%s", cluster_info_list)
        return cluster_info_list

    def execute(self, params):
        try:
            self.LOG.debug('Executing Get Unmanaged Resource')
            cluster_info_list = self._get_all_clusters(params)
            self.LOG.info("Clusters obtained %s" % str(cluster_info_list))
            return self.exit_success(cluster_info_list)
        except Exception as e:
            self.LOG.exception("Get Unmanaged Resouce has Failed!")
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
