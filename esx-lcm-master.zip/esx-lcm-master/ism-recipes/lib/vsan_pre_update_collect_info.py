#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager

DOCUMENTATION = '''
---
module: Get pre update vSAN cluster info
description: Gets the VSAN cluster capacity and health
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
'''

EXAMPLES = '''
- name: Get vSAN pre update cluster info
    vsan_pre_update_collect_info:
      vc_host: "172.18.200.106"
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_port: 443
      vc_cluster: "Nested_Vsan"
      register: vsan_pre_update_collect_info_result'''


class Vsan_Pre_Update_Collect_Info(ModuleBase):
    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        self.LOG.info("Fetching VSAN cluster info.")
        (status, pre_update_data, error_msg) = \
            vsan_cm.vsan_pre_update_collect_info(params)
        if status:
            return self.exit_success({'status': status, 'pre_update_data':
                                      pre_update_data, 'error': error_msg})
        else:
            self.LOG.error(error_msg)
            return self.exit_fail(status, pre_update_data, error_msg)
