#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import os
import sys

from ConfigParser import SafeConfigParser

if os.environ.get("ISM_PATH"):
    ISM_PROPERTIES = os.environ.get("ISM_PATH") + "/ism.properties"
else:
    print "Environment ISM_PATH is not set, Exiting!!"
    sys.exit(1)

SECTION_KEY_ENV_MAP = {
    "ism.applianceManager": {
        "Host": "APP_MGR_HOST",
        "Port": "APP_MGR_PORT"
    },
    "ism.log": {
        "LogLevel": "ESX_LCM_LOGLEVEL"
    },
    "ism.capacityHandler": {
        "EnabledFilters": "ENABLED_FILTERS",
        "MaxClusters": "MAX_CLUSTERS",
        "MaxNodes": "MAX_NODES",
        "MinimumNodes": "MIN_NODES",
        "ScaleType": "SCALE_TYPE"
    },
    "ism.dataCenterConfig": {
        "DatacenterPath": "DATACENTER_PATH"
    },
    "ism.database": {
        "Host": "DB_HOST",
        "Name": "DB_NAME",
        "Pass": "DB_PASS",
        "Port": "DB_PORT",
        "User": "DB_USER"
    },
    "ism.hpeGateway": {
        "ClusterScaleCount": "CLUSTER_SCALE_COUNT",
        "VCpus": "VCPUS",
        "Memory": "MEMORY",
        "PollingInterval": "POLLING_INTERVAL"
    },
    "ism.keystone": {
        "AuthURL": "KEYSTONE_AUTH_URL",
        "Domain": "KEYSTONE_DOMAIN_NAME",
        "Pass": "KEYSTONE_PASS",
        "Project": "KEYSTONE_PROJECT_NAME",
        "User": "KEYSTONE_USER"
    },
    "ism.monasca": {
        "ApiURI": "MONASCA_API_URI"
    },
    "ism.monascaAgent": {
        "Domain": "MONASCA_AGENT_DOMAIN_NAME",
        "Pass": "MONASCA_AGENT_PASS",
        "User": "MONASCA_AGENT_USER",
        "Project": "MONASCA_AGENT_PROJECT_NAME"
    },
    "ism.securityMgr": {
        "Enabled": "SECURITY_MGR_ENABLED"
    },
    "ism.server": {
        "SecurePort": "ESX_LCM_PORT",
        "Debug": "RUN_IN_DEBUG_MODE"
    },
    "ism.commsLcm": {
        "Host": "COMMS_LCM_HOST",
        "Port": "COMMS_LCM_PORT",
        "Enabled": "COMMS_LCM_ENABLED"
    },
    "ism.vsanConfig": {
        "ConfigureVsan": "CONFIGURE_VSAN",
        "EnablePerformanceService": "ENABLE_PERFORMANCE_SERVICE",
        "ForceMarkLocalDiskAsFlash": "FORCE_MARK_LOCAL_DISK_AS_FLASH",
        "WipeDisks": "WIPE_DISKS"
    }
}

parser = SafeConfigParser()
# To write all options without changing it case
parser.optionxform = str

# Default/Top level section
parser.add_section('ism')

# Construct the parser based on Environment variables
for section_name in SECTION_KEY_ENV_MAP.keys():
    parser.add_section(section_name)
    remove_section = True
    section = SECTION_KEY_ENV_MAP.get(section_name)
    for param in section.keys():
        if os.environ.get(section.get(param)):
            parser.set(section_name, param, os.environ.get(section.get(param)))
            remove_section = False

    if remove_section:
        parser.remove_section(section_name)

# write in to properties file
with open(ISM_PROPERTIES, 'w') as properties_ini:
    parser.write(properties_ini)
