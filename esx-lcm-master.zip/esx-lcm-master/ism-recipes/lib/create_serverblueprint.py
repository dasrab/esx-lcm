# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import os
import traceback
from orch import log

from orch.moduleBase import ModuleBase
from common import utils
from common import constants
from common import models
from delete_serverblueprint_by_uri import Delete_Serverblueprint_By_Uri


class Create_Serverblueprint(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger
        self.templates = constants.TEMPLATES_PATH

    def execute(self, params):
        try:
            sbp_model = {}
            sbp_model['name'] = params['serverblueprint_name']
            sbp_model['description'] = "ESX based Server Blueprint"
            sbp_model['applianceUri'] = params['appliance_uri']
            netmap_model = utils.NetworkModelRenderer(
                params['network_map']).render_networkmodel_template()
            sbp_model['networkMap'] = netmap_model['network_map']
            for filename in os.listdir(self.templates):
                # Check if template file matching the server_type is present.
                # Example for file checking operation below
                # Input: String = 'SY 480 Gen9 1'
                # Test for file: SY480
                # First split the string by blankspace and search for
                # first two elements in list i.e, ['SY','480']
                # Later join the elements of list and do check for if file starts with
                if filename.startswith(
                         "".join(
                         params['platform_profile_template']['server_type'].split(' ')[0:2])):
                    # Just add the j2 with the name to create file name
                    template_file_name = (
                        "".join(
                        params['platform_profile_template']['server_type'].split(' ')[0:2])
                        + '.j2')
                    SPTModel = utils.SPTModelRenderer().render_sptmodel_template(
                                 template_file_name ,
                                 params['platform_profile_template']['server_type'])
                    sbp_model['serverProfileTemplateBlueprint'] = SPTModel
                elif filename.startswith('network_sets'):
                    filepath = self.templates + '/' + filename
                    sbp_model['networkSetBlueprints'] = utils.read_json(
                        filepath)['networkSetBlueprints']
            # Check if the storage section is present in template or not
            if params['platform_profile_template']['host_disks']:
                disk_model = utils.DiskModelRenderer(
                    params['platform_profile_template']).render_diskmodel_template()
                sbp_model['serverProfileTemplateBlueprint']['blueprint'][
                    'localStorage'] = disk_model['localStorage']
            sbp_model['_type'] = "ServerBlueprint"
            sbp_model['_version'] = "1"
            try:
                appman_params = {k: params[k] for k in ('appliance_ip',
                                                        'appliance_port')}
                AppManProxy = utils.ApplianceManagerProxy(appman_params)
                result = AppManProxy.create_serverblueprint(sbp_model)
                serverblueprint = models.ServerBlueprint(result)
                sbp_uri = serverblueprint._get_serverblueprint_uri()
                self.LOG.debug("Successfully Created ServerBlueprint '{}',"
                               "ServerBlueprintUri: '{}'".format(
                                   serverblueprint.name, serverblueprint.uri))
            except KeyError as e:
                if result.get('uri'):
                    self.LOG.error(
                        "Required mandatory keys are not present "
                        "in the response from appliance-manager. "
                        "Deallocating the ServerBlueprint '{}'".format(
                            result.get('uri')))
                    appman_params['serverblueprint_uri'] = result.get('uri')
                    try:
                        Delete_Serverblueprint_By_Uri().execute(appman_params)
                        self.LOG.debug("Deleted the ServerBlueprint: "
                                       "'{}'".format(result.get('uri')))
                    except Exception:
                        self.LOG.error("Couldnot Delete the ServerBlueprint: "
                                       "'{}'".format(result.get('uri')))
                        pass
                raise Exception(e)
            return self.exit_success(sbp_uri)
        except Exception as exception:
            self.LOG.error(
                "Create ServerBlueprint failed. Could not create "
                "ServerBlueprint: '{}'".format(sbp_model['name']))
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(sbp_model['name'] + ": " + str(exception))
