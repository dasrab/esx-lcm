#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from common.vcenter_utils import VcenterUtils
from orch import log
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error

LOG = log.getLogger(__name__)


class Check_Hypervisor_Manager_Credentials (ModuleBase):

    def execute(self, params):
        try:
            host = params.get("_host_ip")
            port = params.get("_host_port")
            _vc_utils = VcenterUtils()
            # TODO Need to get port and cert(default to None) from params
            service_instance = _vc_utils.get_service_instance(
                host, params.get("_username"), params.get("_password"), port)

            about = service_instance.content.about
            LOG.info("Connected to %s, %s" % (host, about.fullName))

            LOG.debug('Credentials are fine!')

        except Exception as e:
            self.LOG.exception('Wrong Hypervisor Settings..')
            raise Ism_Error(
                "SYN_ISM_INCORRECT_HYPERVISOR_SETTINGS",
                details=str(e))

        body_dict = {
            "Hypervisor_credentials : Success",
        }

        return self.exit_success(body_dict)
