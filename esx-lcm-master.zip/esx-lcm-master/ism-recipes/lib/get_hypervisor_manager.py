# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector

import hpOneViewClrm as hpovclrm
import traceback


class Get_Hypervisor_Manager(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.debug('Executing Get_Hypervisor_Manager')

        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        hypversior_mgr_name = params.get('_hypervisor_manager_hostname')

        self.LOG.debug(
            'Required parameters: ' +
            str(ov_host) +
            ' ' +
            str(auth) +
            ' ' +
            hypversior_mgr_name)

        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            hypervisor_managers = hpovclrm.hypervisor_managers(connection)
            hyp_mgr = hypervisor_managers.get_hypervisor_manager(
                hypversior_mgr_name)
            if hyp_mgr:
                self.LOG.debug(
                    "Fetched the hypervisor manager (%s) details" %
                    hypversior_mgr_name)
                return self.exit_success(hyp_mgr['uri'])
            else:
                self.LOG.debug(
                    "No hypervisor manager (%s) found" %
                    hypversior_mgr_name)
                return self.exit_success(False)
        except Exception as e:
            self.LOG.debug('Get Hypervisor Manager failed!')
            self.LOG.debug(traceback.format_exc())
            return self.exit_fail(str(e))
