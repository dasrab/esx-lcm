#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback
import hpOneViewClrm as hpovclrm

from common.oneview_connector import OneviewConnector
from orch.moduleBase import ModuleBase
from time import sleep
from common import constants

DOCUMENTATION = '''
---
module: create_hypervisor_manager
short_description: Create a Hypervisor Manager.
description:
    -  Add a hypervisor manager for monitoring and returns the task URI.
options:
    _ov_host:
        description:
            - appliance's address.
    _auth:
        description:
             - Oneview authentication token.
    _hypervisor_environment:
        description:
             - hypervisor manager settings such as ip, username and password
    _hypervisor_type:
        description:
             - hypervisor type.
'''

EXAMPLES = '''
- name: create server profile template
  create_hypervisor_manager:
    _ov_host:  {{ ov_host }}
    _auth:  {{ auth }}
    _hypervisor_settings: {{ hypervisorSettings }}
    _hypervisor_type: "vSphere" 
  register: return_json
'''


class Create_Hypervisor_Manager(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def create_hypervisor_manager(
            self,
            hypervisor_managers,
            name,
            username,
            password,
            hypervisor_type):
        return hypervisor_managers.create_hypervisor_manager(
            name=name,
            username=username,
            password=password,
            hypervisorType=hypervisor_type,
            blocking=True)

    def execute(self, params):
        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth = params.get('_auth')
        hypervisor_type = params.get('_hypervisor_type')
        hypervisor_manager_credentials = params.get(
            '_hypervisor_manager_credentials')
        name = hypervisor_manager_credentials['ipAddress']
        username = hypervisor_manager_credentials['username']
        password = hypervisor_manager_credentials['password']

        connection = OneviewConnector(ov_host, ov_port, auth).connect()
        hypervisor_managers = hpovclrm.hypervisor_managers(connection)

        self.LOG.debug("Creating Hypervisor Manager  '" + name + "'")
        _retries = 3
        self.LOG.debug('Retry creating Hypervisoer manager is set to 3 !')
        for i in range(_retries):
            try:
                hypervisor_obj = self.create_hypervisor_manager(
                    hypervisor_managers, name, username, password, hypervisor_type)
                return self.exit_success(hypervisor_obj['uri'])
            except Exception as exception:
                if i < _retries - 1:    # i is zero indexed
                    sleep(5)
                    continue
                else:
                    self.LOG.error('Task Create Hypervisor Manager failed!')
                    self.LOG.error(traceback.format_exc())
                    return self.exit_fail(name + ": " + str(exception))
