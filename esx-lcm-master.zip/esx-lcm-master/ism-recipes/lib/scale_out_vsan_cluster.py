#!/usr/bin/env python
#
# (C) Copyright 2017 Hewlett Packard Enterprise Development LP
#

from orch import log
from orch.ism_sdk.activity import Ism_Error
from orch.moduleBase import ModuleBase
from vsan import vsan_cluster_manager

DOCUMENTATION = '''
---
module: Scale out VSAN cluster
description: Adds the esx host to VSAN cluster provided a vCenter cluster.
options:
    vc_host:
        description:
            - vCenter host IP.
    vc_user:
        description:
            - vCenter user name.
    vc_password:
       description:
            - Password of the vCenter user
    vc_port:
        description:
            - vCenter server port
    vc_cluster:
        description:
            - Name of the vCenter cluster
    vsan_license:
        description:
            - VSAN license key (empty if not available)
    storage_network_name
        description:
            - Name of the network to be used for storage.
    scaleout_hosts
        description:
            - Name of the host to scale out VSAN cluster
    vsan_disk_info
        description:
            - Host disk information from platform profile template
'''

EXAMPLES = '''
- name: Scale out VSAN cluster
    scale_out_vsan_cluster:
      vc_host: "172.18.200.106"
      vc_port: 443
      vc_user: "Administrator@vsan.local"
      vc_password: "Cloud#123"
      vc_cluster: "Nested_Vsan"
      vsan_license: ""
      storage_network_name: "vsan_net"
      scaleout_hosts: "172.18.200.236"
      vsan_disk_info: {
            "cache_drive_count": 1,
            "cache_drive_size_gb": 1200,
            "cache_drive_type": "local:SAS:HDD",
            "capacity_drive_count": 2,
            "capacity_drive_size_gb": 2000,
            "capacity_drive_type": "bigbird:SATA:HDD" }
    register: setup_result'''


class Scale_Out_Vsan_Cluster(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        vsan_cm = vsan_cluster_manager.VsanClusterManager()
        self.LOG.info("Scaleout VSAN cluster.")
        try:
            (status, failure_details) = vsan_cm.scale_out_cluster(params)
        except Exception as exc:
            self.LOG.exception('Exception in Scaleout '
                               'Vsan_Cluster :: %s' % str(exc))
            raise Ism_Error("NCS_VSAN_SCALEOUT_FAILED", details=str(exc))
            
        if status:
            self.LOG.info("Scaleout of VSAN cluster succeeded.")
            return self.exit_success({'status': status,
                                      'failed_hosts': [],
                                      'error': None,
                                      'errorCode': ''})
        else:
            self.LOG.error("Scaleout of VSAN cluster failed.")
            self.LOG.error(failure_details)
            return self.exit_success({'status': status,
                                      'failed_hosts': failure_details['failed_hosts'],
                                      'error': failure_details['Reason'],
                                      'errorCode': 'NCS_VSAN_SCALEOUT_FAILED'})
            
