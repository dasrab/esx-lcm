# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import hpOneViewClrm as hpovclrm
from common.oneview_connector import OneviewConnector

from hpOneView.resources.servers import server_profiles

from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error
import traceback
import json


class Check_Cluster_Profile_Created_Failure(ModuleBase):

    def validate_Check_Cluster_Profile_Failure_Parameters(
            self,
            ov_host,
            ov_port,
            auth_token,
            hypervisor_cluster_profile):

        if ov_host is None:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Module failed because ov_host was None or not a string " +
                str(ov_host))
        if ov_port is None:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Module failed because ov_port was None or not a integer " +
                str(ov_port))

        if auth_token is None:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Module failed because auth_token was None or not a string " +
                str(auth_token))

        if hypervisor_cluster_profile is None:
            raise Ism_Error(
                "SYN_ISM_INPUT_VALIDATION_FAILED",
                details="Module failed because hypervisor_cluster_profile was None ")

    def execute(self, params):

        ov_host = params.get('_ov_host')
        ov_port = params.get('_ov_port')
        auth_token = params.get('_auth')
        hypervisor_cluster_profile = params.get('_hypervisor_cluster_profile')
        cluster_name = params.get('_cluster_name')
        allocated_server_hw_uris = params.get('_server_hardware_uris')
        min_nodes_for_single_clusters = params.get('_min_single_cluster')

        connection = OneviewConnector(ov_host, ov_port, auth_token).connect()

        cluster_profiles_con = hpovclrm.cluster_profile(connection)
        hypervisor_profiles_con = hpovclrm.hypervisor_profiles(connection)
        server_connection = server_profiles.ServerProfiles(connection)

        validated_server_hw_uris = list()
        failed_hypervisor_host_profiles_uris = []

        validation_data = {'hypervisor_host_profile_uris': [],
                           'hypervisor_cluster_profile_uri': '',
                           'hypervisor_cluster_profile': {},
                           'min_criteria_met': True,
                           }
        try:
            self.validate_Check_Cluster_Profile_Failure_Parameters(
                ov_host, ov_port, auth_token, hypervisor_cluster_profile)

        except Exception as e:
            self.LOG.exception('Error validating parameters: {}'.format(e))
            raise Ism_Error(
                "SYN_ISM_VALIDATION_PARAMS_FAILED",
                details=str(e))

        try:
            if Ism_Error.is_ism_error(hypervisor_cluster_profile):
                self.LOG.debug(
                    "Operation on cluster profile failed. Performing the cleanup")
                ov_cluster_profiles = cluster_profiles_con.get_cluster_profiles()

                if len(ov_cluster_profiles) == 0:
                    self.LOG.warning("No cluster profile created in one view")
                    validation_data['min_criteria_met'] = False
                    return self.exit_success(validation_data)
                else:
                    for cluster_profile in ov_cluster_profiles:
                        if cluster_profile['name'] == cluster_name:
                            hypervisor_cluster_profile = cluster_profile
            else:
                hypervisor_cluster_profile = cluster_profiles_con.get_cluster_profile_by_uri(
                    hypervisor_cluster_profile.get('uri'))

            validation_data[
                'hypervisor_cluster_profile_uri'] = hypervisor_cluster_profile.get('uri')
            validation_data[
                'hypervisor_cluster_profile'] = hypervisor_cluster_profile

            # case 1: check for if hypervisor list is empty
            host_profile_uris = hypervisor_cluster_profile.get(
                'hypervisorHostProfileUris')
            if host_profile_uris and len(host_profile_uris) == 0:
                self.LOG.warning(
                    "Host profile URI list in Cluster profile is empty. Minimum criteria not met. "
                    "Triggering entire system cleanup")
                validation_data['min_criteria_met'] = False
                return self.exit_success(validation_data)

            for hypervisor_host_profile_uri in hypervisor_cluster_profile.get(
                    'hypervisorHostProfileUris', []):

                hypervisor_profile = hypervisor_profiles_con.get_hypervisor_profile_by_uri(
                    hypervisor_host_profile_uri)
                if hypervisor_profile != "null" and hypervisor_profile is not None:
                    state = hypervisor_profile.get("state")
                    if str(state) != "Active":
                        failed_hypervisor_host_profiles_uris.append(
                            hypervisor_host_profile_uri)
                    else:
                        server_profile_uri = hypervisor_profile[
                            'serverProfileUri']

                        if server_profile_uri != "null" and server_profile_uri is not None:
                            server_profile = server_connection.get(
                                hypervisor_profile['serverProfileUri'])

                            if server_profile != "null" and server_profile is not None:
                                validated_server_hw_uris.append(server_profile[
                                    'serverHardwareUri'])
                            else:
                                failed_hypervisor_host_profiles_uris.append(
                                    hypervisor_host_profile_uri)
                        else:
                            failed_hypervisor_host_profiles_uris.append(
                                hypervisor_host_profile_uri)

            validation_data[
                'hypervisor_host_profile_uris'] = failed_hypervisor_host_profiles_uris
            failed_server_hw_uris = list(
                set(allocated_server_hw_uris) - set(validated_server_hw_uris))
            validation_data['failed_server_hw_uris'] = failed_server_hw_uris

            self.LOG.debug("Number of failed host profiles:" +
                           str(len(failed_hypervisor_host_profiles_uris)))

            if len(failed_hypervisor_host_profiles_uris) > 0:
                self.LOG.warning(
                    "Doing cleanup for the failure nodes. "
                    "Failed host profile details:" +
                    json.dumps(failed_hypervisor_host_profiles_uris))
            if len(validated_server_hw_uris) < min_nodes_for_single_clusters:
                self.LOG.warning("You cannot have a cluster with " +
                            "less than " +
                            str(min_nodes_for_single_clusters) +
                            " nodes ")
                validation_data['min_criteria_met'] = False
            return self.exit_success(validation_data)

        except Exception as exception:
            self.LOG.error('Module Failed : ' + traceback.format_exc())
            self.LOG.error(str(exception.message))
            raise Ism_Error(
                "SYN_ISM_CHK_CLUSTER_PROFILE_FAILURE",
                details=str(exception))
