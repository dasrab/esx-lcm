# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import json
import urlparse
import traceback

from hpeGateway import utils
from orch import log
from orch.moduleBase import ModuleBase


class Deallocate_Resource(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            host_agent_info = params['hostagent_info']
            hostagent_status = host_agent_info['status']

            # If the host is not in "ok" state defer the manage operation and
            # fail
            if hostagent_status != 'ok':
                msg = ("Host %s is not in desired state"
                       " to perfom this operation" % host_agent_info['id'])
                return self.exit_fail(msg)
            utils.manage_cluster(params, False)
            return self.exit_success(params['cluster_names'])
        except Exception as e:
            self.LOG.exception("Deallocate Resource(s) %s Failed!",
                               params['cluster_names'])
            self.LOG.exception(traceback.format_exc())
            return self.exit_fail(str(e))
