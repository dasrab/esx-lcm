# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

from orch import log
from orch.moduleBase import ModuleBase
from common.oneview_connector import OneviewConnector

import hpOneViewClrm as hpovclrm
import traceback


class Get_Successfully_Flexed_Up_Hosts_Ip(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        self.LOG.debug('Getting IPs of Successfully Flexed Up Hosts For VSAN ')
        try:
            hypervisor_host_profiles_before_flexup = params.get(
                '_hypervisor_host_profiles_before_flexup')
            hypervisor_host_profiles_after_flexup = params.get(
                '_hypervisor_host_profiles_after_flexup')
            ov_host = params.get("_ov_host")
            ov_port = params.get("_ov_port")
            auth = params.get("_auth")
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            host_profile_conn = hpovclrm.hypervisor_profiles(connection)

            ip_list_of_successfully_flexedup_hosts = []
            for host_profile_uri in hypervisor_host_profiles_after_flexup:
                if host_profile_uri not in hypervisor_host_profiles_before_flexup:
                    host_profile = host_profile_conn.get_hypervisor_profile_by_uri(
                        host_profile_uri)
                    ip_settings = host_profile.get("ipSettings")
                    ip_addr = ip_settings.get("ip")
                    ip_list_of_successfully_flexedup_hosts.append(ip_addr)
            self.LOG.debug(
                "List of ip of successfully flexedup hosts... " +
                str(ip_list_of_successfully_flexedup_hosts))
            return self.exit_success(ip_list_of_successfully_flexedup_hosts)
        except Exception as e:
            self.LOG.debug(
                'Getting IPs of Successfully Flexed Up Hosts For VSAN failed!!' +
                traceback.format_exc())
            return self.exit_fail(str(e))
