# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

import traceback
from orch import log
from orch.moduleBase import ModuleBase

from common import utils
from common import models


class Get_Server_Uris(ModuleBase):

    def __init__(self, logger=None):
        ModuleBase.__init__(self)
        if logger is None:
            self.LOG = log.getLogger(__name__)
        else:
            self.LOG = logger

    def execute(self, params):
        try:
            AppManProxy = utils.ApplianceManagerProxy(
                {k: params[k] for k in ('appliance_ip', 'appliance_port')})
            server_hardware_uris = params['server_hardware_uris']
            server_uris = list()
            allocated_servers = AppManProxy.get_servers()
            for server in allocated_servers:
                if server['serverHardwareUri'] in server_hardware_uris:
                    server_uris.append(server['uri'])
            return self.exit_success(server_uris)
        except Exception as exception:
            self.LOG.error(
                "Could not get requested server details.")
            self.LOG.error(traceback.format_exc())
            return self.exit_fail(str(exception))
