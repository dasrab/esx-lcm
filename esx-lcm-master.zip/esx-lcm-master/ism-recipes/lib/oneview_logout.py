#!/usr/bin/env python
# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback

from builtins import range
from future import standard_library
from common.oneview_connector import OneviewConnector
from orch.ism_sdk.activity import Ism_Error

from orch.moduleBase import ModuleBase


standard_library.install_aliases()

DOCUMENTATION = '''
---
module: logout
short_description: Logout from the appliance.
description:
    - Logout from the appliance.
options:
    _ov_host:
        description:
            - appliance's address.
'''

EXAMPLES = '''
  - name: Logout OV
    logout:
       _ov_host:  "{{ ov_host }}"
'''


class Oneview_Logout(ModuleBase):
    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        try:
            ov_host = params.get('_ov_host')
            ov_port = params.get('_ov_port')
            auth = params.get('_auth')
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            connection.logout()
            return self.exit_success('Logout OV Successful')
        except Exception as e:
            self.LOG.exception("Oneview logout failed! : " + str(e))
            raise Ism_Error(
                "SYN_ISM_LOGOUT_ONEVIEW_FAILED", details=str(e))
