# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import json

from lib.common import constants as const
from lib.hpeGateway import utils

from orch import log
from orch.moduleBase import ModuleBase
from orch.ism_sdk.activity import Ism_Error
from orch.ism_sdk import InfrastructureSystems

from requests.exceptions import HTTPError

LOG = log.getLogger(__name__)


class Synchronize_Unmanaged_Kvm_Servers(ModuleBase):

    def _get_all_infra_sys_for_zone(self, zone_uri, ism_client):
        all_infra_sys = ism_client.get_all_infrastructure_systems()
        infra_sys_for_zone = [
            infra_sys for infra_sys in all_infra_sys
            if infra_sys.get('associatedZoneURI') == zone_uri]
        return infra_sys_for_zone

    def _get_datastore_payload_from_volumes(self, hostname, volumes):
        volume_count = 1
        ds_payload = dict()
        ds_payloads = list()
        for volume in volumes:
            ds_payload['id'] = '-'.join(
                [hostname, 'volume', str(volume_count)])
            volume_count += 1
            ds_payload['name'] = volume['name']
            ds_payload['sizeGiB'] = volume['size']
            ds_payload['type'] = const.KVM_VOLUME_TYPE
            ds_payloads.append(ds_payload)
        return ds_payloads

    def _get_datastores_from_gateway(self, resource, unmanaged_servers):
        volumes = list()
        for kvm_server in unmanaged_servers:
            if kvm_server['id'] == resource['id']:
                volumes += kvm_server['volumes']
                break
        return self._get_datastore_payload_from_volumes(
            kvm_server.get('name'), volumes)

    def _filter_datastores(self, datastores_from_gateway, datastores_from_db):
        existing_datastores = []
        new_datastores = []
        datastores_to_be_deleted = []
        for new_ds in datastores_from_gateway:
            new_datastore = True
            for existing_ds in datastores_from_db:
                if new_ds['name'] == existing_ds['name']:
                    new_datastore = False
                    existing_datastores.append(existing_ds)
                    break
            if new_datastore:
                new_datastores.append(new_ds)
        for existing_ds in datastores_from_db:
            if existing_ds not in existing_datastores:
                datastores_to_be_deleted.append(existing_ds)

        return dict(
            existing_datastores=existing_datastores,
            new_datastores=new_datastores,
            datastores_to_be_deleted=datastores_to_be_deleted
        )

    def _is_update_required(
            self, resource, unmanaged_servers, datastores_from_gateway):
        is_update_required = False
        for kvm_server in unmanaged_servers:
            # Note: KVM server id is nothing but hostname.
            # So hostname shouldn't change !
            if kvm_server['id'] == resource['id']:
                if kvm_server.get('serverUri', '') != resource['serverUri']:
                    LOG.info(
                        "Update required because the 'serverUri' of "
                        "resource '{}' has been changed from '{}' to '{}'"
                        .format(kvm_server['id'], resource.get('serverUri'),
                                kvm_server.get('serverUri')))
                    is_update_required = True
                if kvm_server['state'] != resource['state']:
                    LOG.info("Update required as the State of resource '{}' "
                             "has been changed from '{}' to '{}'"
                             .format(kvm_server['id'], resource.get('state'),
                                     kvm_server['state']))
                    is_update_required = True
                if kvm_server.get('status') != resource.get('status'):
                    LOG.info("Update required as the status of resource '{}'"
                             "has been changed from '{}' to '{}'"
                             .format(kvm_server['id'], resource.get('status'),
                                     kvm_server.get('status')))
                    is_update_required = True
                categorized_datastores = self._filter_datastores(
                    datastores_from_gateway, resource.get('datastores'))
                # Check for New Datastores Added
                if categorized_datastores.get('new_datastores'):
                    self.LOG.info(
                        "Update required as new datastores {} added for "
                        "resource '{}'".format(
                            categorized_datastores['new_datastores'],
                            resource.get('id')))
                    is_update_required = True
                # Check for Existing Datastores Removed
                if categorized_datastores.get('datastores_to_be_deleted'):
                    self.LOG.info(
                        "Update required as existing datastores {} removed "
                        "from resource '{}'"
                        .format(
                            categorized_datastores['datastores_to_be_deleted'],
                            resource.get('id')))
                    is_update_required = True
                # Check for Datastore parameter changes
                if categorized_datastores.get('existing_datastores'):
                    for existing_ds in categorized_datastores.get(
                            'existing_datastores'):
                        for new_ds in datastores_from_gateway:
                            if new_ds['id'] == existing_ds['id']:
                                # Check Datastore/volume name chane
                                if new_ds['name'] != existing_ds['name']:
                                    self.LOG.info(
                                        "Update required as name of datastore/"
                                        " volume has been changed from '{}' to"
                                        " '{}' for resource '{}'"
                                        .format(existing_ds['name'],
                                                new_ds['name'],
                                                resource.get('id')))
                                # Check Datastore Total Disk Capacity Change
                                if new_ds['sizeGiB'] != existing_ds['sizeGiB']:
                                    self.LOG.info(
                                        "Update required as datastore/volume "
                                        "capacity has been changed from '{}' "
                                        "to '{}' for resource '{}'"
                                        .format(existing_ds['sizeGiB'],
                                                new_ds['sizeGiB'],
                                                resource.get('id')))
                                    is_update_required = True
            if is_update_required:
                return True

    def _get_agent_not_responding_error(self):
        return Ism_Error(
            "LCM_HPE_GATEWAY_NOT_RESPONDING",
            error_msg="HPE gateway agent is not responding",
            details=(
                "Possible reasons: "
                "1.The agent may not be running, "
                "2.The host is not in powered on state, "
                "3.IP of the host has been changed, "
                "4.Any Internet connection issues."
            )
        ).to_error()

    def _update_existing_servers(
            self, existing_resources, unmanaged_servers, ism_client):

        for resource in existing_resources:
            LOG.info("Resource '{}' already exist in DB ! Will update the "
                     "resource if required.".format(resource.get('id')))
            if resource['infraState'] in (const.RUNNING):
                if resource.get('state') in (const.ENABLING, const.DISABLING):
                    continue
                datastores_from_gateway = self._get_datastores_from_gateway(
                    resource, unmanaged_servers)
                if not self._is_update_required(
                        resource, unmanaged_servers, datastores_from_gateway):
                    LOG.info("Update not required for resource '{}'"
                             .format(resource.get('id')))
                    continue
                for kvm_server in unmanaged_servers:
                    if kvm_server['id'] == resource.get('id'):
                        payload = [
                            dict(op='replace', path='/name',
                                 value=kvm_server['name']),
                            dict(op='replace', path='/datastores',
                                 value=datastores_from_gateway),
                            dict(op='replace', path='/state',
                                 value=kvm_server['state'])
                        ]
                        if kvm_server.get('serverUri'):
                            payload.append(
                                dict(op='replace', path='/serverUri',
                                     value=kvm_server['serverUri'])
                            )
                        if kvm_server.get('status'):
                            payload.append(
                                dict(op='replace', path='/status',
                                     value=kvm_server['status'])
                            )
                            err = kvm_server['error']
                            if kvm_server['status'] == const.CRITICAL:
                                if not err.get("message"):
                                    # update the generic error
                                    err = self._get_agent_not_responding_error()
                            elif kvm_server['status'] == const.OK:
                                err = {}
                            payload.append(
                                dict(op='replace', path='/error',
                                     value=err)
                            )
                        break
                try:
                    LOG.debug(
                        "Updating resource id='{}' | uri='{}' with payload={}"
                        .format(resource.get('id'), resource.get('uri'),
                                json.dumps(payload, indent=4)))
                    ism_client.update_infrastructure_system(
                        resource.get('uri'), payload)
                except Exception as e:
                    LOG.exception(
                        "Exception occurred while updating resource id='{}'"
                        " | uri='{}'".format(resource.get('id'),
                                             resource.get('uri')))
                    LOG.exception(e)
                    raise e
            else:
                LOG.debug(
                    "Existing resource id='{}' is not in desired state, "
                    "i.e '{}'".format(resource.get('id'),
                                      resource.get('state')))

    def _create_new_servers(self, new_resources, zone_uri, ism_client):
        for resource in new_resources:
            payload = dict(
                id=resource['id'],
                managed='False',
                associatedZoneURI=zone_uri,
                state=resource['state'],
                serverUri=resource.get('serverUri', ''),
                datastores=self._get_datastore_payload_from_volumes(
                    resource.get('name'), resource.get('volumes', {}))
            )

            if resource.get('status'):
                payload['status'] = resource.get('status')
                if resource.get('status') == const.CRITICAL:
                    err = resource.get('error')
                    if err and err.get("message"):
                        self.LOG.debug(
                            "Updating error with error message from gw")
                        payload['error'] = utils.generate_ism_error(
                            err.get("message"))
                    else:
                        # update the generic error
                        self.LOG.debug(
                            "Updating error with generic error message")
                        payload['error'] = self._get_agent_not_responding_error()
            try:
                ism_client.create_infrastructure_system(
                    resource.get('name'), extraPayloadArgs=payload)
                LOG.info("New resource named '{}' created with state '{}' "
                         "and status '{}'".format(resource.get('name'),
                                                  resource.get('state'),
                                                  resource.get('status')))
            except HTTPError as e:
                # Swallow DB conflict exception.
                if const.DB_CONFLICT_EXCEPTION in e.message:
                    LOG.warn("Ignoring the above exception: {}"
                             .format(e.message))
                else:
                    LOG.exception("An exception occurred while creating "
                                  "Infrastructure System for resource "
                                  "'{}'".format(resource.get('name')))
                    raise e

    def _delete_servers(self, delete_resources, ism_client):
        for resource in delete_resources:
            if resource.get('managed') == 'True':
                LOG.info(
                    "Skipping delete of resource id='{}' as it is managed !"
                    .format(resource.get('id')))
                continue
            resource_uri = resource.get('uri')
            resource_id = resource.get('id')
            ism_client.delete_infrastructure_system(resource_uri)
            LOG.info("Successfully deleted resource id='{}' | uri='{}'"
                     .format(resource_id, resource_uri))

    def execute(self, params):
        unmanaged_servers = params['unmanaged_kvm_servers']

        ism_client = InfrastructureSystems(self.private_request)
        # Get all existing InfraSys for particular zone
        infra_sys_for_zone = self._get_all_infra_sys_for_zone(
            params['zone_uri'], ism_client)

        existing_resources = list()
        new_resources = list()
        delete_resources = list()
        for kvm_server in unmanaged_servers:
            new_resource = True
            for infra_sys in infra_sys_for_zone:
                if infra_sys.get('id') == kvm_server['id']:
                    new_resource = False
                    # Server record exists in DB. Update Server !
                    existing_resources.append(infra_sys)
                    break

            # Server record don't exists in DB. New Server !
            if new_resource and not params['is_zone_managed']:
                new_resources.append(kvm_server)

        kvm_server_ids_from_gateway = [kvm_server['id'] for kvm_server in
                                       unmanaged_servers]
        for infra_sys in infra_sys_for_zone:
            if infra_sys.get('id') not in kvm_server_ids_from_gateway:
                # Servers in DB are not there in gateway. Delete !
                if not params['is_zone_managed']:
                    delete_resources.append(infra_sys)

        if existing_resources:
            self._update_existing_servers(
                existing_resources, unmanaged_servers, ism_client)
        if new_resources:
            self._create_new_servers(
                new_resources, params['zone_uri'], ism_client)
        if delete_resources:
            self._delete_servers(delete_resources, ism_client)
        return self.exit_success(
            "Successfully synchronized unmanaged KVM hosts !")
