# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import urlparse
import json

from lib.common import constants as const
from orch import log
import utils


class VMwareNeutronConf(object):

    def __init__(self, params):
        self.LOG = log.getLogger(__name__)
        self.host_agent_info = params['hostagent_info']
        self.res_mgr_info = params['res_mgr_info']
        self.dvs_name = params.get('dvs_name')
        self.vcenter_ip = self.host_agent_info['vcenter_ip']
        self.vcenter_port = const.VCENTER_PORT
        self._get_headers(self.res_mgr_info['token'])
        self._get_net_location()

    def _get_headers(self, token):
        self.headers = {"Content-Type": "application/json",
                        "X-Auth-Token": token}

    def _get_net_location(self):
        _url = self.res_mgr_info['resmgr_url']
        _, net_location, _, _, _ = urlparse.urlsplit(_url)
        self.net_location = net_location

    def _get_neutron_server_default_conf(self):
        neutron = dict(DEFAULT=dict(router_distributed="False"))
        extra = dict(configured=False)
        ml2_vlan = dict(network_vlan_ranges="external")
        ml2_vxlan = dict(vni_ranges="PF9REMOVED")
        ml2_gre = dict(tunnel_id_ranges="PF9REMOVED")
        ml2_type = dict(type_drivers="flat,vlan",
                        tenant_network_types="vlan")
        ml2 = dict(ml2=ml2_type,
                   ml2_type_vxlan=ml2_vxlan,
                   ml2_type_vlan=ml2_vlan,
                   ml2_type_gre=ml2_gre)
        neutron_conf = dict(neutron=neutron,
                            ml2=ml2,
                            extra=extra)
        return neutron_conf

    def _get_neutron_server_dvs_conf(self):

        default = dict(core_plugin=const.DVS_PLUGIN,
                       service_plugins="segments")
        dvs = dict(host_ip="127.0.0.1",
                   host_port=const.TUNNEL_PROXY_PORT,
                   insecure=True,
                   dvs_name=self.dvs_name)
        neutron_conf = dict(neutron=dict(DEFAULT=default),
                            ml2=dict(dvs=dvs))
        return neutron_conf

    def _get_sec_tunnel_request_body(self):
        sec_tunnel_conf = dict(node_uuid=self.host_agent_info['id'],
                               destination_host=self.vcenter_ip,
                               destination_port=self.vcenter_port,
                               proxy_port=const.TUNNEL_PROXY_PORT,
                               client_auth=False)
        return sec_tunnel_conf
    def get_neutron_server_info(self):
        # Apply Neutron server configurations
        self.LOG.info("Applying neutron server configurations")

        with utils.do_request(const.HTTP_GET, self.net_location,
                              const.NEUTRON_SERVER_URI, self.headers
                              ) as response:
            return json.loads(response.read())

    def _is_sec_tunnel_created(self):
        self.LOG.info("Verify if sec tunnel created")
        created = False
        response = self.get_sec_tunnel_info()
        if response:
            created = True
        return created

    def _is_neutron_server_configured(self):
        created = False
        response = self.get_neutron_server_info()
        core_plugin = response['neutron']['DEFAULT'].get('core_plugin', None)
        if core_plugin == const.DVS_PLUGIN:
            created = True
        return created

    def get_sec_tunnel_info(self):
        # Apply Neutron server configurations
        self.LOG.info("Getting sec tunnel configurations")

        with utils.do_request(const.HTTP_GET, self.net_location,
                              const.SEC_TUNNEL_URI, self.headers
                              ) as response:
            return json.loads(response.read())

    def delete_sec_tunnel(self):
        sec_tunnel = self.get_sec_tunnel_info()
        if sec_tunnel:
            # There will be only one sec tunnel for a vcenter
            proxy_port = str(sec_tunnel[0]['proxy_port'])
            proxy_uri = sec_tunnel[0]['proxy_host'] + ":" + proxy_port
            uri = const.SEC_TUNNEL_URI + "/" + proxy_uri
            utils.do_request(const.HTTP_DELETE, self.net_location,
                             uri, self.headers)

    def create_sec_tunnel(self):
        # Create a tunnel for communicating vCenter server and DU
        self.LOG.info("Applying security tunnel configurations")

        if self._is_sec_tunnel_created():
            self.LOG.info("Sec tunnel already created\n")
            return

        request_body = self._get_sec_tunnel_request_body()

        with utils.do_request(const.HTTP_POST, self.net_location,
                              const.SEC_TUNNEL_URI, self.headers,
                              request_body) as response:
            return json.loads(response.read())

    def update_neutron_server_conf(self, default=False):
        # Apply Neutron server configurations
        self.LOG.info("Applying neutron server configurations")

        if not default and self._is_neutron_server_configured():
            self.LOG.info("Neutron server  already configured\n")
            return

        if default:
            request_body = self._get_neutron_server_default_conf()
        else:
            request_body = self._get_neutron_server_dvs_conf()

        with utils.do_request(const.HTTP_PUT, self.net_location,
                              const.NEUTRON_SERVER_URI, self.headers,
                              request_body) as response:
            return json.loads(response.read())

