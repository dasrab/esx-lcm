# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import httplib
import json

from lib.common import constants as const
import utils

from orch import log


class KVMRolesUtil(object):

    def __init__(self, **kwargs):
        self.LOG = log.getLogger(__name__)
        self._net_loc = kwargs['net_loc']
        self._host_agent = kwargs['host_agent']
        self._v1_hosts_path = ''.join(
            [kwargs['res_mgr_path'], const.V1_HOSTS_PATH,
             self._host_agent['id']])
        self._roles_path = '/'.join(
            [self._v1_hosts_path, const.ROLE_PATH])
        self._v1_path = ''.join([kwargs['res_mgr_path'], const.V1_PATH])
        self._headers = kwargs['headers']
        self._kvm_ip = kwargs.get('kvm_ip')
        if kwargs.get('is_enable'):
            self._role_definitions = self._get_kvm_role_definitions()

    def _get_kvm_role_definitions(self):
        # This method will return the default rest body for all roles
        try:
            self.LOG.debug("Fetching default settings to apply roles !")
            v1_role_path = ''.join([self._v1_path, const.ROLE_PATH])
            with utils.do_request(const.HTTP_GET, self._net_loc, v1_role_path,
                                  self._headers) as response:
                return json.loads(response.read())
        except httplib.HTTPException as e:
            self.LOG.exception("Failed to retrieve KVM role definitions !")
            raise e

    def _get_role_rest_body(self, role_name):
        # This method will fetch the default rest body for the particular role
        # It will then invoke the respective method by role name to modify the
        # rest body.
        default_rest_body = dict()
        for role_def in self._role_definitions:
            if role_def.get('name') == role_name:
                default_rest_body = role_def.get('default_settings', {})
                break
        modified_body = dict()
        try:
            method_name = '_'.join(
                ['_get', role_name, 'body']).replace('-', '_')
            modified_body = getattr(self, method_name)()
        except Exception as e:
            if isinstance(e, AttributeError):
                pass
            else:
                raise e

        if modified_body:
            default_rest_body.update(modified_body)
        return default_rest_body

    def _create_physnet_to_bridge_mappings(self):
        server_path = const.NEUTRON_SERVER_SERVICE
        server_path = self._v1_path + server_path
        found_physnets = utils.get_physnets(
            self._net_loc, server_path, self._headers)
        found_physnets = found_physnets.split(",")

        found_bridges = utils.get_val(self._host_agent, 'extensions',
                                      'interfaces', 'data', 'ovs_bridges')
        bridge_mapping_dict = {}
        for physnet in found_physnets:
            if const.BRIDGE_NAME_PREFIX + physnet in found_bridges:
                bridge_mapping_dict[physnet] = (
                    const.BRIDGE_NAME_PREFIX + physnet)
        bridge_mappings = ','.join('{}:{}'.format(key, val) for key, val in
                                   bridge_mapping_dict.items())
        return bridge_mappings

    # Implement the method that need to override default settings !
    # Method name should be in the format of:
    # _get_<role_name_hyphen_replaced_with_underscore>_body()

    def _get_pf9_ostackhost_neutron_body(self):
        return dict(
            novncproxy_base_url=const.NO_VNC_PROXY_URL.format(self._kvm_ip),
            instances_path=const.GATEWAY_INSTANCE_PATH
        )

    def _get_pf9_glance_role_body(self):
        return dict(
            endpoint_address=self._kvm_ip,
            update_public_glance_endpoint=const.ENABLE_PUBLIC_GLANCE_ENDPOINT,
            filesystem_store_datadir=const.GATEWAY_IMAGE_LIB_PATH
        )

    def _get_pf9_cindervolume_ceph_body(self):
        return dict(
            volume_backend_name=const.STORAGE_VOLUME_NAME,
            rbd_pool=const.STORAGE_POOL_NAME,
            rbd_secret_uuid='',
            rbd_user=const.CINDER_USER,
            rbd_flatten_volume_from_snapshot=const.FLATTEN_VOLUME_FROM_SNAPSHOT
        )

    def _get_pf9_cindervolume_lvm_body(self):
        return dict(
            volume_backend_name=const.STORAGE_VOLUME_NAME,
            iscsi_ip_address=self._kvm_ip
        )

    def _get_pf9_neutron_ovs_agent_body(self):
        return dict(
            allow_dhcp_vms=const.ALLOW_DHCP_VMS,
            enable_distributed_routing=const.ENABLE_DISTRIBUTED_ROUTING,
            bridge_mappings=self._create_physnet_to_bridge_mappings()
        )

    def _get_pf9_neutron_l3_agent_body(self):
        return dict(
            agent_mode=const.L3_AGENT_MODE
        )

    @utils.retry(count=3)
    def apply_role(self, role_name):
        if role_name in self._host_agent['roles']:
            self.LOG.info("'{}' role is already applied".format(role_name))
            return
        self.LOG.info("Applying Role '{}'".format(role_name))
        role_path = '/'.join([self._roles_path, role_name])
        body = self._get_role_rest_body(role_name)
        with utils.do_request(const.HTTP_PUT, self._net_loc,
                              role_path, self._headers, body) as response:
            self.LOG.debug(
                "Response for role {} : {}".format(role_name, response.status))

    @utils.retry(count=3)
    def delete_all_roles(self):
        with utils.do_request(const.HTTP_DELETE, self._net_loc,
                              self._v1_hosts_path, self._headers) as response:
            self.LOG.debug("Response for disable host: {}"
                           .format(response.status))
