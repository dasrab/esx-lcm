# (C) Copyright 2017 Hewlett Packard Enterprise Development LP


class Proxy_Server(object):
    """Static class to store proxy server details"""

    proxy_server = None
    proxy_port = None

    @staticmethod
    def set_proxy_details(proxy_server, proxy_port):
        Proxy_Server.proxy_server = proxy_server
        Proxy_Server.proxy_port = proxy_port

    @staticmethod
    def get_proxy_details():
        return (Proxy_Server.proxy_server, Proxy_Server.proxy_port)
