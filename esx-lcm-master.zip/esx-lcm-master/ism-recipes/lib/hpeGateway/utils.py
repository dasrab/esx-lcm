# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import contextlib
import httplib
import ipaddress
import json
import time
import urlparse

from functools import reduce, wraps
from model import Proxy_Server
from orch.ism_sdk.activity import Ism_Error
from lib.hpeGateway import vmware_neutron_utils

from lib.common import constants
from orch import log

LOG = log.getLogger(__name__)


@contextlib.contextmanager
def do_request(action, host, relative_url, headers, body={}):
    """
    Execute the REST call with the details provided.
    """
    try:
        conn = None
        proxy_server, proxy_port = Proxy_Server.get_proxy_details()
        if proxy_server and proxy_port:
            conn = httplib.HTTPSConnection(proxy_server, proxy_port)
            conn.set_tunnel(host)
        else:
            conn = httplib.HTTPSConnection(host)
        body_json = json.JSONEncoder().encode(body)
        conn.request(action, relative_url, body_json, headers)
        response = conn.getresponse()
        if response.status not in (200, 201, 204):
            msg = "'{}': {}".format(response.status, response.reason)
            raise httplib.HTTPException(msg)
    except Exception as e:
        if conn:
            conn.close()
        raise e
    try:
        yield response
    finally:
        if conn:
            conn.close()


def retry(count=5, exc_type=Exception):
    """
    Generalized decorator that lets you specify
    the number of retries and also the exception type.
    """
    def decorator(func):
        @wraps(func)
        def result(*args, **kwargs):
            for _ in range(count):
                try:
                    return func(*args, **kwargs)
                except exc_type as e:
                    pass
            raise Exception(e)
        return result
    return decorator


def get_val(dc, *keys):
    return reduce(lambda d, key: d.get(key, None)
                  if isinstance(d, dict) else None, keys, dc)


def get_host_agents(netloc, path, headers):
    LOG.debug("Getting all the host agents")
    with do_request("GET", netloc, path, headers, {}) as response:
        host_agents = json.loads(response.read())
        return host_agents


def get_number_of_enabled_kvm_servers(netloc, v1_hosts_path, headers):
    enabled_host_count = 0
    host_agents = get_host_agents(netloc, v1_hosts_path, headers)
    for host_agent in host_agents:
        if (host_agent['hypervisor_info']['hypervisor_type'] ==
                constants.KVM_HYPERVISOR):
            if host_agent.get('roles'):
                enabled_host_count += 1
    return enabled_host_count


def get_kvm_host_agent(netloc, path, headers):
    # Note: path = /v1/hosts/host_id
    with do_request(constants.HTTP_GET, netloc, path, headers) as response:
        host_agent = json.loads(response.read())
        return host_agent


def is_healthy_host(host_agent):
    # Warn message can be empty string if there is no configuration error.
    # It will be empty list if problems was fixed after agent was installed.
    is_healthy = True
    msg = ""
    if isinstance(host_agent.get('message'), dict):
        warn = host_agent.get('message').get('warn')
        if warn:
            is_healthy = False
            msg = (
                "Host '{}' encountered an error."
                "Error '{}' . Fix the"
                " problem and run again !"
                .format(host_agent['info']['hostname'],
                        host_agent['message'].get('warn')))
            LOG.error(msg)
    return is_healthy, msg


def _wait_for_kvm_host_agent(netloc, path, headers, disable=False):
    count = 0
    host_agent_status = constants.HOST_AGENT_ROLE_STATUS_CONVERGING
    sleep_time = constants.SLEEP_TIME_TO_GET_CONVERGING_STATE
    while count < constants.MAX_WAIT_TIME_FOR_OK_STATE:
        host_agent = get_kvm_host_agent(netloc, path, headers)
        if disable:
            # Note: There is no state if delete all roles.
            # We are just using the sleep_time variable !
            sleep_time = constants.SLEEP_TIME_TO_GET_OK_STATE
            if not host_agent['roles']:
                # Empty roles means successful de-authorization
                return True
            LOG.info(
                "Waiting for all roles to be cleaned up ! Host = '{}' | "
                "Wait time = {}s | Total wait time={}s"
                .format(host_agent['info']['hostname'], sleep_time, count))
        else:
            LOG.info("Host = '{}' | Required status = '{}' | "
                     "Current status = '{}' | Total wait time = {}s".format(
                      host_agent['info']['hostname'], host_agent_status,
                      host_agent.get('role_status'), count))
            if (host_agent.get('role_status') ==
                    constants.HOST_AGENT_ROLE_STATUS_FAILED):
                return False
            # First wait for 'converging' state
            if host_agent.get('role_status') == host_agent_status:
                # Now wait for 'ok' state
                host_agent_status = constants.HOST_AGENT_ROLE_STATUS_OK
                sleep_time = constants.SLEEP_TIME_TO_GET_OK_STATE
                if host_agent.get('role_status') == host_agent_status:
                    return True
        time.sleep(sleep_time)
        count += sleep_time
    LOG.error("Timed out while waiting for enable/disable/recover KVM server!")


def get_all_host_agent_roles(net_location, path, headers):
    LOG.debug("Getting all the host agent roles")
    path = path + "/v1/roles"
    with do_request("GET", net_location, path, headers, {}) as response:
        all_host_agent_roles = json.loads(response.read())
    host_agent_roles = [role['name'] for role in all_host_agent_roles]
    return host_agent_roles


def _wait_for_host_agent(net_location, path, headers, last_cluster=False):
    count = 0
    host_agent_status = constants.HOST_AGENT_ROLE_STATUS_CONVERGING
    sleep_time = constants.SLEEP_TIME_TO_GET_CONVERGING_STATE
    while count < constants.MAX_WAIT_TIME_FOR_OK_STATE:
        try:
            with do_request("GET", net_location, path, headers) as response:
                result = json.loads(response.read())
        except:
            LOG.info("Received error while connecting. trying again")

        if last_cluster:
            if not result['roles']:
                return True
        else:
            LOG.debug("Host agent's Required status = '{}' | "
                      "Current status = '{}' | Wait time = {}s".format(
                          host_agent_status, result.get('role_status'), count))
            # First wait for 'converging' state
            if result.get('role_status') == host_agent_status:
                # Now wait for 'ok' state
                host_agent_status = constants.HOST_AGENT_ROLE_STATUS_OK
                sleep_time = constants.SLEEP_TIME_TO_GET_OK_STATE
                if result.get('role_status') == host_agent_status:
                    return result
        time.sleep(sleep_time)
        count += sleep_time


@retry(count=3)
def _deauthorize_host(net_location, path, headers):
    # De-authorize the host as we are deallocating the last cluster in
    # HPE gateway
    LOG.debug("Deauthorizing the host")
    with do_request("DELETE", net_location,
                    path, headers, {}) as response:
        return json.loads(response.read())


def _set_neutron_server_default_conf(params):
    neutron = vmware_neutron_utils.VMwareNeutronConf(params)
    neutron.delete_sec_tunnel()
    neutron.update_neutron_server_conf(default=True)


def is_neutron_enabled(neutron):
    return (neutron.get('enabled') and (neutron.get('ep_present')))


def get_all_managed_clusters_from_hpe_gateway(net_location, path,
                                              headers, neutron={}):
    # Get all Managed Clusters from HPE gateway
    LOG.debug("Getting all clusters which are already managed by HPE Gateway")
    role = "/roles/pf9-ostackhost-vmw"

    if is_neutron_enabled(neutron):
        role = "/roles/pf9-ostackhost-neutron-vmw"

    role_path = path + role

    with do_request("GET", net_location,
                    role_path, headers, {}) as response:
        result = json.loads(response.read())
    if result['cluster_name']:
        return result['cluster_name'].split(',')

    else:
        return []


@retry(count=3)
def _apply_tunman_role(net_location, path, headers):
    LOG.info("Applying tunnel manager Role")
    role = "/roles/pf9-tunman"
    role_path = path + role
    body = {}
    with do_request("PUT", net_location,
                    role_path, headers, body) as response:
        return json.loads(response.read())


@retry(count=3)
def _apply_compute_role(net_location, path, headers,
                        cluster_names, datastore_regex,
                        neutron):
    # Apply Compute role
    LOG.info("Applying Compute Role")
    role = "/roles/pf9-ostackhost-vmw"

    if is_neutron_enabled(neutron):
        role = "/roles/pf9-ostackhost-neutron-vmw"

    role_path = path + role

    body = {"cluster_name": cluster_names,
            "datastore_regex": datastore_regex,
            "extension_key": "hpe.onesphere.compute",
            "extension_label": "HPE OneSphere",
            "extension_description": "HPE OneSphere Compute Service"}
    with do_request("PUT", net_location,
                    role_path, headers, body) as response:
        return json.loads(response.read())


@retry(count=3)
def _apply_glance_role(net_location, path, headers, ip_address,
                       datacenter_name, datastore_names):
    # Apply Glance role
    LOG.info("Applying Glance Role")
    role = "/roles/pf9-glance-role-vmw"
    role_path = path + role

    body = {"endpoint_address": ip_address,
            "vmware_datacenter_path": datacenter_name,
            "vmware_store_image_dir": "/hpeonesphere/openstack_glance",
            "vmware_datastore_name": datastore_names[-1]}

    with do_request("PUT", net_location,
                    role_path, headers, body) as response:
        return json.loads(response.read())


@retry(count=3)
def _apply_cinder_role(net_location, path, headers, base):
    # Apply Cinder Role based on the boolen value of base
    # If base is True then apply cinder_base role
    # If base is False the aplly cinder_other role
    if base:
        LOG.info("Applying Cinder Base Role")
        role = "/roles/pf9-cindervolume-base"
        role_path = path + role
        body = {}
    else:
        LOG.info("Applying Cinder Other Role")
        role = "/roles/pf9-cindervolume-other"
        role_path = path + role
        body = {"volume_driver":
                "cinder.volume.drivers.vmware.vmdk.VMwareVcVmdkDriver"}

    with do_request("PUT", net_location,
                    role_path, headers, body) as response:
        return json.loads(response.read())


def get_id_from_uri(uri):
    return uri.split('/')[-1]


@retry(count=3)
def _apply_monasca_role(net_location, path, headers, monasca_details):
    # Apply Monasca Agent Role
    LOG.info("Applying Monasca Role")
    role = "/roles/pf9-monasca-agent"
    role_path = path + role

    body = monasca_details

    with do_request("PUT", net_location,
                    role_path, headers, body) as response:
        return json.loads(response.read())


def _apply_hpe_gateway_roles(clusters,
                             cluster_names,
                             existing_hpe_gateway_roles,
                             ip_address, path, headers,
                             net_location, monasca_details,
                             neutron):
    datastore_names = []
    datacenter_name = None
    for cluster in clusters:
        if cluster['name'] in cluster_names:
            for datastore in cluster['datastores']:
                datacenter_name = datastore['datacenter_name']
                datastore_names.append(datastore['name'])

    # In order to avoid duplication of names in the list
    datastore_names = list(set(datastore_names))

    # Convert the list to comma seperated strings
    cluster_names = ','.join(cluster_names)
    datastore_regex = ','.join(datastore_names)

    # Do a REST call to HPE gateway to manage the given cluster(s)
    _apply_compute_role(net_location, path, headers,
                        cluster_names, datastore_regex,
                        neutron)

    # If Glance role is already applied then skip it
    if "pf9-glance-role-vmw" not in existing_hpe_gateway_roles:
        # Do a REST call to apply Glance role on the host
        _apply_glance_role(net_location, path, headers,
                           ip_address, datacenter_name,
                           datastore_names)

    # If Cinder volume base role is already applied then skip it
    if "pf9-cindervolume-base" not in existing_hpe_gateway_roles:
        # Do a REST call to apply cinder volume base role to host
        _apply_cinder_role(net_location, path, headers, base=True)

    # If Cinder Volume other role is already applied then skip it
    if "pf9-cindervolume-other" not in existing_hpe_gateway_roles:
        # Do a REST call to apply Cinder Volume other role to host
        _apply_cinder_role(net_location, path, headers, base=False)

    # If Monasca role is already applied then skip it
    if "pf9-monasca-agent" not in existing_hpe_gateway_roles:
        # Do a REST call to apply Monasca Role to host
        _apply_monasca_role(net_location, path, headers, monasca_details)

    # If tunman role is already applied then skip it
    if is_neutron_enabled(neutron) and (
            "pf9-tunman" not in existing_hpe_gateway_roles):
        # Do Rest call to apply tunman role on the host
        _apply_tunman_role(net_location, path, headers)


def manage_cluster(params, allocate):
    """
    Method to allocate or dealloacte the cluster based
    on the boolen value of allocate
    """

    host_agent_info = params['hostagent_info']
    res_mgr_info = params['res_mgr_info']
    cluster_list = params['cluster_names']

    # List of all clusters and its datastores info from the host
    clusters = host_agent_info['clusters']

    # Host ID
    host_id = host_agent_info['id']

    headers = {"Content-Type": "application/json",
               "X-Auth-Token": res_mgr_info['token']}

    _, net_location, path, _, _ = urlparse.urlsplit(res_mgr_info['resmgr_url'])
    path = path + "/v1/hosts" + "/" + host_id

    # Get Monasca Details
    monasca_details = {
        "monasca_password": params['monasca_password'],
        "monasca_url": params['monasca_url'],
        "monasca_tenant": params['monasca_tenant'],
        "default_dimensions": {
            "region_id": get_id_from_uri(
                params['region_id']),
            "provider_id": get_id_from_uri(
                params['provider_id']),
            "zone_id": params['zone_id'],
            "provider_type": "NCS"}
    }
    neutron = {
        "enabled": params['vmware_neutron'],
        "ep_present": res_mgr_info['neutron_ep_present']
    }

    # Get the list of cluster from HPE gateway which are already managed
    if ('pf9-ostackhost-vmw' in host_agent_info['roles']) or (
        neutron and ('pf9-ostackhost-neutron-vmw' in host_agent_info['roles'])
            ):
        managed_clusters = get_all_managed_clusters_from_hpe_gateway(
            net_location, path, headers, neutron)
    else:
        managed_clusters = []

    cluster_names = []
    if allocate:
        cluster_names = list(
            set(cluster_names + managed_clusters + cluster_list))
    else:
        cluster_names = list(
            set(cluster_names + managed_clusters) - set(cluster_list))
        if not cluster_names:
            # De-authorize the host
            _deauthorize_host(net_location, path, headers)
            # Wait till the De-authorization of host completes
            if _wait_for_host_agent(net_location, path,
                                    headers, last_cluster=True):
                return True
            else:
                raise Exception("Time out while Deallocating"
                                " the last Cluster(s)")

    # Apply multiple HPE gateway roles on the host
    _apply_hpe_gateway_roles(clusters, cluster_names,
                             host_agent_info['roles'],
                             host_agent_info['ip_address'],
                             path, headers, net_location,
                             monasca_details, neutron)

    # Wait till the above tasks are completed
    if _wait_for_host_agent(net_location, path, headers):
        # Get the list of cluster from HPE gateway which are managed
        managed_clusters = get_all_managed_clusters_from_hpe_gateway(
            net_location, path, headers, neutron)
        # Check if the given set of clusters are allocated or
        # deallocated successfully
        if allocate:
            failed_cluster_list = list(
                set(cluster_list) - set(managed_clusters))
        else:
            failed_cluster_list = list(
                set(cluster_list).intersection(set(managed_clusters)))

        if not failed_cluster_list:
            return True
        else:
            LOG.debug("Cluster(s): {cluster} failed to {operation}".format(
                cluster=failed_cluster_list,
                operation="allocate" if allocate else "deallocate"))
            return True
    else:
        raise Exception("Time out while Managing Cluster(s)")


def enable_disable_resource(params):
    """
    Method to enable and disable the resource in a single call
    """
    LOG.info("Enable and Disable Clusters")
    host_agent_info = params['hostagent_info']
    res_mgr_info = params['res_mgr_info']

    clusters_to_allocate = params.get('clusters_to_allocate', [])
    clusters_to_deallocate = params.get('clusters_to_deallocate', [])
    LOG.info("Clusters to Enable =%s", clusters_to_allocate)
    LOG.info("Clusters to Disable =%s", clusters_to_deallocate)

    # List of all clusters and its datastores info from the host
    clusters = host_agent_info['clusters']

    # Host ID
    host_id = host_agent_info['id']

    headers = {"Content-Type": "application/json",
               "X-Auth-Token": res_mgr_info['token']}

    _, net_location, path, _, _ = urlparse.urlsplit(res_mgr_info['resmgr_url'])
    path = path + "/v1/hosts" + "/" + host_id

    # Get Monasca Details
    monasca_details = {
        "monasca_password": params['monasca_password'],
        "monasca_url": params['monasca_url'],
        "monasca_tenant": params['monasca_tenant'],
        "default_dimensions": {
            "region_id": get_id_from_uri(
                params['region_id']),
            "provider_id": get_id_from_uri(
                params['provider_id']),
            "zone_id": params['zone_id'],
            "provider_type": "NCS"}
    }

    neutron = {
        "enabled": params['vmware_neutron'],
        "ep_present": res_mgr_info['neutron_ep_present']
    }
    # Get the list of cluster from HPE gateway which are already managed
    if ('pf9-ostackhost-vmw' in host_agent_info['roles']) or (
            'pf9-ostackhost-neutron-vmw' in host_agent_info['roles']):
        managed_clusters = get_all_managed_clusters_from_hpe_gateway(
            net_location, path, headers, neutron)
    else:
        managed_clusters = []

    cluster_names = []
    cluster_names = cluster_names + managed_clusters

    if clusters_to_allocate:
        cluster_names = list(
            set(cluster_names + clusters_to_allocate))
    if clusters_to_deallocate:
        cluster_names = list(set(cluster_names) - set(clusters_to_deallocate))

    # If none of the clusters are passed are enable or disable
    if not (clusters_to_allocate or clusters_to_deallocate):
        LOG.debug("Returning as Clusters to enable and disable are empty")
        return True

    if not cluster_names:
        # De-authorize the host
        LOG.info(
            "As %s is last cluster to deallocate we are deauthorizing host",
            clusters_to_deallocate)
        if is_neutron_enabled(neutron):
            _set_neutron_server_default_conf(params)
        _deauthorize_host(net_location, path, headers)
        # Wait till the De-authorization of host completes
        if _wait_for_host_agent(net_location, path,
                                headers, last_cluster=True):
            return True
        else:
            raise Exception("Time out while Deallocating"
                            " the last Cluster(s)")
    # Apply multiple HPE gateway roles on the host
    _apply_hpe_gateway_roles(clusters, cluster_names, host_agent_info['roles'],
                             host_agent_info['ip_address'], path, headers,
                             net_location, monasca_details, neutron)
    # Apply Neutron server roles
    if is_neutron_enabled(neutron):
        _apply_neutron_server_roles(params)
    # Wait till the above tasks are completed
    if _wait_for_host_agent(net_location, path, headers):
        # Get the list of cluster from HPE gateway which are managed
        managed_clusters = get_all_managed_clusters_from_hpe_gateway(
            net_location, path, headers, neutron)
        # Check if the given set of clusters are enabled or
        # deallocated successfully
        failed_cluster_list = set(cluster_names) - set(managed_clusters)
        if not failed_cluster_list:
            return True
        else:
            LOG.debug("Failed to enable/disable the cluster list %s",
                      failed_cluster_list)
            return True
    else:
        raise Exception("Time out while Managing Cluster(s)")


def _apply_neutron_server_roles(params):
    # Create a VMWareNeutronConf object
    neutron = vmware_neutron_utils.VMwareNeutronConf(params)
    neutron.create_sec_tunnel()


def get_resource_manager_endpoint(
        keystone_url,
        username,
        password,
        tenant,
        region,
        vmware_neutron=False):
    """
    Get the token and resource manager endpoint based on region and tenant.
    """
    LOG.debug("Getting Resource Manager Endpoint")
    _, host, path, _, _ = urlparse.urlsplit(keystone_url)
    headers = {"Content-Type": "application/json"}
    body = _get_token_request_body(username, password, tenant)
    with do_request("POST", host,
                    path + "/v3/auth/tokens",
                    headers, body) as response:
        response_body = json.loads(response.read())
        token = response.getheader('X-Subject-Token')
    catalog = response_body['token']['catalog']
    url = ""
    neutron_ep_present = False
    for element in catalog:
        if vmware_neutron and element['type'] == 'network':
            neutron_ep_present = True
            if url:
                break
        if element['type'] == 'resmgr':
            for endpoint in element['endpoints']:
                if endpoint['region'] == region:
                    if endpoint['interface'] == 'public':
                        url = endpoint['url']
                        if neutron_ep_present:
                            break

    # Return token and resource manager endpoint
    if url:
        return {'token': token,
                'resmgr_url': url,
                'neutron_ep_present': neutron_ep_present
                }
    # Could not get resource manager endpoint. Return empty dict.
    return {}


def _get_token_request_body(username, password, tenant):
    """
    Return the json dict for a token request.
    """
    return {
        "auth": {
            "identity": {
                "methods": ["password"],
                "password": {
                    "user": {
                        "name": username,
                        "domain": {"id": "default"},
                        "password": password
                    }
                }
            },
            "scope": {
                "project": {
                    "name": tenant,
                    "domain": {"id": "default"}
                }
            }
        }
    }


def get_token_v3(keystone_url, username, password, tenant):
    """
    Get HPE gateway token by using the given credentials.
    """
    _, host, path, _, _ = urlparse.urlsplit(keystone_url)
    headers = {"Content-Type": "application/json"}
    body = _get_token_request_body(username, password, tenant)
    with do_request("POST", host,
                    path + "/v3/auth/tokens?nocatalog",
                    headers, body) as response:
        token = response.getheader('X-Subject-Token')
    return token


def generate_new_ip(ip_start_range, ip_end_range, reserved_ips):
    """
    Return a new IP address from the given range which is not used.
    """
    ip_start_range = ipaddress.ip_address(unicode(ip_start_range))
    ip_end_range = ipaddress.ip_address(unicode(ip_end_range))
    while ip_start_range <= ip_end_range:
        if str(ip_start_range) not in reserved_ips:
            return str(ip_start_range)
        ip_start_range += 1


def get_physnets(url, path, headers, body=None):
    neutron_server_info = []
    with do_request("GET", url, path, headers, body) as response:
        neutron_server_info = json.loads(response.read())
    return get_val(
        neutron_server_info, "ml2", "ml2_type_vlan", "network_vlan_ranges")


def generate_ism_error(error_msg):
    return Ism_Error(
        "LCM_HPE_GATEWAY_KVM_ERROR",
        error_msg=error_msg,
    ).to_error()
