# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import re
from orch import log

from lib.common import constants
from lib.hpeGateway import utils


class PhysnetUtil(object):

    def __init__(self, net_loc, v1_path, headers, host_agent):
        self.LOG = log.getLogger(__name__)
        self._net_loc = net_loc
        self._v1_path = v1_path
        self._headers = headers
        self._host_agent = host_agent
        self._hostname = self._host_agent['info']['hostname']

    def validate(self):
        found_bridges = self._fetch_bridges()
        no_of_bridges_on_host = len(found_bridges)

        # fail if no bridges found at all matching br-physnet
        if no_of_bridges_on_host == 0:
            raise Exception(
                "At least one bridge of the format 'br-physnet' is expected, "
                "but no. of bridges found are {} on the host '{}'"
                .format(no_of_bridges_on_host, self._hostname))

        found_physnets = self._fetch_physnets()
        no_of_existing_physnets = len(found_physnets)

        if no_of_existing_physnets > 0:
            # Authorizing second host onward we will be here
            # check if there are enough br-physnet bridges on this host
            if no_of_bridges_on_host < no_of_existing_physnets:
                raise Exception(
                    "Expecting bridges '{}'"
                    "Found {} on the host '{}'"
                    .format(no_of_existing_physnets, no_of_bridges_on_host,
                            self._hostname))
            # check if bridge names suffix matching the physnet suffix
            self._validate_bridge_names(found_bridges, found_physnets)

            # bridges match in no and naming convention now
            self.LOG.info(
                "Found bridges matching physnets, bridges that will be mapped "
                "are {} "
                "for the host '{}'".format(found_bridges, self._hostname))
            return
        else:
            # which means physnets are getting created for the first time
            # (this piece of code executes only for 1st host)
            # create physnet names ending with the physnet +
            # suffix of the bridge(br-physnet*)
            expected_physnet_names = []
            search_regex = (constants.BRIDGE_NAME_PREFIX +
                            constants.PHYSNET_KEY + '(.*)$')
            for bridge_name in found_bridges:
                # will never throw AttributeError: 'NoneType'
                # object has no attribute'group' , since bridges are
                # already filtered matching br-physnet
                physnet_suffix = re.search(search_regex, bridge_name).group(1)
                expected_physnet_names.append(constants.PHYSNET_KEY
                                              + physnet_suffix)
            return expected_physnet_names

    def _validate_bridge_names(self, found_bridges, found_physnets):
        matched_bridge_names = []
        unmatched_bridge_names = []
        for physnet in found_physnets:
            if (constants.BRIDGE_NAME_PREFIX + physnet) in found_bridges:
                matched_bridge_names.append(constants.BRIDGE_NAME_PREFIX +
                                            physnet)
                continue
            unmatched_bridge_names.append(constants.BRIDGE_NAME_PREFIX +
                                          physnet)
        if len(unmatched_bridge_names) > 0:
            expected_bridge_names = matched_bridge_names + \
                unmatched_bridge_names
            raise Exception(
                "Expecting bridges: '{}' | Found: "
                "'{}' | hostname: '{}'"
                .format(expected_bridge_names, found_bridges,
                        self._host_agent['id']))

    def _create_physnets(self, physnets_to_create, respone_message):
        server_path = constants.NEUTRON_SERVER_SERVICE
        server_path = self._v1_path + server_path
        physnet_list = ",".join(physnets_to_create)
        body = {
            'ml2': {
                'ml2': {
                    'type_drivers': 'flat,vlan',
                    'tenant_network_types': 'vlan'
                },
                'ml2_type_vxlan': {
                    'vni_ranges': 'PF9REMOVED'
                },
                'ml2_type_gre': {
                    'tunnel_id_ranges': 'PF9REMOVED'
                },
                'ml2_type_vlan': {
                    'network_vlan_ranges': physnet_list
                }
            },
            'neutron': {
                'DEFAULT': {
                    'dhcp_agents_per_network': (
                        constants.DHCP_AGENTS_PER_NETWORK),
                    'router_distributed': True
                }
            },
            'extra': {
                'dnsmasq_dns_servers': None,
                'configured': True
            }
        }
        with utils.do_request(constants.HTTP_PUT, self._net_loc,
                              server_path, self._headers, body) as response:
            self.LOG.info("{} : {}".format(respone_message, response.status))

    def _fetch_bridges(self):
        bridge_info = utils.get_val(self._host_agent, 'extensions',
                                    'interfaces', 'data', 'ovs_bridges')
        # only consider those bridges that are starting with
        # br-physnet for validation
        return [bridge_name for bridge_name in bridge_info
                if bridge_name.startswith(
                    constants.BRIDGE_NAME_PREFIX + constants.PHYSNET_KEY)]

    def _fetch_physnets(self):
        path = ''.join([self._v1_path, constants.NEUTRON_SERVER_SERVICE])
        vlan_ranges = utils.get_physnets(self._net_loc, path,
                                         self._headers)
        vlan_ranges = vlan_ranges.split(',')
        return [
            physnet for physnet in vlan_ranges if physnet.startswith(
                constants.PHYSNET_KEY)]

    def validate_and_create_physnets(self):
        respone_message = "Response for create physnet"
        physnets_to_create = self.validate()
        if physnets_to_create:
            self._create_physnets(physnets_to_create, respone_message)

    def clean_physnet(self):
        respone_message = "Updating physnet to default physnet i.e, external"
        physnets_to_create = [constants.EXTERNAL_PHYSNET]
        self._create_physnets(physnets_to_create, respone_message)
