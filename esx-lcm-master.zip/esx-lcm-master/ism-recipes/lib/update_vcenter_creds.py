# (C) Copyright 2018 Hewlett Packard Enterprise Development LP

import time
import traceback
import hpOneViewClrm as hpovclrm

from orch.moduleBase import ModuleBase

from common.oneview_connector import OneviewConnector


class Update_Vcenter_Creds(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    def execute(self, params):
        connection = OneviewConnector(params['ov_host'],
                                      params['ov_port'],
                                      params['auth']).connect()
        hypervisor_managers = hpovclrm.hypervisor_managers(connection)
        hyp_mgr = hypervisor_managers.get_hypervisor_manager(
            params['vc_remote_host'])

        if (hyp_mgr['username'] != params['vc_username'] or
                hyp_mgr['password'] != params['vc_password']):

            # Trigger vCenter creds update in OV hypervisor-managers because
            # stored creds and passed creds are different.

            hyp_mgr['username'] = params['vc_username']
            hyp_mgr['password'] = params['vc_password']

            _retries = 3
            for i in range(_retries):
                try:
                    hypervisor_managers.update_hypervisor_manager(hyp_mgr)
                    self.LOG.info(
                        "Successfully updated vCenter credentials in"
                        " hypervisor-manager")
                    return self.exit_success(True)
                except Exception as e:
                    if i < _retries - 1:
                        time.sleep(5)
                        continue
                    else:
                        self.LOG.error(
                            "Task Update vCenter Credentials failed!")
                        self.LOG.error(traceback.format_exc())
                        return self.exit_fail(str(e))
        else:
            return self.exit_fail(
                "Provided credentials are same as the credentials stored in "
                "Oneview hypervisor-manger. Skipping vCenter credentials "
                "update process.")
