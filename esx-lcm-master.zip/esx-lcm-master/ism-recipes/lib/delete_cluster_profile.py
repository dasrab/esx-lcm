# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback
import hpOneViewClrm as hpovclrm

from common.oneview_connector import OneviewConnector

from hpOneView.resources import task_monitor as tm
from hpOneView.exceptions import HPOneViewException

from orch.moduleBase import ModuleBase
from orch.moduleBase import with_task
from orch.ism_sdk.activity import Ism_Error


class Delete_Cluster_Profile(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)

    @with_task("HCOE_ISM_DELETE_CLUSTER_PROFILE")
    def execute(self, params):
        self.LOG.debug("Deleting cluster profile initiated")
        ov_host = params.get('_ov_hostname')
        ov_port = params.get('_ov_port')
        auth = params.get('_ov_auth')
        cluster_profile_uri = params.get('_cluster_profile_uri')
        fail_msg = ""
        try:
            connection = OneviewConnector(ov_host, ov_port, auth).connect()
            cluster_profiles = hpovclrm.cluster_profile(connection)
            if not cluster_profile_uri:
                raise Exception(
                    "Cluster profile uri not found in infrastructure systems")
            cluster_profile_body = cluster_profiles.get_cluster_profile_by_uri(
                cluster_profile_uri)
            # get the cluster uri and the list of host uris (to be consumed
            # during ISM inventory deletion)
            cluster_uri = cluster_profile_body['hypervisorClusterUri']
            cluster_name = cluster_profile_body['name']

            host_uri_list = []
            host_name_list = []

            # dictionary which holds the information about deleted hosts uri
            # (and its cluster uri)
            deleted_cluster_host_info = {
                "cluster_name": "",
                "cluster_uri": "",
                "host_uri_list": [],
                "host_name_list": []}
            cluster_profile_uri += "?force=true"

            msg = "Cluster Profile (%s) Deletion " % cluster_name
            fail_msg = msg + "Failed"
            self.LOG.debug(msg + "Started")
            task = cluster_profiles.delete_cluster_profile(
                cluster_profile_uri, blocking=False)

            self.update_task(20, msg + "Started")
            self.LOG.info("Checking OneView task: %s" % task['uri'])

            task_monitor = tm.TaskMonitor(connection)
            task_monitor.get_completed_task(task, timeout=95 * 60)

            self.update_task(90, msg + "Completed")
            self.update_parent_task(70, msg + "Completed")

            deleted_cluster_host_info["cluster_name"] = cluster_name
            deleted_cluster_host_info["cluster_uri"] = cluster_uri
            deleted_cluster_host_info["host_uri_list"] = host_uri_list
            deleted_cluster_host_info["host_name_list"] = host_name_list
            return self.exit_success(deleted_cluster_host_info)

        except HPOneViewException as exe:
            self.update_task(90, fail_msg)
            self.update_parent_task(70, fail_msg)
            self.LOG.error(fail_msg)
            self.LOG.error(traceback.format_exc())
            raise Ism_Error('HCOE_ISM_DELETE_CLUSTER_PROFILE_FAILED',
                            details=fail_msg + '! got (' + str(exe) + ')')
        except Exception as e:
            self.update_task(90, fail_msg)
            self.update_parent_task(70, fail_msg)
            self.LOG.error(fail_msg)
            return self.exit_fail(str(e))
