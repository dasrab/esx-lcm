# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import atexit
import ssl
import time

from orch import log

from pyVim.connect import SmartConnect, Disconnect
from pyVim import task
from pyVmomi import vim

from requests.packages import urllib3

urllib3.disable_warnings()


class VcenterUtils(object):

    def __init__(self):
        self.LOG = log.getLogger(__name__)

    def get_service_instance(self, vcenter_ip, vcenter_username,
                             vcenter_password, vcenter_port, cert_path=None):
        try:
            if cert_path:
                ssl_context = ssl.SSLContext(ssl.CERT_REQUIRED)
            else:
                ssl_context = ssl._create_unverified_context()

            retries = 5
            retry_interval_sec = 10
            for i in range(0, retries):
                try:
                    si = \
                        SmartConnect(host=vcenter_ip,
                                     user=vcenter_username,
                                     pwd=vcenter_password,
                                     port=int(vcenter_port),
                                     sslContext=ssl_context,
                                    certFile=cert_path)
                    atexit.register(Disconnect, si)
                    self.LOG.info("Successfully connected to vCenter Server '{}'"
                                  .format(vcenter_ip))
                    return si

                except ssl.SSLEOFError as sslError:
                    # if we are here then we are certain that there is
                    # SSL error. So, we will retry immediately as putting
                    # a delay is not going to solve anything. It is just
                    # to get rid of startup error.
                    if i == retries - 1:
                        self.LOG.error("Error connecting to vCenter due to SSL "
                                       "error, error details: %s" % str(sslError))
                        raise sslError
                    else:
                        self.LOG.warning("Could not connect vCenter due to "
                                         "SSL error, reconnecting again... : "
                                         "%s" % str(sslError))

                except vim.fault.HostConnectFault as hostConnectFault:
                    # if we are here then we are NOT sure what is
                    # root cause of not being able to connect to host.
                    # It can be because of SSL as well. So, we will try
                    # without sleep if it is because of SSL else we
                    # will pause for delay and then try...who know there
                    # is intermittent connection issue...so delay will
                    # help here.
                    if i == retries - 1:
                        self.LOG.error("Error connecting to vCenter "
                                       "due to SSL error, error "
                                       "details: %s" % str(hostConnectFault))
                        raise hostConnectFault
                    else:
                        self.LOG.warning("Could not connect vCenter host "
                                         "reconnecting again... : "
                                         "%s" % str(hostConnectFault))
                        ssl_error_msg = "EOF occurred in violation of protocol"
                        if not ssl_error_msg in hostConnectFault.msg:
                            # want to take some rest and then retry because
                            # it does not seem to be because of SSL, may
                            # be intermittent connection issue.
                            time.sleep(retry_interval_sec)

        except Exception as e:
            self.LOG.exception("Unable to connect to {}".format(vcenter_ip))
            raise e

    def get_obj(self, content, vimtype, name, folder=None):
        obj = None
        if not folder:
            folder = content.rootFolder
        container = content.viewManager.CreateContainerView(
            folder, vimtype, True)
        for view in container.view:
            if view.name == name:
                obj = view
                break
        return obj

    def reconfigure_vm(self, si, vm, spec):
        try:
            r_task = vm.ReconfigVM_Task(spec)
            task.WaitForTask(r_task, si)
            self.LOG.info("Successfully reconfigured VM '{}'".format(vm.name))
        except Exception as e:
            self.LOG.exception("Exception occurred while reconfiguring VM '{}'"
                               " with the spec '{}'".format(vm.name, spec))
            raise e

    def create_datacenter(self, content, dc_name):
        content.rootFolder.CreateDatacenter(dc_name)

    def enter_maintenance_mode(self, si, host_obj):
        try:
            in_maintenance = host_obj.summary.runtime.inMaintenanceMode
            if (host_obj.summary.runtime.powerState == "poweredOn" and
                not in_maintenance):
                m_task = host_obj.EnterMaintenanceMode_Task(
                    timeout=300, evacuatePoweredOffVms=False)
                task.WaitForTask(m_task, si)
        except Exception as e:
            self.LOG.exception("Exception occurred while putting host into"
                               " maintenance mode '{}'".format(host_obj.name))

    def delete_datacenter(self, si, dc_obj):
        try:
            dc_obj.Destroy()
            self.LOG.info("Successfully deleted Datacenter '{}'".format(dc_obj.name))
        except Exception as e:
            self.LOG.exception("Exception occurred while deleting Datacenter '{}'"
                               .format(dc_obj.name))
            raise e
        return True

    def delete_dvs(self, si, dvs):
        dvs_name = dvs.name
        try:
            if dvs.summary.vm:
                self.LOG.warn(
                    "Cannot delete DVS '{}' because there are some VM's "
                    "connected with it !".format(dvs_name))
                return
            dvs_destroy_task = dvs.Destroy_Task()
            task.WaitForTask(dvs_destroy_task, si)
            self.LOG.info("Successfully deleted DVS '{}'".format(dvs_name))
        except Exception as e:
            self.LOG.exception("Exception occurred while deleting DVS '{}'"
                               .format(dvs_name))
            raise e

    def find_cluster_by_datacenter(self, datacenter, cluster_name):
        '''
        Find particular cluster in a given datacenter
        @param datacenter: Existing datacenter object
        @param cluster_name: Name of a cluster
        @return: cluster_obj
        '''
        try:
            host_folder = datacenter.hostFolder
            for folder in host_folder.childEntity:
                if folder.name == cluster_name:
                    self.LOG.debug(
                        "{} cluster available in {} datacenter".format(
                            cluster_name, datacenter.name))
                    return folder
        except Exception as e:
            self.LOG.exception(
                "Exception occurred in find_cluster_by_datacenter() +\
                while trying to find %s cluster" % cluster_name)
            raise e

    def get_cluster_by_datacenter(
            self,
            service_instance,
            datacenter_name,
            cluster_name):
        '''
        Get particular cluster object using the datacenter
        @param service_instance : vCenter service instance obj
        @param datacenter_name : Name of a datacenter

        @return: particular cluster obj

        '''
        dc = None
        try:
            dc = self.get_obj(service_instance.content, [
                              vim.Datacenter], datacenter_name)
            if dc is not None:
                cluster = self.find_cluster_by_datacenter(dc, cluster_name)
                return cluster
        except Exception as e:
            self.LOG.exception(
                "Exception occurred in get_cluster_by_datacenter() +\
                while trying to get %s cluster details from %s datacenter" % (cluster_name, datacenter_name))
            raise e
