# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import hpOneView
import ssl
import time
import http.client
import json

from orch import log


ONEVIEW_API_VERSION=500

def singleton(class_):
    instances = {}
    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]
    return getinstance


class OVPersistentCon(hpOneView.connection):

    def __init__(self, applianceIp, api_version=300):
        self.persistentCon = None
        self.LOG = log.getLogger(__name__)
        super(OVPersistentCon, self).__init__(applianceIp, api_version)

    def get_connection(self):
        if not self.persistentCon:
            self.persistentCon = super(OVPersistentCon, self).get_connection()
        return self.persistentCon

    def _overriden_do_http(self, method, path, body, custom_headers=None):
        http_headers = self._headers.copy()
        if custom_headers:
            http_headers.update(custom_headers)

        bConnected = False
        conn = None
        while bConnected is False:
            try:
                conn = self.get_connection()
                conn.request(method, path, body, http_headers)
                resp = conn.getresponse()
                tempbytes = ''
                try:
                    tempbytes = resp.read()
                    tempbody = tempbytes.decode('utf-8')
                except UnicodeDecodeError:  # Might be binary data
                    tempbody = tempbytes
                    conn.close()
                    bConnected = True
                    return resp, tempbody
                if tempbody:
                    try:
                        body = json.loads(tempbody)
                    except ValueError:
                        body = tempbody
                bConnected = True
            except http.client.BadStatusLine:
                self.LOG.warning('Bad Status Line. Trying again...')
                if conn:
                    conn.close()
                time.sleep(1)
                continue
        return resp, body

    def do_http(self, method, path, body, custom_headers=None):
        custom_headers = {"Connection": "keep-alive"}
        retries = 5
        for i in range(0,retries):
            try:
                return self._overriden_do_http(method, path, body, custom_headers)
            except ssl.SSLEOFError as e:
                self.LOG.debug("An error occured: %s" % str(e))
                self.LOG.warning("Reinitializing the connection")
                self.persistentCon = None
                time.sleep(1)

@singleton
class OneviewConnector(object):

    def __init__(self, host, port, session_id=None):
        self.oneview_host = host + ":" + str(port)
        self.oneview_session_id = session_id
        self.conn = None

    def connect(self):
        if not self.conn:
            self.conn = OVPersistentCon(self.oneview_host, ONEVIEW_API_VERSION)
            self.conn.set_session_id(self.oneview_session_id)
        return self.conn
