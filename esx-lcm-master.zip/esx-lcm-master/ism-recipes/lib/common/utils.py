# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import json
import requests
import constants

from jinja2 import Environment, FileSystemLoader

template_env = Environment(autoescape=False,
                           loader=FileSystemLoader(constants.TEMPLATES_PATH),
                           trim_blocks=False)


class ApplianceManagerProxy(object):

    def __init__(self, params):
        self.appliance_ip = params['appliance_ip']
        self.appliance_port = params['appliance_port']
        self.headers = {"Content-Type": "application/json"}
        self.base_url = "http://{}:{}".format(self.appliance_ip,
                                              self.appliance_port)

    def create_serverblueprint(self, data):
        """
        Execute the REST call to Create ServerBlueprint.

        Args:
            data: serverblueprint model
        """
        relative_url = constants.SERVERBLUEPRINT_URL
        url = self.base_url + relative_url
        body_json = json.JSONEncoder().encode(data)
        response = requests.post(url, headers=self.headers, data=body_json)
        if response.status_code not in (200, 201, 202):
            raise response.raise_for_status()
        serverblueprint = response.json()
        return serverblueprint

    def get_serverblueprints(self):
        """
        Execute the REST call to Get ServerBlueprints.

        """
        relative_url = constants.SERVERBLUEPRINT_URL
        url = self.base_url + relative_url
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        serverblueprints = response.json()
        return serverblueprints

    def get_serverblueprint_by_uri(self, sbp_uri):
        """
        Execute the REST call to Get ServerBlueprint by uri.

        """
        url = self.base_url + sbp_uri
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        serverblueprint = response.json()
        return serverblueprint

    def delete_serverblueprint_by_uri(self, sbp_uri):
        """
        Execute the REST call to Delete ServerBlueprint by uri.

        """
        url = self.base_url + sbp_uri
        response = requests.delete(url + '?force=true', headers=self.headers)
        if response.status_code not in (200, 202, 204):
            raise response.raise_for_status()
        return "Success"

    def get_server_by_uri(self, server_uri):
        """
        Execute the REST call to Get Server by uri.

        """
        relative_url = (server_uri + '?view=oneview')
        url = self.base_url + relative_url
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        server = response.json()
        return server

    def get_servers(self):
        """
        Execute the REST call to get all servers.

        """
        relative_url = (constants.SERVERS_URL + '?view=oneview')
        url = self.base_url + relative_url
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        server = response.json()
        return server

    def allocate_server(self, data):
        """
        Execute the REST call to Allocate Server for the given
        ServerBlueprint in the server model.

        Args:
            data: server model
        """
        relative_url = constants.SERVERS_URL
        url = self.base_url + relative_url + '?view=oneview'
        body_json = json.JSONEncoder().encode(data)
        response = requests.post(url, headers=self.headers, data=body_json)
        if response.status_code not in (200, 201, 202):
            raise response.raise_for_status()
        server = response.json()
        return server

    def deallocate_server(self, relative_url):
        """
        Execute the REST call to Deallocate Server.

        Args:
            relative_url: server_uri
        """
        url = self.base_url + relative_url
        response = requests.delete(url, headers=self.headers)
        if response.status_code not in (200, 202, 204):
            raise response.raise_for_status()
        return "Success"

    def register_applianceimage(self, data):
        """
        Execute the REST call to Register ApplianceImage.

        Args:
            data: ApplianceImage model
        """
        relative_url = constants.APPLIANCEIMAGE_URL
        url = self.base_url + relative_url
        body_json = json.JSONEncoder().encode(data)
        response = requests.post(url, headers=self.headers, data=body_json)
        if response.status_code not in (200, 201, 202):
            raise response.raise_for_status()
        appliance_image = response.json()
        return appliance_image

    def get_applianceimages(self):
        """
        Execute the REST call to Get ApplianceImages.

        """
        relative_url = constants.APPLIANCEIMAGE_URL
        url = self.base_url + relative_url
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        appliance_images = response.json()
        return appliance_images

    def get_applianceimage_by_uri(self, relative_url):
        """
        Execute the REST call to Get ApplianceImage by URI.

        """
        url = self.base_url + relative_url
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202):
            raise response.raise_for_status()
        appliance_image = response.json()
        return appliance_image

    def unregister_applianceimage(self, relative_url):
        """
        Execute the REST call to Unregister ApplianceImage.

        Args:
            relative_url: applianceimage_uri
        """
        url = self.base_url + relative_url
        response = requests.delete(url, headers=self.headers)
        if response.status_code not in (200, 202, 204):
            raise response.raise_for_status()
        return "Success"

    def get_l2networks(self, relative_url):
        """
        Execute the rest call to fetch l2 networks.

        Args:
            relative_url: appliance_uri

        Example:
            input: /rest/appliance/{UUID}
            output: list of ethernet networks
        """
        url = self.base_url + relative_url + '/ethernet-networks'
        response = requests.get(url, headers=self.headers)
        if response.status_code not in (200, 202, 204):
            raise response.raise_for_status()
        return  response.json()

class DiskModelRenderer(object):

    def __init__(self, disk_profile):
        self.disk_profile = disk_profile

    def _validate_and_fetch_disk_size(self, disk_size):
        try:
            ext_disk_size = int(disk_size)
            int_disk_size = int(disk_size * 0.9)
            return ext_disk_size, int_disk_size
        except BaseException:
            raise Exception("Invalid disk size")

    def _validate_and_fetch_disk_type(self, drive_type):
        drive_types = {
            "bigbird:sas:hdd": "SasHdd",
            "bigbird:sata:hdd": "SataHdd",
            "bigbird:sas:ssd": "SasSsd",
            "bigbird:sata:ssd": "SataSsd",
            "local:sas:hdd": "SasHdd",
            "local:sata:hdd": "SataHdd",
            "local:sas:ssd": "SasSsd",
            "local:sata:ssd": "SataSsd"
        }
        try:
            return drive_types[drive_type.lower()]
        except BaseException:
            raise Exception("Invalid drive type")

    def _create_disk_model_context(self):
        context = {}
        bigbird_disk_count = 0
        local_disk_count = 0
        server_type = self.disk_profile["server_type"].split(' ')
        if 'Gen9' == server_type[2]:
            context['disk_mode'] = 'RAID'
        elif 'Gen10' == server_type[2]:
            context['disk_mode'] = 'Mixed'
        else:
            raise Exception("Invalid server type: '{}'. Please provide a "
                            "valid server type.".format(self.disk_profile["server_type"]))

        # Fetch and validate server_sub_type either standard or premium or diskless
        server_sub_type = self.disk_profile["server_sub_type"].lower()
        if server_sub_type == "expanded":
            context['server_type'] = 'pre'
        elif server_sub_type == "standard":
            context['server_type'] = 'std'
        elif server_sub_type == "diskless":
            context['server_type'] = 'std'
        else:
            raise Exception("Invalid server sub type: '{}'. Please provide a "
                            "valid server sub type.".format(self.disk_profile["server_type"]))

        # Fetch capacity drive count
        context['capacity_drive_count'] = self.disk_profile["host_disks"]["capacity_drive_count"]
        if self.disk_profile["host_disks"]["capacity_drive_type"].split(':')[0].lower() == 'bigbird':
            bigbird_disk_count += self.disk_profile["host_disks"]["capacity_drive_count"]
        elif self.disk_profile["host_disks"]["capacity_drive_type"].split(':')[0].lower() == 'local':
            local_disk_count += self.disk_profile["host_disks"]["capacity_drive_count"]

        # Fetch cache drive count
        context['cache_drive_count'] = self.disk_profile["host_disks"]["cache_drive_count"]
        if self.disk_profile["host_disks"]["cache_drive_type"].split(':')[0].lower() == 'bigbird':
            bigbird_disk_count += self.disk_profile["host_disks"]["cache_drive_count"]
        elif self.disk_profile["host_disks"]["cache_drive_type"].split(':')[0].lower() == 'local':
            local_disk_count += self.disk_profile["host_disks"]["cache_drive_count"]

        # Get the sizes of capacity drive type
        capacity_max_size, capacity_min_size = (
            self._validate_and_fetch_disk_size(
                self.disk_profile["host_disks"]['capacity_drive_size_gb']))
        # Get the sizes of cache drive type
        cache_max_size, cache_min_size = (
            self._validate_and_fetch_disk_size(
                self.disk_profile["host_disks"]['cache_drive_size_gb']))

        context['bigbird_disk_count'] = bigbird_disk_count
        if server_sub_type != "diskless":
            context['local_disk_count'] = local_disk_count
        else:
            context['local_disk_count'] = 0
        context['capacity_max_size'] = capacity_max_size
        context['capacity_min_size'] = capacity_min_size
        context['cache_max_size'] = cache_max_size
        context['cache_min_size'] = cache_min_size
        context['capacity_drive_type'] = self.disk_profile["host_disks"]["capacity_drive_type"].split(':')[0]
        context['cache_drive_type'] = self.disk_profile["host_disks"]["cache_drive_type"].split(':')[0]

        context['cache_drive_technology'] = self._validate_and_fetch_disk_type(
            self.disk_profile["host_disks"]["cache_drive_type"])
        context['capacity_drive_technology'] = self._validate_and_fetch_disk_type(
            self.disk_profile["host_disks"]["capacity_drive_type"])
        return context

    def render_diskmodel_template(self):
        j2_data = template_env.get_template(
            constants.DISK_MODEL_FILENAME).render(
            self._create_disk_model_context())
        return json.loads(j2_data)


class SPTModelRenderer(object):

    def _create_gen_version_context(self, server_hardware_type):
        context = {}
        context['server_hardware_type'] = server_hardware_type
        return context

    def render_sptmodel_template(self, model_filename, server_hardware_type):
        j2_data = template_env.get_template(
            model_filename).render(
            self._create_gen_version_context(server_hardware_type))
        return json.loads(j2_data)


class NetworkModelRenderer(object):

    def __init__(self, network_map):
        self.netmap = network_map

    def _create_networkmap_context(self):
        context = {}
        context['mgmt_net'] = self.netmap['esxManagementNetwork']
        context['vmotion_net'] = self.netmap['vMotionNetwork']
        context['storage_net'] = self.netmap['storageNetwork']
        context['guest_net'] = self.netmap['productionNetworks']
        context['ncs_mgmt'] = self.netmap['ncsManagementNetwork']
        return context

    def render_networkmodel_template(self):
        j2_data = template_env.get_template(
            constants.NETWORKMAP_FILENAME).render(
            self._create_networkmap_context())
        return json.loads(j2_data)


def read_json(filename):
    try:
        with open(filename) as data_file:
            return json.load(data_file)
    except ValueError:
        raise ValueError("Invalid Json Passed")

class SwitchLayoutRenderer(object):

    def __init__(self, l2networks, sbp, netmap):
        self.l2networks = l2networks
        self.sbp = sbp
        self.netmap = netmap

    def _get_ethernet_network(self):
        l2network_dict = {}
        eth_nets = {}
        # Prepare a dictionary of ethernet networks containing the name, uri, purpose and vlanid
        # Filter to fetch only the networks which are avaialable in serverblueprint
        for network in self.l2networks:
            l2network_dict[network['name']] = network

        for net, net_list in self.netmap.iteritems():
            for net_name in net_list:
                ethernet_uri = '/rest/'+ "/".join(l2network_dict[net_name]['uri'].split('/')[-2:])
                eth_nets[net] = {'ethernet_name':net_name, 'uri':ethernet_uri,
                                 'purpose':l2network_dict[net_name]['purpose'],
                                 'vlanId':l2network_dict[net_name]['vlanId'],
                                 'ethernetNetworkType':l2network_dict[net_name]['ethernetNetworkType']}

        # Check if NCS Management network and ESX Management network are same.
        # If same set the VLAN for both to 0.
        if eth_nets['esxManagementNetwork'] == eth_nets['ncsManagementNetwork']:
            eth_nets['ncsManagementNetwork']['ethernetNetworkType'] = 'Untagged'
        # Set VLAN to 0 for ESX management network as it will be configured as
        # native network.
        eth_nets['esxManagementNetwork']['ethernetNetworkType'] = 'Untagged'
        return eth_nets

    def _get_portId_from_sbp(self, switch_layout):
        blueprintConnections = \
            self.sbp['serverProfileTemplateBlueprint']['blueprint']['connectionSettings']['connections']
        # Fetch the portId for the network-sets from serverblueprint
        for index, value in enumerate(switch_layout):
            portId = []
            for connection in blueprintConnections:
                if "_".join(connection['networkUri']['$ref'].split('/')[-2].split('.')) in value['name']:
                    portId.append(connection['portId'])
            switch_layout[index]['portId'] = portId
        return switch_layout

    def _create_ethernetwork_and_networkset_map(self):
        switch_layout = []
        eth_nets = self._get_ethernet_network()
        blueprintsNetworkSet = self.sbp['networkSetBlueprints']
        # Fetch the network-set uri from sbp and create a switch layout.
        # Ethernet networks dictionary prepared in the previous step will be added
        # as input here.
        for bpNet in blueprintsNetworkSet:
            if bpNet['name'] == 'ESX.Management':
                switch_layout.append({'name':"_".join(bpNet['name'].split(".")),
                                      'uri':bpNet['nsUri'][0],
                                      'networks':[eth_nets['esxManagementNetwork'],
                                          eth_nets['vMotionNetwork'],
                                          eth_nets['ncsManagementNetwork']]})
            elif bpNet['name'] == 'ESX.Storage':
                switch_layout.append({'name':"_".join(bpNet['name'].split(".")),
                                      'uri':bpNet['nsUri'][0],
                                      'networks':[eth_nets['storageNetwork']]})
            elif bpNet['name'] == 'ESX.Data':
                switch_layout.append({'name':"_".join(bpNet['name'].split(".")),
                                      'uri':bpNet['nsUri'][0],
                                      'networks':[eth_nets['productionNetworks']]})
        switch_layout = self._get_portId_from_sbp(switch_layout)
        return switch_layout

    def _create_swicthLayout_context(self, network_map):
        context = {}
        for netset in  network_map:
            context[netset['name']+'_uri'] = netset['uri']
            context[netset['name']+'_portId'] = netset['portId']
            if netset['name'] != 'ESX_Data':
                # Avoid duplicate entries
                context[netset['name']+'_networks'] = [
                    dict(t) for t in set([tuple(d.items()) for d in netset['networks']])]
        return context

    def render_switchLayout_template(self):
        network_map = self._create_ethernetwork_and_networkset_map()
        j2_data = template_env.get_template(
            constants.SWITCHLAYOUT_FILENAME).render(
            self._create_swicthLayout_context(network_map))
        return json.loads(j2_data)
