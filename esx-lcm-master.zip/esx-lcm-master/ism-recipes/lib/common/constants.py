# (C) Copyright 2016-2018 Hewlett Packard Enterprise Development LP

TEMPLATES_PATH = "../ism-recipes/templates"
DISK_MODEL_FILENAME = "disk_model.j2"
NETWORKMAP_FILENAME = "networkmap_model.j2"
SWITCHLAYOUT_FILENAME = "switchlayout_model.j2"

# Appman urls
SERVERBLUEPRINT_URL = "/rest/serverblueprints"
SERVERS_URL = "/rest/servers"
APPLIANCEIMAGE_URL = "/rest/applianceimages"

# HTTP Methods
HTTP_GET = 'GET'
HTTP_POST = 'POST'
HTTP_PUT = 'PUT'
HTTP_DELETE = 'DELETE'

# HPE Gateway
MAX_WAIT_TIME_FOR_OK_STATE = 1800  # 30 mins
SLEEP_TIME_TO_GET_OK_STATE = 60  # 1 min
SLEEP_TIME_TO_GET_CONVERGING_STATE = .2  # 200 milliseconds
HOST_AGENT_RETRY_COUNT = 10
TASK_WAIT_DELAY = 5

# States
RUNNING = 'Running'
ENABLED = 'Enabled'
ENABLING = 'Enabling'
DISABLED = 'Disabled'
DISABLING = 'Disabling'
CRITICAL = 'Critical'
OK = 'OK'
HOST_AGENT_ROLE_STATUS_OK = 'ok'
HOST_AGENT_ROLE_STATUS_CONVERGING = 'converging'
HOST_AGENT_ROLE_STATUS_FAILED = 'failed'

KVM_HYPERVISOR = 'kvm'
V1_HOSTS_PATH = '/v1/hosts/'
ROLE_PATH = 'roles'
V1_PATH = '/v1/'
NEUTRON_SERVER_SERVICE = "services/neutron-server"
PHYSNET_KEY = "physnet"
EXTERNAL_PHYSNET = "external"
DHCP_AGENTS_PER_NETWORK = 2
KVM_VOLUME_TYPE = 'lvm'

# InfrastructureSystems attributes
INFRA_SYS_NAME = 'name'
INFRA_SYS_ID = 'id'
INFRA_SYS_STATE = 'state'
INFRA_SYS_DS = 'datastores'
INFRA_SYS_MANAGED = 'managed'
INFRA_SYS_ZONE_URI = 'associatedZoneURI'

# Roles
CINDER_VOLUME_BASE_ROLE = 'pf9-cindervolume-base'
OSTACK_HOST_NEUTRON_ROLE = 'pf9-ostackhost-neutron'
NEUTRON_BASE_ROLE = 'pf9-neutron-base'
GLANCE_ROLE = 'pf9-glance-role'
CEILOMETER_ROLE = 'pf9-ceilometer'
CINDER_VOLUME_CEPH_ROLE = 'pf9-cindervolume-ceph'
CINDER_VOLUME_LVM_ROLE = 'pf9-cindervolume-lvm'
NEUTRON_OVS_AGENT_ROLE = 'pf9-neutron-ovs-agent'
NEUTRON_L3_AGENT_ROLE = 'pf9-neutron-l3-agent'
NEUTRON_METDATA_AGENT_ROLE = 'pf9-neutron-metadata-agent'
NEUTRON_DHCP_AGENT_ROLE = 'pf9-neutron-dhcp-agent'

PRIMARY_KVM_ROLES = [
    OSTACK_HOST_NEUTRON_ROLE,
    NEUTRON_BASE_ROLE,
    NEUTRON_OVS_AGENT_ROLE,
    NEUTRON_L3_AGENT_ROLE,
    NEUTRON_METDATA_AGENT_ROLE,
    NEUTRON_DHCP_AGENT_ROLE
]

# Constants feed from REST body to enable secondary roles !
IMAGE_LIBRARY = 'ImageLibrary'
BLOCK_STORAGE = 'BlockStorage'  # Default BlockStorage role is 'CEPH'
BLOCK_STORAGE_LVM = 'BlockStorage-lvm'

# Secondary KVM Roles. Will be applied on selected servers.
SECONDARY_KVM_ROLES = dict()
SECONDARY_KVM_ROLES[IMAGE_LIBRARY] = [GLANCE_ROLE]
SECONDARY_KVM_ROLES[BLOCK_STORAGE] = [
    CINDER_VOLUME_BASE_ROLE,
    CINDER_VOLUME_CEPH_ROLE
]
SECONDARY_KVM_ROLES[BLOCK_STORAGE_LVM] = [
    CINDER_VOLUME_BASE_ROLE,
    CINDER_VOLUME_LVM_ROLE
]

# HPE GATEWAY constants to configure roles
CINDER_USER = 'cinder'
STORAGE_VOLUME_NAME = 'onesphere-volume'
STORAGE_POOL_NAME = 'onesphere-vm-pool'
FLATTEN_VOLUME_FROM_SNAPSHOT = 'true'
ENABLE_PUBLIC_GLANCE_ENDPOINT = 'true'
NO_VNC_PROXY_URL = 'http://{}:6080/vnc_auto.html'
BRIDGE_NAME_PREFIX = "br-"
L3_AGENT_MODE = "dvr_snat"
ALLOW_DHCP_VMS = "true"
ENABLE_DISTRIBUTED_ROUTING = "true"
GATEWAY_INSTANCE_PATH = '/opt/hpe/data/instances'
GATEWAY_IMAGE_LIB_PATH = '/var/opt/hpe/imagelibrary/data'
DB_CONFLICT_EXCEPTION = '409 Client Error'

# Common between hpOneView-ncs
SEC_1 = 1
SEC_30 = 30
MIN_1 = 60
MIN_3 = 3 * MIN_1
MIN_10 = 10 * MIN_1
MIN_20 = 20 * MIN_1
MIN_11 = 11 * MIN_1
MIN_15 = 15 * MIN_1
MIN_30 = 30 * MIN_1
MIN_35 = 35 * MIN_1
MIN_150 = 150 * MIN_1

HOUR_1 = 60 * MIN_1
HOUR_2 = 2 * HOUR_1
HOUR_3 = 3 * HOUR_1
HOUR_24 = 24 * HOUR_1

INFINITE = 100**100

# VMWare Neutron constansta
NEUTRON_SERVER_URI = "/resmgr/v1/services/neutron-server"
SEC_TUNNEL_URI = "/tunman/v1/sectunnel"
RETRY_COUNT = 3
TUNNEL_PROXY_PORT = 8030
DVS_PLUGIN = "vmware_nsx.plugins.dvs.pf9_plugin.Pf9NsxDvsV2"
VCENTER_PORT = 443
