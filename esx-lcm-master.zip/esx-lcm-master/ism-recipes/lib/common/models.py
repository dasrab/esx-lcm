# (C) Copyright 2017 Hewlett Packard Enterprise Development LP

SERVERBLUEPRINT_KEYS = [
    'name',
    'uri',
    'state']

SERVER_KEYS = [
    'name',
    'uri',
    'serverProfileTemplateUri',
    'serverHardwareUri',
    'serverBlueprintUri',
    'state']

IMAGE_KEYS = [
    'name',
    'imageUrl',
    'applianceUri',
    'uri',
    'state']


class ServerBlueprint(object):

    def __init__(self, args):
        missing_keys = []
        for key in SERVERBLUEPRINT_KEYS:
            if args.get(key) is None:
                missing_keys.append(key)
            else:
                setattr(self, key, args.get(key))
        if len(missing_keys) != 0:
            raise KeyError("The Required keys {} are not present".format(
                missing_keys))
        self.result = args

    def _get_serverblueprint_uri(self):
        serverblueprint_uri = self.result.get('uri')
        return serverblueprint_uri

    def _get_serverblueprint_name(self):
        serverblueprint_name = self.result.get('name')
        return serverblueprint_name

    def serialize(self):
        clean_serverblueprint = {}
        for key in SERVERBLUEPRINT_KEYS:
            clean_serverblueprint[key] = self.result.get(key)
        return clean_serverblueprint


class Server(object):

    def __init__(self, args):
        missing_keys = []
        for key in SERVER_KEYS:
            if args.get(key) is None:
                missing_keys.append(key)
            else:
                setattr(self, key, args.get(key))
        if len(missing_keys) != 0:
            raise KeyError("The Required keys {} are not present".format(
                missing_keys))
        self.result = args

    def _get_server_uri(self):
        server_uri = self.result.get('uri')
        return server_uri

    def _get_spt_uri(self):
        spt_uri = self.result.get('serverProfileTemplateUri')
        return spt_uri

    def _get_sbp_uri(self):
        sbp_uri = self.result.get('serverBlueprintUri')
        return sbp_uri

    def _get_serverhardware_uri(self):
        serverhardware_uri = self.result.get('serverHardwareUri')
        return serverhardware_uri

    def _get_server_name(self):
        server_name = self.result.get('name')
        return server_name

    def _get_server_state(self):
        server_state = self.result.get('state')
        return server_state

    def serialize(self):
        clean_server = {}
        for key in SERVER_KEYS:
            clean_server[key] = self.result.get(key)
        return clean_server


class ApplianceImage(object):

    def __init__(self, args):
        missing_keys = []
        for key in IMAGE_KEYS:
            if args.get(key) is None:
                missing_keys.append(key)
            else:
                setattr(self, key, args.get(key))
        if len(missing_keys) != 0:
            raise KeyError("The Required keys {} are not present".format(
                missing_keys))
        self.result = args

    def _get_uri(self):
        applianceimage_uri = self.result.get('uri')
        return applianceimage_uri

    def _get_applianceimage_name(self):
        applianceimage_name = self.result.get('name')
        return applianceimage_name

    def _get_applianceimage_state(self):
        applianceimage_state = self.result.get('state')
        return applianceimage_state

    def serialize(self):
        clean_applianceimage = {}
        for key in IMAGE_KEYS:
            clean_applianceimage[key] = self.result.get(key)
        return clean_applianceimage
