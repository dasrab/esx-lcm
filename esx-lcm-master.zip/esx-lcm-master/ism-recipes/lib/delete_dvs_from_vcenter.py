# (C) Copyright 2017-2018 Hewlett Packard Enterprise Development LP

import traceback

from pyVmomi import vim

from orch.moduleBase import ModuleBase
from common.vcenter_utils import VcenterUtils

CLRM_DVS_SUFFIX = '__VDS'


class Delete_Dvs_From_Vcenter(ModuleBase):

    def __init__(self):
        ModuleBase.__init__(self)
        self._vc_utils = VcenterUtils()

    def execute(self, params):
        self.LOG.debug("Deletion of DVS initiated...")
        network_sets = params['blueprint'].get('networkSetBlueprints')
        dvs_names = [''.join([ns.get('uname'), CLRM_DVS_SUFFIX])
                     for ns in network_sets]
        self.LOG.info("DVS Names: {}".format(dvs_names))
        if not dvs_names:
            self.LOG.info(
                "Couldn't find any Network Sets to form DVS names from "
                "Blueprint uri '{}'".format(params['blueprint']['uri']))
            return self.exit_success("There is no DVS to delete !")

        try:
            si = self._vc_utils.get_service_instance(
                params['vc_host'], params['vc_username'],
                params['vc_password'], params['vc_port'])
            dc = self._vc_utils.get_obj(
                si.content, [vim.Datacenter], params['datacenter_name'])
            if not dc:
                raise Exception("Couldn't find the Datacenter '{}'"
                                .format(params['datacenter_name']))

            for dvs_name in dvs_names:
                dvs = self._vc_utils.get_obj(
                    si.content, [vim.DistributedVirtualSwitch],
                    dvs_name, dc.networkFolder)
                if not dvs:
                    self.LOG.error(
                        "couldn't find the DVS '{}'".format(dvs_name))
                    continue

                self._vc_utils.delete_dvs(si, dvs)

            return self.exit_success(True)

        except Exception as e:
            self.LOG.warn('Failed to delete DVS in Datacenter. ' + str(params['datacenter_name']))
            self.LOG.warn(traceback.format_exc())
            return self.exit_success(str(e))
