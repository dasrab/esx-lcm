# (C) Copyright 2016-2017 Hewlett Packard Enterprise Development LP

import re
import json
from orch import log
from enum import Enum

LOG = log.getLogger(__name__)


class HeaderKeyword(Enum):
    SUCCESS = 'success'
    SUCCEEDED = 'succeeded'
    FAILED = 'failed'
    FAIL = 'fail'


VAR_REGEXP = '\{\{.*?\}\}'
HEADER_SUCCESS_KEYWORDS = [HeaderKeyword.SUCCESS, HeaderKeyword.SUCCEEDED]
HEADER_FAILURE_KEYWORDS = [HeaderKeyword.FAILED, HeaderKeyword.FAIL]


def parse_vars(object_to_parse, var_map):
    # copy object so we don't modify the original one
    parsed_object = object_to_parse.copy()
    if isinstance(parsed_object, dict):
        for key, value in parsed_object.iteritems():
            # validate if key variable is not using forbidden characters
            if not re.match(r'^[a-zA-Z0-9_]*$', key):
                raise TypeError(
                    "Variable '" +
                    key +
                    "' cannot use any special characters other then underscore.")

            if isinstance(value, basestring):
                value = parse_var(value, var_map)
                parsed_object[key] = value
            else:
                parsed_object[key] = value
    else:
        raise Exception(
            "Object can't be parsed by engine because it's not a dictionary")
    return parsed_object


def eval_expression(
        expression,
        var_map,
        using_brackets=False,
        enable_headers=False):
    if isinstance(expression, list):
        return expression

    expression = expression.strip()

    expression = expression.replace('(', '')
    expression = expression.replace(')', '')

    # if there are any operators left
    if ' or ' in expression or ' and ' in expression:
        or_position = expression.find(' or ')
        and_position = expression.find(' and ')

        # if operator AND was found and is the first one
        if (and_position < or_position and and_position != -1) or or_position == -1:
            return eval_operation(
                'and',
                expression,
                var_map,
                special_operator_position=and_position +
                1)
        else:
            return eval_operation(
                'or',
                expression,
                var_map,
                special_operator_position=or_position +
                1)
    elif '==' in expression:
        return eval_operation('==', expression, var_map)
    elif '!=' in expression:
        return eval_operation('!=', expression, var_map)
    elif '>' in expression:
        return eval_operation('>', expression, var_map)
    elif '<' in expression:
        return eval_operation('<', expression, var_map)
    elif '>=' in expression:
        return eval_operation('>=', expression, var_map)
    elif '<=' in expression:
        return eval_operation('<=', expression, var_map)
    elif '+' in expression:
        return eval_operation('+', expression, var_map)
    elif '*' in expression:
        return eval_operation('*', expression, var_map)
    elif '/' in expression:
        return eval_operation('/', expression, var_map)
    elif 'not ' in expression:
        not_position = expression.find('not ')
        rhs = expression[not_position + len('not') + 1:]
        return not eval_expression(rhs, var_map)
    elif "|length" in expression:
        length_position = expression.find('|length')
        variable = expression[:length_position]

        # get value of variable
        variable_value = eval_expression(variable, var_map)
        return len(variable_value)
    elif is_accessing_headers(expression):
        header_keyword_position = expression.find('|')
        variable = expression[:header_keyword_position]
        header_keyword = expression[header_keyword_position + 1:]

        # get value of variable
        variable_value = eval_expression(
            variable, var_map, enable_headers=True)

        if 'headers' in variable_value:
            headers = variable_value['headers']

            for header_success_keyword in HEADER_SUCCESS_KEYWORDS:
                if header_keyword == header_success_keyword.value:
                    return headers['module_status'] == 'SUCCESS'

            for header_failure_keyword in HEADER_FAILURE_KEYWORDS:
                if header_keyword == header_failure_keyword.value:
                    return headers['module_status'] == 'FAIL'
                else:
                    # This shouldn't happen. Every check in is_accessing_headers
                    # should have an if clause here
                    return False
        else:
            raise KeyError('Execution failed because variable ' +
                           variable + ' does not have headers field')
    else:
        # if variable is a complex object, get the value as a field of the var
        # map
        if re.match(
                '(.+?)[.](.+?)',
                expression) or re.match(
                    '(.+?)\\[(.+?)\\](.*?)',
                    expression) or expression in var_map or using_brackets:
            return _parse_single_var(
                expression, var_map, enable_headers=enable_headers)
        else:
            return _eval_primitive_value(expression)


def eval_operation(
        bool_operator,
        expression,
        var_map,
        special_operator_position=None):
    if special_operator_position:
        operator_position = special_operator_position
    else:
        operator_position = expression.find(bool_operator)

    operator_skip = len(bool_operator)

    lhs = expression[:operator_position - 1]
    rhs = expression[operator_position + operator_skip + 1:]

    if bool_operator == '==':
        return eval_expression(lhs, var_map) == eval_expression(rhs, var_map)
    if bool_operator == '!=':
        return eval_expression(lhs, var_map) != eval_expression(rhs, var_map)
    if bool_operator == '>':
        return eval_expression(lhs, var_map) > eval_expression(rhs, var_map)
    if bool_operator == '<':
        return eval_expression(lhs, var_map) < eval_expression(rhs, var_map)
    if bool_operator == '>=':
        return eval_expression(lhs, var_map) >= eval_expression(rhs, var_map)
    if bool_operator == '<=':
        return eval_expression(lhs, var_map) <= eval_expression(rhs, var_map)
    if bool_operator == 'and':
        return eval_expression(lhs, var_map) and eval_expression(rhs, var_map)
    if bool_operator == 'or':
        return eval_expression(lhs, var_map) or eval_expression(rhs, var_map)
    if bool_operator == '+':
        return eval_expression(lhs, var_map) + eval_expression(rhs, var_map)
    if bool_operator == '*':
        return eval_expression(lhs, var_map) * eval_expression(rhs, var_map)
    if bool_operator == '/':
        return eval_expression(lhs, var_map) / eval_expression(rhs, var_map)

# parse vars inside brackets from a string and generates a new string with
# the variable values


def parse_var(value, var_map, enable_headers=False):
    if not isinstance(value, basestring):
        return value

    pattern = re.compile(VAR_REGEXP)

    # copy value so we don't modify the original one
    response = value
    matches = pattern.findall(value)
    for match in matches:
        try:
            value_to_parse = match.replace('{{', '')
            value_to_parse = value_to_parse.replace('}}', '')
            parsed_value = eval_expression(
                value_to_parse,
                var_map,
                using_brackets=True,
                enable_headers=enable_headers)
        except AttributeError:
            raise AttributeError(
                "Variable " +
                value +
                " could not be evaluated to a value. Please double-check if all values " +
                "and fields exist")
        # if there's only one exact match which corresponds to the entire
        # variable, then return the parsed value as is
        if match == value:
            response = parsed_value
        # if parsed value is string, then just replace it where match is
        elif isinstance(parsed_value, basestring):
            response = response.replace(match, parsed_value)
        # if it's not a string, then use json.dumps to be able to parse any
        # type
        else:
            response = response.replace(match, json.dumps(parsed_value))
    return response

# evaluates if value is a python primitive such as True, False or None


def _eval_primitive_value(value, enable_headers=False):
    if not isinstance(value, basestring):
        # if enable_headers is true, then return the value with body and
        # headers
        if enable_headers:
            return value

        # if there's a body element in dict, then return body
        if isinstance(value, dict) and 'body' in value:
            return value['body']
        # if value is a list, then extract the body from each item if it has
        # one and is a dict
        if isinstance(value, list):
            extracted_info_list = [item['body'] if isinstance(
                item, dict) and 'body' in item else item for item in value]
            return extracted_info_list
        else:
            return value
    elif value.lower() == 'True'.lower():
        return True
    elif value.lower() == 'False'.lower():
        return False
    elif value.lower() == 'None'.lower():
        return None
    try:
        return int(value)
    except ValueError:
        return value

# parse a single variable which could be in a when statement or with brackets


def _parse_single_var(value, var_map, enable_headers=False):
    value = value.strip()

    # validate if variable is not using forbidden characters
    if not re.match(r'^[a-zA-Z0-9-_"\'[\]()|.{}]*$', value):
        raise Exception("Variable '" + value +
                        "' cannot use special characters like _ or +.")

    # validate if variable is not using both formats at the same time which is
    # invalid
    if re.match(
            '(.+?)[.](.+?)',
            value) and re.match(
                '(.+?)\\[(.+?)\\](.*?)',
                value) and '.content' not in value:
        raise Exception("Variable '" + value +
                        "' cannot use both formats (brackets and dots).")

    # remove reference to from_json library
    if '.content|from_json' in value:
        # remove parenthesis
        value = value.replace('(', '')
        value = value.replace(')', '')

        # remove from_json lib
        value = value.replace('.content|from_json', '')
    # matches variable with dots in between strings
    elif re.match('(.+?)[.](.+?)', value):
        return _eval_primitive_value(
            parse_dotted_var(
                value,
                var_map),
            enable_headers=enable_headers)

    # if it's a json resolution, then first get value from map
    if re.match('(.+?)\\[(.+?)\\](.*?)', value):
        begin_brackets_index = value.find('[', 0)
        var_key = value[:begin_brackets_index]

        json_response = var_map[var_key]
        # init variable object with default value
        variable_object = json_response

        # while there are fields to access
        while re.match('(.*?)\\[(.+?)\\](.*?)', value):
            try:
                variable_object = variable_object['body']
            except (KeyError, TypeError):
                # if it's not a json with body and header, the full json should
                # be parsed.
                pass

            # access via field name : body['field_name']
            if value[begin_brackets_index + 1] == '\'':
                begin_index = value.find("['", 0)
                end_index = value.find("']")
                field = value[begin_index + 2:end_index]

                # if it's not the end of the json resolution
                if end_index + 2 < len(value):
                    value = value[end_index + 2:]
                    variable_object = variable_object.get(field)
                else:
                    return _eval_primitive_value(
                        variable_object.get(field), enable_headers=enable_headers)
            # access via index:  body[2]
            else:
                begin_index = value.find('[', 0)
                end_index = value.find(']')
                index = value[begin_index + 1:end_index]

                # if it's the not end of the json resolution
                if end_index + 1 < len(value):
                    value = value[end_index + 1:]
                    variable_object = variable_object[int(index)]
                else:
                    return _eval_primitive_value(
                        variable_object[int(index)], enable_headers=enable_headers)
            # updates first bracket index
            begin_brackets_index = value.find("[", 0)

    return _eval_primitive_value(var_map[value], enable_headers=enable_headers)

# parse a variable which is using dots to access fields and indexes


def parse_dotted_var(value, var_map):
    list_tokens = re.split('\.', value)

    # first token is the key in var_map
    key = list_tokens[0]
    value = var_map[key]

    for i in range(0, len(list_tokens) - 1):
        # try to get field body if existing
        if 'body' in value:
            value = value['body']
        try:
            # if it's an integer, then get index from list
            list_index = int(list_tokens[i + 1])

            if not isinstance(value, list):
                raise Exception('Trying to access variable ' +
                                str(value) +
                                ' as a list but its type is ' +
                                str(type(value)))

            value = value[list_index]
        except ValueError:
            if not isinstance(value, dict):
                raise Exception('Trying to access variable ' +
                                str(value) +
                                ' as a dict but its type is ' +
                                str(type(value)))
            # if it's not an integer, then it's a string
            value = value[list_tokens[i + 1]]
    return value


def is_accessing_headers(value):
    value = value.replace(' ', '')

    header_keywords = HEADER_SUCCESS_KEYWORDS + HEADER_FAILURE_KEYWORDS

    for header_keyword in header_keywords:
        if "|" + header_keyword.value in value:
            return True

    return False
